PROCESS BEFORE OUTPUT.
  MODULE status_0200.
*
PROCESS AFTER INPUT.
  MODULE exit_0200 AT EXIT-COMMAND.

  MODULE get_ok_code.

  MODULE user_command_0200.

PROCESS ON VALUE-REQUEST.
  FIELD gs_options-visibilitygrp MODULE f4_visibilitygrp.
