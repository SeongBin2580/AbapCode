PROCESS BEFORE OUTPUT.
  MODULE status_0400.
*
PROCESS AFTER INPUT.
  MODULE exit_0400 AT EXIT-COMMAND.

  FIELD gs_s0400-user
       MODULE get_user_group ON REQUEST.

  CHAIN.
    FIELD: gs_s0400-group01,
           gs_s0400-group02,
           gs_s0400-group03,
           gs_s0400-group04,
           gs_s0400-group05,
           gs_s0400-group06,
           gs_s0400-group07,
           gs_s0400-group08,
           gs_s0400-group09,
           gs_s0400-group10,
           gs_s0400-group11,
           gs_s0400-group12.
    MODULE check_usergroup ON CHAIN-REQUEST.
  ENDCHAIN.

  MODULE get_ok_code.

  MODULE user_command_0400.

PROCESS ON VALUE-REQUEST.
  FIELD gs_s0400-user MODULE f4_user.
