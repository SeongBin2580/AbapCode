
PROCESS BEFORE OUTPUT.
  MODULE status_0500.

PROCESS AFTER INPUT.
  MODULE user_command_0500.

PROCESS ON VALUE-REQUEST.
  FIELD ip_aname
  MODULE f4help_vocan_name.

  FIELD ip_sname
  MODULE f4help_service_name.
