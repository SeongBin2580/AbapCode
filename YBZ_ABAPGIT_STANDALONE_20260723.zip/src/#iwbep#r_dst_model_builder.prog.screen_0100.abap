
PROCESS BEFORE OUTPUT.

*----
  MODULE get_memory_parameter.
*--- Set status and exclude some functions
  MODULE status_0100.
*--- Set some functions invisible
  MODULE set_buttons_invisible.

*
PROCESS AFTER INPUT.

* check if model is right now available
  CHAIN.
    FIELD gs_model_screen_100-technical_name.
    MODULE check_technical_name ON CHAIN-REQUEST.
  ENDCHAIN.

  CHAIN.
    FIELD gs_model_screen_100-version.
    MODULE check_version ON CHAIN-REQUEST.
  ENDCHAIN.

  CHAIN.
    FIELD gs_model_screen_100-technical_name.
    FIELD gs_model_screen_100-version.
    MODULE check_model.
  ENDCHAIN.

* check model is locked
  CHAIN.
    FIELD gs_model_screen_100-technical_name.
    FIELD gs_model_screen_100-version.
    MODULE check_model_locked.
  ENDCHAIN.

* Only Exit
  MODULE exit_command_100 AT EXIT-COMMAND.

* FCode Handler
  MODULE user_command_0100.

* And now the POV
PROCESS ON VALUE-REQUEST.
  FIELD gs_model_screen_100-technical_name
  MODULE f4get_model.
