
PROCESS BEFORE OUTPUT.
  MODULE status_0400.

PROCESS AFTER INPUT.
  MODULE user_command_0400.

PROCESS ON VALUE-REQUEST.
  FIELD mv_serv_tech_name
  MODULE f4help_service_name.
