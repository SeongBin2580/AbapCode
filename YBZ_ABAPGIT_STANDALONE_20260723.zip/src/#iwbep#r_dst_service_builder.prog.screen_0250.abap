
PROCESS BEFORE OUTPUT.

  MODULE status_0250.
*
PROCESS AFTER INPUT.

  MODULE user_command_0250_exit AT EXIT-COMMAND.

  CHAIN.
    FIELD gs_screen_250-model_tech_name.
    FIELD gs_screen_250-model_version.
    MODULE check_assignment_250.
  ENDCHAIN.


  MODULE user_command_0250.

* And now the POV
PROCESS ON VALUE-REQUEST.
  FIELD gs_screen_250-model_tech_name
  MODULE f4get_model.
