
PROCESS BEFORE OUTPUT.

  MODULE status_0100.
*
PROCESS AFTER INPUT.

* Check if the service is fine.
  CHAIN.
    FIELD gs_screen_100-technical_name.
    MODULE check_technical_name ON CHAIN-REQUEST.
  ENDCHAIN.

  CHAIN.
    FIELD gs_screen_100-version.
    MODULE check_version ON CHAIN-REQUEST.
  ENDCHAIN.

  CHAIN.
    FIELD gs_screen_100-technical_name.
    FIELD gs_screen_100-version.
    MODULE check_service.
  ENDCHAIN.

* Check the exit commands
  MODULE exit_command_0100 AT EXIT-COMMAND.
* Now the commands
  MODULE user_command_0100.

* And now the POV
PROCESS ON VALUE-REQUEST.
  FIELD gs_screen_100-technical_name
  MODULE f4get_services.
