*&---------------------------------------------------------------------*
*& Report /AIF/CONTENT_DISPLAY
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT /aif/content_display.

SELECTION-SCREEN BEGIN OF BLOCK block1 WITH FRAME TITLE TEXT-tt1.
  PARAMETERS: p_depl TYPE /aif/s4_scenario_id OBLIGATORY.
  PARAMETERS: p_proc TYPE /aif/nrt_config-process NO-DISPLAY. " do not use, only for compatibility with used object
SELECTION-SCREEN END OF BLOCK block1.

INCLUDE /aif/cont_displ_cls_inc.

INITIALIZATION.
  DATA lr_report_control TYPE REF TO /aif/if_icd_report.
  lr_report_control = NEW lcl_report( sy-repid ).
  lr_report_control->auth_check_trans( ).

AT SELECTION-SCREEN ON p_depl.
  lr_report_control->read_selection_screen( ).

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_depl.     " value from internal scenario table

  p_depl = lcl_report=>get_instance( )->value_request_deploy( ). "SAP Note:3203641

START-OF-SELECTION.
**********************************************************************
  " report / program flow is in here
  lr_report_control->main( ).

**********************************************************************
  " dynpro logic is in here
  INCLUDE /aif/content_display_mod.
