"! <p class="shorttext synchronized">EEE - Registry Adapter for EEEC Workbench integration</p>
CLASS /iwxbe/cl_eeec_reg_adapter DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES:
      /iwxbe/if_eeec_reg_adapter_wb,
      /iwxbe/if_eeec_reg_adapter_aff.

  PRIVATE SECTION.
    DATA:
      "! <p class="shorttext synchronized" lang="en">Registry instance</p>
      mo_registry              TYPE REF TO /iwxbe/if_default_reg_cfg_cons,
      "! <p class="shorttext synchronized" lang="en">Registry instance for AFF</p>
      mo_registry_aff          TYPE REF TO /iwxbe/if_def_reg_cfg_cons_aff,
      "! <p class="shorttext synchronized" lang="en">AIF interface adapter</p>
      mo_aif_interface_adapter TYPE REF TO /iwxbe/if_aif_intf_adapter,
      "! <p class="shorttext synchronized" lang="en">System utilites</p>
      mo_system_util           TYPE REF TO /iwxbe/if_system_util.

    ALIASES: convert_from_object_key FOR /iwxbe/if_eeec_reg_adapter_wb~convert_from_object_key,
             convert_to_object_key   FOR /iwxbe/if_eeec_reg_adapter_wb~convert_to_object_key.

    METHODS:

      "! <p class="shorttext synchronized" lang="en">Get AIF interface adapter</p>
      "!
      "! @parameter is_consumer_key          | <p class="shorttext synchronized" lang="en">Consumer Key</p>
      "! @parameter ro_aif_interface_adapter | <p class="shorttext synchronized" lang="en">AIF interface adapter</p>
      get_aif_interface_adapter
        IMPORTING
          is_consumer_key                 TYPE /iwxbe/s_reg_consumer_key
        RETURNING
          VALUE(ro_aif_interface_adapter) TYPE REF TO /iwxbe/if_aif_intf_adapter,

      "! <p class="shorttext synchronized" lang="en">Get registry instance</p>
      "!
      "! @parameter ro_registry | <p class="shorttext synchronized" lang="en">Registry</p>
      get_registry
        RETURNING
          VALUE(ro_registry) TYPE REF TO /iwxbe/if_default_reg_cfg_cons,

      "! <p class="shorttext synchronized" lang="en">Get registry instance for AFF specific content</p>
      "!
      "! @parameter ro_registry | <p class="shorttext synchronized" lang="en">Registry AFF specific</p>
      get_registry_aff
        RETURNING
          VALUE(ro_registry) TYPE REF TO /iwxbe/if_def_reg_cfg_cons_aff,

      "! <p class="shorttext synchronized" lang="en">Get system utilities</p>
      "!
      "! @parameter ro_system_util | <p class="shorttext synchronized" lang="en">System utilities</p>
      get_system_util
        RETURNING
          VALUE(ro_system_util) TYPE REF TO /iwxbe/if_system_util,

      "! <p class="shorttext synchronized" lang="en">Delete AIF Interface</p>
      "!
      "! @parameter is_consumer_key         | <p class="shorttext synchronized" lang="en">Consumer Key</p>
      "! @parameter iv_transport            | <p class="shorttext synchronized" lang="en">Transport</p>
      remove_aif_interface
        IMPORTING
          is_consumer_key TYPE /iwxbe/s_reg_consumer_key
          iv_transport    TYPE trkorr.
ENDCLASS.



CLASS /IWXBE/CL_EEEC_REG_ADAPTER IMPLEMENTATION.


  METHOD /iwxbe/if_eeec_reg_adapter_aff~delete.

    /iwxbe/if_eeec_reg_adapter_wb~delete( iv_object_key      = CONV #( io_aff_object->get_name( ) )
                                          iv_suppress_dialog = abap_true ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_aff~does_exist.

    rv_does_exist = NEW /iwxbe/cl_registry_config_cons( )->does_consumer_exist(
        /iwxbe/if_eeec_reg_adapter_wb~convert_from_object_key( CONV #( io_aff_object->get_name( ) ) ) ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_aff~get_content.

    CONSTANTS: lc_format_version_1 TYPE  /iwxbe/if_aff_eeec_v1=>ty_main-format_version VALUE '1'.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key,
          ls_consumer     TYPE /iwxbe/if_registry_types=>ty_s_consumer.


    ls_consumer_key = convert_from_object_key( io_aff_object->get_name( ) ).

    ls_consumer = get_registry( )->get( iv_id               = ls_consumer_key-id
                                        iv_version          = ls_consumer_key-version
                                        iv_state            = io_settings->get_version( )
                                        iv_language         = io_settings->get_language( )
                                        iv_with_event_types = abap_true
                                        iv_with_text        = abap_true ).

    rs_content = CORRESPONDING #(
                      ls_consumer
                    MAPPING
                      format_version   = DEFAULT lc_format_version_1
                      header           = DEFAULT VALUE #( description           = ls_consumer-description
                                                          original_language     = ls_consumer-language
                                                          abap_language_version = ls_consumer-abap_language_version )
                      consumer_class   = class_name
                      descriptor_class = descriptor_class_name  ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_aff~save_content.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key.


    ls_consumer_key = convert_from_object_key( io_aff_object->get_name( ) ).


    get_registry_aff( )->modify( VALUE #( id                    = ls_consumer_key-id
                                          version               = ls_consumer_key-version
                                          state                 = io_settings->get_version( )
                                          abap_language_version = is_data-header-abap_language_version
                                          class_name            = is_data-consumer_class
                                          descriptor_class_name = is_data-descriptor_class
                                          description           = is_data-header-description
                                          language              = io_settings->get_language( )
                                          changed_by            = io_settings->get_user( )
                                          created_by            = io_settings->get_user( )
                                          event_types           = CORRESPONDING #( is_data-event_types ) ) ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~convert_from_object_key.

    rs_consumer_key = VALUE #( repository_id = /iwxbe/if_registry_types=>gcs_repository_id-default
                               id            = iv_object_key(36)
                               version       = iv_object_key+36(4) ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~convert_to_object_key.

    rv_object_key    = is_consumer_key-id.
    rv_object_key+36 = is_consumer_key-version.

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~delete.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key,
          lv_task         TYPE trkorr.


    ls_consumer_key = convert_from_object_key( iv_object_key ).

    lv_task = iv_transport_request.

    " Delete consumer object
    get_registry( )->delete( EXPORTING
                               iv_id              = ls_consumer_key-id
                               iv_version         = ls_consumer_key-version
                               iv_suppress_dialog = iv_suppress_dialog
                             CHANGING
                               cv_task            = lv_task ).
    " Delete AIF interface
    remove_aif_interface( iv_transport    = lv_task
                          is_consumer_key = ls_consumer_key ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~get_content.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key.


    ls_consumer_key = convert_from_object_key( iv_object_key ).

    rs_consumer = get_registry( )->get( iv_id               = ls_consumer_key-id
                                        iv_version          = ls_consumer_key-version
                                        iv_state            = iv_state
                                        iv_with_event_types = abap_true ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~get_descriptions.

    CONSTANTS:
      lc_sign TYPE string VALUE 'I' ##NO_TEXT,
      lc_eq   TYPE string VALUE 'EQ' ##NO_TEXT.

    DATA:
      lt_range_id      TYPE /iwxbe/if_registry_types=>ty_t_range_id,
      lt_range_version TYPE /iwxbe/if_registry_types=>ty_t_range_version,
      lt_consumer      TYPE /iwxbe/if_registry_types=>ty_t_consumer,
      lv_object_key    TYPE sobj_name,
      ls_consumer_key  TYPE /iwxbe/s_reg_consumer_key.


    IF it_object_keys IS INITIAL.
      RETURN.
    ENDIF.

    " Transform incoming consumer object keys to ranges (id/version)
    LOOP AT it_object_keys ASSIGNING FIELD-SYMBOL(<ls_object_key>).
      ls_consumer_key = convert_from_object_key( <ls_object_key> ).
      INSERT VALUE #( sign = lc_sign option = lc_eq low = ls_consumer_key-id ) INTO TABLE lt_range_id.
      INSERT VALUE #( sign = lc_sign option = lc_eq low = ls_consumer_key-version ) INTO TABLE lt_range_version.
    ENDLOOP.

    " Standard table and hence duplicates might occur in range tables
    SORT lt_range_id BY low.
    DELETE ADJACENT DUPLICATES FROM lt_range_id.
    SORT lt_range_version BY low.
    DELETE ADJACENT DUPLICATES FROM lt_range_version.

    " Retrieve the consumer depending on the ranges
    lt_consumer = get_registry( )->get_all( it_range_id      = lt_range_id
                                            it_range_version = lt_range_version
                                            iv_language      = iv_language ).

    " Merge consumer result into object key based text table
    LOOP AT lt_consumer ASSIGNING FIELD-SYMBOL(<ls_consumer>).
      lv_object_key = convert_to_object_key( VALUE #( id      = <ls_consumer>-id
                                                      version = <ls_consumer>-version ) ).

      " Double check if consumer is really requested.
      " Larger consumer result set due to ranges
      IF line_exists( it_object_keys[ table_line = lv_object_key ] ).
        INSERT VALUE #( name        = lv_object_key
                        language    = <ls_consumer>-language
                        description = <ls_consumer>-description ) INTO TABLE rt_consumer_description.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~get_metadata.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key.


    ls_consumer_key = convert_from_object_key( iv_object_key ).

    rs_consumer = get_registry( )->get( iv_id        = ls_consumer_key-id
                                        iv_version   = ls_consumer_key-version
                                        iv_state     = iv_state
                                        iv_with_text = abap_true ).

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~save_content.

    DATA: ls_consumer_key TYPE /iwxbe/s_reg_consumer_key,
          ls_object_data  TYPE /iwxbe/cl_eeec_object_data=>ty_object_data.


    io_object_data->get_selected_data( EXPORTING p_data_selection = if_wb_object_data_selection_co=>c_all_data
                                       IMPORTING p_data           = ls_object_data ).


    ls_consumer_key = convert_from_object_key( io_object_data->get_object_key( ) ).

    CASE iv_access_mode.
      WHEN swbm_c_op_activate.

        get_registry( )->activate( iv_id              = ls_consumer_key-id
                                   iv_version         = ls_consumer_key-version
                                   iv_suppress_dialog = abap_true ).

      WHEN swbm_c_op_insert.

        """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        " Insertion is not yet possible due to tadir name (40) and consumer key conversion.
        " This is not considered while creating the event consumption model in ADT
        """"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


      WHEN swbm_c_op_modify.

        get_registry( )->update( iv_id                    = ls_consumer_key-id
                                 iv_version               = ls_consumer_key-version
                                 iv_state                 = io_object_data->get_version( )
                                 iv_class_name            = ls_object_data-content-consumer_class
                                 iv_descriptor_class_name = ls_object_data-content-descriptor_class
                                 it_event_type            = CORRESPONDING #( ls_object_data-content-event_types )
                                 iv_suppress_dialog       = abap_true ).

    ENDCASE.

  ENDMETHOD.


  METHOD /iwxbe/if_eeec_reg_adapter_wb~save_metadata.

    DATA:
      ls_consumer_key TYPE /iwxbe/s_reg_consumer_key,
      ls_object_data  TYPE /iwxbe/cl_eeec_object_data=>ty_object_data.


    " Only modify of properties MUST be considered
    IF iv_access_mode <> swbm_c_op_modify.
      RETURN.
    ENDIF.

    io_object_data->get_selected_data( EXPORTING p_data_selection = if_wb_object_data_selection_co=>c_properties
                                       IMPORTING p_data           = ls_object_data-metadata ).


    ls_consumer_key = convert_from_object_key( CONV #( ls_object_data-metadata-name ) ).


    get_registry( )->update(
        iv_id                    = ls_consumer_key-id
        iv_version               = ls_consumer_key-version
        iv_state                 = cl_blue_wb_utility=>get_version_token( ls_object_data-metadata-version )
        iv_description           = CONV #( ls_object_data-metadata-description )
        iv_language              = iv_language
        iv_abap_language_version = ls_object_data-metadata-abap_langu_version
        iv_suppress_dialog       = abap_true ).

  ENDMETHOD.


  METHOD get_aif_interface_adapter.

    IF mo_aif_interface_adapter IS NOT BOUND.
      mo_aif_interface_adapter = NEW /iwxbe/cl_aif_intf_adapter( is_consumer_key ).
    ENDIF.
    ro_aif_interface_adapter = mo_aif_interface_adapter.

  ENDMETHOD.


  METHOD get_registry.

    IF mo_registry IS NOT BOUND.
      mo_registry ?= NEW /iwxbe/cl_registry_config_cons( ).
    ENDIF.

    ro_registry = mo_registry.

  ENDMETHOD.


  METHOD get_registry_aff.

    IF mo_registry_aff IS NOT BOUND.
      mo_registry_aff ?= NEW /iwxbe/cl_registry_config_cons( ).
    ENDIF.

    ro_registry = mo_registry_aff.

  ENDMETHOD.


  METHOD get_system_util.

    IF mo_system_util IS NOT BOUND.
      mo_system_util = /iwxbe/cl_system_util=>create( ).
    ENDIF.

    ro_system_util = mo_system_util.

  ENDMETHOD.


  METHOD remove_aif_interface.

    DATA: lo_aif_interface_adapter TYPE REF TO /iwxbe/if_aif_intf_adapter.


    IF get_system_util( )->is_sap_cloud_platform_enabled( ) = abap_false.
      RETURN.
    ENDIF.

    lo_aif_interface_adapter = get_aif_interface_adapter( is_consumer_key ).
    TRY.
        IF lo_aif_interface_adapter->does_exist( ).
          lo_aif_interface_adapter->delete( iv_transport ).
        ENDIF.
      CATCH /iwxbe/cx_aif INTO DATA(lx_error).
        /iwxbe/cl_logger=>log_exception( lx_error ).
    ENDTRY.

  ENDMETHOD.
ENDCLASS.
