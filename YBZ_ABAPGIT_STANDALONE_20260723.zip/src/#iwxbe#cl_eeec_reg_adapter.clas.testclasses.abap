CLASS ltc_registry_adapter DEFINITION FINAL FOR TESTING
  DURATION SHORT
  RISK LEVEL HARMLESS.

  PRIVATE SECTION.
    CONSTANTS:
      BEGIN OF gcs_test_data,
        id                    TYPE /iwxbe/reg_id      VALUE 'CONSUMERID',
        version               TYPE /iwxbe/reg_version VALUE '0001',
        state                 TYPE r3state            VALUE /iwxbe/if_registry_types=>gcs_object_state-active,
        class_name            TYPE seoclsname         VALUE '/IWXBE/CL_TEST_CONSUMER',
        descriptor_class_name TYPE seoclsname         VALUE '/IWXBE/CL_TEST_EVENT_DESCRIP',
        description           TYPE ddtext             VALUE 'Test Description' ##no_text,
        description_2         TYPE ddtext             VALUE 'Test Description Spanish' ##no_text,
        object_key            TYPE seu_objkey         VALUE `CONSUMERID                          0001`,
        object_key_2          TYPE seu_objkey         VALUE `CONSUMERID                          0002`,
      END OF gcs_test_data.

    DATA:
      mo_cut TYPE REF TO /iwxbe/cl_eeec_reg_adapter.

    METHODS: setup,
      convert_from
        FOR TESTING RAISING cx_static_check,
      convert_to
        FOR TESTING RAISING cx_static_check,
      delete
        FOR TESTING RAISING cx_static_check,
      get_descriptions
        FOR TESTING RAISING cx_static_check,
      get_descriptions_initial_keys
        FOR TESTING RAISING cx_static_check,
      get_content
        FOR TESTING RAISING cx_static_check,
      get_metadata
        FOR TESTING RAISING cx_static_check,
      get_registry
        FOR TESTING RAISING cx_static_check,
      save_content
        FOR TESTING RAISING cx_static_check,
      save_metadata
        FOR TESTING RAISING cx_static_check,
      save_metadata_for_insert
        FOR TESTING RAISING cx_static_check,

      get_expected_event_types
        RETURNING
          VALUE(rt_event_type) TYPE /iwxbe/if_registry_types=>ty_t_event_type.
ENDCLASS.

CLASS /iwxbe/cl_eeec_reg_adapter DEFINITION LOCAL FRIENDS ltc_registry_adapter.

CLASS ltc_registry_adapter IMPLEMENTATION.

  METHOD convert_from.

    " Given is an object key
    " When convert_from is called
    " Then the following consumer key is expected
    cl_abap_unit_assert=>assert_equals(
      act = mo_cut->/iwxbe/if_eeec_reg_adapter_wb~convert_from_object_key( gcs_test_data-object_key )
      exp = VALUE /iwxbe/s_reg_consumer_key( repository_id = /iwxbe/if_registry_types=>gcs_repository_id-default
                                             id            = gcs_test_data-id
                                             version       = gcs_test_data-version ) ).

  ENDMETHOD.


  METHOD convert_to.

    " Given is a consumer key
    DATA(ls_consumer_key) = VALUE /iwxbe/s_reg_consumer_key( id      = gcs_test_data-id
                                                             version = gcs_test_data-version ).
    " When convert_to_object_key is called
    " Then the following object key is expected
    cl_abap_unit_assert=>assert_equals(
      exp = gcs_test_data-object_key
      act = mo_cut->/iwxbe/if_eeec_reg_adapter_wb~convert_to_object_key( ls_consumer_key ) ).

  ENDMETHOD.


  METHOD delete.

    " with a consumer to be deleted
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->ignore_parameter( 'CV_TASK'
       )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->delete( iv_id              = gcs_test_data-id
                                 iv_version         = gcs_test_data-version
                                 iv_suppress_dialog = abap_true ).
    " and an system util double
    cl_abap_testdouble=>configure_call( mo_cut->mo_system_util )->returning( abap_true
                                                               )->and_expect(
                                                               )->is_called_once( ).
    mo_cut->mo_system_util->is_sap_cloud_platform_enabled( ).

    " and an aif deletion double
    cl_abap_testdouble=>configure_call( mo_cut->mo_aif_interface_adapter )->returning( abap_true
                                                                         )->and_expect(
                                                                         )->is_called_once( ).
    mo_cut->mo_aif_interface_adapter->does_exist( ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_aif_interface_adapter )->ignore_parameter( 'IV_TRANSPORT_TASK'
                                                                         )->and_expect(
                                                                         )->is_called_once( ).
    mo_cut->mo_aif_interface_adapter->delete( VALUE #( ) ).

    " When get_content is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_wb~delete( iv_object_key      = gcs_test_data-object_key
                                                  iv_suppress_dialog = abap_true ).


    " Then the consumer must be deleted
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).
    " and the aif interface is deleted
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_aif_interface_adapter ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_system_util ).

  ENDMETHOD.


  METHOD get_content.

    DATA: ls_act_consumer TYPE /iwxbe/if_registry_types=>ty_s_consumer,
          ls_exp_consumer TYPE /iwxbe/if_registry_types=>ty_s_consumer,
          lv_changed_ts   TYPE tzntstmps.


    " with a registered consumer
    ls_exp_consumer = VALUE #( id         = gcs_test_data-id
                               version    = gcs_test_data-version
                               state      = gcs_test_data-state
                               changed_ts = lv_changed_ts ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->returning( ls_exp_consumer )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->get( iv_id               = gcs_test_data-id
                              iv_version          = gcs_test_data-version
                              iv_state            = gcs_test_data-state
                              iv_with_event_types = abap_true ).

    " When get_content is called
    ls_act_consumer = mo_cut->/iwxbe/if_eeec_reg_adapter_wb~get_content( iv_object_key = gcs_test_data-object_key
                                                                         iv_state      = gcs_test_data-state ).

    " Then the object_model must contain the following consumer
    cl_abap_unit_assert=>assert_equals( exp = ls_exp_consumer act = ls_act_consumer ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD get_descriptions.

    DATA: lt_act_consumer_description TYPE if_wb_object_persist=>tt_texts,
          lt_object_keys              TYPE if_wb_object_persist=>tt_objkeys,
          lt_exp_consumer             TYPE /iwxbe/if_registry_types=>ty_t_consumer.


    " which will be called for get_all with the given keys
    lt_exp_consumer = VALUE #( id = gcs_test_data-id
                               ( version     = gcs_test_data-version
                                 language    = sy-langu
                                 description = gcs_test_data-description )
                               ( version     = 2
                                 language    = 'S'
                                 description = gcs_test_data-description_2 ) ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->returning( lt_exp_consumer )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->get_all( it_range_id      = VALUE #( ( sign = 'I' option = 'EQ' low = gcs_test_data-id ) )
                                  it_range_version = VALUE #( sign   = 'I'
                                                              option = 'EQ'
                                                              ( low = gcs_test_data-version )
                                                              ( low = '2' ) )
                                  iv_language      = 'S' ).

    " for the following consumer object keys
    lt_object_keys = VALUE #( ( gcs_test_data-object_key )
                              ( gcs_test_data-object_key_2 ) ).


    " When save_metadata is called
    lt_act_consumer_description = mo_cut->/iwxbe/if_eeec_reg_adapter_wb~get_descriptions( it_object_keys = lt_object_keys
                                                                                          iv_language    = 'S' ).

    " Then
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).
    cl_abap_unit_assert=>assert_equals( act = lt_act_consumer_description
                                        exp = VALUE if_wb_object_persist=>tt_texts(
                                                        ( name        = gcs_test_data-object_key
                                                          language    = sy-langu
                                                          description = gcs_test_data-description )
                                                        ( name        = gcs_test_data-object_key_2
                                                          language    = 'S' " spanish
                                                          description = gcs_test_data-description_2 ) ) ).

  ENDMETHOD.


  METHOD get_descriptions_initial_keys.

    " Given is nothing
    " When get_descriptions is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_wb~get_descriptions( VALUE #( ) ).

  ENDMETHOD.


  METHOD get_metadata.

    DATA: ls_act_consumer TYPE /iwxbe/if_registry_types=>ty_s_consumer,
          ls_exp_consumer TYPE /iwxbe/if_registry_types=>ty_s_consumer,
          lv_changed_ts   TYPE tzntstmps.


    " with a registered consumer
    ls_exp_consumer = VALUE #( id         = gcs_test_data-id
                               version    = gcs_test_data-version
                               state      = gcs_test_data-state
                               changed_ts = lv_changed_ts ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->returning( ls_exp_consumer )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->get( iv_id        = gcs_test_data-id
                              iv_version   = gcs_test_data-version
                              iv_state     = gcs_test_data-state
                              iv_with_text = abap_true ).

    " When get_content is called
    ls_act_consumer = mo_cut->/iwxbe/if_eeec_reg_adapter_wb~get_metadata( iv_object_key = gcs_test_data-object_key
                                                                          iv_state      = gcs_test_data-state ).

    " Then the following must contain the following consumer
    cl_abap_unit_assert=>assert_equals( exp = ls_exp_consumer act = ls_act_consumer ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD save_content.

    DATA:
      lo_object_data TYPE REF TO if_wb_object_data_model,
      ls_object_data TYPE /iwxbe/cl_eeec_object_data=>ty_object_data.


    " Given is a WB object data for EEEC
    lo_object_data ?= NEW /iwxbe/cl_eeec_object_data( ).

    " with the appropriate content data
    ls_object_data-metadata = VALUE #( name    = gcs_test_data-object_key
                                       version = 'active' ).
    ls_object_data-content  = VALUE #( consumer_class   = gcs_test_data-class_name
                                       descriptor_class = gcs_test_data-descriptor_class_name
                                       event_types      = CORRESPONDING #( get_expected_event_types( ) ) ).
    lo_object_data->set_selected_data( p_data_selection = if_wb_object_data_selection_co=>c_all_data
                                       p_data           = ls_object_data ).

    " and the registry double will be prepared for an update call
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->update( iv_id                    = gcs_test_data-id
                                 iv_version               = gcs_test_data-version
                                 iv_state                 = gcs_test_data-state
                                 iv_class_name            = gcs_test_data-class_name
                                 iv_descriptor_class_name = gcs_test_data-descriptor_class_name
                                 it_event_type            = get_expected_event_types( )
                                 iv_suppress_dialog       = abap_true ).

    " When save_content is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_wb~save_content( lo_object_data ).

    " Then
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD get_registry.

    " Given is no registry
    CLEAR mo_cut->mo_registry.

    " When get_registry is called
    " Then the following registry instance is expected
    cl_abap_unit_assert=>assert_true( xsdbool( mo_cut->get_registry( ) IS INSTANCE OF /iwxbe/cl_registry_config_cons ) ).

  ENDMETHOD.


  METHOD save_metadata.

    DATA:
      lo_object_data TYPE REF TO if_wb_object_data_model,
      ls_object_data TYPE /iwxbe/cl_eeec_object_data=>ty_object_data.


    " Given is a WB object data for EEEC
    lo_object_data ?= NEW /iwxbe/cl_eeec_object_data( ).

    " with the appropriate metadata data
    ls_object_data-metadata = VALUE #(
        name               = gcs_test_data-object_key
        version            = 'active'
        description        = gcs_test_data-description
        language           = sy-langu
        abap_langu_version = if_aff_types_v1=>co_abap_language_version-cloud_development ).

    lo_object_data->set_selected_data( p_data_selection = if_wb_object_data_selection_co=>c_properties
                                       p_data           = ls_object_data-metadata ).

    " and the registry double will be prepared for an update call
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->update( iv_id                    = gcs_test_data-id
                                 iv_version               = gcs_test_data-version
                                 iv_state                 = gcs_test_data-state
                                 iv_description           = gcs_test_data-description
                                 iv_language              = sy-langu
                                 iv_abap_language_version = if_aff_types_v1=>co_abap_language_version-cloud_development
                                 iv_suppress_dialog       = abap_true ).


    " When save_metadata is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_wb~save_metadata( lo_object_data ).

    " Then
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD save_metadata_for_insert.

    DATA:
      lo_object_data TYPE REF TO if_wb_object_data_model ##needed.


    " and the registry double will be prepared for an update call
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->and_expect( )->is_never_called( ).
    mo_cut->mo_registry->update( iv_id      = gcs_test_data-id
                                 iv_version = gcs_test_data-version ).

    " When save_metadata is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_wb~save_metadata( io_object_data = lo_object_data
                                                         iv_access_mode = swbm_c_op_insert ).

    " Then
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD setup.

    mo_cut = NEW #( ).

    " Given is a double registry
    mo_cut->mo_registry              ?= cl_abap_testdouble=>create( '/iwxbe/if_default_reg_cfg_cons' ).
    mo_cut->mo_aif_interface_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_aif_intf_adapter' ).
    mo_cut->mo_system_util           ?= cl_abap_testdouble=>create( '/iwxbe/if_system_util' ).

  ENDMETHOD.


  METHOD get_expected_event_types.

    rt_event_type = VALUE #( ( type = 'sap.s4.beh.SalesOrder.Created.v1' entity_name = 'Z_A_SO_Created' )
                             ( type = 'sap.s4.beh.SalesOrder.Deleted.v1' entity_name = 'Z_A_SO_Deleted' ) ).

  ENDMETHOD.

ENDCLASS.



CLASS ltcl_eeec_reg_adapter_aff DEFINITION FINAL FOR TESTING
  DURATION SHORT
  RISK LEVEL HARMLESS.

  PRIVATE SECTION.
    CONSTANTS:
      BEGIN OF gcs_test_data,
        state                 TYPE r3state            VALUE /iwxbe/if_registry_types=>gcs_object_state-active,
        abap_language_version TYPE abap_language_version  VALUE if_abap_language_version=>gc_version-sap_cloud_platform,
        consumer_name         TYPE /iwxbe/consumer_name     VALUE `DUMMYCONS                           0001`,
        description           TYPE ddtext VALUE 'Dummy',
        descriptor_class      TYPE seoclsname  VALUE 'CL_Descriptor',
        consumer_class        TYPE seoclsname  VALUE 'CL_Consumer',
        language              TYPE  spras  VALUE 'E',
        BEGIN OF event_type,
          type        TYPE  /iwxbe/reg_event_type  VALUE 'eee.s4.test',
          entity_name TYPE /iwxbe/reg_entity_name  VALUE 'Dummy Event',
        END OF event_type,

        BEGIN OF consumer_key,
          id            TYPE /iwxbe/reg_id            VALUE `DUMMYCONS`,
          version       TYPE /iwxbe/reg_version       VALUE `0001`,
          repository_id TYPE /iwxbe/reg_repository_id VALUE `DEFAULT`,
        END OF consumer_key,
      END OF gcs_test_data.

    DATA:
      mo_cut                 TYPE REF TO /iwxbe/cl_eeec_reg_adapter,
      mo_consumer_repository TYPE REF TO /iwxbe/if_consumer_repository.

    METHODS:
      setup,
      teardown,
      consumer_exist          FOR TESTING RAISING cx_static_check,
      consumer_does_not_exist FOR TESTING RAISING cx_static_check,
      consumer_exist_failure  FOR TESTING RAISING cx_static_check,
      delete                  FOR TESTING RAISING cx_static_check,
      get_content             FOR TESTING RAISING cx_static_check,
      get_registry_aff        FOR TESTING RAISING cx_static_check,
      save_content            FOR TESTING RAISING cx_static_check,
      get_expected_event_types
        RETURNING
          VALUE(rt_event_type) TYPE /iwxbe/if_aff_eeec_v1=>ty_t_event_type.

ENDCLASS.

CLASS /iwxbe/cl_eeec_reg_adapter DEFINITION LOCAL FRIENDS ltcl_eeec_reg_adapter_aff.

CLASS ltcl_eeec_reg_adapter_aff IMPLEMENTATION.

  METHOD setup.

    mo_cut = NEW #( ).

    " Given is a double registry
    mo_cut->mo_registry              ?= cl_abap_testdouble=>create( '/iwxbe/if_default_reg_cfg_cons' ).
    mo_cut->mo_registry_aff          ?= cl_abap_testdouble=>create( '/iwxbe/if_def_reg_cfg_cons_aff' ).
    mo_cut->mo_aif_interface_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_aif_intf_adapter' ).
    mo_cut->mo_system_util           ?= cl_abap_testdouble=>create( '/iwxbe/if_system_util' ).
    " and a consumer repository double
    mo_consumer_repository ?= cl_abap_testdouble=>create( '/iwxbe/if_consumer_repository' ).

  ENDMETHOD.


  METHOD teardown.

    /iwxbe/cl_unit_test_util=>purge_consumer_repository( ).

  ENDMETHOD.


  METHOD consumer_does_not_exist.

    DATA: lo_consumer_object TYPE REF TO if_aff_obj,
          lv_consumer_name   TYPE if_aff_obj=>obj_name.


    " Given is a consumer
    lv_consumer_name = gcs_test_data-consumer_name.

    " Given is a consumer object double
    lo_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_consumer_object )->returning( lv_consumer_name )->and_expect( )->is_called_once( ).
    lo_consumer_object->get_name( ).
    " and a consumer repository double which returns, that any consumer exists
    /iwxbe/cl_unit_test_util=>inject_consumer_repository(
      iv_repository_id     = gcs_test_data-consumer_key-repository_id
      io_repository_double = mo_consumer_repository ).
    cl_abap_testdouble=>configure_call( mo_consumer_repository )->returning( abap_false
                                                               )->and_expect( )->is_called_once( ).
    mo_consumer_repository->does_consumer_exist( iv_consumer_id      = gcs_test_data-consumer_key-id
                                                 iv_consumer_version = gcs_test_data-consumer_key-version ).
    " When does_exist is called
    " Then it returns false
    cl_abap_unit_assert=>assert_false( mo_cut->/iwxbe/if_eeec_reg_adapter_aff~does_exist( lo_consumer_object ) ).
    cl_abap_testdouble=>verify_expectations( lo_consumer_object ).
    cl_abap_testdouble=>verify_expectations( mo_consumer_repository ).

  ENDMETHOD.


  METHOD consumer_exist.

    DATA: lo_consumer_object TYPE REF TO if_aff_obj,
          lv_consumer_name   TYPE if_aff_obj=>obj_name.


    " Given is a consumer
    lv_consumer_name = gcs_test_data-consumer_name.

    " Given is a consumer object double
    lo_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_consumer_object )->returning( lv_consumer_name )->and_expect( )->is_called_once( ).
    lo_consumer_object->get_name( ).
    " and a consumer repository double which returns, that any consumer exists
    /iwxbe/cl_unit_test_util=>inject_consumer_repository(
      iv_repository_id     = gcs_test_data-consumer_key-repository_id
      io_repository_double = mo_consumer_repository ).
    cl_abap_testdouble=>configure_call( mo_consumer_repository )->returning( abap_true
                                                               )->and_expect( )->is_called_once( ).
    mo_consumer_repository->does_consumer_exist( iv_consumer_id      = gcs_test_data-consumer_key-id
                                                 iv_consumer_version = gcs_test_data-consumer_key-version ).
    " When does_exist is called
    " Then it returns true
    cl_abap_unit_assert=>assert_true( mo_cut->/iwxbe/if_eeec_reg_adapter_aff~does_exist( lo_consumer_object ) ).
    cl_abap_testdouble=>verify_expectations( lo_consumer_object ).
    cl_abap_testdouble=>verify_expectations( mo_consumer_repository ).

  ENDMETHOD.


  METHOD consumer_exist_failure.

    DATA: lo_consumer_object TYPE REF TO if_aff_obj,
          lv_consumer_name   TYPE if_aff_obj=>obj_name.


    " Given is a consumer
    lv_consumer_name = gcs_test_data-consumer_name.

    " Given is a consumer object double
    lo_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_consumer_object )->returning( lv_consumer_name )->and_expect( )->is_called_once( ).
    lo_consumer_object->get_name( ).
    " and a consumer repository double which returns, that any consumer exists
    /iwxbe/cl_unit_test_util=>inject_consumer_repository(
      iv_repository_id     = gcs_test_data-consumer_key-repository_id
      io_repository_double = mo_consumer_repository ).
    cl_abap_testdouble=>configure_call( mo_consumer_repository )->raise_exception( NEW /iwxbe/cx_registry( )
                                                               )->and_expect( )->is_called_once( ).
    mo_consumer_repository->does_consumer_exist( iv_consumer_id      = gcs_test_data-consumer_key-id
                                                 iv_consumer_version = gcs_test_data-consumer_key-version ).
    " When does_exist is called and an exception is thrown
    " Then it returns false
    cl_abap_unit_assert=>assert_false( mo_cut->/iwxbe/if_eeec_reg_adapter_aff~does_exist( lo_consumer_object ) ).
    cl_abap_testdouble=>verify_expectations( lo_consumer_object ).
    cl_abap_testdouble=>verify_expectations( mo_consumer_repository ).

  ENDMETHOD.


  METHOD delete.

    DATA: lo_consumer_object TYPE REF TO if_aff_obj,
          lv_consumer_name   TYPE if_aff_obj=>obj_name.


    " Given is a consumer
    lv_consumer_name = gcs_test_data-consumer_name.

    " Given is a consumer object double
    lo_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_consumer_object )->returning( lv_consumer_name )->and_expect( )->is_called_once( ).
    lo_consumer_object->get_name( ).

    " with a consumer to be deleted
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->ignore_parameter( 'CV_TASK'
       )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->delete( iv_id              = gcs_test_data-consumer_key-id
                                 iv_version         = gcs_test_data-consumer_key-version
                                 iv_suppress_dialog = abap_true ).
    " and an system util double
    cl_abap_testdouble=>configure_call( mo_cut->mo_system_util )->returning( abap_true
                                                               )->and_expect(
                                                               )->is_called_once( ).
    mo_cut->mo_system_util->is_sap_cloud_platform_enabled( ).

    " and an aif deletion double
    cl_abap_testdouble=>configure_call( mo_cut->mo_aif_interface_adapter )->returning( abap_true
                                                                         )->and_expect(
                                                                         )->is_called_once( ).
    mo_cut->mo_aif_interface_adapter->does_exist( ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_aif_interface_adapter )->ignore_parameter( 'IV_TRANSPORT_TASK'
                                                                         )->and_expect(
                                                                         )->is_called_once( ).
    mo_cut->mo_aif_interface_adapter->delete( VALUE #( ) ).

    " When get_content is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_aff~delete( lo_consumer_object ).


    " Then the consumer must be deleted
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).
    " and the aif interface is deleted
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_aif_interface_adapter ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_system_util ).
    cl_abap_testdouble=>verify_expectations( lo_consumer_object ).

  ENDMETHOD.


  METHOD get_content.

    DATA:
      ls_consumer            TYPE /iwxbe/if_registry_types=>ty_s_consumer,
      lo_aff_consumer_object TYPE REF TO if_aff_obj,
      lo_aff_settings        TYPE REF TO if_aff_settings_serialize,
      ls_act_content         TYPE /iwxbe/if_aff_eeec_v1=>ty_main.

    " Given is a consumer object double
    lo_aff_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_aff_consumer_object )->returning( gcs_test_data-consumer_name )->and_expect( )->is_called_once( ).
    lo_aff_consumer_object->get_name( ).

    " and a setting
    lo_aff_settings ?= cl_abap_testdouble=>create( 'if_aff_settings_serialize' ).
    cl_abap_testdouble=>configure_call( lo_aff_settings )->returning( gcs_test_data-state )->and_expect( )->is_called_once( ).
    lo_aff_settings->get_version( ).
    cl_abap_testdouble=>configure_call( lo_aff_settings )->returning( gcs_test_data-language )->and_expect( )->is_called_once( ).
    lo_aff_settings->get_language( ).


    " and a registered consumer
    ls_consumer = VALUE #( id                    = gcs_test_data-consumer_key-id
                           version               = gcs_test_data-consumer_key-version
                           state                 = gcs_test_data-state
                           abap_language_version = gcs_test_data-abap_language_version
                           description           = gcs_test_data-description
                           descriptor_class_name = gcs_test_data-descriptor_class
                           event_types           = CORRESPONDING #( get_expected_event_types( ) )
                           language              = gcs_test_data-language
                           class_name            = gcs_test_data-consumer_class ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry )->returning( ls_consumer )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry->get( iv_id               = gcs_test_data-consumer_key-id
                              iv_version          = gcs_test_data-consumer_key-version
                              iv_state            = gcs_test_data-state
                              iv_language         = gcs_test_data-language
                              iv_with_event_types = abap_true
                              iv_with_text        = abap_true ).

    " When get_content is called
    ls_act_content = mo_cut->/iwxbe/if_eeec_reg_adapter_aff~get_content( io_aff_object = lo_aff_consumer_object
                                                                         io_settings   = lo_aff_settings ).

    " Then the following data is expected
    cl_abap_unit_assert=>assert_equals(
      exp = VALUE /iwxbe/if_aff_eeec_v1=>ty_main(
                      format_version   = '1'
                      header           = VALUE #(
                          abap_language_version = if_abap_language_version=>gc_version-sap_cloud_platform
                          description           = gcs_test_data-description
                          original_language     = gcs_test_data-language )
                      consumer_class   = gcs_test_data-consumer_class
                      descriptor_class = gcs_test_data-descriptor_class
                      event_types      = get_expected_event_types( ) )
      act = ls_act_content ).
    " and the double must be verified
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.

  METHOD save_content.

    DATA:
      lo_aff_consumer_object TYPE REF TO if_aff_obj,
      lo_aff_settings        TYPE REF TO if_aff_settings_deserialize,
      ls_exp_content         TYPE /iwxbe/if_aff_eeec_v1=>ty_main.


    " Given is a consumer object double
    lo_aff_consumer_object ?= cl_abap_testdouble=>create( 'if_aff_obj' ).
    cl_abap_testdouble=>configure_call( lo_aff_consumer_object )->returning( gcs_test_data-consumer_name )->and_expect( )->is_called_once( ).
    lo_aff_consumer_object->get_name( ).

    " and a setting
    lo_aff_settings ?= cl_abap_testdouble=>create( 'if_aff_settings_deserialize' ).
    cl_abap_testdouble=>configure_call( lo_aff_settings )->returning( gcs_test_data-state )->and_expect( )->is_called_once( ).
    lo_aff_settings->get_version( ).
    cl_abap_testdouble=>configure_call( lo_aff_settings )->returning( gcs_test_data-language )->and_expect( )->is_called_once( ).
    lo_aff_settings->get_language( ).

    " with the appropriate content data
    ls_exp_content  = VALUE #( header           = VALUE #( abap_language_version = gcs_test_data-abap_language_version
                                                           description           = gcs_test_data-description
                                                           original_language     = gcs_test_data-language )
                               consumer_class   = gcs_test_data-consumer_class
                               descriptor_class = gcs_test_data-descriptor_class
                               event_types      = get_expected_event_types( ) ).

    " and the registry double will be prepared for an update call
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry_aff )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry_aff->modify( VALUE #(
        id                    = gcs_test_data-consumer_key-id
        version               = gcs_test_data-consumer_key-version
        state                 = gcs_test_data-state
        class_name            = gcs_test_data-consumer_class
        descriptor_class_name = gcs_test_data-descriptor_class
        abap_language_version = gcs_test_data-abap_language_version
        language              = gcs_test_data-language
        description           = gcs_test_data-description
        event_types           = CORRESPONDING #( get_expected_event_types( ) ) ) ).

    " When save_content is called
    mo_cut->/iwxbe/if_eeec_reg_adapter_aff~save_content(
      is_data       = ls_exp_content
      io_aff_object = lo_aff_consumer_object
      io_settings   = lo_aff_settings ).

    " Then
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry ).

  ENDMETHOD.


  METHOD get_expected_event_types.
    rt_event_type = VALUE #( ( type = gcs_test_data-event_type-type
                               entity_name = gcs_test_data-event_type-entity_name ) ).
  ENDMETHOD.

  METHOD get_registry_aff.

    " Given is no registry
    CLEAR mo_cut->mo_registry_aff.

    " When get_registry is called
    " Then the following registry instance is expected
    cl_abap_unit_assert=>assert_true( xsdbool( mo_cut->get_registry_aff( ) IS INSTANCE OF /iwxbe/cl_registry_config_cons ) ).

  ENDMETHOD.

ENDCLASS.
