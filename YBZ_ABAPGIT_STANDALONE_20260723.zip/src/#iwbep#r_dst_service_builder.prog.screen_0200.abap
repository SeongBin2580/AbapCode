
PROCESS BEFORE OUTPUT.

  MODULE status_0200.
*--- Set some fields read only
  MODULE set_display_mode.
*--- Disable button for assign Model if model is assigned
  MODULE disable_model_function.
*--- get model
  MODULE get_model_information.
*--- map screen values
  MODULE set_200_values.


PROCESS AFTER INPUT.

* Check if all fields are filled
  CHAIN.
    FIELD:gs_screen_100-class_name
         ,gs_screen_100-description.
    MODULE check_input_fields.
  ENDCHAIN.

* Check Class
  CHAIN.
    FIELD gs_screen_100-class_name.
    MODULE check_class_exist.
  ENDCHAIN.

  MODULE exit_command_0200 AT EXIT-COMMAND.

  MODULE user_command_0200.

PROCESS ON VALUE-REQUEST.
* Search help for the Classes
  FIELD gs_screen_100-class_name MODULE f4_class_name.

  FIELD gs_screen_100-bo_type MODULE f4_bo_type.
