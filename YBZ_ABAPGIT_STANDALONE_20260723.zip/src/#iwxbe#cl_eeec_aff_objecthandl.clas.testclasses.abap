CLASS ltc_eeec_aff_objecthandler DEFINITION FINAL FOR TESTING
  DURATION SHORT
  RISK LEVEL HARMLESS.

  PRIVATE SECTION.
    DATA:
      mo_cut             TYPE REF TO /iwxbe/cl_eeec_aff_objecthandl,
      mo_eeec_aff_object TYPE REF TO cl_aff_obj.

    METHODS: setup,
      delete_object             FOR TESTING RAISING cx_static_check,
      delete_object_not_working FOR TESTING RAISING cx_static_check,
      does_exist                FOR TESTING RAISING cx_static_check,
      does_not_exist            FOR TESTING RAISING cx_static_check,
      get_file_handlers         FOR TESTING RAISING cx_static_check,
      get_registry_adapter      FOR TESTING RAISING cx_static_check.
ENDCLASS.

CLASS /iwxbe/cl_eeec_aff_objecthandl DEFINITION LOCAL FRIENDS ltc_eeec_aff_objecthandler.

CLASS ltc_eeec_aff_objecthandler IMPLEMENTATION.

  METHOD does_exist.

    " Given is a EEEC AFF object
    " and AFF registry adapter which is aware of the consumer
    mo_cut->mo_registry_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_eeec_reg_adapter_aff' ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry_adapter )->returning( abap_true )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry_adapter->does_exist( mo_eeec_aff_object ).


    " When exists is called
    " Then true is expected
    cl_abap_unit_assert=>assert_true( mo_cut->if_aff_object_handler~exists( mo_eeec_aff_object ) ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry_adapter ).

  ENDMETHOD.

  METHOD delete_object.

    " Given is a EEEC AFF object
    " and AFF registry adapter which is prepared for the deletion of the consumer
    mo_cut->mo_registry_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_eeec_reg_adapter_aff' ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry_adapter )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry_adapter->delete( mo_eeec_aff_object ).

    " When exists is called
    mo_cut->delete_object( mo_eeec_aff_object ).

    " Then true is expected
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry_adapter ).

  ENDMETHOD.


  METHOD delete_object_not_working.

    " Given is a EEEC AFF object
    " and AFF registry adapter which is not prepared for the deletion of the consumer
    mo_cut->mo_registry_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_eeec_reg_adapter_aff' ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry_adapter )->raise_exception( NEW /iwxbe/cx_registry( ) )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry_adapter->delete( mo_eeec_aff_object ).

    TRY.
        " When exists is called
        mo_cut->delete_object( mo_eeec_aff_object ).
        cl_abap_unit_assert=>fail( ).
      CATCH cx_aff_root ##no_handler.
        " Then the double must be called
        cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry_adapter ).
    ENDTRY.

  ENDMETHOD.


  METHOD does_not_exist.

    " Given is a EEEC AFF object
    " and AFF registry adapter which is not aware of the consumer
    mo_cut->mo_registry_adapter ?= cl_abap_testdouble=>create( '/iwxbe/if_eeec_reg_adapter_aff' ).
    cl_abap_testdouble=>configure_call( mo_cut->mo_registry_adapter )->returning( abap_false )->and_expect( )->is_called_once( ).
    mo_cut->mo_registry_adapter->does_exist( mo_eeec_aff_object ).

    " When exists is called
    " Then true is expected
    cl_abap_unit_assert=>assert_false( mo_cut->if_aff_object_handler~exists( mo_eeec_aff_object ) ).
    cl_abap_testdouble=>verify_expectations( mo_cut->mo_registry_adapter ).

  ENDMETHOD.


  METHOD get_file_handlers.
    cl_abap_unit_assert=>assert_not_initial( mo_cut->get_file_handlers( mo_eeec_aff_object ) ).
  ENDMETHOD.


  METHOD get_registry_adapter.
    cl_abap_unit_assert=>assert_true( xsdbool( mo_cut->get_registry_adapter( ) IS INSTANCE OF /iwxbe/if_eeec_reg_adapter_aff ) ).
  ENDMETHOD.


  METHOD setup.

    /iwxbe/cl_unit_test_util=>suppress_logging( ).

    mo_eeec_aff_object = NEW cl_aff_obj( package = '$TMP' name = 'CHKO_OBJECT' type = 'CHKO' ).

    mo_cut = NEW #( ).

  ENDMETHOD.


ENDCLASS.
