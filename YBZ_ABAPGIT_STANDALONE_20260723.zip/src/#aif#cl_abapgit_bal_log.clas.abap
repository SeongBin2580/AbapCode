class /AIF/CL_ABAPGIT_BAL_LOG definition
  public
  final
  create public .

public section.

  interfaces /AIF/IF_ICD_BAL .

  types:
    BEGIN OF ty_item,
      obj_type TYPE tadir-object,
      obj_name TYPE tadir-obj_name,
      devclass TYPE devclass,
*      inactive TYPE abap_bool,
    END OF ty_item .

  methods CONSTRUCTOR
    importing
      !IR_GIT_LOG type ref to OBJECT
      !IS_ITEM type TY_ITEM .
protected section.
private section.

  data MR_GIT_LOG type ref to OBJECT .
  data MS_ITEM type TY_ITEM .
ENDCLASS.



CLASS /AIF/CL_ABAPGIT_BAL_LOG IMPLEMENTATION.


  METHOD /aif/if_icd_bal~add_table_selected.
    RETURN.
  ENDMETHOD.


  METHOD /aif/if_icd_bal~clear_log.
    TRY.
        CALL METHOD mr_git_log->('CLEAR').
      CATCH cx_sy_dyn_call_error.
    ENDTRY.

*     TRY.
*        CALL METHOD mr_git_log->('ZIF_ABAPGIT_LOG~CLEAR').
*      CATCH cx_sy_dyn_call_error.
*    ENDTRY.
  ENDMETHOD.


  METHOD /aif/if_icd_bal~display.
    RETURN.
  ENDMETHOD.


  method /AIF/IF_ICD_BAL~GET_HANDLE.
    clear rv_handle.
  endmethod.


  METHOD /aif/if_icd_bal~initialize.
    RETURN.
  ENDMETHOD.


  METHOD /aif/if_icd_bal~log_msg_exist.
    rf_exist = abap_false.
  ENDMETHOD.


  METHOD /aif/if_icd_bal~set_exception.
    TRY.
        CALL METHOD mr_git_log->('ADD_EXCEPTION')
          EXPORTING
            ix_exc  = ir_root
            is_item = ms_item.
      CATCH cx_sy_dyn_call_error.
    ENDTRY.
  ENDMETHOD.


  METHOD /aif/if_icd_bal~set_message.

    TRY.
        DATA lv_text TYPE string.
        MESSAGE ID iv_msgid  TYPE iv_msgty NUMBER iv_msgno WITH iv_msgv1 iv_msgv2 iv_msgv3 iv_msgv4 INTO lv_text.
        CASE iv_msgty.
          WHEN 'A'.
            CALL METHOD mr_git_log->('ADD_ERROR')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
          WHEN 'X'.
            CALL METHOD mr_git_log->('ADD_ERROR')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
          WHEN 'E'.
            CALL METHOD mr_git_log->('ADD_ERROR')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
          WHEN 'W'.
            CALL METHOD mr_git_log->('ADD_WARNING')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
          WHEN 'S'.
            CALL METHOD mr_git_log->('ADD_SUCCESS')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
          WHEN 'I'.
            CALL METHOD mr_git_log->('ADD_INFO')
              EXPORTING
                iv_msg  = lv_text
                is_item = ms_item.
        ENDCASE.
      CATCH cx_sy_dyn_call_error.
    ENDTRY.

  ENDMETHOD.


  METHOD /aif/if_icd_bal~set_message_from_sy.
    /aif/if_icd_bal~set_message( ).
  ENDMETHOD.


  METHOD /aif/if_icd_bal~write_tables_selected.
    RETURN.
  ENDMETHOD.


  METHOD constructor.

    CLEAR mr_git_log.
    mr_git_log = ir_git_log.

    CLEAR ms_item.
    ms_item = is_item.

  ENDMETHOD.
ENDCLASS.
