"! <p class="shorttext synchronized">EEE - ABAP File Format Object Handler for EEEC</p>
CLASS /iwxbe/cl_eeec_aff_objecthandl DEFINITION
  PUBLIC
  INHERITING FROM cl_aff_object_handler
  FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    METHODS:
      constructor,
      if_aff_object_handler~exists REDEFINITION.

    TYPES:
      ty_properties TYPE /iwxbe/if_aff_eeec_v1=>ty_main.

  PROTECTED SECTION.
    METHODS:
      get_file_handlers REDEFINITION,
      delete_object     REDEFINITION.

  PRIVATE SECTION.
    CONSTANTS:
      gc_object_type TYPE trobjtype  VALUE 'EEEC'.

    DATA:
      mo_registry_adapter TYPE REF TO /iwxbe/if_eeec_reg_adapter_aff.

    METHODS:
      get_registry_adapter
        RETURNING
          VALUE(ro_registry_adapter) TYPE REF TO /iwxbe/if_eeec_reg_adapter_aff.
ENDCLASS.



CLASS /IWXBE/CL_EEEC_AFF_OBJECTHANDL IMPLEMENTATION.


  METHOD constructor.
    super->constructor( gc_object_type ).
  ENDMETHOD.


  METHOD delete_object.

    TRY.
        get_registry_adapter( )->delete( object ).
      CATCH /iwxbe/cx_exception INTO DATA(lx_xbe).
        /iwxbe/cl_logger=>log_exception( lx_xbe ).
        RAISE EXCEPTION NEW cx_aff_root( previous = lx_xbe ).
    ENDTRY.

  ENDMETHOD.


  METHOD get_file_handlers.

    DATA(lo_json_file_handler) = cl_aff_file_handler=>for_json( datatype    = VALUE ty_properties( )
                                                                st_name     = '/IWXBE/EEEC_JSON_AFF_V1'
                                                                persistence = NEW /iwxbe/cl_eeec_aff_persistence( ) ).
    result = VALUE #( ( lo_json_file_handler ) ).

  ENDMETHOD.


  METHOD get_registry_adapter.

    IF mo_registry_adapter IS NOT BOUND.
      mo_registry_adapter ?= NEW /iwxbe/cl_eeec_reg_adapter( ).
    ENDIF.

    ro_registry_adapter = mo_registry_adapter.

  ENDMETHOD.


  METHOD if_aff_object_handler~exists.

    result = get_registry_adapter( )->does_exist( object ).

  ENDMETHOD.
ENDCLASS.
