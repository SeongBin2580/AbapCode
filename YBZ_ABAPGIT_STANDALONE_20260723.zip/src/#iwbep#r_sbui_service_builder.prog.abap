*&---------------------------------------------------------------------*
*& Report  /IWBEP/R_SBUI_SERVICE_BUILDER
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*

REPORT /iwbep/r_sbui_service_builder.

PARAMETERS:
      i_prname   TYPE /iwbep/sbdm_project            NO-DISPLAY.

DATA: lx_error   TYPE REF TO cx_root,
      lo_builder TYPE REF TO /iwbep/if_sbui_service_builder.

TRY.
    lo_builder = /iwbep/cl_sbui=>create_service_builder( ).
    lo_builder->start( iv_project = i_prname ).
  CATCH /iwbep/cx_sbcm_exception cx_sy_no_handler INTO lx_error.
    RAISE EXCEPTION TYPE /iwbep/cx_sbcm_fatal EXPORTING previous = lx_error.
ENDTRY.
