*&---------------------------------------------------------------------*
*& Module Pool       /IWBEP/R_MED_REGISTER_SERVICES
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*


INCLUDE /iwbep/r_dst_model_top.                .    " global Data

* INCLUDE /IWBEP/MGW_MED_O01                      .  " PBO-Modules
* INCLUDE /IWBEP/MGW_MED_I01                      .  " PAI-Modules
* INCLUDE /IWBEP/MGW_MED_F01                      .  " FORM-Routines


INCLUDE /iwbep/r_dst_model_builder_pbo.
*INCLUDE /IWBEP/ED_REGISTER_SERVICE_PBO.

INCLUDE /iwbep/r_dst_model_builder_pai.
*INCLUDE /IWBEP/ED_REGISTER_SERVICESPAI.

INCLUDE /iwbep/r_dst_model_builder_f01.
*INCLUDE /IWBEP/ED_REGISTER_SERVICESF01.

INCLUDE /iwbep/r_dst_model_pai_200.
*INCLUDE /IWBEP/ED_REGISTER_PAI_200.
