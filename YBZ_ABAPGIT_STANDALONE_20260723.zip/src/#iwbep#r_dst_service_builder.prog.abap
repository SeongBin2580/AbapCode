*&---------------------------------------------------------------------*
*& Module Pool       /IWBEP/R_MED_REGISTER_MGROUP
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*


INCLUDE /iwbep/ed_register_mgroup_top             .    " global Data

* INCLUDE /IWBEP/MED_MG_O01                       .  " PBO-Modules
* INCLUDE /IWBEP/MED_MG_I01                       .  " PAI-Modules
* INCLUDE /IWBEP/MED_MG_F01                       .  " FORM-Routines


INCLUDE /iwbep/ed_register_mgroup_so01.

INCLUDE /iwbep/ed_register_mgroup_pai.

INCLUDE /iwbep/ed_register_mgroup_form.

INCLUDE /iwbep/ed_register_mgroup_pbo.

INCLUDE /iwbep/st_service_builder_pov.

INCLUDE /iwbep/st_service_builder_f01.

INCLUDE /iwbep/ed_register_pai_0100.
