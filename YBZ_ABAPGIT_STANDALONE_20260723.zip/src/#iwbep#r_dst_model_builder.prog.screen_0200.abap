
PROCESS BEFORE OUTPUT.
  MODULE status_0200.
*
  MODULE set_display_mode.

PROCESS AFTER INPUT.

  MODULE user_command_0200.
  MODULE exit_command_0200 AT EXIT-COMMAND.

PROCESS ON VALUE-REQUEST.
* Search help for the Classes
  FIELD gs_model_screen_200-class_name MODULE f4_class.
