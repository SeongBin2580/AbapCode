*&---------------------------------------------------------------------*
*& Report  /IWBEP/R_DST_VOCAN_REGISTER
*&
*&---------------------------------------------------------------------*
REPORT  /iwbep/r_dst_vocan_register.

TYPE-POOLS: icon.

PARAMETERS: ip_aname TYPE /iwbep/med_va_file_tech_name   NO-DISPLAY,
            ip_avers TYPE /iwbep/med_va_file_version     NO-DISPLAY,
            ip_aclas TYPE /iwbep/med_definition_class    NO-DISPLAY,
            ip_sname TYPE /iwbep/med_grp_technical_name  NO-DISPLAY,
            ip_svers TYPE /iwbep/med_grp_version         NO-DISPLAY.

CLASS lcl_detail DEFINITION DEFERRED.

CLASS lcl_service DEFINITION DEFERRED.

CLASS /iwbep/cl_mgw_med_reg_api DEFINITION LOAD.

TYPES BEGIN OF ty_s_detail.
INCLUDE TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_detail.
TYPES   created_at  TYPE c LENGTH 19.
TYPES   changed_at  TYPE c LENGTH 19.
TYPES END OF ty_s_detail.

TYPES: ty_t_detail  TYPE STANDARD TABLE OF ty_s_detail.

DATA: ok_code                TYPE sy-ucomm,
      ms_variant             TYPE disvariant,
      ms_stable              TYPE lvc_s_stbl,
      ms_detail_layout       TYPE lvc_s_layo,
      ms_service_layout      TYPE lvc_s_layo,
      mt_detail_fcat         TYPE lvc_t_fcat,
      mt_service_fcat        TYPE lvc_t_fcat,
      mt_hidden_code         TYPE ui_functions,
      mo_gui_area            TYPE REF TO cl_gui_custom_container,
      mo_gui_splitter        TYPE REF TO cl_gui_splitter_container,
      mo_gui_detail          TYPE REF TO cl_gui_container,
      mo_gui_detail_grid     TYPE REF TO cl_gui_alv_grid,
      mo_gui_service         TYPE REF TO cl_gui_container,
      mo_gui_service_grid    TYPE REF TO cl_gui_alv_grid,
      mo_detail_application  TYPE REF TO lcl_detail,
      mo_service_application TYPE REF TO lcl_service.

DATA: mv_etext           TYPE c LENGTH 100,
      mv_last_detail_num TYPE i,
      ms_current_detail  TYPE ty_s_detail,
      mt_detail          TYPE ty_t_detail,
      mt_service         TYPE STANDARD TABLE OF /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_service.

DATA: mv_vocan_tech_name   TYPE /iwbep/med_va_file_tech_name,
      mv_vocan_version     TYPE /iwbep/med_va_file_version,
      mv_vocan_class_name  TYPE /iwbep/med_definition_class,
      mv_vocan_description TYPE /iwbep/med_description,
      mv_serv_tech_name    TYPE /iwbep/med_grp_technical_name,
      mv_serv_version      TYPE /iwbep/med_grp_version,
      mv_is_main_service   TYPE /iwbep/med_va_is_life_control,
      mv_serv_alias        TYPE /iwbep/med_va_serv_ref_alias.

DATA: mv_its_sapgui TYPE c,
      mv_new_window TYPE seu_bool.

DATA: mv_serv_tech_name_id TYPE dynfnam,
      mv_serv_version_id   TYPE dynfnam.

DATA: gv_read_only_mode TYPE abap_bool.
DATA: gt_fcode          TYPE STANDARD TABLE OF sy-ucomm.

*----------------------------------------------------------------------*
*       CLASS lcl_detail DEFINITION
*----------------------------------------------------------------------*
CLASS lcl_detail DEFINITION FINAL.

  SET EXTENDED CHECK OFF.                            "#EC CI_USE_WANTED

  PUBLIC SECTION.
    METHODS:
      handle_toolbar
                    FOR EVENT toolbar OF cl_gui_alv_grid
        IMPORTING e_object e_interactive,

      handle_user_command
                    FOR EVENT user_command OF cl_gui_alv_grid
        IMPORTING e_ucomm,

      handle_double_click
                    FOR EVENT double_click OF cl_gui_alv_grid
        IMPORTING es_row_no e_row e_column,

      handle_hotspot_click
                    FOR EVENT hotspot_click OF cl_gui_alv_grid
        IMPORTING es_row_no e_column_id.

    SET EXTENDED CHECK ON.                           "#EC CI_USE_WANTED

ENDCLASS.                    "lcl_detail DEFINITION


*----------------------------------------------------------------------*
*       CLASS lcl_detail IMPLEMENTATION
*----------------------------------------------------------------------*
CLASS lcl_detail IMPLEMENTATION.

  METHOD handle_toolbar.

    CHECK gv_read_only_mode = abap_false.

    DATA: ls_toolbar TYPE stb_button.

    MOVE 3 TO ls_toolbar-butn_type.
    APPEND ls_toolbar TO e_object->mt_toolbar.

* Delete
    CLEAR ls_toolbar.
    MOVE 'DELETE'                        TO ls_toolbar-function.
    MOVE icon_delete                     TO ls_toolbar-icon.
    MOVE 'Delete Annotation Models'(001) TO ls_toolbar-quickinfo.
    IF mt_detail IS INITIAL.
      ls_toolbar-disabled = abap_true.
    ENDIF.
    APPEND ls_toolbar                    TO e_object->mt_toolbar.

* Create
    CLEAR ls_toolbar.
    MOVE 'CREATE'                        TO ls_toolbar-function.
    MOVE icon_create                     TO ls_toolbar-icon.
    MOVE 'Create'(002)                   TO ls_toolbar-text.
    MOVE 'Create Annotation Model'(003)  TO ls_toolbar-quickinfo.
    APPEND ls_toolbar                    TO e_object->mt_toolbar.

* Change
    CLEAR ls_toolbar.
    MOVE 'CHANGE'                        TO ls_toolbar-function.
    MOVE icon_change                     TO ls_toolbar-icon.
    MOVE 'Change'(004)                   TO ls_toolbar-text.
    MOVE 'Change Annotation Model'(005)  TO ls_toolbar-quickinfo.
    IF mt_detail IS INITIAL.
      ls_toolbar-disabled = abap_true.
    ENDIF.
    APPEND ls_toolbar                  TO e_object->mt_toolbar.

  ENDMETHOD.                    "handle_toolbar


  METHOD handle_user_command.

    DATA: lt_row  TYPE lvc_t_roid.

* Check for grid-dependent Commands
    IF e_ucomm = 'CHANGE' OR
       e_ucomm = 'DELETE'.
      PERFORM get_detail_selected_rows USING lt_row.
      IF lt_row IS INITIAL.
        mv_etext = 'Mark at least one entry'(009).
        MESSAGE i100(/iwbep/cos_sutil) WITH mv_etext(50) mv_etext+50. "#EC CI_USE_WANTED
        EXIT.
      ENDIF.
      IF lines( lt_row ) > 1 AND e_ucomm = 'CHANGE'.
        mv_etext = 'Mark only one entry'(010).
        MESSAGE i100(/iwbep/cos_sutil) WITH mv_etext(50) mv_etext+50. "#EC CI_USE_WANTED
        EXIT.
      ENDIF.
    ENDIF.

    CASE e_ucomm.

      WHEN 'CREATE'.
        PERFORM create_vocan.

      WHEN 'CHANGE'.
        PERFORM change_vocan USING lt_row.

      WHEN 'DELETE'.
        PERFORM delete_vocan USING lt_row.

    ENDCASE.

  ENDMETHOD.                    " handle_user_command


  METHOD handle_double_click.

    IF es_row_no IS NOT INITIAL.
      mv_last_detail_num = es_row_no-row_id.
      READ TABLE mt_detail INDEX es_row_no-row_id INTO ms_current_detail.
      mt_service = ms_current_detail-services.
      CALL METHOD mo_gui_service_grid->refresh_table_display( is_stable = ms_stable ).
    ENDIF.

  ENDMETHOD.                    "handle_grid_double_click


  METHOD handle_hotspot_click.

    IF es_row_no IS NOT INITIAL.
      mv_last_detail_num = es_row_no-row_id.
      READ TABLE mt_detail INDEX es_row_no-row_id INTO ms_current_detail.

      CASE e_column_id.

        WHEN 'TECHNICAL_NAME'.
          mt_service = ms_current_detail-services.
          CALL METHOD mo_gui_service_grid->refresh_table_display( is_stable = ms_stable ).

        WHEN 'CLASS_NAME'.
          /iwbep/cl_sutil_helper=>show_source(
            EXPORTING
              iv_class = ms_current_detail-class_name
              iv_new_window = mv_new_window
          ).

      ENDCASE.
    ENDIF.

  ENDMETHOD.                    "handle_hotspot_click

ENDCLASS.                    "lcl_detail IMPLEMENTATION


*----------------------------------------------------------------------*
*       CLASS lcl_service DEFINITION
*----------------------------------------------------------------------*
CLASS lcl_service DEFINITION FINAL.

  SET EXTENDED CHECK OFF.                            "#EC CI_USE_WANTED

  PUBLIC SECTION.
    METHODS:
      handle_toolbar
                    FOR EVENT toolbar OF cl_gui_alv_grid
        IMPORTING e_object e_interactive,

      handle_user_command
                    FOR EVENT user_command OF cl_gui_alv_grid
        IMPORTING e_ucomm,

      handle_hotspot_click
                    FOR EVENT hotspot_click OF cl_gui_alv_grid
        IMPORTING es_row_no e_column_id.

    SET EXTENDED CHECK ON.                           "#EC CI_USE_WANTED

ENDCLASS.                    "lcl_service DEFINITION


*----------------------------------------------------------------------*
*       CLASS lcl_service IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_service IMPLEMENTATION.

  METHOD handle_toolbar.

    CHECK gv_read_only_mode = abap_false.

    DATA: ls_toolbar  TYPE stb_button.

    MOVE 3 TO ls_toolbar-butn_type.
    APPEND ls_toolbar TO e_object->mt_toolbar.

* Add assignment
    CLEAR ls_toolbar.
    MOVE 'ASSIGN'                      TO ls_toolbar-function.
    MOVE icon_insert_row               TO ls_toolbar-icon.
    MOVE 'Add Assignment'(011)         TO ls_toolbar-text.
    MOVE 'Add Assignment'(011)         TO ls_toolbar-quickinfo.
    IF mt_detail IS INITIAL.
      ls_toolbar-disabled = abap_true.
    ENDIF.
    APPEND ls_toolbar                  TO e_object->mt_toolbar.

* Remove assignment
    CLEAR ls_toolbar.
    MOVE 'UNASSIGN'                    TO ls_toolbar-function.
    MOVE icon_delete_row               TO ls_toolbar-icon.
    MOVE 'Remove Assigment'(012)       TO ls_toolbar-quickinfo.
    MOVE 'Remove Assigment'(012)       TO ls_toolbar-text.
    IF mt_service IS INITIAL.
      ls_toolbar-disabled = abap_true.
    ENDIF.
    APPEND ls_toolbar                  TO e_object->mt_toolbar.

* Main Service
    CLEAR ls_toolbar.
    MOVE 'MAIN_SERV'                   TO ls_toolbar-function.
    MOVE icon_change                   TO ls_toolbar-icon.
    MOVE 'Set Main Service'(013)       TO ls_toolbar-quickinfo.
    MOVE 'Set Main Service'(013)       TO ls_toolbar-text.
    IF mt_service IS INITIAL.
      ls_toolbar-disabled = abap_true.
    ENDIF.
    APPEND ls_toolbar                  TO e_object->mt_toolbar.

  ENDMETHOD.                    "handle_toolbar


  METHOD handle_user_command.

    DATA: lt_row  TYPE lvc_t_roid.

* Check for grid-dependent Commands
    IF e_ucomm = 'UNASSIGN' OR e_ucomm = 'MAIN_SERV'.
      PERFORM get_service_selected_rows USING lt_row.
      IF lt_row IS INITIAL.
        mv_etext = 'Mark at least one entry'(009).
        MESSAGE i100(/iwbep/cos_sutil) WITH mv_etext(50) mv_etext+50. "#EC CI_USE_WANTED
        EXIT.
      ENDIF.
      IF lines( lt_row ) > 1 AND e_ucomm = 'MAIN_SERV'.
        mv_etext = 'Mark only one entry'(010).
        MESSAGE i100(/iwbep/cos_sutil) WITH mv_etext(50) mv_etext+50. "#EC CI_USE_WANTED
        EXIT.
      ENDIF.
    ENDIF.

* Handle command
    CASE e_ucomm.

      WHEN 'ASSIGN'.
        PERFORM assign_to_service.

      WHEN 'UNASSIGN'.
        PERFORM unassign_from_service USING lt_row.

      WHEN 'MAIN_SERV'.
        PERFORM set_main_service USING lt_row.

    ENDCASE.

  ENDMETHOD.                    " handle_user_command


  METHOD handle_hotspot_click.

    IF es_row_no IS NOT INITIAL.

      CASE e_column_id.

        WHEN 'SERV_TECH_NAME'.
          PERFORM run_service_implementation USING es_row_no-row_id.

      ENDCASE.
    ENDIF.

  ENDMETHOD.                    "handle_double_click

ENDCLASS.                    "lcl_service IMPLEMENTATION


*&---------------------------------------------------------------------*
*&      Module  status_0100  OUTPUT
*&---------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

  " set change / read only access
  TRY.
      gv_read_only_mode = /iwbep/cl_cof_util=>authority_check_config_mode( iv_db_name = '/IWBEP/C_SCO' ).
    CATCH /iwbep/cx_scon INTO DATA(lx_scon).
      MESSAGE lx_scon TYPE 'E' DISPLAY LIKE 'E'.
  ENDTRY.

  IF gv_read_only_mode = abap_true.
    MESSAGE s008(/iwbep/cos_sutil).
  ENDIF.

  SET PF-STATUS 'LIST'.
  SET TITLEBAR 'TITLE'.

  IF mo_detail_application IS INITIAL.

    ms_stable-row = ms_stable-col = abap_true.

    " ITS: Use the same window
    CALL FUNCTION 'GUI_IS_ITS'
      IMPORTING
        return = mv_its_sapgui.
    IF mv_its_sapgui IS NOT INITIAL.
      CLEAR mv_new_window.
    ELSE.
      mv_new_window = abap_true.
    ENDIF.

    CREATE OBJECT mo_detail_application.

    CREATE OBJECT mo_service_application.

  ENDIF.

  IF mo_gui_area IS INITIAL.
    CREATE OBJECT mo_gui_area
      EXPORTING
        container_name = 'GUI_AREA'.

    CREATE OBJECT mo_gui_splitter
      EXPORTING
        parent  = mo_gui_area
        rows    = 2
        columns = 1.

    CALL METHOD mo_gui_splitter->get_container
      EXPORTING
        row       = 1
        column    = 1
      RECEIVING
        container = mo_gui_detail.

    CALL METHOD mo_gui_splitter->get_container
      EXPORTING
        row       = 2
        column    = 1
      RECEIVING
        container = mo_gui_service.

    CREATE OBJECT mo_gui_detail_grid
      EXPORTING
        i_parent = mo_gui_detail.

    CREATE OBJECT mo_gui_service_grid
      EXPORTING
        i_parent = mo_gui_service.

    SET HANDLER mo_detail_application->handle_toolbar        FOR mo_gui_detail_grid.
    SET HANDLER mo_detail_application->handle_user_command   FOR mo_gui_detail_grid.
    SET HANDLER mo_detail_application->handle_double_click   FOR mo_gui_detail_grid.
    SET HANDLER mo_detail_application->handle_hotspot_click  FOR mo_gui_detail_grid.

    SET HANDLER mo_service_application->handle_toolbar        FOR mo_gui_service_grid.
    SET HANDLER mo_service_application->handle_user_command   FOR mo_gui_service_grid.
    SET HANDLER mo_service_application->handle_hotspot_click  FOR mo_gui_service_grid.

    PERFORM hide_toolbar.

    PERFORM create_layout.

    PERFORM get_data.

    MOVE sy-repid TO ms_variant-report.

    CALL METHOD mo_gui_detail_grid->set_table_for_first_display
      EXPORTING
        it_toolbar_excluding = mt_hidden_code
        is_layout            = ms_detail_layout
        i_save               = 'A'
        is_variant           = ms_variant
      CHANGING
        it_fieldcatalog      = mt_detail_fcat
        it_outtab            = mt_detail.

    READ TABLE mt_detail INTO ms_current_detail INDEX 1.
    mv_last_detail_num = 1.
    mt_service = ms_current_detail-services.

    CALL METHOD mo_gui_service_grid->set_table_for_first_display
      EXPORTING
        it_toolbar_excluding = mt_hidden_code
        is_layout            = ms_service_layout
        i_save               = 'A'
        is_variant           = ms_variant
      CHANGING
        it_fieldcatalog      = mt_service_fcat
        it_outtab            = mt_service.

  ENDIF.

ENDMODULE.                 " status_0100  OUTPUT


*&---------------------------------------------------------------------*
*&      Module  user_command_0100 INPUT
*&---------------------------------------------------------------------*
MODULE user_command_0100 INPUT .

  CASE ok_code.

    WHEN 'REFRESH'.
      PERFORM refresh_vocans.

    WHEN 'RE_SELECT'.
      PERFORM select_vocans.

    WHEN 'BACK' OR 'EXIT' OR 'CANCEL'.
      LEAVE TO SCREEN 0.

  ENDCASE.

ENDMODULE.                 " user_command_0100 INPUT


*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
MODULE status_0200 OUTPUT.

  SET PF-STATUS 'GOON'.
  SET TITLEBAR 'CREATE_VOCAN'.

  mv_vocan_version = 1.

ENDMODULE.                 " status_0200  OUTPUT


*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
MODULE user_command_0200 INPUT.

  CASE ok_code.

    WHEN 'CANCEL'.
      SET SCREEN 0. LEAVE SCREEN.

    WHEN 'GOON'.
      IF mv_vocan_tech_name IS INITIAL.
        MESSAGE 'Invalid Annotation Model Name'(e01) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 200.
      ENDIF.
      IF mv_vocan_version IS INITIAL.
        MESSAGE 'Invalid Annotation Model Version'(e02) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 200.
      ENDIF.
      IF mv_vocan_class_name IS INITIAL.
        MESSAGE 'Invalid Annotation Model Provider Class'(e03) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 200.
      ENDIF.
      IF mv_vocan_description IS INITIAL.
        MESSAGE 'Invalid Description'(e04) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 200.
      ENDIF.
      SET SCREEN 0. LEAVE SCREEN.

  ENDCASE.

ENDMODULE.                 " user_command_0200  INPUT


*&---------------------------------------------------------------------*
*&      Module  STATUS_0300  OUTPUT
*&---------------------------------------------------------------------*
MODULE status_0300 OUTPUT.

  SET PF-STATUS 'GOON'.
  SET TITLEBAR 'CREATE_VOCAN'.

  mv_vocan_tech_name   = ms_current_detail-technical_name.
  mv_vocan_version     = ms_current_detail-version.
  mv_vocan_class_name  = ms_current_detail-class_name.
  mv_vocan_description = ms_current_detail-description.

ENDMODULE.                 " status_0300  OUTPUT


*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0300  INPUT
*&---------------------------------------------------------------------*
MODULE user_command_0300 INPUT.

  CASE ok_code.

    WHEN 'CANCEL'.
      SET SCREEN 0. LEAVE SCREEN.

    WHEN 'GOON'.
      IF mv_vocan_class_name IS INITIAL.
        MESSAGE 'Invalid Annotation Model Provider Class'(e03) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 300.
      ENDIF.
      IF mv_vocan_description IS INITIAL.
        MESSAGE 'Invalid Description'(e04) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 300.
      ENDIF.
      SET SCREEN 0. LEAVE SCREEN.

  ENDCASE.

ENDMODULE.                 " user_command_0300  INPUT


*&---------------------------------------------------------------------*
*&      Module  STATUS_0400  OUTPUT
*&---------------------------------------------------------------------*
MODULE status_0400 OUTPUT.

  SET PF-STATUS 'GOON'.
  SET TITLEBAR 'ASSIGN_SERVICE'.

  mv_vocan_tech_name   = ms_current_detail-technical_name.
  mv_vocan_version     = ms_current_detail-version.
  mv_serv_version      = 1.

ENDMODULE.                 " status_0400  OUTPUT


*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0400  INPUT
*&---------------------------------------------------------------------*
MODULE user_command_0400 INPUT.

  CASE ok_code.

    WHEN 'CANCEL'.
      SET SCREEN 0. LEAVE SCREEN.

    WHEN 'GOON'.
      IF mv_serv_tech_name IS INITIAL.
        MESSAGE 'Invalid Technical Service Name'(e05) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 400.
      ENDIF.
      IF mv_serv_version IS INITIAL.
        MESSAGE 'Invalid Service Version'(e06) TYPE 'I'. "#EC CI_USE_WANTED
        LEAVE TO SCREEN 400.
      ENDIF.
      SET SCREEN 0. LEAVE SCREEN.

  ENDCASE.

ENDMODULE.                 " user_command_0400  INPUT


*&---------------------------------------------------------------------*
*&      Module  f4help_service_name  INPUT
*&---------------------------------------------------------------------*
MODULE f4help_service_name INPUT.

  IF sy-dynnr = '0400'.
    mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
    mv_serv_version_id   = 'MV_SERV_VERSION'.
  ELSEIF sy-dynnr = '0500'.
    mv_serv_tech_name_id = 'IP_SNAME'.
    mv_serv_version_id   = 'IP_SVERS'.
  ELSE.
    EXIT.
  ENDIF.
  PERFORM select_service_name.

ENDMODULE.                 " f4help_service_name  INPUT


*&---------------------------------------------------------------------*
*&      Module  STATUS_0500  OUTPUT
*&---------------------------------------------------------------------*
MODULE status_0500 OUTPUT.

  SET PF-STATUS 'GOON'.
  SET TITLEBAR 'SELECT_VOCAN'.

ENDMODULE.                 " status_0500  OUTPUT


*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0500  INPUT
*&---------------------------------------------------------------------*
MODULE user_command_0500 INPUT.

  CASE ok_code.

    WHEN 'CANCEL'.
      SET SCREEN 0. LEAVE SCREEN.

    WHEN 'GOON'.
      SET SCREEN 0. LEAVE SCREEN.

  ENDCASE.

ENDMODULE.                 " user_command_0500  INPUT


*&---------------------------------------------------------------------*
*&      Module  f4help_vocan_name  INPUT
*&---------------------------------------------------------------------*
MODULE f4help_vocan_name INPUT.

  PERFORM select_vocan_name.

ENDMODULE.                 " f4help_vocan_name  INPUT


*&---------------------------------------------------------------------*
*&      Form  get_data
*&---------------------------------------------------------------------*
FORM get_data.

  DATA: lv_local_date   TYPE d,
        lv_local_time   TYPE t,
        lv_date_long    TYPE c LENGTH 10,
        lv_time_long    TYPE c LENGTH 8,
        lv_found        TYPE xsdboolean,
        ls_detail       TYPE ty_s_detail,
        lv_message_text TYPE string,
        ls_vocan_detail TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_detail,
        lt_vocan_detail TYPE /iwbep/cl_mgw_med_reg_api=>ty_t_vocan_detail,
        ls_service      TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_service.

  CLEAR mt_detail.

* Get all vocans
  /iwbep/cl_mgw_med_reg_api=>vocan_get_all(
    IMPORTING
      et_vocan_detail = lt_vocan_detail
  ).

* Create result
  LOOP AT lt_vocan_detail INTO ls_vocan_detail.

    " Specific Vocan selected
    IF ip_aname IS NOT INITIAL.
      IF ls_vocan_detail-technical_name NP ip_aname. CONTINUE. ENDIF.
      IF ip_avers IS NOT INITIAL.
        IF ls_vocan_detail-version <> ip_avers. CONTINUE. ENDIF.
      ENDIF.
    ENDIF.

    " Specific Vocan class selected
    IF ip_aclas IS NOT INITIAL.
      IF ip_aclas CS '*'.
        IF ls_vocan_detail-class_name NP ip_aclas. CONTINUE. ENDIF.
      ELSE.
        IF ls_vocan_detail-class_name <> ip_aclas. CONTINUE. ENDIF.
      ENDIF.
    ENDIF.

    " Specific Service selected
    IF ip_sname IS NOT INITIAL.
      LOOP AT ls_vocan_detail-services INTO ls_service
        WHERE serv_tech_name CP ip_sname.
        lv_found = abap_true.
        EXIT.
      ENDLOOP.
      IF lv_found = abap_false. CONTINUE. ENDIF.
      IF ip_svers IS NOT INITIAL.
        IF ls_service-serv_version <> ip_svers. CONTINUE. ENDIF.
      ENDIF.
    ENDIF.

    MOVE-CORRESPONDING ls_vocan_detail TO ls_detail.

    /iwbep/cl_sutil_helper=>convert_to_local_time(
      EXPORTING
        iv_timestamp  = ls_detail-created_timestmp
      IMPORTING
        ev_local_date = lv_local_date
        ev_local_time = lv_local_time ).
    WRITE: lv_local_date TO lv_date_long,
           lv_local_time TO lv_time_long.
    CONCATENATE lv_date_long lv_time_long
      INTO ls_detail-created_at SEPARATED BY space.

    /iwbep/cl_sutil_helper=>convert_to_local_time(
      EXPORTING
        iv_timestamp  = ls_detail-changed_timestmp
      IMPORTING
        ev_local_date = lv_local_date
        ev_local_time = lv_local_time ).
    WRITE: lv_local_date TO lv_date_long,
           lv_local_time TO lv_time_long.
    CONCATENATE lv_date_long lv_time_long
      INTO ls_detail-changed_at SEPARATED BY space.

    APPEND ls_detail TO mt_detail.

  ENDLOOP.

ENDFORM.                    " get_data


*&---------------------------------------------------------------------*
*&      Form  refresh_vocans
*&---------------------------------------------------------------------*
FORM refresh_vocans.

  DATA: ls_detail  TYPE ty_s_detail.

  PERFORM get_data.

  IF ms_current_detail IS INITIAL.
    CALL METHOD mo_gui_detail_grid->refresh_table_display( ).
    READ TABLE mt_detail INTO ms_current_detail INDEX 1.
    mv_last_detail_num = 1.
    mt_service = ms_current_detail-services.
    CALL METHOD mo_gui_service_grid->refresh_table_display( ).
  ELSE.
    ls_detail = ms_current_detail.
    READ TABLE mt_detail INTO ms_current_detail
      WITH KEY technical_name = ls_detail-technical_name
               version        = ls_detail-version.
    IF sy-subrc = 0.
      mv_last_detail_num = sy-tabix.
      CALL METHOD mo_gui_detail_grid->refresh_table_display( is_stable = ms_stable ).
      mt_service = ms_current_detail-services.
      CALL METHOD mo_gui_service_grid->refresh_table_display( is_stable = ms_stable ).
    ELSE.
      CLEAR: ms_current_detail, mt_service.
      CALL METHOD mo_gui_detail_grid->refresh_table_display( ).
      READ TABLE mt_detail INTO ms_current_detail INDEX 1.
      mv_last_detail_num = 1.
      mt_service = ms_current_detail-services.
      CALL METHOD mo_gui_service_grid->refresh_table_display( ).
    ENDIF.
  ENDIF.

ENDFORM.                    " refresh_vocans


*&---------------------------------------------------------------------*
*&      Form  select_vocans
*&---------------------------------------------------------------------*
FORM select_vocans.

  CALL SCREEN 500 STARTING AT 10 5.
  IF ok_code = 'CANCEL'.
    CLEAR ok_code.
    EXIT.
  ENDIF.

  CLEAR: ms_current_detail, mt_service.
  PERFORM refresh_vocans.

ENDFORM.                    " select_vocans


*&---------------------------------------------------------------------*
*&      Form  get_detail_selected_rows
*&---------------------------------------------------------------------*
FORM get_detail_selected_rows USING pt_row TYPE lvc_t_roid.

  DATA: ls_row  TYPE lvc_s_roid,
        ls_cell TYPE lvc_s_ceno,
        lt_cell TYPE lvc_t_ceno.

  CALL METHOD mo_gui_detail_grid->get_selected_rows
    IMPORTING
      et_row_no = pt_row.
  IF pt_row[] IS INITIAL.
    CALL METHOD mo_gui_detail_grid->get_selected_cells_id
      IMPORTING
        et_cells = lt_cell.
    READ TABLE lt_cell INTO ls_cell INDEX 1.
    IF sy-subrc = 0.
      ls_row-row_id = ls_cell-row_id.
      APPEND ls_row TO pt_row.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_detail_selected_rows


*&---------------------------------------------------------------------*
*&      Form  get_service_selected_rows
*&---------------------------------------------------------------------*
FORM get_service_selected_rows USING pt_row TYPE lvc_t_roid.

  DATA: ls_row  TYPE lvc_s_roid,
        ls_cell TYPE lvc_s_ceno,
        lt_cell TYPE lvc_t_ceno.

  CALL METHOD mo_gui_service_grid->get_selected_rows
    IMPORTING
      et_row_no = pt_row.
  IF pt_row[] IS INITIAL.
    CALL METHOD mo_gui_service_grid->get_selected_cells_id
      IMPORTING
        et_cells = lt_cell.
    READ TABLE lt_cell INTO ls_cell INDEX 1.
    IF sy-subrc = 0.
      ls_row-row_id = ls_cell-row_id.
      APPEND ls_row TO pt_row.
    ENDIF.
  ENDIF.

ENDFORM.                    " get_service_selected_rows


*&---------------------------------------------------------------------*
*&      Form  create_vocan
*&---------------------------------------------------------------------*
FORM create_vocan.

  DATA: ls_vocan         TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan,
        lv_message_text  TYPE string,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

  CALL SCREEN 200 STARTING AT 10 5.
  IF ok_code = 'CANCEL'.
    CLEAR ok_code.
    EXIT.
  ENDIF.

  ls_vocan-technical_name = mv_vocan_tech_name.
  ls_vocan-version        = mv_vocan_version.
  ls_vocan-class_name     = mv_vocan_class_name.
  ls_vocan-language       = sy-langu.
  ls_vocan-description    = mv_vocan_description.

  TRY.
      /iwbep/cl_mgw_med_reg_api=>vocan_create( is_vocan = ls_vocan ).

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      lv_message_text = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE lv_message_text TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

  PERFORM refresh_vocans.

ENDFORM.                    " create_vocan


*&---------------------------------------------------------------------*
*&      Form  change_vocan
*&---------------------------------------------------------------------*
FORM change_vocan USING it_row TYPE lvc_t_roid.

  DATA: ls_row           TYPE lvc_s_roid,
        lv_message_text  TYPE string,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

* Get current service
  READ TABLE it_row INTO ls_row INDEX 1.
  READ TABLE mt_detail INTO ms_current_detail INDEX ls_row-row_id.

  CALL SCREEN 300 STARTING AT 10 5.
  IF ok_code = 'CANCEL'.
    CLEAR ok_code.
    EXIT.
  ENDIF.

  TRY.
      /iwbep/cl_mgw_med_reg_api=>vocan_update(
        iv_vocan_tech_name = mv_vocan_tech_name
        iv_vocan_version   = mv_vocan_version
        iv_language        = sy-langu
        iv_description     = mv_vocan_description
        iv_class_name      = mv_vocan_class_name
      ).

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      lv_message_text = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE lv_message_text TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

  PERFORM refresh_vocans.

ENDFORM.                    " change_vocan


*&---------------------------------------------------------------------*
*&      Form  delete_vocan
*&---------------------------------------------------------------------*
FORM delete_vocan USING it_row TYPE lvc_t_roid.

  DATA: lv_answer        TYPE c,
        ls_row           TYPE lvc_s_roid,
        ls_detail        TYPE ty_s_detail,
        lv_message_text  TYPE string,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

  CALL FUNCTION 'POPUP_TO_CONFIRM'
    EXPORTING
      titlebar      = 'Delete Annotation Models'(051)
      text_question = 'Delete marked Annotation Models?'(052)
    IMPORTING
      answer        = lv_answer.

  IF lv_answer = '1'.
    TRY.
        LOOP AT it_row INTO ls_row.
          READ TABLE mt_detail INTO ls_detail INDEX ls_row-row_id.
          /iwbep/cl_mgw_med_reg_api=>vocan_delete(
            EXPORTING
              iv_vocan_tech_name = ls_detail-technical_name
              iv_vocan_version   = ls_detail-version
          ).
        ENDLOOP.
      CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
        lv_message_text = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
        MESSAGE lv_message_text TYPE 'I' DISPLAY LIKE 'I'.
        EXIT.
    ENDTRY.
  ENDIF.

  PERFORM refresh_vocans.

ENDFORM.                    " delete_vocan


*&---------------------------------------------------------------------*
*&      Form  run_service_implementation
*&---------------------------------------------------------------------*
FORM run_service_implementation USING iv_row_no TYPE i.

  CONSTANTS: co_function_bep_implement TYPE rs38l-name VALUE '/IWBEP/FM_MGW_MAINT_SERVICE'.

  DATA: lv_function_name   TYPE rs38l-name,
        lv_namespace       TYPE /iwbep/med_grp_namespace,
        lv_service_name    TYPE /iwbep/med_grp_external_name,
        lv_service_version TYPE /iwbep/med_grp_version,
        lv_task            TYPE n LENGTH 8,
        lv_rfc_message     TYPE c LENGTH 255,
        lt_string          TYPE string_table,
        ls_service         TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_service.

  READ TABLE mt_service INDEX iv_row_no INTO ls_service.

  SPLIT ls_service-serv_tech_name AT '/' INTO TABLE lt_string.
  IF lines( lt_string ) = 3.
    READ TABLE lt_string INTO lv_namespace INDEX 2.
    CONCATENATE '/'
                lv_namespace
                '/'
      INTO lv_namespace.
    READ TABLE lt_string INTO lv_service_name INDEX 3.
  ELSE.
    lv_namespace    = '/SAP/'.
    lv_service_name = ls_service-serv_tech_name.
  ENDIF.

  lv_service_version = ls_service-serv_version.

  lv_function_name = co_function_bep_implement.
  CALL FUNCTION lv_function_name
    STARTING NEW TASK lv_task
    DESTINATION 'NONE'
    EXPORTING
      iv_namespace          = lv_namespace
      iv_ext_service_name   = lv_service_name
      iv_service_version    = lv_service_version
      iv_read_only_access   = gv_read_only_mode
    EXCEPTIONS
      system_failure        = 1 MESSAGE lv_rfc_message
      communication_failure = 2 MESSAGE lv_rfc_message
      OTHERS                = 0.

  IF sy-subrc <> 0.
    mv_etext = lv_rfc_message.
    MESSAGE i100(/iwbep/cos_sutil) WITH mv_etext(50) mv_etext+50. "#EC CI_USE_WANTED
    EXIT.
  ENDIF.

ENDFORM.                    " run_service_implementation


*&---------------------------------------------------------------------*
*&      Form  assign_to_service
*&---------------------------------------------------------------------*
FORM assign_to_service.

  DATA:
    lv_message_text  TYPE string,
    lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

* Get current service
  IF ms_current_detail IS INITIAL. EXIT. ENDIF.

  CALL SCREEN 400 STARTING AT 10 5.
  IF ok_code = 'CANCEL'.
    CLEAR ok_code.
    EXIT.
  ENDIF.

  TRY.
      " Assign
      /iwbep/cl_mgw_med_reg_api=>vocan_assign(
        iv_vocan_tech_name = mv_vocan_tech_name
        iv_vocan_version   = mv_vocan_version
        iv_serv_tech_name  = mv_serv_tech_name
        iv_serv_version    = mv_serv_version
        iv_is_main_service = mv_is_main_service
        iv_serv_alias      = mv_serv_alias
      ).

      " Update assigned services
      PERFORM update_assigned_services.

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      lv_message_text = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE lv_message_text TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

ENDFORM.                    " assign_to_service


*&---------------------------------------------------------------------*
*&      Form  unassign_from_service
*&---------------------------------------------------------------------*
FORM unassign_from_service USING it_row TYPE lvc_t_roid.

  DATA: ls_row           TYPE lvc_s_roid,
        ls_service       TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_service,
        lv_message_text  TYPE string,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

  IF ms_current_detail-services IS INITIAL. EXIT. ENDIF.

  TRY.
      " Unassign
      LOOP AT it_row INTO ls_row.
        READ TABLE ms_current_detail-services INTO ls_service INDEX ls_row-row_id.
        /iwbep/cl_mgw_med_reg_api=>vocan_unassign(
          EXPORTING
            iv_vocan_tech_name = ms_current_detail-technical_name
            iv_vocan_version   = ms_current_detail-version
            iv_serv_tech_name  = ls_service-serv_tech_name
            iv_serv_version    = ls_service-serv_version
        ).
      ENDLOOP.

      " Update assigned services
      PERFORM update_assigned_services.

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      mv_etext = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE mv_etext TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

ENDFORM.                    " unassign_from_service


*&---------------------------------------------------------------------*
*&      Form  set_main_service
*&---------------------------------------------------------------------*
FORM set_main_service USING it_row TYPE lvc_t_roid.

  DATA: ls_row           TYPE lvc_s_roid,
        ls_service       TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_service,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

* Get current service
  READ TABLE it_row INTO ls_row INDEX 1.
  READ TABLE ms_current_detail-services INTO ls_service INDEX ls_row-row_id.
  IF ls_service IS INITIAL OR ls_service-is_main_service = abap_true. EXIT. ENDIF.

  TRY.
      " Set main service
      /iwbep/cl_mgw_med_reg_api=>vocan_set_main_service(
        EXPORTING
          iv_vocan_tech_name = ms_current_detail-technical_name
          iv_vocan_version   = ms_current_detail-version
          iv_serv_tech_name  = ls_service-serv_tech_name
          iv_serv_version    = ls_service-serv_version
      ).

      " Update assigned services
      PERFORM update_assigned_services.

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      mv_etext = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE mv_etext TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

ENDFORM.                    " set_main_service


*&---------------------------------------------------------------------*
*&      Form  update_assigned_services
*&---------------------------------------------------------------------*
FORM update_assigned_services.

  DATA: lv_local_date    TYPE d,
        lv_local_time    TYPE t,
        lv_date_long     TYPE c LENGTH 10,
        lv_time_long     TYPE c LENGTH 8,
        lv_message_text  TYPE string,
        ls_vocan_detail  TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_detail,
        lx_med_exception TYPE REF TO /iwbep/cx_mgw_med_exception.

  TRY.

      " Get new assigned services
      /iwbep/cl_mgw_med_reg_api=>vocan_get_detail(
        EXPORTING
          iv_vocan_tech_name = ms_current_detail-technical_name
          iv_vocan_version   = ms_current_detail-version
        IMPORTING
          es_vocan_detail    = ls_vocan_detail
      ).
      MOVE-CORRESPONDING ls_vocan_detail TO ms_current_detail.

     /iwbep/cl_sutil_helper=>convert_to_local_time(
        EXPORTING
         iv_timestamp  = ms_current_detail-created_timestmp
        IMPORTING
          ev_local_date = lv_local_date
          ev_local_time = lv_local_time ).
      WRITE: lv_local_date TO lv_date_long,
             lv_local_time TO lv_time_long.
      CONCATENATE lv_date_long lv_time_long
        INTO ms_current_detail-created_at SEPARATED BY space.

     /iwbep/cl_sutil_helper=>convert_to_local_time(
        EXPORTING
         iv_timestamp  = ms_current_detail-changed_timestmp
        IMPORTING
          ev_local_date = lv_local_date
          ev_local_time = lv_local_time ).
      WRITE: lv_local_date TO lv_date_long,
             lv_local_time TO lv_time_long.
      CONCATENATE lv_date_long lv_time_long
        INTO ms_current_detail-changed_at SEPARATED BY space.

      " Update and output new assigned services
      MODIFY mt_detail FROM ms_current_detail INDEX mv_last_detail_num.
      mt_service = ms_current_detail-services.
      CALL METHOD mo_gui_service_grid->refresh_table_display( is_stable = ms_stable ).

    CATCH /iwbep/cx_mgw_med_exception INTO lx_med_exception.
      mv_etext = /iwbep/cl_cof_util=>get_message_text( ix_message = lx_med_exception ).
      MESSAGE mv_etext TYPE 'I' DISPLAY LIKE 'I'.
      EXIT.
  ENDTRY.

ENDFORM.                    " update_assigned_services


*&---------------------------------------------------------------------*
*&      Form  select_service_name
*&---------------------------------------------------------------------*
FORM select_service_name.

***************************************************
* Dynpro 0400: MV_SERV_TECH_NAME, MV_SERV_VERSION *
* Dynpro 0500: IP_SNAME, IP_SVERS                 *
***************************************************

  DATA: ls_return         TYPE ddshretval,
        lt_return         TYPE TABLE OF ddshretval,
        ls_dynp_field     TYPE dynpread,
        lt_dynp_field     TYPE STANDARD TABLE OF dynpread,
        lv_technical_name TYPE dynfieldvalue.

* Set Input Parameters for Dynpro 0400 or 0500
  ls_dynp_field-fieldname = mv_serv_tech_name_id.
  APPEND ls_dynp_field TO lt_dynp_field.

  ls_dynp_field-fieldname = mv_serv_version_id.
  APPEND ls_dynp_field TO lt_dynp_field.

* Get input from screen
  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
    TABLES
      dynpfields = lt_dynp_field.

* Get technical service name
  CLEAR ls_dynp_field.
  READ TABLE lt_dynp_field WITH KEY fieldname = mv_serv_tech_name_id INTO ls_dynp_field. "#EC CI_STDSEQ
  lv_technical_name = ls_dynp_field-fieldvalue.

* Select service
  CALL FUNCTION 'F4IF_FIELD_VALUE_REQUEST'
    EXPORTING
      tabname    = '/IWBEP/I_MGW_SRH'
      fieldname  = 'TECHNICAL_NAME'
      searchhelp = '/IWBEP/SH_I_MGW_SRH'
      dynpprog   = sy-repid
      dynpnr     = sy-dynnr
      value      = lv_technical_name
    TABLES
      return_tab = lt_return
    EXCEPTIONS
      OTHERS     = 1.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno.
    EXIT.
  ENDIF.

* Determine selected service
  READ TABLE lt_return INTO ls_return INDEX 1.
  IF sy-subrc = 0.
    IF mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
      mv_serv_tech_name = ls_return-fieldval.
      GET PARAMETER ID '/IWBEP/VER' FIELD mv_serv_version.  "#EC EXISTS
    ELSE.
      ip_sname = ls_return-fieldval.
      GET PARAMETER ID '/IWBEP/VER' FIELD ip_svers.         "#EC EXISTS
    ENDIF.
  ELSE.
    IF mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
      CLEAR: mv_serv_tech_name, mv_serv_version.
    ELSE.
      CLEAR: ip_sname, ip_svers.
    ENDIF.
  ENDIF.
  IF mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
    IF mv_serv_tech_name IS INITIAL. EXIT. ENDIF.
  ELSE.
    IF ip_sname IS INITIAL. EXIT. ENDIF.
  ENDIF.

* Prepare for screen update
  CLEAR: ls_dynp_field, lt_dynp_field.
  ls_dynp_field-fieldname  = mv_serv_tech_name_id.
  IF mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
    ls_dynp_field-fieldvalue = mv_serv_tech_name.
  ELSE.
    ls_dynp_field-fieldvalue = ip_sname.
  ENDIF.
  APPEND ls_dynp_field TO lt_dynp_field.

  ls_dynp_field-fieldname  = mv_serv_version_id.
  IF mv_serv_tech_name_id = 'MV_SERV_TECH_NAME'.
    ls_dynp_field-fieldvalue = mv_serv_version.
  ELSE.
    ls_dynp_field-fieldvalue = ip_svers.
  ENDIF.
  APPEND ls_dynp_field TO lt_dynp_field.

* Update screen fields
  CALL FUNCTION 'DYNP_VALUES_UPDATE'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
    TABLES
      dynpfields = lt_dynp_field.

  SET PARAMETER ID '/IWBEP/VER' FIELD space.                "#EC EXISTS

ENDFORM.                    " select_service_name


*&---------------------------------------------------------------------*
*&      Form  select_vocan_name
*&---------------------------------------------------------------------*
FORM select_vocan_name.

  DATA: ls_dynp_field      TYPE dynpread,
        lt_dynp_field      TYPE STANDARD TABLE OF dynpread,
        ls_dynp_result     TYPE ddshretval,
        lt_dynp_result     TYPE STANDARD TABLE OF ddshretval,
        lt_dynp_output     TYPE STANDARD TABLE OF /iwbep/sh_vocan_tech_name,
        lv_vocan_tech_name TYPE dynfieldvalue,
        ls_vocan_detail    TYPE /iwbep/cl_mgw_med_reg_api=>ty_s_vocan_detail,
        lt_vocan_detail    TYPE /iwbep/cl_mgw_med_reg_api=>ty_t_vocan_detail.

* Set Input Parameter
  ls_dynp_field-fieldname = 'IP_ANAME'.
  APPEND ls_dynp_field TO lt_dynp_field.

* Get input from screen
  CALL FUNCTION 'DYNP_VALUES_READ'
    EXPORTING
      dyname     = sy-repid
      dynumb     = sy-dynnr
    TABLES
      dynpfields = lt_dynp_field.

* Get VOCAN technical name
  CLEAR ls_dynp_field.
  READ TABLE lt_dynp_field WITH KEY fieldname = 'IP_ANAME' INTO ls_dynp_field. "#EC CI_STDSEQ
  lv_vocan_tech_name = ls_dynp_field-fieldvalue.

* Get all VOCANs
  /iwbep/cl_mgw_med_reg_api=>vocan_get_all(
    IMPORTING
      et_vocan_detail = lt_vocan_detail
  ).
  IF lv_vocan_tech_name IS NOT INITIAL.
    IF lv_vocan_tech_name CS '*'.
      DELETE lt_vocan_detail
        WHERE technical_name NP lv_vocan_tech_name.
    ELSE.
      DELETE lt_vocan_detail
        WHERE technical_name <> lv_vocan_tech_name.
    ENDIF.
  ENDIF.

* Only one --> Return directly
  IF lines( lt_vocan_detail ) = 1.
    READ TABLE lt_vocan_detail INTO ls_vocan_detail INDEX 1.
    ip_aname = ls_vocan_detail-technical_name.
    EXIT.
  ENDIF.

* Prepare Output List
  CLEAR lt_dynp_output.
  LOOP AT lt_vocan_detail INTO ls_vocan_detail.
    APPEND ls_vocan_detail-technical_name TO lt_dynp_output.
  ENDLOOP.

* Select Annotation
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      ddic_structure  = '/IWBEP/SH_VOCAN_TECH_NAME'
      retfield        = 'TECHNICAL_NAME'
      value_org       = 'S'
      window_title    = 'Annotation Name'
    TABLES
      value_tab       = lt_dynp_output
      return_tab      = lt_dynp_result
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.                                  "#EC NOTEXT
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.      "#EC CI_USE_WANTED
  ENDIF.

  READ TABLE lt_dynp_result INTO ls_dynp_result INDEX 1.
  ip_aname = ls_dynp_result-fieldval.

ENDFORM.                    " select_vocan_name


*&---------------------------------------------------------------------*
*&      Form  create_layout
*&---------------------------------------------------------------------*
FORM create_layout.

  DATA: lv_index    TYPE i,
        ls_gui_fcat TYPE lvc_s_fcat.

* HEADER Layout
  ms_detail_layout-grid_title = 'Annotation Models'(030).
  ms_detail_layout-sel_mode   = 'A'.

  lv_index = 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'TECHNICAL_NAME'.
  ls_gui_fcat-coltext   = 'Annotation Model Name'(031).
  ls_gui_fcat-hotspot   = abap_true.
  ls_gui_fcat-outputlen = 34.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'VERSION'.
  ls_gui_fcat-coltext   = 'Annotation Model Version'(032).
  ls_gui_fcat-outputlen = 7.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'CLASS_NAME'.
  ls_gui_fcat-coltext   = 'Annotation Model Provider Class'(033).
  ls_gui_fcat-hotspot   = abap_true.
  ls_gui_fcat-outputlen = 30.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'DESCRIPTION'.
  ls_gui_fcat-coltext   = 'Description'(034).
  ls_gui_fcat-outputlen = 60.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'CHANGED_BY'.
  ls_gui_fcat-coltext   = 'Changed by'(035).
  ls_gui_fcat-outputlen = 13.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'CHANGED_AT'.
  ls_gui_fcat-coltext   = 'Changed at'(036).
  ls_gui_fcat-outputlen = 19.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'CREATED_BY'.
  ls_gui_fcat-coltext   = 'Created by'(037).
  ls_gui_fcat-outputlen = 12.
  ls_gui_fcat-no_out    = abap_true.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'CREATED_AT'.
  ls_gui_fcat-coltext   = 'Created at'(038).
  ls_gui_fcat-outputlen = 19.
  ls_gui_fcat-no_out    = abap_true.
  APPEND ls_gui_fcat TO mt_detail_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'LANGUAGE'.
  ls_gui_fcat-coltext   = 'Language'(039).
  ls_gui_fcat-outputlen = 1.
  ls_gui_fcat-no_out    = abap_true.
  APPEND ls_gui_fcat TO mt_detail_fcat.


* SERVICE Layout
  ms_service_layout-grid_title = 'Assigned Services'(040).
  ms_service_layout-sel_mode   = 'A'.

  lv_index = 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'SERV_TECH_NAME'.
  ls_gui_fcat-coltext   = 'Service Name'(041).
  ls_gui_fcat-hotspot   = abap_true.
  ls_gui_fcat-outputlen = 37.
  APPEND ls_gui_fcat TO mt_service_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'SERV_VERSION'.
  ls_gui_fcat-coltext   = 'Service Version'(042).
  ls_gui_fcat-outputlen = 7.
  APPEND ls_gui_fcat TO mt_service_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'IS_MAIN_SERVICE'.
  ls_gui_fcat-coltext   = 'Main Service'(043).
  ls_gui_fcat-checkbox  = abap_true.
  ls_gui_fcat-outputlen = 10.
  APPEND ls_gui_fcat TO mt_service_fcat.

  lv_index = lv_index + 1.
  CLEAR ls_gui_fcat.
  ls_gui_fcat-col_pos   = lv_index.
  ls_gui_fcat-fieldname = 'SERV_ALIAS'.
  ls_gui_fcat-coltext   = 'Service Namespace Alias'(044).
  ls_gui_fcat-outputlen = 37.
  APPEND ls_gui_fcat TO mt_service_fcat.

ENDFORM.                    " create_layout


*&---------------------------------------------------------------------*
*&      Form  hide_toolbar
*&---------------------------------------------------------------------*
FORM hide_toolbar .

* Hidden Codes
  APPEND cl_gui_alv_grid=>mc_fc_col_optimize          TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_help                  TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_col_invisible         TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_find                  TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_loc_copy              TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_delete_filter         TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_unfix_columns         TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_filter                TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_subtot                TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_sum                   TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_print                 TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_views                 TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_graph                 TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_to_office             TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_html                  TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_fc_info                  TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_pc_file               TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_expcrdata             TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_expcrdesig            TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_extend                TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_expmdb                TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_expcrtempl            TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_view_excel            TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_view_grid             TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_view_lotus            TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_view_crystal          TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_word_processor        TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_url_copy_to_clipboard TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_fc_to_rep_tree           TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_mb_export                TO mt_hidden_code.
*  APPEND cl_gui_alv_grid=>mc_mb_view                  TO mt_hidden_code.
  APPEND cl_gui_alv_grid=>mc_mb_sum                   TO mt_hidden_code.

ENDFORM.                    " hide_toolbar


START-OF-SELECTION.

  CALL SCREEN 100.
