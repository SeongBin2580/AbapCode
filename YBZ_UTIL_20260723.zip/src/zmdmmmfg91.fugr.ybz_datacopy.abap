FUNCTION ybz_datacopy.
*"----------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     VALUE(IV_FR_TAB) TYPE  TABNAME
*"     VALUE(IV_TO_TAB) TYPE  TABNAME OPTIONAL
*"  TABLES
*"      IT_WTAB STRUCTURE  RSDSWHERE
*"      ET_DATA STRUCTURE  BAPIXMSPOW
*"----------------------------------------------------------------------

  DATA: lv_mandt   TYPE mandt,
        lv_tab_len TYPE i,
        lv_where   TYPE string.

  FIELD-SYMBOLS : <fs_table> TYPE STANDARD TABLE,
                  <fs_work>  TYPE any.

  DATA: lo_new_line  TYPE REF TO data,  " dereference <fs>
        lo_new_table TYPE REF TO data.

  DATA: lv_tabname      TYPE tabname.

  IF iv_to_tab IS INITIAL.
    lv_tabname = iv_fr_tab.
  ELSE.
    lv_tabname = iv_to_tab.
  ENDIF.

  " to Table 이 없는 경우 from table 을 가지고 온다...
  SELECT COUNT( * )
    FROM dd02l
    INTO sy-dbcnt
   WHERE tabname = lv_tabname.
  IF sy-subrc NE 0 OR sy-dbcnt = 0.
    lv_tabname = iv_fr_tab.
  ENDIF.

  CREATE DATA lo_new_table TYPE TABLE OF (lv_tabname).
  CREATE DATA lo_new_line  TYPE (lv_tabname).
  ASSIGN lo_new_table->* TO <fs_table>.
  ASSIGN lo_new_line->*  TO <fs_work>.

  CLEAR: et_data[], lv_where.

  SELECT *
  FROM (lv_tabname) CLIENT SPECIFIED
  INTO CORRESPONDING FIELDS OF TABLE <fs_table>
 WHERE (it_wtab).
  IF sy-subrc NE 0.
    EXIT.
  ENDIF.

* UNICode 때문에 Type Conversion 해야 한다

  LOOP AT <fs_table> INTO <fs_work>.

    CALL FUNCTION 'PI_BP_MOVE_UNICODE'
      EXPORTING
        iv_move_from = <fs_work>
      CHANGING
        cv_move_to   = et_data.
    APPEND et_data.
  ENDLOOP.



ENDFUNCTION.
