FUNCTION-POOL zmdmmmfg91        MESSAGE-ID zmdm01
                                NO STANDARD PAGE HEADING.

INCLUDE zmdmmmx0000top.      " 공용 Data Define.
INCLUDE zmdmmmx0100alv.      " 공용 ALV Grid - 0100
INCLUDE zmdmmmx0200edt.      " 공용 Editor   - 0200

TYPES: tys_itf_token TYPE stxtoken.

CONSTANTS:
  gc_object_type_0100        TYPE char8     VALUE 'CH_0100_',

  gc_prog_id                 TYPE sy-repid   VALUE 'SAPLZMDMMMFG91',
  gc_check_form              TYPE formname   VALUE 'CHECK_DATA',
  gc_save_form               TYPE formname   VALUE 'SAVE_DATA',

  gc_token_line_begin        TYPE tys_itf_token-code VALUE '(L', " 0
  gc_token_line_end          TYPE tys_itf_token-code VALUE ')L', " 0
  gc_token_symbol_begin      TYPE tys_itf_token-code VALUE '(&', " 0
  gc_token_symbol_end        TYPE tys_itf_token-code VALUE ')&', " 0
  gc_token_string            TYPE tys_itf_token-code VALUE 'ST', " n  ...
  gc_token_tab               TYPE tys_itf_token-code VALUE 'TA', " 0
  gc_token_text_end          TYPE tys_itf_token-code VALUE '##', " 0

  gc_with_command_scan(1)    VALUE '1',  " Kommandos analysieren
  gc_without_command_scan(1) VALUE '2',  " Kommandos nicht analys.
  gc_form_text(1)            VALUE '1',  " Formulartext
  gc_no_form_text(1)         VALUE '2',  " kein Formulartext
  gc_with_url_token          VALUE '1',  " mit URL Erkennung
  gc_without_url_token       VALUE '2'.  " ohen URL Erkennung

*--------------------------------------------------------------------*
*  ALV POPUP
*--------------------------------------------------------------------*
DATA: gv_selected_0100,
      gv_exit_mode_0100,
      gv_save_msg       TYPE char1,
      gv_line_length    TYPE i,
      gv_check_form     TYPE formname,
      gv_save_form      TYPE formname,
      gv_add_bt_form    TYPE formname,
      gt_dropdown_0100  TYPE        lvc_t_dral.

DATA: gv_exclude_tb_all,
      gv_dynnr           TYPE sy-dynnr,
      gv_object_text     TYPE char30,
      gv_selection_field TYPE fieldname,
      gv_exclude_save    TYPE char1,
      gt_fcode_in        TYPE zmdmmmy9070,
      gt_scrfield_in     TYPE zmdmmmy9080,
      gs_scrfield_in     TYPE zmdmmms9080,
      gs_scrattr_in      TYPE zmdmmms9082.

DATA: gv_save_bt   TYPE smp_dyntxt, " 저장
      gv_cancel_bt TYPE smp_dyntxt, " 취소
      gv_add_bt_01 TYPE smp_dyntxt,
      gv_add_bt_02 TYPE smp_dyntxt,
      gv_add_bt_03 TYPE smp_dyntxt,
      gv_add_bt_04 TYPE smp_dyntxt,
      gv_add_bt_05 TYPE smp_dyntxt,
      gv_add_bt_06 TYPE smp_dyntxt,
      gv_add_bt_07 TYPE smp_dyntxt,
      gv_add_bt_08 TYPE smp_dyntxt,
      gv_add_bt_09 TYPE smp_dyntxt.

FIELD-SYMBOLS:
      <gt_s0100>             TYPE STANDARD TABLE.

*--------------------------------------------------------------------*
*  ALV Editor
*--------------------------------------------------------------------*
DATA: BEGIN OF gt_s0200    OCCURS 0,
        line(260),
      END OF gt_s0200,

      BEGIN OF gs_s9200,
        title_01 TYPE text40,
        value_01 TYPE text255,
        title_02 TYPE text40,
        value_02 TYPE text255,
        title_03 TYPE text40,
        value_03 TYPE text255,
        title_04 TYPE text40,
        value_04 TYPE text255,
        title_05 TYPE text40,
        value_05 TYPE text255,
        title_06 TYPE text40,
        value_06 TYPE text255,
        title_07 TYPE text40,
        value_07 TYPE text255,
        title_08 TYPE text40,
        value_08 TYPE text255,
        title_09 TYPE text40,
        value_09 TYPE text255,
        title_10 TYPE text40,
        value_10 TYPE text255,
        title_11 TYPE text40,
        value_11 TYPE text255,
        title_12 TYPE text40,
        value_12 TYPE text255,
      END OF gs_s9200.

DATA: gv_max_stream_line_width TYPE i,    " max width of stream line
      gv_act_stream_line_width TYPE i.    " actual width of stream line
