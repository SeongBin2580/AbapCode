CLASS zcl_zmdm_mm_edit_info DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPE-POOLS cndd .

    TYPES:
      BEGIN OF ts_flavor,
        flavor    TYPE cndd_flavor,
        dr_source TYPE char1,
        dr_target TYPE char1,
        effect    TYPE i,
      END OF ts_flavor .
    TYPES:
      tt_flavor          TYPE TABLE OF ts_flavor .

    CONSTANTS gc_exit_alv_form TYPE formname VALUE 'COM_EXIT_' ##NO_TEXT.
    CONSTANTS gc_ok_back_exit TYPE sy-ucomm VALUE 'BACK_EXIT' ##NO_TEXT.
    CONSTANTS gc_ok_canc_exit TYPE sy-ucomm VALUE 'CANC_EXIT' ##NO_TEXT.
    CONSTANTS gc_ok_exit TYPE sy-ucomm VALUE 'EXIT' ##NO_TEXT.
    DATA gv_repid TYPE sy-repid .
    DATA gv_set_error_data TYPE string .
    DATA gv_set_new_okcode TYPE string .
    DATA gv_set_okcode TYPE string .
    DATA gv_set_no_refresh TYPE string .
    DATA go_comfunc TYPE REF TO ZCL_ZMDM_MM_comfunc .

    METHODS constructor
      IMPORTING
        !iv_repid   TYPE sy-repid OPTIONAL
        !io_comfunc TYPE REF TO ZCL_ZMDM_MM_comfunc OPTIONAL
          PREFERRED PARAMETER iv_repid .
    METHODS create_on_con
      IMPORTING
        !iv_repid       TYPE syrepid
        !iv_dynnr       TYPE sydynnr
        !iv_contnm      TYPE scrfname OPTIONAL
        !iv_line_length TYPE i DEFAULT 80
      EXPORTING
        !eo_ccon        TYPE REF TO cl_gui_custom_container
        !eo_edit        TYPE REF TO cl_gui_textedit .
    METHODS set_event
      IMPORTING
        !iv_object_text TYPE char30
        !io_edit        TYPE REF TO cl_gui_textedit
      CHANGING
        !co_edit_event  TYPE REF TO ZCL_ZMDM_MM_edit_event .
    METHODS set_display_mode
      IMPORTING
        !iv_scrno TYPE sydynnr .
    METHODS set_edit_box
      IMPORTING
        !io_edit           TYPE REF TO cl_gui_textedit
        !iv_toolbar_mode   TYPE i DEFAULT 0
        !iv_statusbar_mode TYPE i DEFAULT 0 .
    METHODS check_text_modify
      IMPORTING
        !io_edit         TYPE REF TO cl_gui_textedit
      RETURNING
        VALUE(rv_output) TYPE char1 .
    METHODS get_r3table
      IMPORTING
        !io_edit  TYPE REF TO cl_gui_textedit
      EXPORTING
        !et_table TYPE STANDARD TABLE .
    METHODS set_r3table
      IMPORTING
        !io_edit  TYPE REF TO cl_gui_textedit
        !it_table TYPE STANDARD TABLE .
    METHODS exit_program
      IMPORTING
        !iv_save_flag       TYPE char1 DEFAULT space
        !iv_msg             TYPE char1 DEFAULT space
      RETURNING
        VALUE(rv_exit_flag) TYPE char1 .
    METHODS dispatch
      IMPORTING
        !iv_scrno           TYPE sydynnr
      RETURNING
        VALUE(rv_exit_form) TYPE char1 .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA gv_set_textedit TYPE string .
    DATA gv_set_dispmode TYPE string .
    DATA gv_set_editccon TYPE string .

    METHODS set_local_fields .
    METHODS set_local_fields_with_scrno
      IMPORTING
        !iv_scrno TYPE sydynnr .
    METHODS exit_edit_screen
      IMPORTING
        !iv_scrno TYPE sydynnr .
ENDCLASS.



CLASS ZCL_ZMDM_MM_EDIT_INFO IMPLEMENTATION.


  METHOD check_text_modify.

    DATA: lv_is_modified TYPE i.

    CLEAR: rv_output.
    CALL METHOD io_edit->get_textmodified_status
      IMPORTING
        status                 = lv_is_modified
      EXCEPTIONS
        error_cntl_call_method = 1
        OTHERS                 = 2.

    IF lv_is_modified EQ cl_gui_textedit=>true.
      rv_output = 'X'.
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    IF iv_repid IS INITIAL.
      gv_repid = sy-repid.
    ELSE.
      gv_repid = iv_repid.
    ENDIF.

    " Common Function\
    IF io_comfunc IS BOUND.
      go_comfunc = io_comfunc.
    ELSE.
      CREATE OBJECT go_comfunc
        EXPORTING
          iv_repid = gv_repid.
    ENDIF.

    " 기타 변수 지정
    me->set_local_fields( ).

  ENDMETHOD.


  METHOD create_on_con.

*  Customer container 생성..
    CREATE OBJECT eo_ccon
      EXPORTING
*       repid                       = pv_repid
*       dynnr                       = pv_dynnr
        container_name              = iv_contnm
        no_autodef_progid_dynnr     = 'X'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    " Editor 생성..
    CREATE OBJECT eo_edit
      EXPORTING
        parent                     = eo_ccon
        wordwrap_position          = iv_line_length
        wordwrap_mode              = cl_gui_textedit=>wordwrap_at_fixed_position
        wordwrap_to_linebreak_mode = cl_gui_textedit=>true
      EXCEPTIONS
        error_cntl_create          = 1
        error_cntl_init            = 2
        error_cntl_link            = 3
        error_dp_create            = 4
        gui_type_not_supported     = 5
        OTHERS                     = 99.

  ENDMETHOD.


  METHOD dispatch.

    FIELD-SYMBOLS:
      <lo_text_edit>      TYPE REF TO cl_gui_textedit.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_textedit) TO <lo_text_edit>.   " text edit
    CHECK <lo_text_edit> IS ASSIGNED AND <lo_text_edit> IS BOUND.

    DATA: lv_cargo 	           TYPE syucomm,
          lv_eventid 	         TYPE i,
          lv_is_shellevent     TYPE char1,
          lv_is_systemdispatch TYPE char1.


    CALL METHOD <lo_text_edit>->dispatch
      EXPORTING
        cargo             = lv_cargo
        eventid           = lv_eventid
        is_shellevent     = lv_is_shellevent
        is_systemdispatch = lv_is_systemdispatch
      EXCEPTIONS
        cntl_error        = 1
        OTHERS            = 2.

  ENDMETHOD.


  METHOD exit_edit_screen.

    FIELD-SYMBOLS:
*    <lo_edit_dcon>  TYPE REF TO cl_gui_docking_container,
      <lo_edit_ccon> TYPE REF TO cl_gui_custom_container,
      <lo_edit>      TYPE REF TO cl_gui_textedit.

    me->set_local_fields_with_scrno( iv_scrno ).

*  ASSIGN (gv_set_alvdcon) TO <lo_alv_dcon>.   " Docking
    ASSIGN (gv_set_editccon) TO <lo_edit_ccon>.   " Customer

    ASSIGN (gv_set_textedit) TO <lo_edit>.   " Text Edit
    CHECK <lo_edit> IS ASSIGNED AND <lo_edit> IS BOUND.

    IF <lo_edit> IS BOUND.
*    IF <lo_edit_dcon> IS BOUND OR <lo_edit_ccon> IS BOUND.
      IF <lo_edit_ccon> IS BOUND.
        CALL METHOD <lo_edit>->finalize.
        CALL METHOD <lo_edit>->free.
      ENDIF.
      CLEAR: <lo_edit>.
    ENDIF.

*  IF <lo_alv_dcon> IS BOUND.
*    CALL METHOD <lo_alv_dcon>->finalize.
*    CALL METHOD <lo_alv_dcon>->free.
*    CLEAR: <lo_alv_dcon>.
*  ENDIF.

    IF <lo_edit_ccon> IS BOUND.
      CALL METHOD <lo_edit_ccon>->finalize.
      CALL METHOD <lo_edit_ccon>->free.
      CLEAR: <lo_edit_ccon>.
    ENDIF.

    CALL METHOD cl_gui_cfw=>flush.

  ENDMETHOD.


  METHOD exit_program.

    DATA: lv_exit_edit_form TYPE txt40,
          lv_title          TYPE string,
          lv_text           TYPE string.

    FIELD-SYMBOLS:
       <lv_ok_code> TYPE any.

    ASSIGN (gv_set_okcode) TO <lv_ok_code>.
    CHECK <lv_ok_code> IS ASSIGNED.

    DATA: lv_msg TYPE char1.
    lv_msg = iv_msg.
    IF lv_msg IS INITIAL.
      lv_msg = 'E'.
    ENDIF.

    IF iv_save_flag = 'X'.

* 종료확인 메세지
      rv_exit_flag = go_comfunc->check_message( iv_msg = lv_msg ).

    ELSE.
      rv_exit_flag = 'X'.

    ENDIF.
    CHECK rv_exit_flag = 'X'.

    " 종료시 공통에서 처리 하지 않는, 프로그램마다 개별로 넣야 하는
    " 로직이 있는경우 FORM LUC_EXIT 을 만들어 사용한다.
*  IF rv_exit_flag = 'X'.
    PERFORM luc_exit IN PROGRAM (gv_repid) IF FOUND.
*  ENDIF.

*  종료인경우 프로그램 종료
*  CHECK ( <lv_ok_code> = gc_ok_exit      OR <lv_ok_code> = gc_ok_canc_exit OR
*          <lv_ok_code> = gc_ok_back_exit                                    ) AND
*        rv_exit_flag = 'X'.

    " 종료 프로그램
    me->exit_edit_screen( sy-dynnr ).

    CALL METHOD cl_gui_cfw=>flush.

    " 종료 Button 실행시 프로그램 종료한다.
    IF <lv_ok_code> = gc_ok_exit.
      LEAVE PROGRAM.
    ENDIF.

  ENDMETHOD.


  METHOD get_r3table.

    CHECK me->check_text_modify( io_edit ) = 'X'.

    CLEAR: et_table[].
    CALL METHOD io_edit->get_text_as_r3table
*    EXPORTING
*      only_when_modified     = cl_gui_textedit=>true
      IMPORTING
        table                  = et_table[]
*       is_modified            = is_modified
      EXCEPTIONS
        error_dp               = 1
        error_cntl_call_method = 2
        OTHERS                 = 3.

    CALL METHOD cl_gui_cfw=>flush.

  ENDMETHOD.


  METHOD set_display_mode.

    DATA: lv_set_dispmode TYPE string.

    FIELD-SYMBOLS:
      <lv_dispmode>  TYPE any,
      <lo_text_edit> TYPE REF TO cl_gui_textedit.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_textedit) TO <lo_text_edit>.   " text edit
    CHECK <lo_text_edit> IS ASSIGNED AND <lo_text_edit> IS BOUND.

    ASSIGN (gv_set_dispmode) TO <lv_dispmode>.   " display mode
    CHECK <lv_dispmode> IS ASSIGNED.

    CASE <lv_dispmode>.
      WHEN 'X'. " Display MODE SETTING
        CALL METHOD <lo_text_edit>->set_readonly_mode
          EXPORTING
            readonly_mode = '1'.

      WHEN OTHERS.  " Editor MODE ENABLE SETTING
        CALL METHOD <lo_text_edit>->set_readonly_mode
          EXPORTING
            readonly_mode = '0'.
    ENDCASE.

  ENDMETHOD.


  METHOD set_edit_box.
    CALL METHOD io_edit->set_toolbar_mode
      EXPORTING
        toolbar_mode           = iv_toolbar_mode
      EXCEPTIONS
        error_cntl_call_method = 1
        invalid_parameter      = 2
        OTHERS                 = 3.

    CALL METHOD io_edit->set_statusbar_mode
      EXPORTING
        statusbar_mode         = iv_statusbar_mode
      EXCEPTIONS
        error_cntl_call_method = 1
        invalid_parameter      = 2
        OTHERS                 = 3.
  ENDMETHOD.


  METHOD set_event.
*  CREATE LOCAL CLASS
    CREATE OBJECT co_edit_event
      EXPORTING
        iv_repid       = gv_repid
        iv_object_text = iv_object_text.

    SET HANDLER co_edit_event->handle_ondrag         FOR io_edit.
    SET HANDLER co_edit_event->handle_ondrop         FOR io_edit.
    SET HANDLER co_edit_event->handle_ondropcomplete FOR io_edit.
  ENDMETHOD.


  METHOD set_local_fields .

    " gv_error_in_data
    CONCATENATE `(` gv_repid `)GV_ERROR_IN_DATA` INTO gv_set_error_data .

    " gv_new_ok_code
    CONCATENATE `(` gv_repid `)GV_NEW_OK_CODE` INTO gv_set_new_okcode .

    " gv_ok_code
    CONCATENATE `(` gv_repid `)GV_OK_CODE` INTO gv_set_okcode .

    " gv_no_refresh
    CONCATENATE `(` gv_repid `)GV_NO_REFRESH` INTO gv_set_no_refresh .

  ENDMETHOD.


  METHOD set_local_fields_with_scrno.

    " text Container
    CONCATENATE `(` gv_repid `)GO_CCON_` iv_scrno INTO gv_set_editccon.

    " text edit
    CONCATENATE `(` gv_repid `)GO_EDIT_` iv_scrno INTO gv_set_textedit.

    " display Mode
    CONCATENATE `(` gv_repid `)GV_DISPLAY_MODE_` iv_scrno INTO gv_set_dispmode.

  ENDMETHOD.


  METHOD set_r3table.

    CALL METHOD io_edit->set_text_as_r3table
      EXPORTING
        table           = it_table[]
      EXCEPTIONS
        error_dp        = 1
        error_dp_create = 2
        OTHERS          = 99.

    CALL METHOD cl_gui_textedit=>set_focus
      EXPORTING
        control           = io_edit
      EXCEPTIONS
        cntl_error        = 1
        cntl_system_error = 2
        OTHERS            = 3.

    CALL METHOD cl_gui_cfw=>flush
      EXCEPTIONS
        cntl_system_error = 1
        cntl_error        = 2
        OTHERS            = 3.

  ENDMETHOD.
ENDCLASS.
