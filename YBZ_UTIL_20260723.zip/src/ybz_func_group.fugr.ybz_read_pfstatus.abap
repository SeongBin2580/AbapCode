FUNCTION YBZ_READ_PFSTATUS .
*"--------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     VALUE(IV_PROGID) TYPE  PROGRAMM
*"     VALUE(IV_LANGU) TYPE  SY-LANGU DEFAULT SY-LANGU
*"  TABLES
*"      ET_STA STRUCTURE  RSMPE_STAT
*"      ET_FUN STRUCTURE  RSMPE_FUNT
*"      ET_MEN STRUCTURE  RSMPE_MEN
*"      ET_MTX STRUCTURE  RSMPE_MNLT
*"      ET_ACT STRUCTURE  RSMPE_ACT
*"      ET_BUT STRUCTURE  RSMPE_BUT
*"      ET_PFK STRUCTURE  RSMPE_PFK
*"      ET_SET STRUCTURE  RSMPE_STAF
*"      ET_DOC STRUCTURE  RSMPE_ATRT
*"      ET_TIT STRUCTURE  RSMPE_TITT
*"      ET_BIV STRUCTURE  RSMPE_BUTS
*"  EXCEPTIONS
*"      NOT_FOUND
*"--------------------------------------------------------------------
*----------------------------------------------------------------------*
*   Description : Read PF Status in Program
*----------------------------------------------------------------------*
* Version                                                              *
*   1.0             : 2025.01.15   생성                                *
*----------------------------------------------------------------------*



  DATA: lv_program TYPE trdir-name,
        lv_langu   TYPE sy-langu.
  DATA: lv_rc TYPE sy-subrc.

  lv_program = IV_PROGID.
  lv_langu   = iv_langu.

  CALL FUNCTION 'RS_CUA_INTERNAL_FETCH'
    EXPORTING
      program         = lv_program
      language        = lv_langu
    TABLES
      sta             = et_sta
      fun             = et_fun
      men             = et_men
      mtx             = et_mtx
      act             = et_act
      but             = et_but
      pfk             = et_pfk
      set             = et_set
      doc             = et_doc
      tit             = et_tit
      biv             = et_biv
    EXCEPTIONS
      not_found       = 1
      unknown_version = 2
      OTHERS          = 3.
ENDFUNCTION.
