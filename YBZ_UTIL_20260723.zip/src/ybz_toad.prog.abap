*&---------------------------------------------------------------------*
*& Program : YBZ_TOAD / YTOAD, Org Program is ZTOAD..
*& Author  : S. Hermann
*& Date    : 31.12.2017
*& Version : 4.8.0
*& Required: Table YBT_TOAD
*& Description: ABAP SQL Editor and Executor
***&---------------------------------------------------------------------*
***  3번째 구분자
***    WHEN '='.    ls_line-tdformat = '='.  " 구분선 (Horizontal line)
***    WHEN '3'.    ls_line-tdformat = 'U3'. " 사용자 정의 스타일, 레벨(예: H1, H2, H3처럼 제목 계층)
***    WHEN 'E'.    ls_line-tdformat = 'PE'. " 표의 끝(End of table)
***    WHEN OTHERS. ls_line-tdformat = '*'.  " 일반 Text
***
*&---------------------------------------------------------------------*
*& This program allow you to execute query directly on the server
*& 1/ Write your query in the editor window (ABAP SQL)
*& 2/ View the result in ALV window (in case of SELECT query)
*&
*3 Features :
*& The top center pane allow you to write your query in ABAP SQL format.
*= Query can be complex with JOIN, UNION and subqueries. You can write
*= query on several lines. You could also add spaces.
*= To add comment, start the line by * or prefix your comment by "
*&
*& You could write several queries in the query editor, separated by
*= dot ".". To execute one of them, highlight all the wanted query,
*= or just put the cursor anywhere inside the wanted query.
*= By default, the last query is executed.
*&
*& In case of error, you can display generated code to help you to
*= correct your query (only if you have S_DEVELOP access)
*&
*& F1 Help is managed to help you on ABAP SQL Syntax
*& Code completion is also available :
*& - TAB to autocomplete with tooltip word
*& - CTRL + ESPACE to display list of available words
*& Be carefull to not use with INSERT statement (see below)
*&
*& The top left pane allow you to store your query :
*& - You could save your query to reuse it later
*& - You could share your query : define users, usergroup, all
*& - You could export query into file to reuse it on another server
*&
*& The top right pane display ddic object that is currently used to help
*= you to write the proper query
****& Synergy with ZSPRO program : display tables defined in ZSPRO in the
****= ddic tree
*& Tips :
*&   - You can search for tables by clicking the 'FIND' button in the tree header.
*&   - If you double-click a field name in the DDIC, the field name will be copied
*&     to the editor window.
*&
*3 Managed queries
*& SELECT, INSERT, UPDATE, DELETE, Any native SQL command
*&
*3 About New SQL Query Syntax
*& You could use new syntax (if your SAP system manage it)
*& YBZ_TOAD autmatically detect if you are using new sytax when:
*& - You separated your selected fields with comma
*& // You prefixed your variable with @ in the INTO TABLE statement
*& - Using New SQL Function
*&
*3 Select Clause managed
*& SELECT [DISTINCT / SINGLE] select clause
*& FROM from clause
*& [UP TO x ROWS]
*& [WHERE cond1]
*& [GROUP BY fields1]
*& [HAVING cond2]
*& [ORDER BY fields2]
*& [UNION SELECT...]
*&
*& UP TO (Default max rows) ROWS added at end of query if omitted
*& You could force select without limits by adding UP TO 0 ROWS
*&
*& COUNT, AVG, MAX, MIN, SUM are managed
*& DO NOT FORGET SPACE in ( ) of aggregat
*&
*3 Insert special syntax
*& In ABAP, insert query is always used with given structure
*& In this SQL editor, you have 2 ways to do an INSERT :
*& - By passing each value, 1 by 1
*E INSERT SEOCLASSTX VALUES ( 'ZZMACLASS', ' ', 'Test claSS' )
*&
*& - By passing value of used fields only
*E INSERT SEOCLASSTX SET CLSNAME = 'ZZMACLASS' DESCRIPT = 'TeSt class'
*&
****3 Native SQL special syntax
****& To execute a native SQL command, please add the prefix NATIVE
****& before your query
****& NATIVE CREATE INDEX 'TESTINDEX' ON T001 (MANDT, WAERS, BUKRS)
****& NATIVE DROP INDEX 'TESTINDEX'
*&
*3 New SQL syntax
*& To execute a new Syntax available in 740 SP3 or later
*& INSERT target table FROM ( SELECT * FROM source table ).
*&
*3 Sample of query :
*&
*& SELECT SINGLE * FROM VBAP WHERE VBELN = '00412345678'
*&
*& SELECT COUNT( * ) SUBC MAX( PROG ) FROM TRDIR GROUP BY SUBC
*&
*& SELECT VBAK~* from VBAK UP TO 3 ROWS ORDER BY VKORG.
*&
*& SELECT T1~VBELN T2~POSNR FROM VBAk AS T1
*&        JOIN VBAP AS T2 ON T1~VBELN = T2~VBELN
*&
*& INSERT SEOCLASSTX VALUES ( 'ZZMACLASS', ' ', 'Test claSS' )
*&
*& INSERT SEOCLASSTX SET CLSNAME = 'ZZMACLASS' DESCRIPT = 'TeSt class'
*&
*& UPDATE SEOCLASSTX SET DESCRIPT = 'txt' WHERE CLSNAME = 'ZZMACLASS'
*&
*& DELETE SEOCLASSTX WHERE CLSNAME = 'ZZMACLASS'
*&
*& WITH +cities AS ( SELECT cityfrom AS city FROM spfli
*&                                           WHERE carrid = 'LH'
*&                   UNION DISTINCT
*&                   SELECT cityto AS city FROM spfli
*&                                         WHERE carrid = 'LH' )
*&     SELECT * FROM sgeocity
*&             WHERE city IN ( SELECT city FROM +cities )
*&
*& WITH +BSEG AS ( SELECT DISTINCT BELNR FROM BSEG ),
*&      +BSET AS ( SELECT DISTINCT BELNR FROM _BSEG )
*&     SELECT A~VBELN, A~BELNR  FROM VBRP AS A
*&           inner join +bseg  as b on b~belnr = a~belnr
*&           inner join +bset  as c on c~belnr = a~belnr
*&     WHERE a~VBELN = '0012345678'
*&      and a~POSNR = '00001'
*&
*& INSERT SEOCLASSTX FROM ( SELECT * FROM SEOCLASSTX )
*&
*3 SQL GROUP BY GROUPING SETS
*&
*&     Select Case
*&            When Grouping( Weblnr ) = 0 Then '1'  " 있다 = 0, 없다 = 1
*&            When Grouping( Weblnr ) = 1 Then '2'
*&            End As Set_type,
*&            Weblnr,
*&            Weblpos,
*&            Matnr,
*&            Aufnr,
*&            Sum( Erfmg ) As Erfmg
*&       From Affw
*&      Where Matnr = '000000005000000712'
*&      Group By Grouping Sets (
*&            ( Weblnr, Weblpos, Matnr, Aufnr ),
*&            ( Matnr, Aufnr )
*&            )
*&
*3 SQL Function
*&
*& ROW_NUMBER( ) : row 단위 순번 부여, PARTITION 생략가능
*&
*& RANK( ) : 순위, 순위 일련번호 중간에 건너뛰기 있음
*&
*& DENSE_RANK( ) : 순위, 순위 일련번호 중간에 건너뛰기 없음
*&
*& OVER( PARTITION BY [ 순번을 부여하는 블럭, 블럭이 틀리면 순번을 새로 시작, 없는경우 전체 ]
*&       ORDER BY [ 정렬순서 ]
*&
*& CASE( ) : 조건에 의한 분기
*&    검색조건에 의한 분기시 결과값이 NULL 인 경우 처리
*&      - CASE coalesce( t1~fieldname, @space )
*&                 WHEN @space THEN 처리문..
*&
*&
*3 Inline Option : Mark '$'
*&
*& newsyntax : newsyntax mode on
*&
*&
*E Please send comment & improvements to http://quelquepart.biz
*&---------------------------------------------------------------------*
*& History :
*& 2026.05.13 v4.8.0:Add Source Editor 기능 추가 with ChatGTP
*& 2025.10.14 v4.7.0:Mod 중복 Code 최적화 with ChatGTP
*& 2025.09.24 v4.6.8:Fix Field List 만들기 변경, CAST 문번 parsing 변경
*& 2025.07.15 v4.6.7:Fix Ddic tree 내용 수정 : CDSVIEW Field Text 누락 수정
*&                       Ddic 내 CTE 지정 Table list 추가
*& 2025.07.03 v4.6.6:del Native SQL 수행 기능 제거
*& 2025.06.18 v4.6.5:Add Concat 기능추가
*& 2025.05.20 v4.6.4:Fix Case 결과값 data type 오류 수정
*& 2024.07.11 v4.6.3:Fix Case 결과값 data type 오류 수정
*& 2023.07.11 v4.6.2:Fix Union 다음 where 조건 기술 부분 변경
*&                   Fix Case 문 행분리 오류 수정
*& 2023.05.23 v4.6.1:Fix Union 다음 select field list * 변환
*& 2023.04.25 v4.6.0:Add Inline option:new syntax 설정 기능추가
*& 2023.04.20 v4.5.0:Add Ext Source 저장/불러오기 기능 추가
*& 2023.04.18 v4.4.2:Fix Select Single Logic 일부 개선
*& 2023.04.14 v4.4.1:Mod GUI Status 정리(일부 Button -> Menu)
*&                   Add DDIC Column 추가( Key, Conv Exit )
*& 2023.03.15 v4.4  :Del ZSPRO
*& 2023.03.10 v4.3  :Add Execution Program 기능
*& 2023.02.24 v4.2  :Add UserGroup 등록 화면
*& 2023.01.20 v4.1  :Add New Syntax WITH,Row_NUMBER  등
*&                   Add ALV Column Text 출력
*& -----------------------------------------------------------------------
*& 2017.12.31 v4.0.2:Fix dump in case of multiple aggregations
*&                       Thanks to Sabrina Villa for the fix
*& 2017.04.01 v4.0.1:Fix new Tab dump
*& 2016.12.17 v4.0  :Add Tab management. You can have up to 30 tabs
*&                   Fix Status corruption
*&                   Add Import/Export function for saved queries
*&                   Mod Code cleaning
*& 2016.09.10 v3.6  :Add New syntax management of "case"
*& 2016.07.06 v3.5.1:Fix Auth issue
*&                   Fix Dump on select with no empty selection part
*& 2016.03.28 v3.5  :Add Value Help on DDIC field. Select a value to
*&                       paste in editor
*&                   Add Button Execute into file to download results
*&                       instead of display it in ALV
*&                   Mod Use class CL_RSAWB_SPLITTER_FOR_TOOLBAR for
*&                       creation of DDIC toolbar
*&                   Add Refresh the DDIC tree when executing a query
*&                       even if error found
*& Thanks to Patrick Prime Reinoso for the following changes :
*&                   Fix Remove confirmation popup on display code for
*&                       no select statement
*&                   Add Option to display technical name in ALV
*&                   Mod Move option button to main toolbar
*&                   Mod Rename subroutines (code cleaning)
*&                   Mod Allow save on exit popup
*&                   Add New query button
*&                   Mod New query template changed
*& 2015.11.07 v3.4.3:Fix dump if cursor on first position
*&                   Fix prevent dump on too many sql run
*& 2015.11.07 v3.4.2:Fix cancel of save query popup
*&                   Fix Allow usage of " and . inside ''
*& 2015.11.01 v3.4.1:Fix issue with delete all history context menu
*& 2015.09.19 v3.4  :Add Code completion on SQL editor
*&                   Thanks to Benjamin Krencker for his code
*&                   Add Remove useless APPENDING TABLE statement in qry
*& 2015.09.13 v3.3  :Add New Options panel to save user preferences
*&                   Add Delete all history entries context menu
*&                   Add option to add linebreak after paste field from
*&                       ddic tree
*&                   Add Count column in alv grid display
*&                   Thanks again to Shai Sinai for his suggestions
*& 2015.09.06 v3.2.1:Mod Default limit to 100 rows is now optional
*& 2015.08.30 v3.2  :Add Manage new SQL Syntax introduced by NW7.40 SP5
*&                   Add Remove useless INTO TABLE statement in query
*&                   Add All NATIVE Sql commands
*&                   Mod Auth object use now the sap standard way
*&                   Fix Dump in case of up to xx rows in unioned query
*&                   Fix Dump at activation if ZSPRO does not exist
*&                   Fix Compatibility issues with older sap system
*& 2015.08.05 v3.1  :Add Manage drag&drop from DDIC tree to SQL Editor
*&                   Mod Double clic on field in DDIC tree paste field
*&                       in editor instead of filling clipboard
*&                   Thanks to Shai Sinai for his suggestions
*& 2015.06.13 v3.0  :Add INSERT, UPDATE, DELETE command
*&                   Add Authorization management
*&                   Add History tree display first query line if it
*&                       is a comment line
*&                   Mod Code cleaning
*& 2015.03.05 v2.1.1:Mod grid size is no more changed before display
*&                       query result
*& 2015.01.11 v2.1  :Add UNION instruction managed to merge 2 queries
*&                   Mod Do not refresh result grid for count(*)
*&                   Mod Back close the grid instead of leave program if
*&                       result grid is displayed
*&                   Add Display program header as default help
*&                   Add Run highlighted query
*&                   Mod Documentation rewritten
*& 2014.10.23 v2.0.2:Add Display number of entries found
*&                   Add Confirmation before exit for unsaved queries
*& 2014.10.19 v2.0.1:Fix bug on search ddic function
*& 2014.08.03 v2.0 : Completely rewritten version
*&                   - Save and share queries with colaborators
*&                   - Queries are now saved in database
*&                   - Display tables (+ fields) of the where clause
*&                   - Display ZSPRO entries in ddic tree
*&                   - Allow direct change in query after execution
*&                   - Count( * ) allowed
*&                   - Can display generated code
*&                   - Display query execution time
*&                   - Allow write of several queries (but 1 executed)
*& 2013.12.03 v1.3 : Allow case sensitive constant in where clause
*& 2012.08.30 v1.2 : Rewrite data definition to avoid dump on too long
*&                   fieldname
*& 2012.04.01 v1.1 : Updated to work also on BW system
*& 2009.10.26 v1.0 : Initial release
*&---------------------------------------------------------------------*
*&  Table Name : YBT_TOAD - YB_Z_TOAD - Saved queries
*&
*&  MANDT           X  MANDT           CLNT    3   0 0 클라이언트
*&  QUERYID         X  GUID_32         CHAR    32  0 0 대문자 'CHAR' 포맷의 GUID
*&  OWNER              SYUNAME         CHAR    12  0 0 사용자 이름
*&  AEDAT              TIMESTAMP       DEC     15  0 0 짧은 형식의 UTC 타임스탬프(YYYYMMDDhhmmss)
*&  VISIBILITY                         CHAR    1   0 0 Visibility(0:owner, 1:usergroup, 2:all, 3:define usergroup)
*&  VISIBILITY_GROUP   XUCLASS         CHAR    12  0 0 사용자 그룹
*&  TEXT                               CHAR    100 0 0 Description of the query
*&  QUERY                              STRING  0   0 0 Query
*&---------------------------------------------------------------------*

" 또다른 sql editor
*****DATA: lv_sql        TYPE string,
*****      lo_sql_stmt   TYPE REF TO cl_sql_statement,
*****      lo_result_set TYPE REF TO cl_sql_result_set,
*****      lt_data       TYPE TABLE OF REF TO data,
*****      lr_data       TYPE REF TO data,
*****      lo_descr      TYPE REF TO cl_abap_structdescr,
*****      lo_row        TYPE REF TO data.
*****
*****FIELD-SYMBOLS: <lt_table> TYPE ANY TABLE,
*****               <ls_line>  TYPE any.
*****
*****lv_sql = p_sql.
*****
*****TRY.
*****    " 1. Statement 생성
*****    CREATE OBJECT lo_sql_stmt
*****      EXPORTING con_ref = cl_sql_connection=>get_connection( ).
*****
*****    " 2. SELECT 문인지 체크
*****    IF lv_sql CP 'SELECT*'.
*****      " 3. 결과 구조 유추 및 실행
*****      lo_result_set = lo_sql_stmt->execute_query( lv_sql ).
*****      lo_descr = lo_result_set->get_struct_descr( ).
*****      CREATE DATA lr_data TYPE HANDLE lo_descr.
*****      CREATE DATA lt_data TYPE STANDARD TABLE OF HANDLE lo_descr.
*****      ASSIGN lt_data->* TO <lt_table>.
*****
*****      WHILE lo_result_set->next( ) = abap_true.
*****        lo_result_set->set_param_struct( lr_data ).
*****        ASSIGN lr_data->* TO <ls_line>.
*****        APPEND <ls_line> TO <lt_table>.
*****      ENDWHILE.
*****
*****      " ALV 출력
*****      cl_demo_output=>display( <lt_table> ).
*****
*****    ELSE.
*****      " 4. 비SELECT 문 실행 (예: INSERT, UPDATE)
*****      lo_sql_stmt->execute_update( lv_sql ).
*****      WRITE: / 'SQL executed successfully.'.
*****    ENDIF.
*****
*****  CATCH cx_sql_exception INTO DATA(lx_sql).
*****    MESSAGE lx_sql->get_text( ) TYPE 'E'.
*****
*****  CATCH cx_root INTO DATA(lx_root).
*****    MESSAGE lx_root->get_text( ) TYPE 'E'.
*****
*****ENDTRY.
*--------------------------------------------------------------------*
REPORT ybz_toad.


TYPE-POOLS: abap,
            vrm.
*--------------------------------------------------------------------*
TYPES: tys_find_result TYPE match_result,
       tyt_find_result TYPE match_result_tab,
       tyt_string      TYPE TABLE OF string,
       tys_source_line TYPE c LENGTH 1024,
       tyt_source      TYPE STANDARD TABLE OF tys_source_line WITH EMPTY KEY,
       ty_toad_tabtype TYPE c LENGTH 1,
       ty_toad_progtyp TYPE c LENGTH 1.

TYPES: BEGIN OF tys_s0400,
         user    TYPE sy-uname,
         group01 TYPE usr02-class,
         group02 TYPE usr02-class,
         group03 TYPE usr02-class,
         group04 TYPE usr02-class,
         group05 TYPE usr02-class,
         group06 TYPE usr02-class,
         group07 TYPE usr02-class,
         group08 TYPE usr02-class,
         group09 TYPE usr02-class,
         group10 TYPE usr02-class,
         group11 TYPE usr02-class,
         group12 TYPE usr02-class,
       END OF tys_s0400.

* Global types
TYPES: BEGIN OF tys_fieldlist,
         field      TYPE string,
         ref_table  TYPE string,
         ref_field  TYPE string,
         field_txt  TYPE string,
         field_type TYPE string,
         table_ref  TYPE string,
         field_ref  TYPE string,
       END OF tys_fieldlist,
       tyt_fieldlist TYPE STANDARD TABLE OF tys_fieldlist.

TYPES: tyt_field_w TYPE tys_fieldlist OCCURS 0,

       BEGIN OF tys_table_w,
         tabname    TYPE tabname,
         field_list TYPE tyt_field_w,
       END OF tys_table_w,
       tyt_table_w TYPE TABLE OF tys_table_w.

TYPES: BEGIN OF tys_table_list,
         table         TYPE tabname,
         alias(30),
         table_org(30),
         is_ddls,
       END OF tys_table_list,
       tyt_table_list TYPE TABLE OF tys_table_list.

TYPES: BEGIN OF tys_ddic_fields,
         tabname    TYPE dd03l-tabname,
         fieldname  TYPE dd03l-fieldname,
         position   TYPE dd03l-position,
         keyflag    TYPE dd03l-keyflag,
         datatype   TYPE dd03l-datatype,
         leng       TYPE dd03l-leng,
         decimals   TYPE dd03l-decimals,
         shlporigin TYPE dd03l-shlporigin,
         ddtext1    TYPE dd03t-ddtext,
         ddtext2    TYPE dd04t-ddtext,
         convexit_4 TYPE dd01l-convexit,
         convexit_1 TYPE dd01l-convexit,
       END OF tys_ddic_fields,
       tyt_ddic_fields TYPE TABLE OF tys_ddic_fields.

TYPES: BEGIN OF tys_inline_option,
         new_syntax(1) TYPE c,
       END OF tys_inline_option.

TYPES: BEGIN OF tys_table_alias,
         table TYPE tabname,
         alias TYPE tabname,
       END OF tys_table_alias,
       tyt_table_alias TYPE STANDARD TABLE OF tys_table_alias WITH EMPTY KEY.

*######################################################################*
*
*                        CUSTOMIZATION SECTION
*
*######################################################################*
DATA : BEGIN OF gs_customize,                               "#EC NEEDED
* Default number of lines to return for SELECT if no "up to xxx rows"
* defined in the query.
* Set to 0 if you dont want default limit.
         default_rows    TYPE i VALUE 100,

* When you dblclic on a field in the ddic tree, field is pasted to
* editor at the cursor position
* You could choose to add a linebreak after the field pasted
         paste_break(1)  TYPE c VALUE space, "abap_true to break

* In ALV grid result, display technical name instead of column label
         techname(1)     TYPE c VALUE space, "abap_true for technical

* Conversion Exit 사용여부
         no_convext(1)   TYPE c VALUE space, " abap_true for no conversion exit

* You could define your authorization object to restrict
* function usage by user
* If you dont define auth object, all users will have same access as
* defined bellow
* The auth object have 2 fields TABLE and ACTVT
* ACTVT can take 5 values that you could define here. By default :
* 01 for INSERT command
* 02 for UPDATE command
* 03 for SELECT command
* 06 for DELETE command
* 16 for EXECUTE NATIVE SQL command
* TABLE contain allowed table name pattern
* '*' to allow all table, 'Z*' to allow all specific tables...
         auth_object(20) TYPE c VALUE '', "'YBT_TOAD_AUTH',
         actvt_select    TYPE tactt-actvt VALUE '03',
         actvt_insert    TYPE tactt-actvt VALUE '01',
         actvt_update    TYPE tactt-actvt VALUE '02',
         actvt_delete    TYPE tactt-actvt VALUE '06',
         actvt_native    TYPE tactt-actvt VALUE '16',

* Bellow is default AUTH used if no auth_object is defined
* Allow SELECT query on SAP table (restricted by given pattern)
         auth_select     TYPE string VALUE '*',
* Allow INSERT query on SAP table (restricted by given pattern)
         auth_insert     TYPE string VALUE space, "'*',
* Allow UPDATE query on SAP table (restricted by given pattern)
         auth_update     TYPE string VALUE space, "'*',
* Allow DELETE query on SAP table (restricted by given pattern)
         auth_delete     TYPE string VALUE space, "'*',
* Allow any native sql command (set value to space to disable)
         auth_native(1)  TYPE c VALUE space, "abap_true,

       END OF gs_customize.

*######################################################################*
*
*                             DATA SECTION
*
*######################################################################*
* Objects
CLASS lcl_application DEFINITION DEFERRED.

* Screen objects
DATA : go_handle_event            TYPE REF TO lcl_application,
       go_container               TYPE REF TO cl_gui_custom_container,
       go_splitter                TYPE REF TO cl_gui_splitter_container,
       go_splitter_top            TYPE REF TO cl_gui_splitter_container,
       go_splittoolbar_ddic       TYPE REF TO cl_rsawb_splitter_for_toolbar,
       go_splittoolbar_repository TYPE REF TO cl_rsawb_splitter_for_toolbar,
       go_container_top           TYPE REF TO cl_gui_container,
       go_container_top_right     TYPE REF TO cl_gui_container,
       go_container_top_left      TYPE REF TO cl_gui_container,
       go_container_options       TYPE REF TO cl_gui_custom_container,
       go_container_repository    TYPE REF TO cl_gui_container,
       go_container_query         TYPE REF TO cl_gui_container,
       go_container_ddic          TYPE REF TO cl_gui_container,
       go_container_result        TYPE REF TO cl_gui_container,

* Tabs objects (editor, ddic, alv)
       BEGIN OF gs_tab_active,
         textedit    TYPE REF TO cl_gui_abapedit,
         tree_ddic   TYPE REF TO cl_gui_column_tree,
         t_node_ddic TYPE treev_ntab,
         t_item_ddic TYPE TABLE OF mtreeitm,
         alv_result  TYPE REF TO cl_gui_alv_grid,
         row_height  TYPE i,
         tab_type    TYPE ty_toad_tabtype,
         prog_name   TYPE programm,
         main_prog   TYPE programm,
         is_new      TYPE abap_bool,
         prog_type   TYPE ty_toad_progtyp,
         trdir_info  TYPE trdir,
       END OF gs_tab_active,
       gt_tabs            LIKE TABLE OF gs_tab_active,

* Repository data
       go_tree_repository TYPE REF TO cl_gui_simple_tree,
       BEGIN OF gs_node_repository.
         INCLUDE TYPE treev_node. "mtreesnode.
DATA: visibility_group TYPE ybt_toad-visibility_group,
         visibility       TYPE ybt_toad-visibility,
         text             TYPE ybt_toad-text,
         edit(1)          TYPE c,
         queryid          TYPE ybt_toad-queryid,
       END OF gs_node_repository,
       gt_node_repository     LIKE TABLE OF gs_node_repository,

* DDIC data
       w_dragdrop_handle_tree TYPE i,
* DDIC toolbar
       go_toolbar_ddic        TYPE REF TO cl_gui_toolbar,
* Repgo toolbar
       go_toolbar_repgo       TYPE REF TO cl_gui_toolbar,
* Option panel
       go_options             TYPE REF TO cl_wdy_wb_property_box,
* Save option
       BEGIN OF gs_options,
         name          TYPE ybt_toad-text,
         visibility    TYPE ybt_toad-visibility,
         visibilitygrp TYPE usr02-class,
       END OF gs_options,
* Keep last loaded id
       w_last_loaded_query TYPE ybt_toad-queryid,
* Count number of runs
       w_run               TYPE i.

DATA: gv_ok_code TYPE sy-ucomm,
      gv_save_ok TYPE sy-ucomm,
      BEGIN OF gs_tab,
        title1  TYPE string VALUE 'Tab 1',                  "#EC NOTEXT
        title2  TYPE string VALUE 'Tab 2',                  "#EC NOTEXT
        title3  TYPE string VALUE 'Tab 3',                  "#EC NOTEXT
        title4  TYPE string VALUE 'Tab 4',                  "#EC NOTEXT
        title5  TYPE string VALUE 'Tab 5',                  "#EC NOTEXT
        title6  TYPE string VALUE 'Tab 6',                  "#EC NOTEXT
        title7  TYPE string VALUE 'Tab 7',                  "#EC NOTEXT
        title8  TYPE string VALUE 'Tab 8',                  "#EC NOTEXT
        title9  TYPE string VALUE 'Tab 9',                  "#EC NOTEXT
        title10 TYPE string VALUE 'Tab 10',                 "#EC NOTEXT
        title11 TYPE string VALUE 'Tab 11',                 "#EC NOTEXT
        title12 TYPE string VALUE 'Tab 12',                 "#EC NOTEXT
        title13 TYPE string VALUE 'Tab 13',                 "#EC NOTEXT
        title14 TYPE string VALUE 'Tab 14',                 "#EC NOTEXT
        title15 TYPE string VALUE 'Tab 15',                 "#EC NOTEXT
        title16 TYPE string VALUE 'Tab 16',                 "#EC NOTEXT
        title17 TYPE string VALUE 'Tab 17',                 "#EC NOTEXT
        title18 TYPE string VALUE 'Tab 18',                 "#EC NOTEXT
        title19 TYPE string VALUE 'Tab 19',                 "#EC NOTEXT
        title20 TYPE string VALUE 'Tab 20',                 "#EC NOTEXT
        title21 TYPE string VALUE 'Tab 21',                 "#EC NOTEXT
        title22 TYPE string VALUE 'Tab 22',                 "#EC NOTEXT
        title23 TYPE string VALUE 'Tab 23',                 "#EC NOTEXT
        title24 TYPE string VALUE 'Tab 24',                 "#EC NOTEXT
        title25 TYPE string VALUE 'Tab 25',                 "#EC NOTEXT
        title26 TYPE string VALUE 'Tab 26',                 "#EC NOTEXT
        title27 TYPE string VALUE 'Tab 27',                 "#EC NOTEXT
        title28 TYPE string VALUE 'Tab 28',                 "#EC NOTEXT
        title29 TYPE string VALUE 'Tab 29',                 "#EC NOTEXT
        title30 TYPE string VALUE 'Tab 30',                 "#EC NOTEXT
      END OF gs_tab.
CONTROLS go_tabstrip TYPE TABSTRIP.

* Constants
CONSTANTS : gc_ddic_col1               TYPE mtreeitm-item_name  VALUE 'FIELDNAME', "#EC NOTEXT
            gc_ddic_col2               TYPE mtreeitm-item_name  VALUE 'F4', "#EC NOTEXT
            gc_ddic_col3               TYPE mtreeitm-item_name  VALUE 'DESCRIPTION', "#EC NOTEXT
            gc_ddic_col4               TYPE mtreeitm-item_name  VALUE 'CONVEXIT', "#EC NOTEXT
            gc_ddic_col5               TYPE mtreeitm-item_name  VALUE 'DATATYPE', "#EC NOTEXT
            gc_ddic_col6               TYPE mtreeitm-item_name  VALUE 'LENG', "#EC NOTEXT
            gc_visibility_all          TYPE ybt_toad-visibility VALUE '2',
            gc_visibility_shared       TYPE ybt_toad-visibility VALUE '1',
            gc_visibility_my           TYPE ybt_toad-visibility VALUE '0',
            gc_visibility_group        TYPE ybt_toad-visibility VALUE '3',
            gc_nodekey_repgo_my        TYPE mtreesnode-node_key VALUE 'MY',
            gc_nodekey_repgo_shared    TYPE mtreesnode-node_key VALUE 'SHARED',
            gc_nodekey_repgo_history   TYPE mtreesnode-node_key VALUE 'HISTO',
            gc_nodekey_repgo_extsource TYPE mtreesnode-node_key VALUE 'EXTSOURCE',
            gc_line_max                TYPE i VALUE 150,
            gc_msg_success             TYPE c VALUE 'S',
            gc_msg_error               TYPE c VALUE 'E',
            gc_msg_information         TYPE c VALUE 'I',
            gc_vers_active             TYPE as4local VALUE 'A',
            gc_ddic_dtelm              TYPE comptype VALUE 'E',
            gc_native_command          TYPE string VALUE 'NATIVE',
            gc_query_max_exec          TYPE i VALUE 36,

            gc_xmlnode_root            TYPE string VALUE 'root', "#EC NOTEXT
            gc_xmlnode_file            TYPE string VALUE 'query', "#EC NOTEXT
            gc_xmlattr_visibility      TYPE string VALUE 'visibility', "#EC NOTEXT
            gc_xmlattr_text            TYPE string VALUE 'description'. "#EC NOTEXT

DATA: gv_action_flag,
      gs_s0400       TYPE tys_s0400,
      gs_return      TYPE ddshretval,
      gt_return      TYPE TABLE OF ddshretval.

DATA: gt_code_string TYPE TABLE OF string,
      gt_table_w     TYPE tyt_table_w.


*######################################################################*
*
*                             CLASS SECTION
*
*######################################################################*
*----------------------------------------------------------------------*
*       CLASS lcl_drag_object DEFINITION
*----------------------------------------------------------------------*
*       Class to store object on drag & drop from DDIC to sql editor
*----------------------------------------------------------------------*
CLASS lcl_drag_object DEFINITION FINAL.

  PUBLIC SECTION.
    DATA field TYPE string.

ENDCLASS."lcl_drag_object DEFINITION

*----------------------------------------------------------------------*
*       CLASS lcl_application DEFINITION
*----------------------------------------------------------------------*
*       Class to handle application events
*----------------------------------------------------------------------*
CLASS lcl_application DEFINITION FINAL.

  PUBLIC SECTION.
    METHODS :
* Handle F1 call on ABAP editor
      hnd_editor_f1
        FOR EVENT f1 OF cl_gui_abapedit,

* Handle Node double clic on ddic tree
      hnd_ddic_item_dblclick
        FOR EVENT item_double_click                OF cl_gui_column_tree
        IMPORTING node_key,

* Handle context menu display on repository tree
      hnd_repgo_context_menu
        FOR EVENT node_context_menu_request        OF cl_gui_simple_tree
        IMPORTING menu,

* Handle context menu clic on repository tree
      hnd_repgo_context_menu_sel
        FOR EVENT node_context_menu_select         OF cl_gui_simple_tree
        IMPORTING fcode,

* Handle Node double clic on repository tree
      hnd_repgo_dblclick
        FOR EVENT node_double_click                OF cl_gui_simple_tree
        IMPORTING node_key,

* Handle repository toolbar clic
      hnd_repgo_toolbar_clic
        FOR EVENT function_selected                OF cl_gui_toolbar
        IMPORTING fcode,

* Handle toolbar display on ALV result
      hnd_result_toolbar
        FOR EVENT toolbar                          OF cl_gui_alv_grid
        IMPORTING e_object,

* Handle toolbar clic on ALV result
      hnd_result_user_command
        FOR EVENT user_command                     OF cl_gui_alv_grid
        IMPORTING e_ucomm,

* Handle DDIC tree drag
      hnd_ddic_drag
        FOR EVENT on_drag                          OF cl_gui_column_tree
        IMPORTING node_key drag_drop_object,

* Handle editor drop
      hnd_editor_drop
        FOR EVENT on_drop                          OF cl_gui_abapedit
        IMPORTING line pos dragdrop_object,

* Handle ddic toolbar clic
      hnd_ddic_toolbar_clic
        FOR EVENT function_selected                OF cl_gui_toolbar
        IMPORTING fcode.

ENDCLASS.                    "lcl_application DEFINITION
*----------------------------------------------------------------------*
*       CLASS LCL_APPLICATION IMPLEMENTATION
*----------------------------------------------------------------------*
*       Class to handle application events                             *
*----------------------------------------------------------------------*
CLASS lcl_application IMPLEMENTATION.
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_repgo_context_menu
*&---------------------------------------------------------------------*
*       Handle context menu display on repository tree
*----------------------------------------------------------------------*
  METHOD hnd_repgo_context_menu.

    DATA l_node_key TYPE tv_nodekey.

    CALL METHOD go_tree_repository->get_selected_node
      IMPORTING
        node_key = l_node_key.

* For History node, add a "delete all" entry
* Only if there is at least 1 history entry
    CASE l_node_key.
      WHEN gc_nodekey_repgo_history.
        CALL METHOD menu->add_function
          EXPORTING
            text  = 'Delete All'(m36)
            icon  = '@02@'
            fcode = 'DELETE_HIST'.

      WHEN gc_nodekey_repgo_extsource.
        CALL METHOD menu->add_function
          EXPORTING
            text  = 'Delete All'(m36)
            icon  = '@02@'
            fcode = 'DELETE_EXTSOURCE'.

      WHEN OTHERS.
* Add Delete option only for own queries
        READ TABLE gt_node_repository INTO gs_node_repository
                   WITH KEY node_key = l_node_key.
        IF sy-subrc NE 0 OR gs_node_repository-edit = space.
          RETURN.
        ENDIF.

        CALL METHOD menu->add_function
          EXPORTING
            text  = 'Delete'(m01)
            icon  = '@02@'
            fcode = 'DELETE_QUERY'.
    ENDCASE.

  ENDMETHOD.                    "hnd_repgo_context_menu
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_repgo_context_menu_sel
*&---------------------------------------------------------------------*
*       Handle context menu clic on repository tree
*----------------------------------------------------------------------*
  METHOD hnd_repgo_context_menu_sel.

    DATA : l_node_key TYPE tv_nodekey,
           l_subrc    TYPE i,
           ls_histo   LIKE gs_node_repository,
           lv_queryid LIKE ls_histo-queryid.

* Delete stored query
    CASE fcode.
      WHEN 'DELETE_QUERY'.     PERFORM lct_ics_delete_query. " delete single history
      WHEN 'DELETE_HIST'.      PERFORM lct_ics_delete_hist  USING '0'.  " delete all history
      WHEN 'DELETE_EXTSOURCE'. PERFORM lct_ics_delete_hist  USING '4'.  " delete all history
    ENDCASE.

  ENDMETHOD.                    "hnd_repgo_context_menu_sel
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_editor_f1
*&---------------------------------------------------------------------*
*       Handle F1 call on ABAP editor
*----------------------------------------------------------------------*
  METHOD hnd_editor_f1.

    DATA : lv_cursor_line_from TYPE i,
           lv_cursor_line_to   TYPE i,
           lv_cursor_pos_from  TYPE i,
           lv_cursor_pos_to    TYPE i,
           lv_offset           TYPE i,
           lv_length           TYPE i,
           lt_query            TYPE soli_tab,
           ls_query            LIKE LINE OF lt_query,
           lv_sel              TYPE string.

* Find active query
    CALL METHOD gs_tab_active-textedit->get_selection_pos
      IMPORTING
        from_line = lv_cursor_line_from
        from_pos  = lv_cursor_pos_from
        to_line   = lv_cursor_line_to
        to_pos    = lv_cursor_pos_to.

* If nothing selected, no help to display
    IF lv_cursor_line_from = lv_cursor_line_to
    AND lv_cursor_pos_to = lv_cursor_pos_from.
      RETURN.
    ENDIF.

* Get content of abap edit box
    CALL METHOD gs_tab_active-textedit->get_text
      IMPORTING
        table  = lt_query[]
      EXCEPTIONS
        OTHERS = 1.

    READ TABLE lt_query INTO ls_query INDEX lv_cursor_line_from.
    IF lv_cursor_line_from = lv_cursor_line_to.
      lv_length = lv_cursor_pos_to - lv_cursor_pos_from.
      lv_offset = lv_cursor_pos_from - 1.
      lv_sel = ls_query+lv_offset(lv_length).
    ELSE.
      lv_offset = lv_cursor_pos_from - 1.
      lv_sel = ls_query+lv_offset.
    ENDIF.

    CALL FUNCTION 'ABAP_DOCU_START'
      EXPORTING
        word = lv_sel.

  ENDMETHOD.                    "hnd_editor_f1
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_ddic_item_dblclick
*&---------------------------------------------------------------------*
*       Handle Node double clic on ddic tree
*----------------------------------------------------------------------*
  METHOD hnd_ddic_item_dblclick.

    DATA : ls_node       LIKE LINE OF gs_tab_active-t_node_ddic,
           lv_line_start TYPE i,
           lv_pos_start  TYPE i,
           lv_line_end   TYPE i,
           lv_pos_end    TYPE i,
           lv_data       TYPE string.

* Check clicked node is valid
    READ TABLE gs_tab_active-t_node_ddic INTO ls_node
               WITH KEY node_key = node_key.
    IF sy-subrc NE 0 OR ls_node-isfolder = abap_true.
      RETURN.
    ENDIF.

* Get text for the node selected
    PERFORM ddic_get_field_from_node USING node_key ls_node-relatkey
                                     CHANGING lv_data.

* Get current cursor position/selection in editor
    CALL METHOD gs_tab_active-textedit->get_selection_pos
      IMPORTING
        from_line = lv_line_start
        from_pos  = lv_pos_start
        to_line   = lv_line_end
        to_pos    = lv_pos_end
      EXCEPTIONS
        OTHERS    = 4.
    IF sy-subrc NE 0.
      MESSAGE 'Cannot get cursor position'(m35) TYPE gc_msg_error.
    ENDIF.

*   If text is selected/highlighted, delete it
    IF lv_line_start NE lv_line_end
    OR lv_pos_start NE lv_pos_end.
      CALL METHOD gs_tab_active-textedit->delete_text
        EXPORTING
          from_line = lv_line_start
          from_pos  = lv_pos_start
          to_line   = lv_line_end
          to_pos    = lv_pos_end.
    ENDIF.

    PERFORM editor_paste USING lv_data lv_line_start lv_pos_start.

  ENDMETHOD.                    "hnd_ddic_item_dblclick
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_repgo_dblclick
*&---------------------------------------------------------------------*
*       Handle Node double clic on repository tree
*----------------------------------------------------------------------*
  METHOD hnd_repgo_dblclick.

    DATA lt_query TYPE TABLE OF string.

    READ TABLE gt_node_repository INTO gs_node_repository
               WITH KEY node_key = node_key.
    IF sy-subrc = 0 AND gs_node_repository-isfolder IS INITIAL.
      PERFORM query_load USING gs_node_repository-queryid
                         CHANGING lt_query.

      CASE gs_node_repository-visibility.
        WHEN '4'.
          gt_code_string = lt_query.
          PERFORM edit_and_execute_source.

        WHEN OTHERS.
          CALL METHOD gs_tab_active-textedit->set_text
            EXPORTING
              table  = lt_query
            EXCEPTIONS
              OTHERS = 0.

          PERFORM ddic_refresh_tree.

      ENDCASE.
    ENDIF.

  ENDMETHOD. "hnd_repgo_dblclick
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_result_toolbar
*&---------------------------------------------------------------------*
*       Handle grid toolbar to add specific button
*----------------------------------------------------------------------*
  METHOD hnd_result_toolbar.

    DATA: ls_toolbar  TYPE stb_button.

* Add Separator
    CLEAR ls_toolbar.
    ls_toolbar-function = '&&SEP99'.
    ls_toolbar-butn_type = 3.
    APPEND ls_toolbar TO e_object->mt_toolbar.

* Add button to close the grid
    CLEAR ls_toolbar.
    ls_toolbar-function  = 'CLOSE_GRID'.
    ls_toolbar-icon      = '@3X@'.
    ls_toolbar-quickinfo = 'Close Grid'(m05).
    ls_toolbar-text      = 'Close'(m06).
    ls_toolbar-butn_type = 0.
    ls_toolbar-disabled = space.
    APPEND ls_toolbar TO e_object->mt_toolbar.

  ENDMETHOD.                    "hnd_result_toolbar
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_result_user_command
*&---------------------------------------------------------------------*
*       Handle grid user command to manage specific fcode
*       (menus & toolbar)
*----------------------------------------------------------------------*
  METHOD hnd_result_user_command.

    IF e_ucomm = 'CLOSE_GRID'.
      CALL METHOD go_splitter->set_row_height
        EXPORTING
          id     = 1
          height = 100.
    ENDIF.

  ENDMETHOD. "hnd_result_user_command
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_ddic_drag
*&---------------------------------------------------------------------*
*       Handle drag on DDIC field (store fieldname)
*----------------------------------------------------------------------*
  METHOD hnd_ddic_drag.

    DATA : lo_drag_object TYPE REF TO lcl_drag_object,
           ls_node        LIKE LINE OF gs_tab_active-t_node_ddic,
           lv_text        TYPE string.

    READ TABLE gs_tab_active-t_node_ddic INTO ls_node
               WITH KEY node_key = node_key.
    IF sy-subrc NE 0 OR ls_node-isfolder = abap_true. "may not append
      MESSAGE 'Only fields can be drag&drop to editor'(m34)
               TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.

* Get text for the node selected
    PERFORM ddic_get_field_from_node USING node_key ls_node-relatkey
                                     CHANGING lv_text.

* Store the node text
    CREATE OBJECT lo_drag_object.
    lo_drag_object->field = lv_text.
    drag_drop_object->object = lo_drag_object.

  ENDMETHOD."hnd_ddic_drag
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_editor_drop
*&---------------------------------------------------------------------*
*       Handle drop on SQL Editor : paste fieldname at cursor position
*----------------------------------------------------------------------*
  METHOD hnd_editor_drop.

    DATA lo_drag_object TYPE REF TO lcl_drag_object.

    lo_drag_object ?= dragdrop_object->object.
    IF lo_drag_object IS INITIAL OR lo_drag_object->field IS INITIAL.
      RETURN.
    ENDIF.

* Paste fieldname to editor at drop position
    PERFORM editor_paste USING lo_drag_object->field line pos.

  ENDMETHOD."hnd_editor_drop
*&---------------------------------------------------------------------*
*&      CLASS lcl_application
*&      METHOD hnd_ddic_toolbar_clic
*&---------------------------------------------------------------------*
*       Handle DDIC toolbar button clic
*----------------------------------------------------------------------*
  METHOD hnd_ddic_toolbar_clic.

    CASE fcode.
      WHEN 'REFRESH'.
        PERFORM ddic_refresh_tree.
      WHEN 'FIND'.
        PERFORM ddic_find_in_tree.
      WHEN 'F4'.
        PERFORM ddic_f4.
    ENDCASE.

  ENDMETHOD.                    "hnd_ddic_toolbar_clic

  METHOD hnd_repgo_toolbar_clic.

    CASE fcode.
      WHEN 'REFRESH'.
        PERFORM repgo_make_query_history.
    ENDCASE.

  ENDMETHOD.                    "hnd_repgo_toolbar_clic
ENDCLASS.                    "lcl_application IMPLEMENTATION
*--------------------------------------------------------------------*
*  subpool 생성 -> 실행을 대체할 source
CLASS lcl_dyn_sql_runner DEFINITION FINAL.
  PUBLIC SECTION.
    METHODS run_sql_into_ref
      IMPORTING iv_sql  TYPE string
                iv_pkg  TYPE i DEFAULT 5000
      CHANGING  po_tab  TYPE REF TO data   " 호출자가 준비한 itab 참조
                pv_time TYPE p
                pv_cnt  TYPE i
                pv_show TYPE c.
ENDCLASS.

CLASS lcl_dyn_sql_runner IMPLEMENTATION.
  METHOD run_sql_into_ref.
    DATA t0 TYPE timestampl.
    DATA t1 TYPE timestampl.
    GET TIME STAMP FIELD t0.

    TRY.
        DATA(lo_con)  = cl_sql_connection=>get_connection( ).
        DATA(lo_stmt) = lo_con->create_statement( ).
        DATA(lo_res)  = lo_stmt->execute_query( iv_sql ).

*        IF iv_pkg > 0.
*          lo_res->set_package_size( iv_pkg ).
*        ENDIF.

        FIELD-SYMBOLS <lt_out> TYPE STANDARD TABLE.
        ASSIGN po_tab->* TO <lt_out>.

        DATA lr_pkg TYPE REF TO data.
        CREATE DATA lr_pkg LIKE <lt_out>.
        FIELD-SYMBOLS <lt_pkg> TYPE STANDARD TABLE.
        ASSIGN lr_pkg->* TO <lt_pkg>.

        lo_res->set_param_table( lr_pkg ).

        WHILE lo_res->next_package( ) > 0.
          INSERT LINES OF <lt_pkg> INTO TABLE <lt_out>.
          CLEAR <lt_pkg>.
        ENDWHILE.

        lo_res->close( ).
*    lo_stmt->close( ).
        lo_con->close( ).

      CATCH cx_sql_exception.

    ENDTRY.

    pv_cnt  = lines( <lt_out> ).
    pv_show = abap_true.

    GET TIME STAMP FIELD t1.
    pv_time = t1 - t0.
  ENDMETHOD.
ENDCLASS.

*=== Injected Local Utility (ABAP 7.50 / 75I) ============================*
CLASS lcl_toad_util DEFINITION FINAL.
  PUBLIC SECTION.
    TYPES: BEGIN OF tys_table_alias,
             table TYPE string,
             alias TYPE string,
           END OF tys_table_alias,
           tyt_table_alias TYPE STANDARD TABLE OF tys_table_alias WITH EMPTY KEY.

    CLASS-METHODS extract_tables_and_aliases
      IMPORTING
        iv_from         TYPE string
        iv_union_all    TYPE string OPTIONAL
      RETURNING
        VALUE(rt_pairs) TYPE tyt_table_alias.

    CLASS-METHODS add_toolbar_button
      EXPORTING
        es_button TYPE stb_button
      CHANGING
        cs_button TYPE stb_button.

    CLASS-METHODS get_dfies_buffered
      IMPORTING
        iv_tabname      TYPE tabname
        iv_fieldname    TYPE dfies-fieldname OPTIONAL
        iv_all_types    TYPE abap_bool DEFAULT abap_false
      RETURNING
        VALUE(rt_dfies) TYPE dfies_table.

    CLASS-METHODS soli_tab_to_string
      IMPORTING
        it_query        TYPE soli_tab
      RETURNING
        VALUE(rv_query) TYPE string.

    CLASS-METHODS string_tab_to_string
      IMPORTING
        it_lines             TYPE tyt_string
        iv_add_source_header TYPE abap_bool DEFAULT abap_false
      RETURNING
        VALUE(rv_text)       TYPE string.

  PRIVATE SECTION.
    TYPES: BEGIN OF tys_dfies_cache_val,
             tabname   TYPE tabname,
             all_types TYPE abap_bool,
             dfies_tab TYPE dfies_table,
           END OF tys_dfies_cache_val.
    CLASS-DATA mt_dfies_cache TYPE HASHED TABLE OF tys_dfies_cache_val
                               WITH UNIQUE KEY tabname all_types.

    CLASS-METHODS read_token
      IMPORTING iv_sql TYPE string
                iv_pos TYPE i
      EXPORTING ev_tok TYPE string
                ev_end TYPE i.                 " 다음 읽기 위치
    CLASS-METHODS is_keyword
      IMPORTING iv_tok        TYPE string
      RETURNING VALUE(rv_yes) TYPE abap_bool.

ENDCLASS.

CLASS lcl_toad_util IMPLEMENTATION.

  METHOD extract_tables_and_aliases.

    DATA: lv_sql   TYPE string,
          lv_char  TYPE c LENGTH 1,
          lv_in_q  TYPE abap_bool VALUE abap_false,
          lv_depth TYPE i         VALUE 0,
          lv_i     TYPE i,
          lv_n     TYPE i.

    "-------------------------------
    " 0) 전처리 (플러스는 건드리지 않음)
    "-------------------------------
    lv_sql = to_upper( iv_from ).
    IF iv_union_all IS NOT INITIAL.
      lv_sql = lv_sql && space && to_upper( iv_union_all ).
    ENDIF.

    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_sql WITH space.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_sql WITH space.
    CONDENSE lv_sql.  " NO-GAPS 금지

    " fragment 가드: 'FROM'으로 시작하지 않고, 토큰 ' FROM '도 없으면 앞에 붙이기
    IF NOT ( lv_sql CP |FROM*| ) AND NOT ( lv_sql CS | FROM | ).
      CONCATENATE 'FROM' lv_sql INTO lv_sql SEPARATED BY space.
    ENDIF.

    CLEAR rt_pairs.
    lv_in_q  = abap_false.
    lv_depth = 0.

    "-------------------------------
    " 1) 단일 스캔
    "-------------------------------
    lv_i = 0.
    lv_n = strlen( lv_sql ).

    WHILE lv_i < lv_n.
      lv_char = lv_sql+lv_i(1).

      " 문자열리터럴 스킵 ('' 이스케이프)
      IF lv_char = ''''.
        DATA lv_off_next TYPE i.
        DATA lv_ch_next  TYPE c LENGTH 1.
        lv_off_next = lv_i + 1.
        IF lv_in_q = abap_true AND lv_off_next < lv_n.
          lv_ch_next = lv_sql+lv_off_next(1).
          IF lv_ch_next = ''''.
            lv_i = lv_i + 2.
            CONTINUE.
          ENDIF.
        ENDIF.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1.
        CONTINUE.
      ENDIF.

      IF lv_in_q = abap_false.
        " 괄호 깊이
        IF lv_char = '('.
          lv_depth = lv_depth + 1.
          lv_i = lv_i + 1.
          CONTINUE.
        ELSEIF lv_char = ')'.
          IF lv_depth > 0.
            lv_depth = lv_depth - 1.
          ENDIF.
          lv_i = lv_i + 1.
          CONTINUE.
        ENDIF.

        IF lv_depth = 0.

          "---------------------------
          " FROM 토큰 (공백 없이도 허용)
          "---------------------------
          IF lv_i + 3 < lv_n AND lv_sql+lv_i(4) = |FROM|.
            DATA lv_off_prev TYPE i.
            DATA lv_off_after TYPE i.
            DATA lv_prev TYPE c LENGTH 1.
            DATA lv_next TYPE c LENGTH 1.

            " 이전 문자
            IF lv_i = 0.
              lv_prev = space.
            ELSE.
              lv_off_prev = lv_i - 1.
              lv_prev     = lv_sql+lv_off_prev(1).
            ENDIF.

            " 다음 문자 (FROM 뒤)
            lv_off_after = lv_i + 4.
            IF lv_off_after < lv_n.
              lv_next = lv_sql+lv_off_after(1).
            ELSE.
              CLEAR lv_next. " 문자열 끝
            ENDIF.

            " 경계 허용: 이전은 SPACE/)/,/;/(탭/개행), 다음은 SPACE/+/"/(,/;/(탭/개행)/끝
            IF ( lv_i = 0 OR lv_prev = space OR lv_prev = ')' OR lv_prev = ',' OR
                 lv_prev = ';' OR lv_prev = cl_abap_char_utilities=>horizontal_tab OR
                 lv_prev = cl_abap_char_utilities=>newline )
            AND
               ( lv_off_after = lv_n OR lv_next = space OR lv_next = '+' OR
                 lv_next = '"' OR lv_next = '(' OR lv_next = ',' OR lv_next = ';' OR
                 lv_next = cl_abap_char_utilities=>horizontal_tab OR
                 lv_next = cl_abap_char_utilities=>newline ).

              DATA(lv_pos) = lv_off_after.
              WHILE lv_pos < lv_n AND lv_sql+lv_pos(1) = space.
                lv_pos = lv_pos + 1.
              ENDWHILE.

              DATA: lv_tab TYPE string,
                    lv_end TYPE i.
              read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos
                          IMPORTING ev_tok = lv_tab ev_end = lv_pos ).

              IF lv_tab IS NOT INITIAL.
                DATA(ls_pair) = VALUE tys_table_alias( table = lv_tab alias = '' ).

                " 선택적 AS / 암묵 별칭
                WHILE lv_pos < lv_n AND lv_sql+lv_pos(1) = space.
                  lv_pos = lv_pos + 1.
                ENDWHILE.

                DATA: lv_tok    TYPE string,
                      lv_end_as TYPE i.
                read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos
                            IMPORTING ev_tok = lv_tok ev_end = lv_end_as ).

                IF to_upper( lv_tok ) = |AS|.
                  lv_pos = lv_end_as.
                  WHILE lv_pos < lv_n AND lv_sql+lv_pos(1) = space.
                    lv_pos = lv_pos + 1.
                  ENDWHILE.
                  read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos
                              IMPORTING ev_tok = ls_pair-alias ev_end = lv_pos ).
                ELSEIF lv_tok IS NOT INITIAL AND is_keyword( lv_tok ) = abap_false.
                  ls_pair-alias = lv_tok.
                  lv_pos = lv_end_as.
                ENDIF.

                APPEND ls_pair TO rt_pairs.
                lv_i = lv_pos.
                CONTINUE.
              ENDIF.
            ENDIF.
          ENDIF.

          "---------------------------
          " JOIN 토큰 (FROM과 동일한 경계 규칙으로 감지)
          "---------------------------
          IF lv_i + 3 < lv_n AND lv_sql+lv_i(4) = |JOIN|.
            DATA lv_off_prev2  TYPE i.
            DATA lv_off_after2 TYPE i.
            DATA lv_prev2 TYPE c LENGTH 1.
            DATA lv_next2 TYPE c LENGTH 1.

            " 이전 문자
            IF lv_i = 0.
              lv_prev2 = space.
            ELSE.
              lv_off_prev2 = lv_i - 1.
              lv_prev2     = lv_sql+lv_off_prev2(1).
            ENDIF.

            " 다음 문자 (JOIN 뒤)
            lv_off_after2 = lv_i + 4.
            IF lv_off_after2 < lv_n.
              lv_next2 = lv_sql+lv_off_after2(1).
            ELSE.
              CLEAR lv_next2.
            ENDIF.

            " FROM과 동일: 이전은 SPACE/)/,/;/(탭/개행), 다음은 SPACE/+/"/(,/;/(탭/개행)/끝
            IF ( lv_i = 0 OR lv_prev2 = space OR lv_prev2 = ')' OR lv_prev2 = ',' OR
                 lv_prev2 = ';' OR lv_prev2 = cl_abap_char_utilities=>horizontal_tab OR
                 lv_prev2 = cl_abap_char_utilities=>newline )
            AND
               ( lv_off_after2 = lv_n OR lv_next2 = space OR lv_next2 = '+' OR
                 lv_next2 = '"' OR lv_next2 = '(' OR lv_next2 = ',' OR lv_next2 = ';' OR
                 lv_next2 = cl_abap_char_utilities=>horizontal_tab OR
                 lv_next2 = cl_abap_char_utilities=>newline ).

              DATA(lv_pos2) = lv_off_after2.
              WHILE lv_pos2 < lv_n AND lv_sql+lv_pos2(1) = space.
                lv_pos2 = lv_pos2 + 1.
              ENDWHILE.

              DATA: lv_tab2 TYPE string,
                    lv_end2 TYPE i.
              read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos2
                          IMPORTING ev_tok = lv_tab2 ev_end = lv_pos2 ).

              IF lv_tab2 IS NOT INITIAL.
                DATA(ls_pair2) = VALUE tys_table_alias( table = lv_tab2 alias = '' ).

                WHILE lv_pos2 < lv_n AND lv_sql+lv_pos2(1) = space.
                  lv_pos2 = lv_pos2 + 1.
                ENDWHILE.

                DATA lv_tok2    TYPE string.
                DATA lv_end_as2 TYPE i.
                read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos2
                            IMPORTING ev_tok = lv_tok2 ev_end = lv_end_as2 ).

                IF to_upper( lv_tok2 ) = |AS|.
                  lv_pos2 = lv_end_as2.
                  WHILE lv_pos2 < lv_n AND lv_sql+lv_pos2(1) = space.
                    lv_pos2 = lv_pos2 + 1.
                  ENDWHILE.
                  read_token( EXPORTING iv_sql = lv_sql iv_pos = lv_pos2
                              IMPORTING ev_tok = ls_pair2-alias ev_end = lv_pos2 ).
                ELSEIF lv_tok2 IS NOT INITIAL AND is_keyword( lv_tok2 ) = abap_false.
                  ls_pair2-alias = lv_tok2.
                  lv_pos2 = lv_end_as2.
                ENDIF.

                APPEND ls_pair2 TO rt_pairs.
                lv_i = lv_pos2.
                CONTINUE.
              ENDIF.
            ENDIF.
          ENDIF.

        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.

  ENDMETHOD.

  METHOD read_token.

    " 허용 문자: A-Z 0-9 _ $ # . + /   (CTE '+V_*', 네임스페이스 '/BIC/...') 보존
    DATA lv_pos TYPE i.
    lv_pos = iv_pos.
    DATA lv_len TYPE i.
    ev_tok = ''. ev_end = lv_pos.

    IF lv_pos >= strlen( iv_sql ).
      RETURN.
    ENDIF.

    DATA lv_c TYPE c LENGTH 1.
    lv_c = iv_sql+lv_pos(1).

    " 쿼티드 식별자 "ALIAS" / "SCHEMA.TABLE"
    IF lv_c = '"'.
      lv_pos = lv_pos + 1.
      DATA(lv_beg) = lv_pos.
      WHILE lv_pos < strlen( iv_sql ) AND iv_sql+lv_pos(1) <> '"'.
        lv_pos = lv_pos + 1.
      ENDWHILE.
      lv_len = lv_pos - lv_beg.
      ev_tok = iv_sql+lv_beg(lv_len).
      IF lv_pos < strlen( iv_sql ).
        lv_pos = lv_pos + 1.   " 닫는 쿼트
      ENDIF.
      ev_end = lv_pos.
      RETURN.
    ENDIF.

    " 비쿼티드 토큰
    DATA lv_b TYPE i.
    IF iv_sql+lv_pos(1) CO 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.$#+/'.
    ELSE.
      lv_pos = lv_pos + 1.
    ENDIF.

    lv_b = lv_pos.
    WHILE lv_pos < strlen( iv_sql ).
      lv_c = iv_sql+lv_pos(1).
      IF lv_c CO 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.$#+/'.
        lv_pos = lv_pos + 1.
      ELSE.
        EXIT.
      ENDIF.
    ENDWHILE.

    lv_len = lv_pos - lv_b.
    ev_tok = iv_sql+lv_b(lv_len).
    ev_end = lv_pos.

  ENDMETHOD.

  METHOD is_keyword.

    DATA lt_kw TYPE STANDARD TABLE OF string WITH EMPTY KEY.

    lt_kw = VALUE #(
      ( |FROM| ) ( |AS| ) ( |JOIN| )
      ( |LEFT| ) ( |RIGHT| ) ( |FULL| ) ( |OUTER| ) ( |INNER| ) ( |CROSS| ) ( |NATURAL| )
      ( |ON| ) ( |WHERE| ) ( |GROUP| ) ( |ORDER| ) ( |HAVING| ) ( |UNION| ) ( |BY| )
    ).

    DATA lv_up TYPE string.
    lv_up = to_upper( iv_tok ).
    READ TABLE lt_kw WITH KEY table_line = lv_up TRANSPORTING NO FIELDS.
    rv_yes = xsdbool( sy-subrc = 0 ).

  ENDMETHOD.

  METHOD add_toolbar_button.

    es_button = cs_button.

  ENDMETHOD.

  METHOD get_dfies_buffered.

    DATA lv_all_types TYPE abap_bool.

    FIELD-SYMBOLS <ls_cache> TYPE tys_dfies_cache_val.

    IF iv_all_types = abap_true.
      lv_all_types = abap_true.
    ELSE.
      CLEAR lv_all_types.
    ENDIF.

    READ TABLE mt_dfies_cache ASSIGNING <ls_cache>
      WITH TABLE KEY tabname   = iv_tabname
                     all_types = lv_all_types.
    IF sy-subrc = 0.
      rt_dfies = <ls_cache>-dfies_tab.
      IF iv_fieldname IS NOT INITIAL.
        DELETE rt_dfies WHERE fieldname <> iv_fieldname.
      ENDIF.
      RETURN.
    ENDIF.

    CALL FUNCTION 'DDIF_FIELDINFO_GET'
      EXPORTING
        tabname        = iv_tabname
        langu          = sy-langu
        all_types      = lv_all_types
      TABLES
        dfies_tab      = rt_dfies
      EXCEPTIONS
        not_found      = 1
        internal_error = 2
        OTHERS         = 3.
    IF sy-subrc = 0.
      INSERT VALUE #( tabname   = iv_tabname
                      all_types = lv_all_types
                      dfies_tab = rt_dfies )
        INTO TABLE mt_dfies_cache.
    ENDIF.

    IF iv_fieldname IS NOT INITIAL.
      DELETE rt_dfies WHERE fieldname <> iv_fieldname.
    ENDIF.

  ENDMETHOD.

  METHOD soli_tab_to_string.

    LOOP AT it_query INTO DATA(ls_query).
      CONCATENATE rv_query ls_query cl_abap_char_utilities=>cr_lf
                  INTO rv_query.
    ENDLOOP.

  ENDMETHOD.

  METHOD string_tab_to_string.

    DATA lv_first TYPE abap_bool VALUE abap_true.

    LOOP AT it_lines INTO DATA(lv_line).
      IF iv_add_source_header = abap_true
         AND lv_first = abap_true
         AND lv_line IS NOT INITIAL
         AND lv_line+0(1) <> '*'.
        CONCATENATE '* Source of Execution Program'
                    cl_abap_char_utilities=>cr_lf
                    INTO rv_text.
      ENDIF.

      CLEAR lv_first.
      CONCATENATE rv_text lv_line cl_abap_char_utilities=>cr_lf
                  INTO rv_text.
    ENDLOOP.

  ENDMETHOD.
ENDCLASS.


*--------------------------------------------------------------------*
* Local class : Source editor tab adapter
*--------------------------------------------------------------------*
CLASS lcl_toad_source_editor DEFINITION FINAL.

  PUBLIC SECTION.
    CONSTANTS gc_tab_type_editor TYPE ty_toad_tabtype VALUE 'E'.

    CLASS-METHODS is_source_tab
      RETURNING VALUE(rv_is_source_tab) TYPE abap_bool.

    CLASS-METHODS create_tab.

    CLASS-METHODS save_current_tab.

    CLASS-METHODS set_active_title.

  PRIVATE SECTION.
    CLASS-METHODS get_active_tabix
      RETURNING VALUE(rv_tabix) TYPE sy-tabix.

    CLASS-METHODS update_active_tab.

    CLASS-METHODS request_program
      RETURNING VALUE(rv_prog) TYPE programm.

    CLASS-METHODS read_trdir
      IMPORTING
        iv_prog      TYPE programm
      EXPORTING
        es_trdir     TYPE trdir
        ev_is_new    TYPE abap_bool
        ev_prog_type TYPE ty_toad_progtyp.

    CLASS-METHODS find_mainprog
      IMPORTING
        iv_prog             TYPE programm
      RETURNING
        VALUE(rv_main_prog) TYPE programm.

    CLASS-METHODS syntax_check
      IMPORTING
        iv_prog      TYPE programm
        iv_main_prog TYPE programm
        it_src       TYPE tyt_source
      EXPORTING
        ev_err_inc   TYPE programm
        ev_err_line  TYPE i
        ev_err_msg   TYPE string
        ev_err_offs  TYPE i
        ev_err_subrc TYPE sy-subrc.

    CLASS-METHODS confirm_on_error
      IMPORTING
        iv_err_inc      TYPE programm
        iv_err_line     TYPE i
        iv_err_msg      TYPE string
      RETURNING
        VALUE(rv_go_on) TYPE abap_bool.

    CLASS-METHODS save_new
      IMPORTING
        iv_prog         TYPE programm
        is_trdir        TYPE trdir
        it_src          TYPE tyt_source
      RETURNING
        VALUE(rv_subrc) TYPE sy-subrc.

    CLASS-METHODS save_update
      IMPORTING
        iv_prog         TYPE programm
        iv_prog_type    TYPE ty_toad_progtyp
        it_src          TYPE tyt_source
      RETURNING
        VALUE(rv_subrc) TYPE sy-subrc.
ENDCLASS.

CLASS lcl_toad_source_editor IMPLEMENTATION.

  METHOD is_source_tab.

    rv_is_source_tab = xsdbool( gs_tab_active-tab_type = gc_tab_type_editor ).

  ENDMETHOD.

  METHOD get_active_tabix.

    DATA lv_tabix_c TYPE c LENGTH 2.

    IF go_tabstrip-activetab IS INITIAL.
      rv_tabix = 1.
      RETURN.
    ENDIF.

    lv_tabix_c = go_tabstrip-activetab+3.
    CONDENSE lv_tabix_c NO-GAPS.
    rv_tabix = lv_tabix_c.

    IF rv_tabix IS INITIAL.
      rv_tabix = 1.
    ENDIF.

  ENDMETHOD.

  METHOD update_active_tab.

    DATA(lv_tabix) = get_active_tabix( ).

    IF lv_tabix > 0.
      MODIFY gt_tabs FROM gs_tab_active INDEX lv_tabix.
    ENDIF.

  ENDMETHOD.

  METHOD set_active_title.
    DATA lv_name  TYPE c LENGTH 30.
    DATA lv_title TYPE string.

    FIELD-SYMBOLS <lv_fld_title> TYPE any.

    lv_name = |GS_TAB-TITLE{ get_active_tabix( ) }|.
    ASSIGN (lv_name) TO <lv_fld_title>.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    IF gs_tab_active-prog_name IS INITIAL.
      lv_title = 'ABAP Source'.
    ELSE.
      lv_title = |ABAP:{ gs_tab_active-prog_name }|.
    ENDIF.

    <lv_fld_title> = lv_title.
  ENDMETHOD.

  METHOD request_program.
    DATA: lt_sval       TYPE TABLE OF sval,
          ls_sval       TYPE sval,
          lv_returncode TYPE c.

    CLEAR ls_sval.
    ls_sval-tabname   = 'TRDIR'.
    ls_sval-fieldname = 'NAME'.
    APPEND ls_sval TO lt_sval.

    CALL FUNCTION 'POPUP_GET_VALUES'
      EXPORTING
        popup_title     = 'ABAP Source Program'
      IMPORTING
        returncode      = lv_returncode
      TABLES
        fields          = lt_sval
      EXCEPTIONS
        error_in_fields = 1
        OTHERS          = 2.
    IF sy-subrc <> 0 OR lv_returncode <> space.
      RETURN.
    ENDIF.

    READ TABLE lt_sval INTO ls_sval INDEX 1.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    rv_prog = ls_sval-value.
    TRANSLATE rv_prog TO UPPER CASE.
    CONDENSE rv_prog NO-GAPS.
  ENDMETHOD.

  METHOD read_trdir.
    CLEAR: es_trdir, ev_is_new, ev_prog_type.

    SELECT SINGLE subc, uccheck, fixpt
      FROM trdir
      WHERE name = @iv_prog
      INTO CORRESPONDING FIELDS OF @es_trdir.

    IF sy-subrc <> 0.
      ev_is_new        = abap_true.
      es_trdir-name    = iv_prog.
      es_trdir-subc    = '1'.
      es_trdir-uccheck = 'X'.
      es_trdir-fixpt   = 'X'.
      ev_prog_type     = es_trdir-subc.
    ELSE.
      ev_is_new    = abap_false.
      ev_prog_type = COND #( WHEN es_trdir-subc IS INITIAL THEN '1'
                             ELSE es_trdir-subc ).
    ENDIF.
  ENDMETHOD.

  METHOD find_mainprog.
    DATA lt_main TYPE TABLE OF programm.

    CLEAR rv_main_prog.

    CALL FUNCTION 'RS_GET_MAINPROGRAMS'
      EXPORTING
        name         = iv_prog
      TABLES
        mainprograms = lt_main
      EXCEPTIONS
        cancelled    = 1
        OTHERS       = 2.

    IF sy-subrc = 0 AND lines( lt_main ) > 0.
      READ TABLE lt_main INTO rv_main_prog INDEX 1.
    ENDIF.

    IF rv_main_prog IS INITIAL.
      rv_main_prog = iv_prog.
    ENDIF.
  ENDMETHOD.

  METHOD create_tab.
    DATA: lv_prog      TYPE programm,
          ls_trdir     TYPE trdir,
          lv_is_new    TYPE abap_bool,
          lv_prog_type TYPE ty_toad_progtyp,
          lt_src       TYPE tyt_source.

    lv_prog = request_program( ).
    IF lv_prog IS INITIAL.
      RETURN.
    ENDIF.

    read_trdir(
      EXPORTING
        iv_prog      = lv_prog
      IMPORTING
        es_trdir     = ls_trdir
        ev_is_new    = lv_is_new
        ev_prog_type = lv_prog_type ).

    IF lv_is_new = abap_false.
      READ REPORT lv_prog INTO lt_src.
      IF sy-subrc <> 0.
        MESSAGE i000(oo) WITH '프로그램 소스를 읽을 수 없습니다' lv_prog.
        RETURN.
      ENDIF.
    ENDIF.

    PERFORM tab_new.

    gs_tab_active-tab_type   = gc_tab_type_editor.
    gs_tab_active-prog_name  = lv_prog.
    gs_tab_active-main_prog  = find_mainprog( lv_prog ).
    gs_tab_active-is_new     = lv_is_new.
    gs_tab_active-prog_type  = lv_prog_type.
    gs_tab_active-trdir_info = ls_trdir.
    gs_tab_active-row_height = 100.

    CALL METHOD go_splitter->set_row_height
      EXPORTING
        id     = 1
        height = gs_tab_active-row_height.

    CALL METHOD gs_tab_active-textedit->set_text
      EXPORTING
        table  = lt_src
      EXCEPTIONS
        OTHERS = 1.
    IF sy-subrc <> 0.
      MESSAGE i000(oo) WITH '에디터에 소스를 표시할 수 없습니다' DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.

    IF gs_tab_active-tree_ddic IS BOUND.
      CALL METHOD gs_tab_active-tree_ddic->delete_all_nodes.
    ENDIF.

    gs_tab_active-textedit->set_textmodified_status( ).

    set_active_title( ).
    update_active_tab( ).

    CALL METHOD cl_gui_control=>set_focus
      EXPORTING
        control = gs_tab_active-textedit
      EXCEPTIONS
        OTHERS  = 0.
  ENDMETHOD.

  METHOD syntax_check.
    CLEAR: ev_err_inc, ev_err_line, ev_err_msg, ev_err_offs, ev_err_subrc.

    CALL FUNCTION 'EDITOR_SYNTAX_CHECK'
      EXPORTING
        i_global_check   = 'X'
        i_global_program = iv_main_prog
        i_program        = iv_prog
      IMPORTING
        o_error_include  = ev_err_inc
        o_error_line     = ev_err_line
        o_error_message  = ev_err_msg
        o_error_offset   = ev_err_offs
        o_error_subrc    = ev_err_subrc
      TABLES
        i_source         = it_src.
  ENDMETHOD.

  METHOD confirm_on_error.
    DATA(lv_line_text) = ||.
    DATA(lv_answer)    = VALUE char1( ).

    IF iv_err_line > 0.
      lv_line_text = |{ iv_err_inc } : { iv_err_line }|.
    ENDIF.

    CALL FUNCTION 'POPUP_TO_CONFIRM_WITH_MESSAGE'
      EXPORTING
        defaultoption  = 'N'
        diagnosetext1  = '에러가 있습니다. 그래도 저장 하시겠습니까?'
        textline1      = iv_err_msg
        textline2      = lv_line_text
        titel          = '저장확인'
        cancel_display = space
      IMPORTING
        answer         = lv_answer.

    rv_go_on = COND abap_bool( WHEN lv_answer = 'N'
                               THEN abap_false
                               ELSE abap_true ).
  ENDMETHOD.

  METHOD save_new.
    DATA ls_trdir TYPE trdir.

    ls_trdir = is_trdir.
    ls_trdir-name = iv_prog.

    INSERT REPORT iv_prog FROM it_src DIRECTORY ENTRY ls_trdir.
    rv_subrc = sy-subrc.
  ENDMETHOD.

  METHOD save_update.
    INSERT REPORT iv_prog FROM it_src
           STATE                  'A'
           VERSION                'X'
           FIXED-POINT ARITHMETIC 'X'
           PROGRAM TYPE           iv_prog_type.
    rv_subrc = sy-subrc.
  ENDMETHOD.

  METHOD save_current_tab.
    DATA: lt_src        TYPE tyt_source,
          lv_err_inc    TYPE programm,
          lv_err_line   TYPE i,
          lv_err_msg    TYPE string,
          lv_err_offs   TYPE i,
          lv_err_subrc  TYPE sy-subrc,
          lv_save_subrc TYPE sy-subrc.

    IF is_source_tab( ) = abap_false.
      RETURN.
    ENDIF.

    IF gs_tab_active-prog_name IS INITIAL.
      MESSAGE i000(oo) WITH '저장 대상 프로그램명이 없습니다' DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.

    CALL METHOD gs_tab_active-textedit->get_text
      IMPORTING
        table  = lt_src
      EXCEPTIONS
        OTHERS = 1.
    IF sy-subrc <> 0.
      MESSAGE i000(oo) WITH '에디터 내용을 읽을 수 없습니다' DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.

    syntax_check(
      EXPORTING
        iv_prog      = gs_tab_active-prog_name
        iv_main_prog = gs_tab_active-main_prog
        it_src       = lt_src
      IMPORTING
        ev_err_inc   = lv_err_inc
        ev_err_line  = lv_err_line
        ev_err_msg   = lv_err_msg
        ev_err_offs  = lv_err_offs
        ev_err_subrc = lv_err_subrc ).

    IF lv_err_subrc <> 0.
      IF confirm_on_error(
           iv_err_inc  = lv_err_inc
           iv_err_line = lv_err_line
           iv_err_msg  = lv_err_msg ) = abap_false.
        MESSAGE i000(oo) WITH '저장이 취소되었습니다'.
        RETURN.
      ENDIF.
    ENDIF.

    IF gs_tab_active-is_new = abap_true.
      lv_save_subrc = save_new(
                        iv_prog  = gs_tab_active-prog_name
                        is_trdir = gs_tab_active-trdir_info
                        it_src   = lt_src ).
    ELSE.
      lv_save_subrc = save_update(
                        iv_prog      = gs_tab_active-prog_name
                        iv_prog_type = gs_tab_active-prog_type
                        it_src       = lt_src ).
    ENDIF.

    IF lv_save_subrc <> 0.
      MESSAGE i000(oo) WITH '프로그램 저장 중 오류가 발생했습니다' DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.

    gs_tab_active-is_new = abap_false.
    gs_tab_active-textedit->set_textmodified_status( ).

    set_active_title( ).
    update_active_tab( ).

    MESSAGE i000(oo) WITH '저장되었습니다'.
  ENDMETHOD.
ENDCLASS.

*--------------------------------------------------------------------*
DEFINE c.
  lv_strlen_string = &1.
  PERFORM add_line_to_table USING lv_strlen_string
                            CHANGING lt_code_string.
END-OF-DEFINITION.
DEFINE c1.
  lv_strlen_string = &1.
  PERFORM add_line_to_table USING    lv_strlen_string
                            CHANGING pt_code_string.
END-OF-DEFINITION.
*--------------------------------------------------------------------*
*
*                             MAIN SECTION
*
*--------------------------------------------------------------------*
START-OF-SELECTION.
  CALL SCREEN '0010'.

*--------------------------------------------------------------------*
*
*                             PBO SECTION
*
*--------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0010  OUTPUT
*&---------------------------------------------------------------------*
*       Set status for main screen
*       and initialize custom container at first run
*----------------------------------------------------------------------*
MODULE status_0010 OUTPUT.

* Initialization of object screen
  IF go_container IS INITIAL.
    PERFORM screen_init.
    APPEND gs_tab_active TO gt_tabs.
  ENDIF.

  PERFORM set_status_0010.

ENDMODULE.                 " STATUS_0010  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*       Set status for modal box (save query)
*----------------------------------------------------------------------*
MODULE status_0200 OUTPUT.

* Fill dropdown listbox with values
  PERFORM screen_init_listbox_0200.

  SET PF-STATUS 'S0200'.
  SET TITLEBAR 'S0200'.  " Save Query

ENDMODULE.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0300  OUTPUT
*&---------------------------------------------------------------------*
*       Set status for modal box (options)
*----------------------------------------------------------------------*
MODULE status_0300 OUTPUT.

* Create option screen
  IF go_container_options IS INITIAL.
    PERFORM options_init.
  ENDIF.

  SET PF-STATUS 'S0200'.
  SET TITLEBAR 'S0300'.  " Options panel

ENDMODULE.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*& Module STATUS_0400 OUTPUT
*&---------------------------------------------------------------------*
*&   User group management
*&---------------------------------------------------------------------*
MODULE status_0400 OUTPUT.

  SET PF-STATUS 'S0200'.
  SET TITLEBAR 'S0400'. " User group management

ENDMODULE.
*######################################################################*
*
*                             PAI SECTION
*
*######################################################################*
*&---------------------------------------------------------------------*
*&      Module  get_ok_code  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_ok_code INPUT.

  gv_save_ok = gv_ok_code.
  CLEAR gv_ok_code.

ENDMODULE.                 " get_ok_code  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0010  INPUT
*&---------------------------------------------------------------------*
*       User command for main screen
*----------------------------------------------------------------------*
MODULE user_command_0010 INPUT.

  CASE gv_save_ok.
    WHEN 'EXIT'.       PERFORM screen_exit.

    WHEN 'EXECUTE'.
      IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
        MESSAGE i000(oo) WITH 'ABAP Source 탭에서는 SQL 실행을 사용할 수 없습니다'.
      ELSE.
        PERFORM query_process USING space     space.
      ENDIF.

    WHEN 'DOWNLOAD'.
      IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
        MESSAGE i000(oo) WITH 'ABAP Source 탭에서는 다운로드 실행을 사용할 수 없습니다'.
      ELSE.
        PERFORM query_process USING space     abap_true.
      ENDIF.

    WHEN 'SHOWCODE'.
      IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
        MESSAGE i000(oo) WITH 'ABAP Source 탭에서는 생성코드 조회를 사용할 수 없습니다'.
      ELSE.
        PERFORM query_process USING abap_true space.
      ENDIF.

    WHEN 'SAVE'.
      IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
        lcl_toad_source_editor=>save_current_tab( ).
      ELSE.
        PERFORM repgo_save_query.
      ENDIF.

    WHEN 'HELP'.       PERFORM screen_display_help.
    WHEN 'OPTIONS'.    PERFORM options_display.

    WHEN 'NEW'.        PERFORM tab_new.
    WHEN 'DEL'.        PERFORM tab_del.

    WHEN 'XMLE'.       PERFORM export_xml.
    WHEN 'XMLI'.       PERFORM import_xml.

    WHEN 'USERGRP'.    PERFORM user_group_management.
    WHEN 'EXECSOURCE'. PERFORM edit_and_execute_source .

    WHEN '&EDITOR'.    PERFORM editor_source .

    WHEN OTHERS.
      IF gv_save_ok(3) = 'TAB' AND go_tabstrip-activetab NE gv_save_ok.
        PERFORM leave_current_tab.
        go_tabstrip-activetab = gv_save_ok.
        PERFORM show_new_tab.
      ENDIF.
  ENDCASE.

  CLEAR: gv_save_ok.

ENDMODULE.                 " USER_COMMAND_0010  INPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0200 INPUT.

  CLEAR gs_options.
  LEAVE TO SCREEN 0.

ENDMODULE.                 " exit_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       PAI module for modal box (save query)
*----------------------------------------------------------------------*
MODULE user_command_0200 INPUT.

  CASE gv_save_ok.
    WHEN 'CLOSE'.
      CLEAR gs_options.
      LEAVE TO SCREEN 0.

    WHEN 'OK'.
      LEAVE TO SCREEN 0.
  ENDCASE.
  CLEAR: gv_save_ok.

ENDMODULE.                 " USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0300  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0300 INPUT.

  LEAVE TO SCREEN 0.

ENDMODULE.                 " EXIT_0300  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0300  INPUT
*&---------------------------------------------------------------------*
*       PAI module for modal box (options)
*----------------------------------------------------------------------*
MODULE user_command_0300 INPUT.

  CASE gv_save_ok.
    WHEN 'CLOSE' OR 'OK'.
      LEAVE TO SCREEN 0.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0400  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0400 INPUT.

  gv_action_flag = 'C'.
  LEAVE TO SCREEN 0.

ENDMODULE.                 " EXIT_0400  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0400  INPUT
*&---------------------------------------------------------------------*
*       User group management
*----------------------------------------------------------------------*
MODULE user_command_0400 INPUT.

  CASE gv_save_ok.
    WHEN 'OK'.
      gv_action_flag = 'S'.
      LEAVE TO SCREEN 0.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  CHECK_USERGROUP  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_usergroup INPUT.

  PERFORM check_usergroup.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_USER_GROUP  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_user_group INPUT.

  PERFORM get_user_group.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  F4_USER  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_user INPUT.

  DATA: BEGIN OF ls_user,
          bname     TYPE usr21-bname,
          name_last TYPE adrp-name_last,
        END OF ls_user,
        lt_user LIKE TABLE OF ls_user.

  SELECT a~bname p~name_last
    FROM usr21 AS a
         LEFT OUTER JOIN adrp AS p ON p~persnumber = a~persnumber
    INTO CORRESPONDING FIELDS OF TABLE lt_user.
  CHECK sy-subrc = 0.

  SORT lt_user BY name_last.
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'BNAME'
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      window_title    = 'User Selected'
      value_org       = 'S'
      display         = ' '
    TABLES
      value_tab       = lt_user[]
      return_tab      = gt_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  CHECK sy-subrc = 0.

  READ TABLE gt_return INTO gs_return INDEX 1.
  CHECK sy-subrc = 0.

  gs_s0400-user = gs_return-fieldval.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  F4_VISIBILITYGRP  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_visibilitygrp INPUT.

  DATA: BEGIN OF ls_usergroup,
          visibility_group TYPE ybt_toad-visibility_group,
        END OF ls_usergroup,
        lt_usergroup LIKE TABLE OF ls_usergroup.

  SELECT DISTINCT visibility_group
    FROM ybt_toad
    INTO TABLE @lt_usergroup
   WHERE owner             = @sy-uname
     AND visibility        = '3'
     AND visibility_group <> @space.
  CHECK sy-subrc = 0.

  SORT lt_usergroup.
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'VISIBILITYGRP'
      dynpprog        = sy-repid
      dynpnr          = sy-dynnr
      window_title    = 'User Group Selected'
      value_org       = 'S'
      display         = ' '
    TABLES
      value_tab       = lt_usergroup[]
      return_tab      = gt_return
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  CHECK sy-subrc = 0.

  READ TABLE gt_return INTO gs_return INDEX 1.
  CHECK sy-subrc = 0.

  gs_options-visibilitygrp = gs_return-fieldval.

ENDMODULE.
*######################################################################*
*
*                             FORM SECTION
*
*######################################################################*
*&---------------------------------------------------------------------*
*&      Form  SCREEN_INIT
*&---------------------------------------------------------------------*
*       Initialize all objects on the screen
*----------------------------------------------------------------------*
FORM screen_init.
* Get user default values
  PERFORM options_load.

* Create the handle object (required to catch events)
  CREATE OBJECT go_handle_event.

* Split the screen into 4 parts
  PERFORM screen_init_splitter.

* Init History Tree
  PERFORM repgo_initialize.

* Init DDIC toolbar
  PERFORM ddic_toolbar_init.

* Init DDic tree
  PERFORM ddic_init.

* Init Query editor
  PERFORM editor_init.

* Init ALV result object
  PERFORM result_init.

ENDFORM.                    " SCREEN_INIT
*&---------------------------------------------------------------------*
*&      Form  SCREEN_INIT_SPLITTER
*&---------------------------------------------------------------------*
*       Split the main screen in 2 lines
* 1 line with 3 columns : Repository tree / Query code / Ddic tree
* 1 line with ALV result
*----------------------------------------------------------------------*
FORM screen_init_splitter.

* Create the custom container
  CREATE OBJECT go_container
    EXPORTING
      container_name = 'CUSTCONT'.

* Insert splitter into this container
  CREATE OBJECT go_splitter
    EXPORTING
      parent  = go_container
      rows    = 2
      columns = 1.

* Get the first row of the main splitter
  CALL METHOD go_splitter->get_container
    EXPORTING
      row       = 1
      column    = 1
    RECEIVING
      container = go_container_top.

*  Spliter for the high part (first row)
  CREATE OBJECT go_splitter_top
    EXPORTING
      parent  = go_container_top
      rows    = 1
      columns = 3.

* Get the right part of the top part
  CALL METHOD go_splitter_top->get_container
    EXPORTING
      row       = 1
      column    = 3
    RECEIVING      "container = go_container_ddic.
      container = go_container_top_right.

* Add a toolbar to the DDIC container
  CREATE OBJECT go_splittoolbar_ddic
    EXPORTING
      i_r_container = go_container_top_right.

* Affect an object to each "cell" of the high sub splitter
  CALL METHOD go_splitter_top->get_container
    EXPORTING
      row       = 1
      column    = 1
    RECEIVING
      container = go_container_top_left.

* Add a toolbar to the DDIC container
  CREATE OBJECT go_splittoolbar_repository
    EXPORTING
      i_r_container = go_container_top_left.

  CALL METHOD go_splitter_top->get_container
    EXPORTING
      row       = 1
      column    = 2
    RECEIVING
      container = go_container_query.

  CALL METHOD go_splittoolbar_ddic->get_controlcontainer
    RECEIVING
      e_r_container_control = go_container_ddic.

  CALL METHOD go_splittoolbar_repository->get_controlcontainer
    RECEIVING
      e_r_container_control = go_container_repository.

  CALL METHOD go_splitter->get_container
    EXPORTING
      row       = 2
      column    = 1
    RECEIVING
      container = go_container_result.

* Initial repartition :
*   line 1 = 100% (code+repo+ddic)
*   line 2 = 0% (result)
*   line 1 col 1 & 3 = 20% (repo & ddic)
*   line 1 col 2 = 60% (code)
  CALL METHOD go_splitter->set_row_height
    EXPORTING
      id     = 1
      height = 100.

  CALL METHOD go_splitter_top->set_column_width
    EXPORTING
      id    = 1
      width = 20.
  CALL METHOD go_splitter_top->set_column_width
    EXPORTING
      id    = 3
      width = 20.

ENDFORM.                    " SCREEN_INIT_SPLITTER
*&---------------------------------------------------------------------*
*&      Form  ddic_toolbar_init
*&---------------------------------------------------------------------*
*       Initialize DDIC Toolbar
*
*----------------------------------------------------------------------*
FORM ddic_toolbar_init.

  DATA: lt_button TYPE ttb_button,
        ls_button LIKE LINE OF lt_button,
        lt_events TYPE cntl_simple_events,
        ls_events LIKE LINE OF lt_events.

*  Toolbar already created by class CL_RSAWB_SPLITTER_FOR_TOOLBAR
  go_toolbar_ddic = go_splittoolbar_ddic->get_toolbar( ).

* Add buttons to toolbar
  CLEAR ls_button.
  ls_button-function  = 'REFRESH'.
  ls_button-icon      = '@42@'.
  ls_button-quickinfo = 'Refresh DDIC tree'(m41).
  ls_button-text      = 'Refresh'(m40).
  lcl_toad_util=>add_toolbar_button( IMPORTING es_button = ls_button CHANGING cs_button = ls_button  ).
  ls_button-butn_type = 0.
  APPEND ls_button TO lt_button.

  CLEAR ls_button.
  ls_button-function  = 'FIND'.
  ls_button-icon      = '@13@'.
  ls_button-quickinfo = 'Search in DDIC tree'(m43).
  ls_button-text      = 'Find'(m42).
  lcl_toad_util=>add_toolbar_button( IMPORTING es_button = ls_button CHANGING cs_button = ls_button  ).
  ls_button-butn_type = 0.
  APPEND ls_button TO lt_button.

  CLEAR ls_button.
  ls_button-function  = 'F4'.
  ls_button-icon      = '@6T@'.
  ls_button-quickinfo = 'Display values of sel. field'(m54).
  ls_button-text      = 'Value list(F4)'(m55).
  ls_button-butn_type = 0.
  APPEND ls_button TO lt_button.

  CALL METHOD go_toolbar_ddic->add_button_group
    EXPORTING
      data_table = lt_button.

* Register events
  ls_events-eventid     = cl_gui_toolbar=>m_id_function_selected.
  ls_events-appl_event  = space.
  APPEND ls_events     TO lt_events.

  CALL METHOD go_toolbar_ddic->set_registered_events
    EXPORTING
      events = lt_events.

  SET HANDLER go_handle_event->hnd_ddic_toolbar_clic FOR go_toolbar_ddic.

ENDFORM.                    "ddic_toolbar_init
*&---------------------------------------------------------------------*
*&      Form  EDITOR_INIT
*&---------------------------------------------------------------------*
*       Initialize the sql editor object
*       Fill it with last query, or template if no previous query
*----------------------------------------------------------------------*
FORM editor_init.

  DATA : lt_events     TYPE cntl_simple_events,
         ls_event      TYPE cntl_simple_event,
         lt_default    TYPE TABLE OF string,
         lv_queryid    TYPE ybt_toad-queryid,
         lo_dragrop    TYPE REF TO cl_dragdrop,
         lv_dummy_date TYPE timestamp.                      "#EC NEEDED

* For first tab, Get last query used
  IF gt_tabs IS INITIAL.
    CONCATENATE sy-uname '#%' INTO lv_queryid.
* aedat is not used but added in select for compatibility reason
    SELECT queryid aedat
           INTO (lv_queryid, lv_dummy_date)
           FROM ybt_toad
           UP TO 1 ROWS
           WHERE queryid LIKE lv_queryid
           AND owner = sy-uname
           AND visibility = '0'
           ORDER BY aedat DESCENDING.
    ENDSELECT.
    IF sy-subrc = 0.
      PERFORM query_load USING lv_queryid
                         CHANGING lt_default.
      PERFORM repgo_focus_query USING lv_queryid.
    ENDIF.
  ENDIF.

* If no last query found, use default template
  IF lt_default IS INITIAL.
    PERFORM editor_get_default_query CHANGING lt_default.
  ENDIF.

* Create the sql editor
*  CREATE OBJECT gs_tab_active-container_query
*    EXPORTING
*      parent = go_container_query.

  CREATE OBJECT gs_tab_active-textedit
    EXPORTING
      parent = go_container_query.

* Register events
  SET HANDLER go_handle_event->hnd_editor_f1 FOR gs_tab_active-textedit.
  SET HANDLER go_handle_event->hnd_editor_drop FOR gs_tab_active-textedit.

  ls_event-eventid = cl_gui_textedit=>event_f1.
  APPEND ls_event TO lt_events.

  CALL METHOD gs_tab_active-textedit->set_registered_events
    EXPORTING
      events                    = lt_events
    EXCEPTIONS
      cntl_error                = 1
      cntl_system_error         = 2
      illegal_event_combination = 3.
  IF sy-subrc <> 0.
    IF sy-msgno IS NOT INITIAL.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              DISPLAY LIKE gc_msg_error
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4 .
    ENDIF.
  ENDIF.

* Activate Code Completion and Quickinfo
* Comment the paragraph if CL_ABAP_PARSER doesnt exists on your system
* BEGIN OF ABAP PARSER
  DATA lo_completer TYPE REF TO cl_abap_parser.
  CALL METHOD gs_tab_active-textedit->('INIT_COMPLETER').
  CALL METHOD gs_tab_active-textedit->('GET_COMPLETER')
    RECEIVING
      m_parser = lo_completer.
  SET HANDLER lo_completer->handle_completion_request FOR gs_tab_active-textedit.
  SET HANDLER lo_completer->handle_insertion_request FOR gs_tab_active-textedit.
  SET HANDLER lo_completer->handle_quickinfo_request FOR gs_tab_active-textedit.
  gs_tab_active-textedit->register_event_completion( ).
  gs_tab_active-textedit->register_event_quick_info( ).
  gs_tab_active-textedit->register_event_insert_pattern( ).
* END OF ABAP PARSER

* Manage Drop on SQL editor
  CREATE OBJECT lo_dragrop.
  CALL METHOD lo_dragrop->add
    EXPORTING
      flavor     = 'EDIT_INSERT'
      dragsrc    = space
      droptarget = abap_true
      effect     = cl_dragdrop=>copy.
  CALL METHOD gs_tab_active-textedit->set_dragdrop
    EXPORTING
      dragdrop = lo_dragrop.

* Set Default template
  CALL METHOD gs_tab_active-textedit->set_text
    EXPORTING
      table  = lt_default
    EXCEPTIONS
      OTHERS = 0.

* Set focus
  CALL METHOD cl_gui_control=>set_focus
    EXPORTING
      control = gs_tab_active-textedit
    EXCEPTIONS
      OTHERS  = 0.

  PERFORM ddic_refresh_tree.

ENDFORM.                    " EDITOR_INIT
*&---------------------------------------------------------------------*
*&      Form  query_process
*&---------------------------------------------------------------------*
*       Process selected query : execute or display code
*----------------------------------------------------------------------*
*      -->pv_DISPLAY : Flag abap_true to display code
*      -->pv_DOWNLOAD: Flag abap_true to save results into file
*----------------------------------------------------------------------*
FORM query_process USING pv_display  TYPE c
                         pv_download TYPE c.

  DATA : lv_query         TYPE string,
         lv_select        TYPE string,
         lv_from          TYPE string,
         lv_where         TYPE string,
         lv_union         TYPE string,
         lv_with          TYPE string,
         lv_query2        TYPE string,
         lv_command       TYPE string,
         lv_rows(6)       TYPE n,
         lv_program       TYPE sy-repid,
         lo_result        TYPE REF TO data,
         lo_result2       TYPE REF TO data,
         lt_fieldlist     TYPE tyt_fieldlist,
         lt_fieldlist2    TYPE tyt_fieldlist,
         lv_count_only(1) TYPE c,
         lv_show_result   TYPE c,
         lv_show_result2  TYPE c,
         lv_time          TYPE p LENGTH 8 DECIMALS 2,
         lv_time2         LIKE lv_time,
         lv_count         TYPE i,
         lv_count2        LIKE lv_count,
         lv_charnumb(12)  TYPE c,
         lv_msg           TYPE string,
         lv_noauth(1)     TYPE c,
         lv_newsyntax(1)  TYPE c,
         lv_distinct(1)   TYPE c,
         lv_answer(1)     TYPE c,
         lv_from_concat   LIKE lv_from,
         lv_error(1)      TYPE c,
         ls_inline_option TYPE tys_inline_option.

  FIELD-SYMBOLS : <lpt_data>  TYPE STANDARD TABLE,
                  <lpt_data2> TYPE STANDARD TABLE.

* Get only usefull code for current query
  CLEAR: ls_inline_option.
  PERFORM editor_get_query USING space CHANGING lv_query ls_inline_option.
  CHECK lv_query IS NOT INITIAL.

* Parse SELECT Query
  PERFORM query_parse USING    lv_query
                      CHANGING lv_select lv_from  lv_where
                               lv_with   lv_union lv_rows lv_noauth
                               lv_newsyntax lv_error.
  IF lv_error NE space.
    MESSAGE 'Cannot parse the query'(m07) TYPE gc_msg_error.
  ENDIF.

* Not a select query
  IF lv_select IS INITIAL.
    PERFORM query_parse_noselect USING    lv_query
                                 CHANGING lv_noauth
                                          lv_command
                                          lv_from
                                          lv_where.
    IF lv_noauth NE space.
      PERFORM ddic_set_tree USING lv_query lv_from lv_union.
      RETURN.
    ENDIF.

* For native sql command, execute it directly
    IF lv_command = gc_native_command.
      RETURN.
    ENDIF.

* For other no select command, generate program
    IF w_run LT gc_query_max_exec.

      " new syntax 인지 여부 확인
      PERFORM check_query_new_syntax USING    lv_command lv_where
                                     CHANGING lv_newsyntax.

      IF lv_newsyntax = abap_true.
        PERFORM query_generate_noselect_new USING    lv_command lv_from
                                                     lv_query pv_display
                                            CHANGING lv_program.

      ELSE.
        " old syntax 인 경우
        PERFORM query_generate_noselect USING    lv_command lv_from
                                                 lv_where pv_display
                                        CHANGING lv_program.
      ENDIF.
      w_run = w_run + 1.
    ELSE.
      MESSAGE 'No more run available. Please restart program'(m50)
              TYPE gc_msg_error.
    ENDIF.
    IF pv_display IS INITIAL.
      PERFORM ddic_set_tree USING lv_query lv_from lv_union.
      CONCATENATE 'Are you sure you want to do a'(m31) lv_command
                  'on table'(m32) lv_from '?'(m33)
                  INTO lv_msg SEPARATED BY space.
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          titlebar              = 'Warning : critical operation'(t04)
          text_question         = lv_msg
          default_button        = '2'
          display_cancel_button = space
        IMPORTING
          answer                = lv_answer
        EXCEPTIONS
          text_not_found        = 1
          OTHERS                = 2.
      IF sy-subrc NE 0 OR lv_answer NE '1'.
        RETURN.
      ENDIF.
    ENDIF.
    lv_count_only = abap_true. "no result grid to display

  ELSEIF lv_noauth NE space.
    PERFORM ddic_set_tree USING lv_query lv_from lv_union.
    RETURN.

  ELSEIF lv_from IS INITIAL.
    PERFORM ddic_set_tree USING lv_query lv_from lv_union.
    MESSAGE 'Cannot parse the query'(m07) TYPE gc_msg_error.

  ELSE.
* Generate SELECT subroutine
    IF w_run LT gc_query_max_exec.
      PERFORM query_generate USING    lv_with  lv_select lv_from
                                      lv_where lv_union  pv_display
                             CHANGING lv_newsyntax
                                      lv_program lv_rows
                                      lt_fieldlist lv_count_only.
      IF lv_program IS INITIAL.
        PERFORM ddic_set_tree USING lv_query lv_from lv_union.
        RETURN.
      ENDIF.
      w_run = w_run + 1.
    ELSE.
      MESSAGE 'No more run available. Please restart program'(m50)
              TYPE gc_msg_error.
    ENDIF.
  ENDIF.

* Call the generated subroutine
  IF NOT lv_program IS INITIAL.
    PERFORM tab_update_title USING lv_query.

    PERFORM run_sql IN PROGRAM (lv_program)
                    CHANGING lo_result lv_show_result lv_time lv_count.
    lv_from_concat = lv_from.
* For union, process second (and further) query
    IF lv_newsyntax IS INITIAL.
      CLEAR: lv_distinct.
      WHILE NOT lv_union IS INITIAL.
* Parse Query
        lv_query2 = lv_union.
        IF lv_query2+0(8) = 'DISTINCT'.
          lv_distinct = abap_true.
        ENDIF.

        PERFORM query_parse USING lv_query2
                            CHANGING lv_select lv_from lv_where
                                     lv_with lv_union lv_rows lv_noauth
                                     lv_newsyntax lv_error.
        CONCATENATE lv_from_concat 'JOIN' lv_from INTO lv_from_concat.
        IF lv_noauth NE space.
          PERFORM ddic_set_tree USING lv_query lv_from_concat lv_union.
          RETURN.
        ELSEIF lv_select IS INITIAL OR lv_from IS INITIAL
        OR lv_error = abap_true.
          PERFORM ddic_set_tree USING lv_query lv_from_concat lv_union.
          MESSAGE 'Cannot parse the unioned query'(m08) TYPE gc_msg_error.
          EXIT. "exit while
        ENDIF.
* Generate subroutine
        IF w_run LT gc_query_max_exec.
          PERFORM query_generate USING    lv_with     lv_select    lv_from
                                          lv_where    lv_where     pv_display
                                 CHANGING lv_newsyntax
                                          lv_program lv_rows
                                          lt_fieldlist2 lv_count_only.
          IF lv_program IS INITIAL.
            PERFORM ddic_set_tree USING lv_query lv_from_concat lv_union.
            RETURN.
          ENDIF.
          w_run = w_run + 1.
        ELSE.
          MESSAGE 'No more run available. Please restart program'(m50)
                  TYPE gc_msg_error.
        ENDIF.
* Call the generated subroutine
        PERFORM run_sql IN PROGRAM (lv_program)
                        CHANGING lo_result2 lv_show_result2 lv_time2 lv_count2.

* Append lines of the further queries to the first query
        ASSIGN lo_result->*  TO <lpt_data>.
        ASSIGN lo_result2->* TO <lpt_data2>.
        APPEND LINES OF <lpt_data2> TO <lpt_data>.
        REFRESH <lpt_data2>.
        lv_time = lv_time + lv_time2.
        lv_count = lv_count + lv_count2.
      ENDWHILE.

      IF lv_distinct = abap_true.
        SORT <lpt_data>.
        DELETE ADJACENT DUPLICATES FROM <lpt_data>
               COMPARING ALL FIELDS.
        lv_count = lines( <lpt_data> ).
      ENDIF.
    ENDIF.

    PERFORM ddic_set_tree USING lv_query lv_from_concat lv_union.

* Display message
    lv_charnumb = lv_time.
    CONCATENATE 'Query executed in'(m09) lv_charnumb INTO lv_msg
                SEPARATED BY space.
    lv_charnumb = lv_count.
    IF NOT lv_select IS INITIAL.
      CONCATENATE lv_msg 'seconds.'(m10)
                  lv_charnumb 'entries found'(m11)
                  INTO lv_msg SEPARATED BY space.
      CONDENSE lv_msg.
      MESSAGE lv_msg TYPE gc_msg_success.
    ELSE.
      CONCATENATE lv_msg 'seconds.'(m10)
                  lv_charnumb 'entries Changed'(m12)
                  INTO lv_msg SEPARATED BY space.
      CONDENSE lv_msg.
      MESSAGE lv_msg TYPE gc_msg_information.
    ENDIF.

* Display result except for count(*)
    IF lv_count_only IS INITIAL.
      IF pv_download = space.
        PERFORM result_display USING lo_result lt_fieldlist lv_msg.
      ELSE.
        PERFORM result_save_file USING lo_result lt_fieldlist.
      ENDIF.
    ENDIF.

    PERFORM repgo_save_current_query USING '0'.

    " 프로그램 실행 종료
*    DELETE program lv_program.
  ENDIF.

ENDFORM.                    " QUERY_PROCESS
*&---------------------------------------------------------------------*
*&      Form  EDITOR_GET_QUERY
*&---------------------------------------------------------------------*
*       Return active query without comment
*----------------------------------------------------------------------*
*      -->pv_FORCE_LAST  Keep last request
*      <--pv_QUERY       Query code
*----------------------------------------------------------------------*
FORM editor_get_query USING    pv_force_last    TYPE c
                      CHANGING pv_query         TYPE string
                               ps_inline_option TYPE tys_inline_option.

  DATA : lt_query         TYPE soli_tab,
         ls_query         LIKE LINE OF lt_query,
         ls_find          TYPE match_result,
         lt_find          TYPE match_result_tab,
         lt_find_sub      TYPE match_result_tab,
         lv_lines         TYPE i,
         lv_cursor_line   TYPE i,
         lv_cursor_pos    TYPE i,
         lv_delto_line    TYPE i,
         lv_delto_pos     TYPE i,
         lv_cursor_offset TYPE i,
         lv_last          TYPE c.

  CLEAR: pv_query.

* Get selected content
  CALL METHOD gs_tab_active-textedit->get_selected_text_as_table
    IMPORTING
      table = lt_query[].

* if no selected content, get complete content of abap edit box
  IF lt_query[] IS INITIAL.
    CALL METHOD gs_tab_active-textedit->get_text
      IMPORTING
        table  = lt_query[]
      EXCEPTIONS
        OTHERS = 1.
  ENDIF.

  " 입력된 query 가 없는 경우
  IF lt_query[] IS INITIAL.
    MESSAGE s000(oo) WITH 'No query entered' DISPLAY LIKE 'E'.
    EXIT.
  ENDIF.

* get inline option
  DATA: lt_option TYPE TABLE OF string.
  LOOP AT lt_query INTO ls_query WHERE line(1) = '$' .

    SPLIT ls_query-line+1 AT ',' INTO TABLE lt_option.
    LOOP AT lt_option INTO DATA(ls_option).
      TRANSLATE ls_option TO UPPER CASE.
      CASE ls_option.
        WHEN 'NEW_SYNTAX' OR 'NEW SYNTAX' OR 'NEWSYNTAX'.
          ps_inline_option-new_syntax = abap_true.
      ENDCASE.
    ENDLOOP.

    CLEAR ls_query-line.
    MODIFY lt_query FROM ls_query.
  ENDLOOP.

* Remove * comment
  LOOP AT lt_query INTO ls_query WHERE line(1) = '*' .
    CLEAR ls_query-line.
    MODIFY lt_query FROM ls_query.
  ENDLOOP.

* Remove " comment
  LOOP AT lt_query INTO ls_query WHERE line CS '"'.
*    condense ls_query-line.
    FIND ALL OCCURRENCES OF '"' IN ls_query-line RESULTS lt_find.
    IF sy-subrc NE 0. "may not occurs
      CONTINUE.
    ENDIF.

    LOOP AT lt_find INTO ls_find.
      IF ls_find-offset GT 0.
* Search open '
        FIND ALL OCCURRENCES OF '''' IN ls_query-line(ls_find-offset)
             RESULTS lt_find_sub.
        IF sy-subrc = 0.
          DESCRIBE TABLE lt_find_sub LINES lv_lines.
          lv_lines = lv_lines MOD 2.
          IF lv_lines = 1.
            CONTINUE.
          ENDIF.
        ENDIF.
        ls_query-line = ls_query-line(ls_find-offset).
        EXIT. "exit loop
      ELSE.
        CLEAR ls_query-line.
        EXIT. "exit loop
      ENDIF.
    ENDLOOP.
    MODIFY lt_query FROM ls_query.
  ENDLOOP.

* Find active query
  CALL METHOD gs_tab_active-textedit->get_selection_pos
    IMPORTING
      from_line = lv_cursor_line
      from_pos  = lv_cursor_pos.
  lv_cursor_offset = lv_cursor_pos - 1.

  FIND ALL OCCURRENCES OF '.' IN TABLE lt_query RESULTS lt_find.
  CLEAR : lv_delto_line,
          lv_delto_pos,
          lv_last.

  LOOP AT lt_find INTO ls_find.
    AT LAST.
      lv_last = abap_true.
    ENDAT.
* Search for open '
    IF ls_find-offset GT 0.
      READ TABLE lt_query INTO ls_query INDEX ls_find-line.
      FIND ALL OCCURRENCES OF '''' IN ls_query(ls_find-offset)
           RESULTS lt_find_sub.
      DESCRIBE TABLE lt_find_sub LINES lv_lines.
      lv_lines = lv_lines MOD 2.
* If open ' found, ignore the dot
      IF lv_lines = 1.
        CONTINUE.
      ENDIF.
    ENDIF.

* Active Query
    IF ls_find-line GT lv_cursor_line
    OR ( ls_find-line = lv_cursor_line
         AND ls_find-offset GE lv_cursor_offset )
    OR ( lv_last = abap_true AND pv_force_last = abap_true ).
* Delete all query after query active
      ls_find-line = ls_find-line + 1.
      DELETE lt_query FROM ls_find-line.
      ls_find-line = ls_find-line - 1.
* Do not keep the . for active query
      IF ls_find-offset = 0.
        DELETE lt_query FROM ls_find-line.
      ELSE.
        ls_query-line = ls_query-line(ls_find-offset).
        MODIFY lt_query FROM ls_query INDEX ls_find-line.
      ENDIF.
      EXIT.
* Query before active
    ELSE.
      lv_delto_line = ls_find-line.
      lv_delto_pos = ls_find-offset + 1.
    ENDIF.
  ENDLOOP.

* Delete all query before query active
  IF NOT lv_delto_line IS INITIAL.
    IF lv_delto_line GT 1.
      lv_delto_line = lv_delto_line - 1.
      DELETE lt_query FROM 1 TO lv_delto_line.
    ENDIF.
    READ TABLE lt_query INTO ls_query INDEX 1.
    ls_query-line(lv_delto_pos) = ''.
    MODIFY lt_query FROM ls_query INDEX 1.
  ENDIF.

* Delete empty lines
  DELETE lt_query WHERE line CO ' .'.

* Build query string & Remove unnessential spaces
  LOOP AT lt_query INTO ls_query.
    CONDENSE ls_query-line.
    SHIFT ls_query-line LEFT DELETING LEADING space.
    CONCATENATE pv_query ls_query-line INTO pv_query SEPARATED BY space.
  ENDLOOP.
  IF NOT pv_query IS INITIAL.
    pv_query = pv_query+1.
  ENDIF.

* If no query selected, try to get the last one
  IF lt_query IS INITIAL AND pv_force_last = space.
    PERFORM editor_get_query USING    abap_true
                             CHANGING pv_query ps_inline_option.
  ENDIF.

ENDFORM.                    " EDITOR_GET_QUERY
*&---------------------------------------------------------------------*
*&      Form  QUERY_PARSE
*&---------------------------------------------------------------------*
*       Split the query into 3 parts : Select / From / Where
*       - Select : List of the fields to extract
*       - From   : List of the tables - with join condition
*       - Where  : List of filters + group, order, having clauses
*----------------------------------------------------------------------*
*      -->pv_QUERY   Query to parse
*      <--pv_SELECT  Select part of the query
*      <--pv_FROM    From part of the query
*      <--pv_WHERE   Where part of the query
*      <--pv_ROWS    Number of rows to display
*      <--pv_UNION   Union part of the query
*      <--pv_NOAUTH  Unallowed table entered
*      <--pv_NEWSYNTAX Use new SQL syntax introduced with NW7.40 SP5
*      <--pv_ERROR   Cannot parse the query
*----------------------------------------------------------------------*
FORM query_parse  USING    pv_query     TYPE string
                  CHANGING pv_select    TYPE string
                           pv_from      TYPE string
                           pv_where     TYPE string
                           pv_with      TYPE string
                           pv_union     TYPE string
                           pv_rows      TYPE n
                           pv_noauth    TYPE c
                           pv_newsyntax TYPE c
                           pv_error     TYPE c.

  DATA: ls_find_select TYPE match_result,
        ls_find_from   TYPE match_result,
        ls_find_where  TYPE match_result,
        ls_find_fields TYPE match_result,
        ls_sub         LIKE LINE OF ls_find_select-submatches,
        lv_offset      TYPE i,
        lv_length      TYPE i,
        lv_query       TYPE string,
        lo_regex       TYPE REF TO cl_abap_regex,
        lt_split       TYPE TABLE OF string,
        lv_from        TYPE string,
        lv_dummy       TYPE string,
        lv_string      TYPE string,
        lv_tabix       TYPE i,
        lv_table       TYPE tabname.

  DATA: lv_no      TYPE i,
        lv_ngo_n   TYPE i,
        ls_find_u1 TYPE tys_find_result,
        lt_find_u1 TYPE tyt_find_result,
        lt_find_u2 TYPE tyt_find_result.

  CLEAR : pv_select,
          pv_from,
          pv_where,
          pv_rows,
          pv_union,
          pv_noauth,
          pv_newsyntax.

  lv_query = pv_query.
  pv_error = abap_false.

  " 처음 단어가 table data 갱신용 인지 여부 확인
  SPLIT lv_query AT space INTO lv_string lv_dummy.
  TRANSLATE lv_string TO UPPER CASE.
  CASE lv_string.
    WHEN 'INSERT' OR 'UPDATE' OR 'DELETE' OR 'MODIFY'. RETURN.
    WHEN OTHERS.
  ENDCASE.

  " search with
  DATA lv_query_s TYPE string.
  PERFORM split_with_clause  USING    lv_query
                             CHANGING pv_with
                                      lv_query_s
                                      pv_newsyntax.
* Search union
  PERFORM split_union_clause  USING    lv_query_s
                              CHANGING lv_query
                                       pv_union.
* Search UP TO xxx ROWS.
* Catch the number of rows, delete command in query
  CREATE OBJECT lo_regex
    EXPORTING
      pattern     = 'UP TO ([0-9]+) ROWS'
      ignore_case = abap_true
      ##REGEX_POSIX.

  FIND FIRST OCCURRENCE OF REGEX lo_regex
       IN lv_query RESULTS ls_find_select.
  IF sy-subrc = 0.
    READ TABLE ls_find_select-submatches INTO ls_sub INDEX 1.
    IF sy-subrc = 0.
      pv_rows = lv_query+ls_sub-offset(ls_sub-length).
    ENDIF.
    REPLACE FIRST OCCURRENCE OF REGEX lo_regex IN lv_query WITH ''.
  ELSE.
* Set default number of rows
    pv_rows = gs_customize-default_rows.
  ENDIF.

* Remove unused INTO (CORRESPONDING FIELDS OF)(TABLE)
* Detect new syntax in internal table name
  CONCATENATE '(INTO|APPENDING)( TABLE'
              '| CORRESPONDING FIELDS OF TABLE |'
              'CORRESPONDING FIELDS OF | )(\S*)'
              INTO lv_string SEPARATED BY space.
  CREATE OBJECT lo_regex
    EXPORTING
      pattern     = lv_string
      ignore_case = abap_true
      ##REGEX_POSIX.

  FIND FIRST OCCURRENCE OF REGEX lo_regex
       IN lv_query RESULTS ls_find_select.
  IF sy-subrc = 0.
    IF ls_find_select-length NE 0 AND
       pv_query+ls_find_select-offset(ls_find_select-length) CS '@'.
      pv_newsyntax = abap_true.
    ENDIF.
    REPLACE FIRST OCCURRENCE OF REGEX lo_regex IN lv_query WITH ''.
  ENDIF.

* Search SELECT
  FIND FIRST OCCURRENCE OF 'SELECT ' IN lv_query
       RESULTS ls_find_select IGNORING CASE.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

* Search FROM
  PERFORM search_from_in_query USING    lv_query
                               CHANGING pv_select
                                        pv_from
                                        pv_where
                                        pv_newsyntax
                                        pv_error.
  IF pv_error = abap_true.
    EXIT.
  ENDIF.

ENDFORM.                    " QUERY_PARSE
*&---------------------------------------------------------------------*
*&      Form  add_line_to_table
*&---------------------------------------------------------------------*
*       Add a string line in a table
*       Break line at 255 char, respecting words if possible
*----------------------------------------------------------------------*
*      -->pv_LINE    Line to add in table
*      <--pt_TABLE   Table to append
*----------------------------------------------------------------------*
FORM add_line_to_table USING pv_line TYPE string
                       CHANGING pt_table TYPE table.
  DATA : lv_length TYPE i,
         lv_offset TYPE i,
         ls_find   TYPE match_result.

  lv_length = strlen( pv_line ).
  lv_offset = 0.
  DO.
    IF lv_length LE gc_line_max.
      APPEND pv_line+lv_offset(lv_length) TO pt_table.
      EXIT. "exit do
    ELSE.
      FIND ALL OCCURRENCES OF REGEX '\s' "search space
           IN SECTION OFFSET lv_offset LENGTH gc_line_max
           OF pv_line RESULTS ls_find
           ##REGEX_POSIX .
      IF sy-subrc NE 0.
        APPEND pv_line+lv_offset(gc_line_max) TO pt_table.
        lv_length = lv_length - gc_line_max.
        lv_offset = lv_offset + gc_line_max.
      ELSE.
        ls_find-length = ls_find-offset - lv_offset.
        APPEND pv_line+lv_offset(ls_find-length) TO pt_table.
        lv_length = lv_length + lv_offset - ls_find-offset - 1.
        lv_offset = ls_find-offset + 1.
      ENDIF.
    ENDIF.
  ENDDO.

ENDFORM.                    "add_line_to_table
*&---------------------------------------------------------------------*
*&      Form  QUERY_GENERATE
*&---------------------------------------------------------------------*
*       Create SELECT SQL query in a new generated temp program
*----------------------------------------------------------------------*
*      -->pv_SELECT    Select part of the query
*      -->pv_FROM      From part of the query
*      -->pv_WHERE     Where part of the query
*      -->pv_DISPLAY   Display code instead of generated routine
*      -->pv_NEWSYNTAX Use new SQL syntax introduced with NW7.40 SP5
*      <--pv_PROGRAM   Name of the generated program
*      <--pv_ROWS      Number of rows to display
*      <--pt_FIELDLIST List of fields to display
*      <--pv_COUNT     = true if query is only count( * )
*----------------------------------------------------------------------*
FORM query_generate  USING    pv_with      TYPE string
                              pv_select    TYPE string
                              pv_from      TYPE string
                              pv_where     TYPE string
                              pv_union     TYPE string
                              pv_display   TYPE c
                     CHANGING pv_newsyntax TYPE c
                              pv_program   TYPE sy-repid
                              pv_rows      TYPE n
                              pt_fieldlist TYPE tyt_fieldlist
                              pv_count     TYPE c.

  DATA: lt_code_string      TYPE TABLE OF string,
        lt_split            TYPE TABLE OF string,
        lv_string           TYPE string,
        lv_field_as         TYPE string,
        lv_string2          TYPE string,
        ls_table_alias      TYPE tys_table_alias,
        lt_table_alias      TYPE tyt_table_alias,
        lv_with             TYPE string,
        lv_union            TYPE string,
        lv_union_single     TYPE string,
        lv_select           TYPE string,
        lv_select_repl      TYPE string,
        lv_from             TYPE string,
        lv_index            TYPE i,
        lv_select_distinct  TYPE c,
        lv_select_length    TYPE i,
        lv_char_10(20)      TYPE c,
        lv_flag             TYPE c,
        lv_dummy            TYPE string,
        lv_field_number(6)  TYPE n,
        lv_current_line     TYPE i,
        lv_current_length   TYPE i,
        lv_len              TYPE i,
        lv_pos              TYPE i,
        lv_struct_line      TYPE string,
        lv_struct_line_type TYPE string,
        lv_select_table     TYPE string,
        lv_select_field     TYPE string,
        ls_dd03l            TYPE dd03l,
        lv_mess(255),
        lv_line             TYPE i,
        lv_word(30),
        ls_fieldlist        TYPE tys_fieldlist,
        lv_strlen_string    TYPE string,
        lv_explicit         TYPE string,
        lv_value            TYPE c,
        lv_comma            TYPE c.

  FIELD-SYMBOLS: <lv_value> TYPE x.

  CLEAR : lv_select_distinct,
          pv_count.


* Write Header
  c 'PROGRAM SUBPOOL.'.
  c ''.
  c '** Generated Program * Do Not Change It **'.
  c 'TYPE-POOLS: slis.'.                                    "#EC NOTEXT
  c ''.

  lv_with = pv_with.
  TRANSLATE lv_with TO UPPER CASE.

  DATA: ls_table_w TYPE tys_table_w,
        ls_field_w TYPE tys_fieldlist.

  CLEAR: gt_table_w[].
  PERFORM make_table_w USING    lv_with
                       CHANGING gt_table_w.

  lv_select = pv_select.
  SHIFT lv_select LEFT DELETING LEADING space.
  TRANSLATE lv_select TO UPPER CASE.

  lv_from = pv_from.
  TRANSLATE lv_from TO UPPER CASE.

* Search special term "single" or "distinct"
  SHIFT lv_select LEFT DELETING LEADING space.
  lv_select_length = strlen( lv_select ).

  IF lv_select = 'SINGLE' OR lv_select CP 'SINGLE *'.
* Force rows number = 1 for select single
    pv_rows = 1.
    lv_select = lv_select+6.
    SHIFT lv_select LEFT DELETING LEADING space.
    lv_select_length = strlen( lv_select ).
  ENDIF.

  IF lv_select = 'DISTINCT' OR lv_select CP 'DISTINCT *'.
    lv_select_distinct = abap_true.
    lv_select = lv_select+8.
    SHIFT lv_select LEFT DELETING LEADING space.
    lv_select_length = strlen( lv_select ).
  ENDIF.

* Search for special syntax "count( * )"
  IF lv_select = 'COUNT( * )'.
    pv_count = abap_true.
  ENDIF.

* Create alias table mapping
  SPLIT lv_from AT space INTO TABLE lt_split.
  PERFORM create_alias_table_mapping TABLES lt_split lt_table_alias.

* Write Data declaration
  c '***************************************'.              "#EC NOTEXT
  c '*      Begin of data declaration      *'.              "#EC NOTEXT
  c '*   Used to store lines of the query  *'.              "#EC NOTEXT
  c '***************************************'.              "#EC NOTEXT
  c 'DATA: BEGIN OF gs_result'.                             "#EC NOTEXT
  lv_field_number = 1.

  lv_string = lv_select.
  IF pv_newsyntax = abap_true.
    PERFORM split_field_list_table USING lv_string CHANGING lt_split.
  ELSE.
    SPLIT lv_string AT space INTO TABLE lt_split.
  ENDIF.

  PERFORM make_select_field_list USING    abap_true
                                 CHANGING pv_newsyntax
                                          lv_select
                                          lt_split
                                          pt_fieldlist
                                          lt_table_alias
                                          lt_code_string.

* End of data definition
  c ', END OF GS_RESULT'.                                   "#EC NOTEXT
  c '  '.
  c ', gt_result like table of gs_result'.                  "#EC NOTEXT
  c ', gv_timestart type timestampl'.                       "#EC NOTEXT
  c ', gv_timeend type timestampl.'.                        "#EC NOTEXT
  c '  '.

* Write the dynamic subroutine that run the SELECT
  c 'FORM run_sql CHANGING po_result    TYPE REF TO data'.  "#EC NOTEXT
  c '                      pv_show_result  TYPE c'.         "#EC NOTEXT
  c '                      pv_time      TYPE p'.            "#EC NOTEXT
  c '                      pv_count     TYPE i.'.           "#EC NOTEXT
  c '  '.
*  c 'field-symbols <ls_result> like GS_RESULT.'.           "#EC NOTEXT
*  c '  '.
  c 'get TIME STAMP FIELD gv_timestart.'.                   "#EC NOTEXT
  c '  '.
  c '***************************************'.              "#EC NOTEXT
  c '*            Begin of query           *'.              "#EC NOTEXT
  c '***************************************'.              "#EC NOTEXT
  c '  '.
  IF lv_with IS NOT INITIAL.
    c lv_with.
    c '  '.
  ENDIF.

  IF pv_count = abap_true.
    CONCATENATE 'SELECT SINGLE' lv_select                   "#EC NOTEXT
                INTO lv_select SEPARATED BY space.
    c lv_select.
    IF pv_newsyntax = abap_true.
    ELSE.
      c 'INTO GS_RESULT-F000000'.                           "#EC NOTEXT
    ENDIF.
  ELSE.
    IF pv_newsyntax = abap_true.
      FIND FIRST OCCURRENCE OF ',' IN lv_select.
      IF sy-subrc NE 0. " 1 line
        SPLIT lv_string AT space INTO lv_char_10 lv_dummy.
        REPLACE ALL OCCURRENCES OF '(' IN lv_char_10 WITH space.

        CASE lv_char_10.
          WHEN 'COUNT' OR 'SUM' OR 'MAX' OR 'MIN' OR 'AVG'.
            pv_count = abap_true.

          WHEN OTHERS.
        ENDCASE.
      ENDIF.
    ENDIF.

    IF lv_select_distinct NE space.
      CONCATENATE 'SELECT DISTINCT' lv_select               "#EC NOTEXT
                  INTO lv_select SEPARATED BY space.
    ELSE.
      CONCATENATE 'SELECT' lv_select                        "#EC NOTEXT
                  INTO lv_select SEPARATED BY space.
    ENDIF.
    c lv_select.
    IF pv_newsyntax = abap_true OR
       lines( pt_fieldlist ) = 1.
    ELSE.
      c 'INTO TABLE GT_RESULT'.                             "#EC NOTEXT
    ENDIF.

* Add UP TO xxx ROWS
    IF NOT pv_rows IS INITIAL AND pv_newsyntax = space.
      c 'UP TO'.                                            "#EC NOTEXT
      c pv_rows.
      c 'ROWS'.                                             "#EC NOTEXT
    ENDIF.
  ENDIF.

  c 'FROM'.                                                 "#EC NOTEXT
  c lv_from.

* Where, group by, having, order by
  IF NOT pv_where IS INITIAL.
    c pv_where.
  ENDIF.

  " new syntax 이면서 union 이 있는 경우
  IF NOT pv_union IS INITIAL AND pv_newsyntax = abap_true.
    c pv_union.
  ENDIF.

  " new syntax 인 경우 into 절은 마지막에...
  IF pv_newsyntax = abap_true OR
       lines( pt_fieldlist ) = 1.
    IF pv_count = abap_true.
      c 'INTO @GS_RESULT-F000000'.                          "#EC NOTEXT
    ELSE.
      c 'INTO TABLE @GT_RESULT'.                            "#EC NOTEXT
      IF NOT pv_rows IS INITIAL.
        c 'UP TO'.                                          "#EC NOTEXT
        c pv_rows.
        c 'ROWS'.                                           "#EC NOTEXT
      ENDIF.
    ENDIF.
  ENDIF.

  c '.'.

  c '***************************************'.              "#EC NOTEXT
  c '*            End of query             *'.              "#EC NOTEXT
  c '***************************************'.              "#EC NOTEXT

* Display query execution time
  c 'get TIME STAMP FIELD gv_timeend.'.                     "#EC NOTEXT
  c '  '.
  c 'pv_time = gv_timeend - gv_timestart.'.                 "#EC NOTEXT
  c 'pv_count = sy-dbcnt.'.                                 "#EC NOTEXT

  IF pv_display = abap_true.
    c 'pv_show_result = abap_true.'.
  ENDIF.

  c '  '.

  IF pv_count NE space.
    c 'MESSAGE I753(TG) WITH GS_RESULT-F000000.'.           "#EC NOTEXT
    c '  '.
  ENDIF.

  c '  '.
  c 'GET REFERENCE OF gt_result INTO po_result.'.           "#EC NOTEXT
  c '  '.
  c 'ENDFORM.'.                                             "#EC NOTEXT

  CLEAR : lv_line,
          lv_word,
          lv_mess.
  SYNTAX-CHECK FOR lt_code_string PROGRAM sy-repid
               MESSAGE lv_mess LINE lv_line WORD lv_word.
  IF sy-subrc NE 0 AND pv_display = space.
    MESSAGE lv_mess TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    CLEAR pv_program.
    RETURN.
  ENDIF.

  IF pv_display = space.
    GENERATE SUBROUTINE POOL lt_code_string NAME pv_program.
  ELSE.
    IF lv_mess IS NOT INITIAL.
      lv_explicit = lv_line.
      CONCATENATE lv_mess '(line'(m28) lv_explicit ',word'(m29)
                  lv_word ')'(m30)
                  INTO lv_mess SEPARATED BY space.
      MESSAGE lv_mess TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    ENDIF.
    EDITOR-CALL FOR lt_code_string DISPLAY-MODE
                TITLE 'Generated code for current query'(t01).
  ENDIF.

ENDFORM.                    " QUERY_GENERATE
*&---------------------------------------------------------------------*
*&      Form  RESULT_DISPLAY
*&---------------------------------------------------------------------*
*       Display data table in the bottom ALV part of the screen
*----------------------------------------------------------------------*
*      -->po_result    Reference to data to display
*      -->pt_FIELDLIST List of fields to display
*      -->pv_TITLE     Title of the ALV
*----------------------------------------------------------------------*
FORM result_display  USING po_result    TYPE REF TO data
                           pt_fieldlist TYPE tyt_fieldlist
                           pv_title     TYPE string.
*  TYPE-POOLS lvc. "for older sap system only

  DATA: ls_layout    TYPE lvc_s_layo,
        lt_fieldcat  TYPE lvc_t_fcat,
        ls_fieldlist TYPE tys_fieldlist,
        ls_fieldcat  TYPE lvc_s_fcat.

  DATA: lo_descr_table TYPE REF TO cl_abap_tabledescr,
        lo_descr_line  TYPE REF TO cl_abap_structdescr,
        ls_compx       TYPE abap_compdescr,
        lv_height      TYPE i.

  FIELD-SYMBOLS: <lpt_data> TYPE ANY TABLE.

  ASSIGN po_result->* TO <lpt_data>.
  IF sy-subrc NE 0.
    MESSAGE i000(oo) WITH 'Assign Error'.
    EXIT.
  ENDIF.

* Get data type for COUNT & AVG fields
  lo_descr_table ?=
    cl_abap_typedescr=>describe_by_data_ref( po_result ).
  lo_descr_line ?= lo_descr_table->get_table_line_type( ).

  " field table 이 없는 경우
  IF pt_fieldlist[] IS INITIAL.
    LOOP AT lo_descr_line->components INTO ls_compx.
      ls_fieldlist-field = ls_compx-name.
      ls_fieldlist-ref_field = ls_compx-name.
      APPEND ls_fieldlist TO pt_fieldlist.
    ENDLOOP.
  ENDIF.

  LOOP AT pt_fieldlist INTO ls_fieldlist.
    CLEAR ls_fieldcat.
    ls_fieldcat-fieldname = ls_fieldlist-field.

    ls_fieldcat-no_convext = gs_customize-no_convext.

    IF NOT ls_fieldlist-ref_table IS INITIAL.
      ls_fieldcat-ref_field = ls_fieldlist-ref_field.
      ls_fieldcat-ref_table = ls_fieldlist-ref_table.
      IF gs_customize-techname = abap_true.

        IF ls_fieldlist-field_txt IS NOT INITIAL.
          ls_fieldcat-coltext = ls_fieldlist-field_txt.
          ls_fieldcat-reptext = ls_fieldlist-field_txt.
        ELSE.
          ls_fieldcat-coltext = ls_fieldlist-ref_field.
          ls_fieldcat-reptext = ls_fieldlist-ref_field.
        ENDIF.

      ELSE.
        IF ls_fieldlist-field_txt IS INITIAL.
          IF ls_fieldlist-ref_table IS NOT INITIAL AND
             ls_fieldlist-ref_field IS NOT INITIAL.

            PERFORM get_fieldinfo USING ls_fieldlist CHANGING ls_fieldcat.

          ELSE.
            ls_fieldcat-coltext   = ls_fieldlist-ref_field.
            ls_fieldcat-reptext   = ls_fieldlist-ref_field.
            ls_fieldcat-scrtext_s = ls_fieldlist-ref_field.
            ls_fieldcat-scrtext_m = ls_fieldlist-ref_field.
            ls_fieldcat-scrtext_l = ls_fieldlist-ref_field.
          ENDIF.
        ELSE.
          ls_fieldcat-coltext   = ls_fieldlist-field_txt.
          ls_fieldcat-reptext   = ls_fieldlist-field_txt.
          ls_fieldcat-scrtext_s = ls_fieldlist-field_txt.
          ls_fieldcat-scrtext_m = ls_fieldlist-field_txt.
          ls_fieldcat-scrtext_l = ls_fieldlist-field_txt.
        ENDIF.
      ENDIF.

    ELSE. "COUNT & AVG field
      CLEAR ls_compx.
      READ TABLE lo_descr_line->components INTO ls_compx
                 WITH KEY name = ls_fieldlist-field.        "#EC WARNOK
      ls_fieldcat-intlen    = ls_compx-length.
      ls_fieldcat-decimals  = ls_compx-decimals.
      ls_fieldcat-inttype   = ls_compx-type_kind.

      IF ls_fieldlist-field_txt IS INITIAL.
        ls_fieldcat-coltext   = ls_fieldlist-ref_field.
        ls_fieldcat-reptext   = ls_fieldlist-ref_field.
        ls_fieldcat-scrtext_s = ls_fieldlist-ref_field.
        ls_fieldcat-scrtext_m = ls_fieldlist-ref_field.
        ls_fieldcat-scrtext_l = ls_fieldlist-ref_field.
      ELSE.
        ls_fieldcat-coltext   = ls_fieldlist-field_txt.
        ls_fieldcat-reptext   = ls_fieldlist-field_txt.
        ls_fieldcat-scrtext_s = ls_fieldlist-field_txt.
        ls_fieldcat-scrtext_m = ls_fieldlist-field_txt.
        ls_fieldcat-scrtext_l = ls_fieldlist-field_txt.
      ENDIF.
    ENDIF.

    CASE ls_fieldlist-field_type.
      WHEN 'CURR'.
        ls_fieldcat-cfieldname = ls_fieldlist-field_ref.
      WHEN 'QUAN'.
        ls_fieldcat-qfieldname = ls_fieldlist-field_ref.
      WHEN OTHERS.
    ENDCASE.
    APPEND ls_fieldcat TO lt_fieldcat.
  ENDLOOP.

  ls_layout-smalltitle = abap_true.
  ls_layout-zebra      = abap_true.
  ls_layout-cwidth_opt = abap_true.
  ls_layout-grid_title = pv_title.
  ls_layout-detailinit = abap_true.  " 세부사항 초기값도 조회
  ls_layout-sel_mode   = 'A'.
*  ls_layout-countfname = 'COUNT'.

* Set the grid config and content
  CALL METHOD gs_tab_active-alv_result->set_table_for_first_display
    EXPORTING
      is_layout       = ls_layout
    CHANGING
      it_outtab       = <lpt_data>
      it_fieldcatalog = lt_fieldcat.

* Search if grid is currently displayed
  CALL METHOD go_splitter->get_row_height
    EXPORTING
      id     = 1
    IMPORTING
      result = lv_height.
  CALL METHOD cl_gui_cfw=>flush.

* If grid is hidden, display it
  IF lv_height = 100.
    CALL METHOD go_splitter->set_row_height
      EXPORTING
        id     = 1
        height = 20.
  ENDIF.
ENDFORM.                    " RESULT_DISPLAY
*&---------------------------------------------------------------------*
*&      Form  DDIC_INIT
*&---------------------------------------------------------------------*
*       Initialize ddic tree
*----------------------------------------------------------------------*
FORM ddic_init.

  DATA: ls_header   TYPE treev_hhdr,
        ls_event    TYPE cntl_simple_event,
        lt_events   TYPE cntl_simple_events,
        lo_dragdrop TYPE REF TO cl_dragdrop,
        lv_mode     TYPE i.

  ls_header-heading = 'SAP Table/Fields'(t02).
  ls_header-width = 18.
  lv_mode = cl_gui_column_tree=>node_sel_mode_single.

* Column1 : Table/Fields
  CREATE OBJECT gs_tab_active-tree_ddic
    EXPORTING
      parent                      = go_container_ddic
      node_selection_mode         = lv_mode
      item_selection              = abap_true
      hierarchy_column_name       = gc_ddic_col1
      hierarchy_header            = ls_header
    EXCEPTIONS
      cntl_system_error           = 1
      create_error                = 2
      failed                      = 3
      illegal_node_selection_mode = 4
      illegal_column_name         = 5
      lifetime_error              = 6.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

* Column2: Description
  CALL METHOD gs_tab_active-tree_ddic->add_column
    EXPORTING
      name                         = gc_ddic_col3
      width                        = 40
      header_text                  = 'Description'(t03)
    EXCEPTIONS
      column_exists                = 1
      illegal_column_name          = 2
      too_many_columns             = 3
      illegal_alignment            = 4
      different_column_types       = 5
      cntl_system_error            = 6
      failed                       = 7
      predecessor_column_not_found = 8.

* Column3 : F4
  CALL METHOD gs_tab_active-tree_ddic->add_column
    EXPORTING
      name                         = gc_ddic_col2
      width                        = 04
      header_text                  = 'F4'(t09)
    EXCEPTIONS
      column_exists                = 1
      illegal_column_name          = 2
      too_many_columns             = 3
      illegal_alignment            = 4
      different_column_types       = 5
      cntl_system_error            = 6
      failed                       = 7
      predecessor_column_not_found = 8.


* Column4 : Conversion Exit
  CALL METHOD gs_tab_active-tree_ddic->add_column
    EXPORTING
      name                         = gc_ddic_col4
      width                        = 06
      header_text                  = 'ConvExit'(t10)
    EXCEPTIONS
      column_exists                = 1
      illegal_column_name          = 2
      too_many_columns             = 3
      illegal_alignment            = 4
      different_column_types       = 5
      cntl_system_error            = 6
      failed                       = 7
      predecessor_column_not_found = 8.

* Column5 : Data Type
  CALL METHOD gs_tab_active-tree_ddic->add_column
    EXPORTING
      name                         = gc_ddic_col5
      width                        = 06
      header_text                  = 'DataType'(t11)
    EXCEPTIONS
      column_exists                = 1
      illegal_column_name          = 2
      too_many_columns             = 3
      illegal_alignment            = 4
      different_column_types       = 5
      cntl_system_error            = 6
      failed                       = 7
      predecessor_column_not_found = 8.

* Column6 : Length/Decimals
  CALL METHOD gs_tab_active-tree_ddic->add_column
    EXPORTING
      name                         = gc_ddic_col6
      width                        = 10
      header_text                  = 'Leng'(t12)
    EXCEPTIONS
      column_exists                = 1
      illegal_column_name          = 2
      too_many_columns             = 3
      illegal_alignment            = 4
      different_column_types       = 5
      cntl_system_error            = 6
      failed                       = 7
      predecessor_column_not_found = 8.


* Manage Item clic event to copy value in clipboard
  ls_event-eventid    = cl_gui_column_tree=>eventid_item_double_click.
  ls_event-appl_event = abap_true.
  APPEND ls_event TO lt_events.

  CALL METHOD gs_tab_active-tree_ddic->set_registered_events
    EXPORTING
      events                    = lt_events
    EXCEPTIONS
      cntl_error                = 1
      cntl_system_error         = 2
      illegal_event_combination = 3.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

* Manage Drag from DDIC editor
  CREATE OBJECT lo_dragdrop.
  CALL METHOD lo_dragdrop->add
    EXPORTING
      flavor     = 'EDIT_INSERT'
      dragsrc    = abap_true
      droptarget = space
      effect     = cl_dragdrop=>copy.
  CALL METHOD lo_dragdrop->get_handle
    IMPORTING
      handle = w_dragdrop_handle_tree.

  SET HANDLER go_handle_event->hnd_ddic_item_dblclick FOR gs_tab_active-tree_ddic.
  SET HANDLER go_handle_event->hnd_ddic_drag          FOR gs_tab_active-tree_ddic.

ENDFORM.                    " DDIC_INIT
*&---------------------------------------------------------------------*
*&      Form  DDIC_SET_TREE
*&---------------------------------------------------------------------*
*       Refresh query with list of table/fields of the given query
*       Add User defined tree from ZSPRO (if relevant)
*----------------------------------------------------------------------*
*      -->pv_FROM  From part of the query
*----------------------------------------------------------------------*
FORM ddic_set_tree USING pv_query TYPE string
                         pv_from  TYPE string
                         pv_union TYPE string.

  DATA : lv_from           TYPE string,
         lv_union          TYPE string,
         lt_split          TYPE TABLE OF string,
         lv_string         TYPE string,
         lv_tabix          TYPE i,
         ls_table_list     TYPE tys_table_list,
         lt_table_list     TYPE tyt_table_list,
         lv_node_number(6) TYPE n,
         lv_tabname        TYPE tabname,
         lv_fieldname      TYPE fieldname,
         ls_node           LIKE LINE OF gs_tab_active-t_node_ddic,
         ls_item           LIKE LINE OF gs_tab_active-t_item_ddic,
         lv_parent_node    LIKE ls_node-node_key,
         ls_ddic_fields    TYPE tys_ddic_fields,
         lt_ddic_fields    TYPE tyt_ddic_fields,
         ls_table_w        TYPE tys_table_w,
         lt_dfies          TYPE TABLE OF dfies.

  CONCATENATE 'FROM' pv_from INTO lv_from SEPARATED BY space.
  TRANSLATE lv_from TO UPPER CASE.
  SPLIT lv_from AT space INTO TABLE lt_split.

  " union
  lv_union = pv_union.

  DATA(lt_pairs___) = lcl_toad_util=>extract_tables_and_aliases(
                        iv_from      = lv_from
                        iv_union_all = lv_union ).

  IF lt_pairs___ IS NOT INITIAL.
    " util 결과를 그대로 lt_table_list 로 매핑 (레거시 분해 루프는 건너뜀)
    CLEAR lt_table_list.
    LOOP AT lt_pairs___ ASSIGNING FIELD-SYMBOL(<ls_pair___>).
      CLEAR ls_table_list.
      ls_table_list-table = <ls_pair___>-table.   " ex) STAS, +V_STAS
      ls_table_list-alias = <ls_pair___>-alias.   " ex) A, B (있으면)
      APPEND ls_table_list TO lt_table_list.
    ENDLOOP.

  ELSE.
    " ▼▼▼ 기존 레거시 분해 로직은 폴백으로만 사용 ▼▼▼
    CONCATENATE 'FROM' pv_from INTO lv_from SEPARATED BY space.
    TRANSLATE lv_from TO UPPER CASE.
    SPLIT lv_from AT space INTO TABLE lt_split.

    LOOP AT lt_split INTO lv_string.

      lv_tabix = sy-tabix + 1.
      CHECK sy-tabix = 1 OR lv_string = 'JOIN'.
      " Read next line (table name)
      READ TABLE lt_split INTO lv_string INDEX lv_tabix.
      CHECK sy-subrc = 0.

      CLEAR ls_table_list.
      ls_table_list-table = lv_string.

      lv_tabix = lv_tabix + 1.
      " Read next line (search alias)
      READ TABLE lt_split INTO lv_string INDEX lv_tabix.
      IF sy-subrc = 0 AND lv_string = 'AS'.
        lv_tabix = lv_tabix + 1.
        READ TABLE lt_split INTO lv_string INDEX lv_tabix.
        IF sy-subrc = 0.
          ls_table_list-alias = lv_string.
        ENDIF.
      ENDIF.

      APPEND ls_table_list TO lt_table_list.

    ENDLOOP.

  ENDIF.

  " 입력된 query 에 with 문이 있는지 확인
  DATA: lv_query_s   TYPE string,
        lv_with      TYPE string,
        lv_newsyntax.
  PERFORM split_with_clause  USING    pv_query
                             CHANGING lv_with
                                      lv_query_s
                                      lv_newsyntax.
  CLEAR: gt_table_w[].
  PERFORM make_table_w USING    lv_with
                       CHANGING gt_table_w.

  " with 문에 추가된 table
  IF gt_table_w IS NOT INITIAL.
    LOOP AT gt_table_w INTO ls_table_w .
      CLEAR: ls_table_list.
      ls_table_list-table = ls_table_w-tabname.
      APPEND ls_table_list TO lt_table_list.
    ENDLOOP.
  ENDIF.

  SORT lt_table_list BY table ASCENDING
                        alias DESCENDING.
  DELETE ADJACENT DUPLICATES FROM lt_table_list
         COMPARING table.

* Get list of fields for selected tables
  PERFORM check_ddlsource CHANGING lt_table_list.
  IF NOT lt_table_list IS INITIAL.
    LOOP AT lt_table_list INTO ls_table_list.

      CLEAR lt_dfies.
      lt_dfies = lcl_toad_util=>get_dfies_buffered(
                   iv_tabname = ls_table_list-table ).
      CHECK lt_dfies IS NOT INITIAL.

      lt_ddic_fields = CORRESPONDING #( BASE ( lt_ddic_fields ) lt_dfies
                                               MAPPING convexit_4 = convexit
                                                       convexit_1 = convexit
                                                       ddtext1    = fieldtext
                                                       ddtext2    = fieldtext
                                                       shlporigin = f4availabl
                                      ).
    ENDLOOP.

    SORT lt_ddic_fields BY tabname keyflag DESCENDING position.
    DELETE ADJACENT DUPLICATES FROM lt_ddic_fields
                               COMPARING tabname fieldname.

    " inline view list 추가
    DATA: lv_position         TYPE dd03l-position,
          lv_select_field     TYPE string,
          lv_select_field_txt TYPE string.
    LOOP AT lt_table_list INTO ls_table_list.

      CHECK ls_table_list-table+0(1) = '+'.

      ls_table_w = VALUE #( gt_table_w[ tabname = ls_table_list-table ] OPTIONAL ).
      CHECK ls_table_w IS NOT INITIAL.

      CLEAR: lv_position.
      LOOP AT ls_table_w-field_list INTO DATA(ls_field_list).

        ADD  1  TO lv_position.

        CLEAR: ls_ddic_fields.
        IF ls_field_list-ref_table IS NOT INITIAL AND
           ls_field_list-ref_field IS NOT INITIAL.

          IF ls_field_list-ref_table+0(1) = '+'.

          ELSE.
            lv_tabname   = ls_field_list-ref_table.
            lv_fieldname = ls_field_list-ref_field.

            CLEAR: lt_dfies, ls_ddic_fields.
            lt_dfies = lcl_toad_util=>get_dfies_buffered(
                         iv_tabname   = lv_tabname
                         iv_fieldname = lv_fieldname ).
            IF lt_dfies IS NOT INITIAL.
              ls_ddic_fields = CORRESPONDING #( lt_dfies[ 1 ]
                                                MAPPING convexit_4 = convexit
                                                        convexit_1 = convexit
                                                        ddtext1    = fieldtext
                                                        ddtext2    = fieldtext
                                                        shlporigin = f4availabl
                                              ).
            ENDIF.

          ENDIF.

        ELSE.
          SELECT SINGLE datatype leng decimals
            FROM dd04l
            INTO CORRESPONDING FIELDS OF ls_ddic_fields
           WHERE rollname = ls_field_list-field_type
             AND as4local = 'A'.
          IF sy-subrc NE 0.
            ls_ddic_fields-datatype = ls_field_list-field_type.
          ENDIF.
        ENDIF.

        ls_ddic_fields-tabname   = ls_table_w-tabname.
        ls_ddic_fields-fieldname = ls_field_list-field.
        ls_ddic_fields-position  = lv_position.
        APPEND ls_ddic_fields TO lt_ddic_fields.

      ENDLOOP.

    ENDLOOP.
  ENDIF.

* Build Node & Item tree
  REFRESH : gs_tab_active-t_node_ddic,
            gs_tab_active-t_item_ddic.

  lv_node_number = 0.
  SORT lt_table_list BY table.
  LOOP AT lt_table_list INTO ls_table_list.

* Check table exists (has at least one field)
    READ TABLE lt_ddic_fields TRANSPORTING NO FIELDS
               WITH KEY tabname = ls_table_list-table.
    IF sy-subrc NE 0.
      DELETE lt_table_list.
      CONTINUE.
    ENDIF.

    lv_node_number = lv_node_number + 1.

    CLEAR ls_node.
    ls_node-node_key  = lv_node_number.
    ls_node-isfolder  = abap_true.
    ls_node-n_image   = '@PO@'.
    ls_node-exp_image = '@PO@'.
    ls_node-expander  = abap_true.
    APPEND ls_node TO gs_tab_active-t_node_ddic.

    CLEAR ls_item.
    ls_item-node_key  = lv_node_number.
    ls_item-class     = cl_gui_column_tree=>item_class_text.
    ls_item-item_name = gc_ddic_col1.
    IF ls_table_list-alias IS INITIAL.
      ls_item-text = ls_table_list-table.
    ELSE.
      CONCATENATE ls_table_list-table 'AS' ls_table_list-alias
                   INTO ls_item-text SEPARATED BY space.
    ENDIF.

    IF ls_table_list-table_org IS NOT INITIAL.
      CONCATENATE ls_item-text '(' ls_table_list-table_org ')'
                   INTO ls_item-text SEPARATED BY space.
    ENDIF.

    APPEND ls_item TO gs_tab_active-t_item_ddic.

* Table Description
    ls_item-item_name = gc_ddic_col3.
    IF ls_table_list-is_ddls = abap_true.
      SELECT SINGLE t~ddtext
        FROM ddldependency  AS v
             INNER JOIN ddddlsrct AS t ON  t~ddlname    = v~ddlname
                                       AND t~ddlanguage = sy-langu
        INTO ls_item-text
       WHERE ( v~ddlname    = ls_table_list-table_org OR
               v~objectname = ls_table_list-table_org ).

    ELSE.
      SELECT SINGLE ddtext INTO ls_item-text
             FROM dd02t
             WHERE tabname = ls_table_list-table
             AND ddlanguage = sy-langu
             AND as4local = gc_vers_active
             AND as4vers = space.
    ENDIF.
    IF sy-subrc NE 0.
      ls_item-text = ls_table_list-table.
    ENDIF.
    APPEND ls_item TO gs_tab_active-t_item_ddic.

* Display list of fields
    lv_parent_node = ls_node-node_key.
    LOOP AT lt_ddic_fields INTO ls_ddic_fields
            WHERE tabname = ls_table_list-table.
      CLEAR ls_node.
      lv_node_number = lv_node_number + 1.
      ls_node-node_key = lv_node_number.
      ls_node-relatkey = lv_parent_node.
      ls_node-relatship = cl_gui_column_tree=>relat_last_child.

      IF ls_ddic_fields-keyflag = space.
        ls_node-n_image   = '@3W@'.
        ls_node-exp_image = '@3W@'.
      ELSE.
        ls_node-n_image   = '@3V@'.
        ls_node-exp_image = '@3V@'.
      ENDIF.

      ls_node-dragdropid = w_dragdrop_handle_tree.
      APPEND ls_node TO gs_tab_active-t_node_ddic.

      " field name
      CLEAR ls_item.
      ls_item-node_key = lv_node_number.
      ls_item-class = cl_gui_column_tree=>item_class_text.
      ls_item-item_name = gc_ddic_col1.
      ls_item-text = ls_ddic_fields-fieldname.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

      " Possable Entry
      ls_item-item_name = gc_ddic_col2.
      IF ls_ddic_fields-shlporigin IS NOT INITIAL.
        ls_item-text = abap_true.
      ELSE.
        ls_item-text = space.
      ENDIF.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

      " description
      ls_item-item_name = gc_ddic_col3.
      IF NOT ls_ddic_fields-ddtext1 IS INITIAL.
        ls_item-text = ls_ddic_fields-ddtext1.
      ELSE.
        ls_item-text = ls_ddic_fields-ddtext2.
      ENDIF.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

      " convertion exit
      ls_item-item_name = gc_ddic_col4.
      IF NOT ls_ddic_fields-convexit_4 IS INITIAL.
        ls_item-text = ls_ddic_fields-convexit_1.
      ELSE.
        ls_item-text = ls_ddic_fields-convexit_4.
      ENDIF.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

      " data type
      ls_item-item_name = gc_ddic_col5.
      ls_item-text = ls_ddic_fields-datatype.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

      " Length
      ls_item-item_name = gc_ddic_col6.
      ls_item-text      = |{ ls_ddic_fields-leng     ALPHA = OUT }|.
      IF NOT ls_ddic_fields-decimals IS INITIAL.
        ls_item-text = ls_item-text && |.{ ls_ddic_fields-decimals ALPHA = OUT }|.
      ENDIF.
      APPEND ls_item TO gs_tab_active-t_item_ddic.

    ENDLOOP.
  ENDLOOP.

  CALL METHOD gs_tab_active-tree_ddic->delete_all_nodes.

  CALL METHOD gs_tab_active-tree_ddic->add_nodes_and_items
    EXPORTING
      node_table                     = gs_tab_active-t_node_ddic
      item_table                     = gs_tab_active-t_item_ddic
      item_table_structure_name      = 'MTREEITM'
    EXCEPTIONS
      failed                         = 1
      cntl_system_error              = 3
      error_in_tables                = 4
      dp_error                       = 5
      table_structure_name_not_found = 6.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

  DESCRIBE TABLE lt_table_list LINES lv_tabix.

* If no table found, display message
  IF lv_tabix = 0.
    MESSAGE 'No valid table found'(m15) TYPE gc_msg_success
            DISPLAY LIKE gc_msg_error.
* If 1 table found, expand it
  ELSEIF lv_tabix = 1.
    gs_tab_active-tree_ddic->expand_root_nodes( ).
  ENDIF.

ENDFORM.                    " DDIC_SET_TREE
*&---------------------------------------------------------------------*
*&      Form  REPGO_SAVE_QUERY
*&---------------------------------------------------------------------*
*       Save query
*----------------------------------------------------------------------*
FORM repgo_save_query.

  DATA : lt_query         TYPE soli_tab,
         ls_query         LIKE LINE OF lt_query,
         lv_query_with_cr TYPE string,
         lv_guid          TYPE guid_32,
         ls_ybt_toad      TYPE ybt_toad,
         lv_timestamp(14) TYPE c.

* Set default options
  SELECT visibility_group INTO gs_options-visibilitygrp
         FROM ybt_toad UP TO 1 ROWS
         WHERE owner             = sy-uname
           AND visibility        = '3'
           AND visibility_group <> space
        ORDER BY queryid.
  ENDSELECT.
  gs_options-visibility    = '0'.

* Ask for options / query name
  CALL SCREEN 0200 STARTING AT 10 5
                   ENDING AT 63 7.
  IF gs_options IS INITIAL.
    MESSAGE 'Action cancelled'(m14) TYPE gc_msg_success
            DISPLAY LIKE gc_msg_error.
    RETURN.
  ENDIF.

* Get content of abap edit box
  CALL METHOD gs_tab_active-textedit->get_text
    IMPORTING
      table  = lt_query[]
    EXCEPTIONS
      OTHERS = 1.

* Serialize query into a string
  lv_query_with_cr = lcl_toad_util=>soli_tab_to_string(
                       it_query = lt_query ).

* Generate new GUID
  DO 100 TIMES.
* Old function to get an unique id
    CALL FUNCTION 'GUID_CREATE'
      IMPORTING
        ev_guid_32 = lv_guid.
* New function to get an unique id (do not work on older sap system)
*    TRY.
*        lv_guid = cl_system_uuid=>create_uuid_c32_static( ).
*      CATCH cx_uuid_error.
*        EXIT. "exit do
*    ENDTRY.

* Check that this uid is not already used
    SELECT SINGLE queryid INTO ls_ybt_toad-queryid
           FROM ybt_toad
           WHERE queryid = lv_guid.
    IF sy-subrc NE 0.
      EXIT. "exit do
    ENDIF.
  ENDDO.

  ls_ybt_toad-queryid          = lv_guid.
  ls_ybt_toad-owner            = sy-uname.
  lv_timestamp(8)              = sy-datum.
  lv_timestamp+8               = sy-uzeit.
  ls_ybt_toad-aedat            = lv_timestamp.
  ls_ybt_toad-text             = gs_options-name.
  ls_ybt_toad-visibility       = gs_options-visibility.
  ls_ybt_toad-visibility_group = gs_options-visibilitygrp.
  ls_ybt_toad-query            = lv_query_with_cr.
  INSERT ybt_toad FROM ls_ybt_toad.
  IF sy-subrc = 0.
    MESSAGE s031(r9). "Query saved
  ELSE.
    MESSAGE e220(iqapi). "Error when saving the query
  ENDIF.

* Reset the modified status
  gs_tab_active-textedit->set_textmodified_status( ).

* Refresh repository to display new saved query
  PERFORM repgo_make_query_history.

* Focus repository on new saved query
  PERFORM repgo_focus_query USING lv_guid.

ENDFORM.                    " REPGO_SAVE_QUERY
*&---------------------------------------------------------------------*
*&      Form  REPGO_INITIALIZE
*&---------------------------------------------------------------------*
*       Initialize repository tree
*----------------------------------------------------------------------*
FORM repgo_initialize.

  DATA: lt_button TYPE ttb_button,
        ls_button LIKE LINE OF lt_button,
        lt_event  TYPE cntl_simple_events,
        ls_event  TYPE cntl_simple_event.

* Create a tree control
  CREATE OBJECT go_tree_repository
    EXPORTING
      parent              = go_container_repository
      node_selection_mode = cl_gui_simple_tree=>node_sel_mode_single
    EXCEPTIONS
      lifetime_error      = 1
      cntl_system_error   = 2
      create_error        = 3
      failed              = 4
      OTHERS              = 5.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

* Catch double clic to open query
  ls_event-eventid = cl_gui_simple_tree=>eventid_node_double_click.
*  ls_event-appl_event = abap_true. " no PAI if event occurs
  ls_event-appl_event = space.
  APPEND ls_event TO lt_event.

* Catch context menu call
  ls_event-eventid = cl_gui_simple_tree=>eventid_node_context_menu_req.
*  ls_event-appl_event = abap_true. " no PAI if event occurs
  ls_event-appl_event = space.
  APPEND ls_event TO lt_event.

* Add buttons event
*  ls_event-eventid = cl_gui_toolbar=>m_id_function_selected.
*  ls_event-appl_event = space.
*  APPEND ls_event TO lt_event.

  CALL METHOD go_tree_repository->set_registered_events
    EXPORTING
      events                    = lt_event
    EXCEPTIONS
      cntl_error                = 1
      cntl_system_error         = 2
      illegal_event_combination = 3.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

* toolbar
  go_toolbar_repgo = go_splittoolbar_repository->get_toolbar( ).
* Add buttons to toolbar
  CLEAR ls_button.
  ls_button-function  = 'REFRESH'.
  ls_button-icon      = '@42@'.
  ls_button-quickinfo = 'Refresh Repository Tree'(m70).
  ls_button-text      = 'Refresh'(m40).
  lcl_toad_util=>add_toolbar_button( IMPORTING es_button = ls_button CHANGING cs_button = ls_button  ).
  ls_button-butn_type = 0.
  APPEND ls_button   TO lt_button.

  CALL METHOD go_toolbar_repgo->add_button_group
    EXPORTING
      data_table = lt_button.


* Assign event handlers in the application class to each desired event
  SET HANDLER go_handle_event->hnd_repgo_toolbar_clic      FOR go_toolbar_repgo.

  SET HANDLER go_handle_event->hnd_repgo_dblclick          FOR go_tree_repository.
  SET HANDLER go_handle_event->hnd_repgo_context_menu      FOR go_tree_repository.
  SET HANDLER go_handle_event->hnd_repgo_context_menu_sel  FOR go_tree_repository.

  PERFORM repgo_make_query_history.

ENDFORM.                    " REPGO_Initialize
*&---------------------------------------------------------------------*
*&      Form  REPGO_MAKE_QUERY_HISTORY
*&---------------------------------------------------------------------*
*       Fill repository tree with all allowed queries
*----------------------------------------------------------------------*
FORM repgo_make_query_history.

  DATA: lv_usergroup   TYPE usr02-class,
        ls_node_parent LIKE gs_node_repository,
        BEGIN OF ls_query,
          queryid          TYPE ybt_toad-queryid,
          owner            TYPE ybt_toad-owner,
          aedat            TYPE ybt_toad-aedat,
          visibility       TYPE ybt_toad-visibility,
          visibility_group TYPE ybt_toad-visibility_group,
          text             TYPE ybt_toad-text,
          query            TYPE ybt_toad-query,
        END OF ls_query,
        lt_query_my     LIKE TABLE OF ls_query,
        lt_query_shared LIKE TABLE OF ls_query,
        lv_node_key(6)  TYPE n,
        lv_queryid      TYPE ybt_toad-queryid,
        lv_dummy(1)     TYPE c.                             "#EC NEEDED

* Get usergroup
  DATA: lr_usergroup   TYPE RANGE OF ybt_toad-visibility_group,
        ls_usergroup_r LIKE LINE OF lr_usergroup.

  SELECT visibility_group AS low
    FROM ybt_toad
    INTO CORRESPONDING FIELDS OF TABLE lr_usergroup
   WHERE owner             = sy-uname
     AND visibility        = gc_visibility_group
     AND visibility_group NE space.

  ls_usergroup_r-sign   = 'I'.
  ls_usergroup_r-option = 'EQ'.
  MODIFY lr_usergroup FROM ls_usergroup_r
         TRANSPORTING sign option
         WHERE sign = space.

* Get all my queries
  SELECT queryid aedat visibility visibility_group text query owner
    FROM ybt_toad
    INTO CORRESPONDING FIELDS OF TABLE lt_query_my
   WHERE owner = sy-uname.
  SORT lt_query_my BY visibility_group visibility aedat DESCENDING.

* Get all queries that i can use
  SELECT queryid aedat visibility visibility_group text query owner
    FROM ybt_toad
    INTO CORRESPONDING FIELDS OF TABLE lt_query_shared
   WHERE owner NE sy-uname
     AND ( visibility = gc_visibility_all OR
          ( visibility = gc_visibility_shared AND visibility_group IN lr_usergroup )
         ).
  SORT lt_query_shared BY owner visibility_group visibility aedat DESCENDING.

  REFRESH gt_node_repository.

  CALL METHOD go_tree_repository->delete_all_nodes.

*--------------------------------------------------------------------*
  CLEAR gs_node_repository.
  gs_node_repository-node_key = gc_nodekey_repgo_my.
  gs_node_repository-isfolder = abap_true.
  gs_node_repository-text     = 'My Queries'(m16).
  APPEND gs_node_repository  TO gt_node_repository.

  CLEAR lv_node_key.
  CONCATENATE sy-uname '+++' INTO lv_queryid.

  " 사용자 Group 추가
  LOOP AT lt_query_my INTO ls_query WHERE visibility = gc_visibility_group.

    " group 이 있는지 확인
    CHECK ls_query-visibility_group IS NOT INITIAL.
    READ TABLE gt_node_repository INTO ls_node_parent
         WITH KEY visibility_group = ls_query-visibility_group
                  relatkey         = gc_nodekey_repgo_my.
    CHECK sy-subrc NE 0.

    lv_node_key = lv_node_key + 1.
    CLEAR gs_node_repository.
    gs_node_repository-node_key          = lv_node_key.
    gs_node_repository-relatkey          = gc_nodekey_repgo_my.
    gs_node_repository-isfolder          = abap_true.
    gs_node_repository-visibility_group  = ls_query-visibility_group.
    gs_node_repository-text              = ls_query-visibility_group.
    APPEND gs_node_repository TO gt_node_repository.

  ENDLOOP.

  LOOP AT lt_query_my INTO ls_query WHERE queryid NP lv_queryid
                                      AND visibility <> gc_visibility_group.

*  query 의 group 지정
    IF ls_query-visibility_group IS INITIAL.
      ls_node_parent-node_key = gc_nodekey_repgo_my.
    ELSE.
      " group 이 있는지 확인
      READ TABLE gt_node_repository INTO ls_node_parent
           WITH KEY visibility_group = ls_query-visibility_group
                    relatkey         = gc_nodekey_repgo_my.
      IF sy-subrc NE 0.
        ls_node_parent-node_key = gc_nodekey_repgo_my.
      ENDIF.
    ENDIF.

    lv_node_key = lv_node_key + 1.
    CLEAR gs_node_repository.
    gs_node_repository-node_key  = lv_node_key.
    gs_node_repository-relatkey  = ls_node_parent-node_key.
    gs_node_repository-relatship = cl_gui_simple_tree=>relat_last_child.
    IF ls_query-visibility = gc_visibility_my.
      gs_node_repository-n_image = gs_node_repository-exp_image = '@LC@'.
    ELSE.
      gs_node_repository-n_image = gs_node_repository-exp_image = '@L9@'.
    ENDIF.

*    CONCATENATE ls_query-text '(' ls_query-visibility ')'
*           INTO gs_node_repository-text.
    gs_node_repository-text = ls_query-text.

    SHIFT ls_query-query LEFT DELETING LEADING cl_abap_char_utilities=>cr_lf.
    SHIFT ls_query-query LEFT DELETING LEADING space.

    IF ls_query-query IS NOT INITIAL AND
       ( ls_query-query(1) = '*' OR ls_query-query(1) = '"' ).
      SPLIT ls_query-query+1 AT cl_abap_char_utilities=>cr_lf
            INTO ls_query-query lv_dummy.
      CONCATENATE gs_node_repository-text ':' ls_query-query
                  INTO gs_node_repository-text SEPARATED BY space.
    ENDIF.

    gs_node_repository-queryid = ls_query-queryid.
    gs_node_repository-edit    = abap_true.
    APPEND gs_node_repository TO gt_node_repository.

  ENDLOOP.

*--------------------------------------------------------------------*
  CLEAR gs_node_repository.
  gs_node_repository-node_key = gc_nodekey_repgo_shared.
  gs_node_repository-isfolder = abap_true.
  gs_node_repository-text     = 'Shared Queries'(m17).
  APPEND gs_node_repository  TO gt_node_repository.

  LOOP AT lt_query_shared INTO ls_query WHERE visibility = '1' OR visibility = '2'.

    IF ls_query-visibility_group IS INITIAL.
      ls_node_parent-node_key = gc_nodekey_repgo_shared.
    ELSE.
      " group 이 있는지 확인
      READ TABLE gt_node_repository INTO ls_node_parent
           WITH KEY visibility_group = ls_query-visibility_group
                    relatkey         = gc_nodekey_repgo_shared.
      IF sy-subrc NE 0.
        lv_node_key = lv_node_key + 1.
        CLEAR gs_node_repository.
        gs_node_repository-node_key  = lv_node_key.
        gs_node_repository-relatkey  = gc_nodekey_repgo_shared.
        gs_node_repository-isfolder  = abap_true.
        gs_node_repository-visibility_group    = ls_query-visibility_group.
        gs_node_repository-text      = ls_query-visibility_group.
        APPEND gs_node_repository   TO gt_node_repository.

        ls_node_parent-node_key = lv_node_key.
      ENDIF.
    ENDIF.

    lv_node_key = lv_node_key + 1.

    CLEAR gs_node_repository.
    gs_node_repository-node_key  = lv_node_key.
    gs_node_repository-relatkey  = ls_node_parent-node_key.
    gs_node_repository-relatship = cl_gui_simple_tree=>relat_last_child.
    gs_node_repository-n_image   = gs_node_repository-exp_image = '@L9@'.
    gs_node_repository-queryid   = ls_query-queryid.
    gs_node_repository-edit      = space.

    CONCATENATE ls_query-text '(' ls_query-owner ')'
           INTO gs_node_repository-text.

    SHIFT ls_query-query LEFT DELETING LEADING cl_abap_char_utilities=>cr_lf.
    SHIFT ls_query-query LEFT DELETING LEADING space.
    IF ls_query-query IS NOT INITIAL AND
       ( ls_query-query(1) = '*' OR ls_query-query(1) = '"' ).
      SPLIT ls_query-query+1 AT cl_abap_char_utilities=>cr_lf
            INTO ls_query-query lv_dummy.
      CONCATENATE gs_node_repository-text ':' ls_query-query
                  INTO gs_node_repository-text SEPARATED BY space.
    ENDIF.

    APPEND gs_node_repository TO gt_node_repository.

  ENDLOOP.

*--------------------------------------------------------------------*
* Add history node
  CLEAR gs_node_repository.
  gs_node_repository-node_key = gc_nodekey_repgo_history.
  gs_node_repository-isfolder = abap_true.
  gs_node_repository-text = 'Query History'(m18).
  APPEND gs_node_repository TO gt_node_repository.

  DELETE lt_query_my WHERE queryid NP lv_queryid.
  SORT lt_query_my BY aedat DESCENDING.

  LOOP AT lt_query_my INTO ls_query WHERE visibility = '0' .

    lv_node_key = lv_node_key + 1.

    CLEAR gs_node_repository.
    gs_node_repository-node_key   = lv_node_key.
    gs_node_repository-relatkey   = gc_nodekey_repgo_history.
    gs_node_repository-relatship  = cl_gui_simple_tree=>relat_last_child.
    gs_node_repository-n_image    = gs_node_repository-exp_image = '@LC@'.
    gs_node_repository-text       = ls_query-text.
    gs_node_repository-queryid    = ls_query-queryid.
    gs_node_repository-visibility = ls_query-visibility.
    gs_node_repository-edit       = abap_true.

    SHIFT ls_query-query LEFT DELETING LEADING cl_abap_char_utilities=>cr_lf.
    SHIFT ls_query-query LEFT DELETING LEADING space.
    IF ls_query-query IS NOT INITIAL AND
       ( ls_query-query(1) = '*' OR ls_query-query(1) = '"' ).
      SPLIT ls_query-query+1 AT cl_abap_char_utilities=>cr_lf
            INTO ls_query-query lv_dummy.
      CONCATENATE gs_node_repository-text ':' ls_query-query
                  INTO gs_node_repository-text SEPARATED BY space.
    ENDIF.
    APPEND gs_node_repository TO gt_node_repository.
  ENDLOOP.

*--------------------------------------------------------------------*
* Add Source of Execution Program node
  CLEAR gs_node_repository.
  gs_node_repository-node_key = gc_nodekey_repgo_extsource.
  gs_node_repository-isfolder = abap_true.
  gs_node_repository-text = 'Source of Execution Program '(m69).
  APPEND gs_node_repository TO gt_node_repository.

  LOOP AT lt_query_my INTO ls_query WHERE visibility = '4' .

    lv_node_key = lv_node_key + 1.

    CLEAR gs_node_repository.
    gs_node_repository-node_key   = lv_node_key.
    gs_node_repository-relatkey   = gc_nodekey_repgo_extsource.
    gs_node_repository-relatship  = cl_gui_simple_tree=>relat_last_child.
    gs_node_repository-n_image    = gs_node_repository-exp_image = '@LC@'.
    gs_node_repository-text       = ls_query-text.
    gs_node_repository-queryid    = ls_query-queryid.
    gs_node_repository-visibility = ls_query-visibility.
    gs_node_repository-edit       = abap_true.

    SHIFT ls_query-query LEFT DELETING LEADING cl_abap_char_utilities=>cr_lf.
    SHIFT ls_query-query LEFT DELETING LEADING space.
    IF ls_query-query IS NOT INITIAL AND
       ( ls_query-query(1) = '*' OR ls_query-query(1) = '"' ).
      SPLIT ls_query-query+1 AT cl_abap_char_utilities=>cr_lf
      INTO ls_query-query lv_dummy.
      CONCATENATE gs_node_repository-text ':' ls_query-query
                  INTO gs_node_repository-text SEPARATED BY space.
    ENDIF.
    APPEND gs_node_repository TO gt_node_repository.
  ENDLOOP.
*--------------------------------------------------------------------*

  CALL METHOD go_tree_repository->add_nodes
    EXPORTING
      table_structure_name           = 'MTREESNODE'
      node_table                     = gt_node_repository
    EXCEPTIONS
      failed                         = 1
      error_in_node_table            = 2
      dp_error                       = 3
      table_structure_name_not_found = 4
      OTHERS                         = 5.
  IF sy-subrc <> 0.
    MESSAGE a000(tree_control_msg).
  ENDIF.

* Exand all root nodes (my, shared, history)
  CALL METHOD go_tree_repository->expand_root_nodes.

ENDFORM.                    " REPGO_MAKE_QUERY_HISTORY
*&---------------------------------------------------------------------*
*&      Form  REPgo_SAVE_CURRENT_QUERY
*&---------------------------------------------------------------------*
*       Save query in the history area
*       Keep only 100 last queries
*----------------------------------------------------------------------*
FORM repgo_save_current_query USING pv_visibility.

  DATA : lt_query         TYPE soli_tab,
         ls_query         LIKE LINE OF lt_query,
         lv_query_with_cr TYPE string,
         ls_ybt_toad      TYPE ybt_toad,
         lv_number(2)     TYPE n,
         lv_timestamp(14) TYPE c,
         lv_dummy(1)      TYPE c,                           "#EC NEEDED
         lv_query_last    TYPE string,
         lv_date(10)      TYPE c,
         lv_time(8)       TYPE c,
         lv_dummy_date    TYPE timestamp,                   "#EC NEEDED
         lt_code_string   TYPE TABLE OF string.

  CLEAR lv_query_with_cr.

* Get content of abap edit box
  CASE pv_visibility.
    WHEN '0'.
      CALL METHOD gs_tab_active-textedit->get_text
        IMPORTING
          table  = lt_query[]
        EXCEPTIONS
          OTHERS = 1.

* Serialize query into a string
      lv_query_with_cr = lcl_toad_util=>soli_tab_to_string(
                           it_query = lt_query ).

    WHEN '4'.
      IMPORT content = lt_code_string
        FROM MEMORY ID 'YB_SOURCE_SAVE'.

      lv_query_with_cr = lcl_toad_util=>string_tab_to_string(
                           it_lines             = lt_code_string
                           iv_add_source_header = abap_true ).
    WHEN OTHERS.
      EXIT.
  ENDCASE.

* Define timestamp
  lv_timestamp(8)   = sy-datum.
  lv_timestamp+8    = sy-uzeit.
  ls_ybt_toad-aedat = lv_timestamp.

* Search if query is same as last loaded
  SELECT SINGLE query INTO lv_query_last
         FROM ybt_toad
         WHERE queryid = w_last_loaded_query.
  IF sy-subrc = 0 AND lv_query_last = lv_query_with_cr.
    RETURN.
  ENDIF.

* Get usergroup
*  SELECT SINGLE class INTO ls_ybt_toad-visibility_group
*         FROM usr02
*         WHERE bname = sy-uname.

  CLEAR lv_number.

* Get last query from history
  CONCATENATE sy-uname '#%' INTO ls_ybt_toad-queryid.
* aedat is not used but added in select for compatibility reason
  SELECT queryid aedat
         INTO (ls_ybt_toad-queryid, lv_dummy_date)
         FROM ybt_toad
         UP TO 1 ROWS
         WHERE queryid LIKE ls_ybt_toad-queryid
         AND owner = sy-uname
         ORDER BY aedat DESCENDING.
  ENDSELECT.
  IF sy-subrc = 0.
    SPLIT ls_ybt_toad-queryid AT '#' INTO lv_dummy lv_number.
  ENDIF.

  lv_number = lv_number + 1.

* For history query, guid = <sy-uname>#NN
  CONCATENATE sy-uname '#' lv_number INTO ls_ybt_toad-queryid.
  ls_ybt_toad-owner      = sy-uname.
  ls_ybt_toad-visibility = pv_visibility.

* Define text for query as timestamp
  WRITE sy-datlo TO lv_date.
  WRITE sy-timlo TO lv_time.
*  CONCATENATE lv_date lv_time INTO ls_ybt_toad-text SEPARATED BY space.
  CONCATENATE lv_date+5 lv_time+0(5) INTO ls_ybt_toad-text SEPARATED BY space.

  ls_ybt_toad-query = lv_query_with_cr.
  MODIFY ybt_toad FROM ls_ybt_toad.

  w_last_loaded_query = ls_ybt_toad-queryid.

* Reset the modified status
  gs_tab_active-textedit->set_textmodified_status( ).

* Refresh repository
  PERFORM repgo_make_query_history.

* Focus on new query
  PERFORM repgo_focus_query USING ls_ybt_toad-queryid.

ENDFORM.                    " REPgo_SAVE_CURRENT_QUERY
*&---------------------------------------------------------------------*
*&      Form  QUERY_LOAD
*&---------------------------------------------------------------------*
*       Load query
*----------------------------------------------------------------------*
*      -->pv_QUERYID QueryID to load
*      <--pt_QUERY   Saved query
*----------------------------------------------------------------------*
FORM query_load USING pv_queryid TYPE ybt_toad-queryid
                CHANGING pt_query TYPE table.

  DATA lv_query_with_cr TYPE string.
  REFRESH pt_query.

  SELECT SINGLE query INTO lv_query_with_cr
         FROM ybt_toad
         WHERE queryid = pv_queryid.
  IF sy-subrc = 0.
    SPLIT lv_query_with_cr AT cl_abap_char_utilities=>cr_lf
                           INTO TABLE pt_query.
  ENDIF.

  w_last_loaded_query = pv_queryid.

ENDFORM.                    " QUERY_LOAD
*&---------------------------------------------------------------------*
*&      Form  REPgo_FOCUS_QUERY
*&---------------------------------------------------------------------*
*       Focus repository tree on a given queryid
*----------------------------------------------------------------------*
*      -->pv_QUERYID  ID of the query to focus
*----------------------------------------------------------------------*
FORM repgo_focus_query USING pv_queryid TYPE ybt_toad-queryid.

  READ TABLE gt_node_repository INTO gs_node_repository
             WITH KEY queryid = pv_queryid.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

  CALL METHOD go_tree_repository->set_selected_node
    EXPORTING
      node_key = gs_node_repository-node_key.

ENDFORM.                    " FOCUS_REPOSITORY
*&---------------------------------------------------------------------*
*&      Form  RESULT_INIT
*&---------------------------------------------------------------------*
*       Initialize ALV grid
*----------------------------------------------------------------------*
FORM result_init.

* Create ALV
  CREATE OBJECT gs_tab_active-alv_result
    EXPORTING
      i_parent = go_container_result.

* Register event toolbar to add button
  SET HANDLER go_handle_event->hnd_result_toolbar FOR gs_tab_active-alv_result.
  SET HANDLER go_handle_event->hnd_result_user_command FOR gs_tab_active-alv_result.

ENDFORM.                    " RESULT_INIT
*&---------------------------------------------------------------------*
*&      Form  SCREEN_INIT_LISTBOX_0200
*&---------------------------------------------------------------------*
*       Fill dropdown listbox with value on screen 200
*----------------------------------------------------------------------*
FORM screen_init_listbox_0200.

  DATA : lt_visibility TYPE vrm_values,
         ls_visibility LIKE LINE OF lt_visibility.

  REFRESH lt_visibility.

  ls_visibility-key = gc_visibility_my.
  ls_visibility-text = 'Personal'(m19).
  APPEND ls_visibility TO lt_visibility.

  ls_visibility-key = gc_visibility_shared.
  ls_visibility-text = 'User group'(m20).
  APPEND ls_visibility TO lt_visibility.

  ls_visibility-key = gc_visibility_all.
  ls_visibility-text = 'All'(m21).
  APPEND ls_visibility TO lt_visibility.

  CALL FUNCTION 'VRM_SET_VALUES'
    EXPORTING
      id     = 'GS_OPTIONS-VISIBILITY'
      values = lt_visibility.

ENDFORM.                    " SCREEN_INIT_LISTBOX_0200
*&---------------------------------------------------------------------*
*&      Form  SCREEN_EXIT
*&---------------------------------------------------------------------*
*       Close the grid. If grid is closed, leave program
*       If sql text area is modified, ask confirmation before leave
*----------------------------------------------------------------------*
FORM screen_exit.

  DATA : lv_status    TYPE i,
         lv_answer(1) TYPE c,
         lv_size      TYPE i,
         lv_string    TYPE string.

* Check if grid is displayed
  CALL METHOD go_splitter->get_row_height
    EXPORTING
      id     = 1
    IMPORTING
      result = lv_size.
  CALL METHOD cl_gui_cfw=>flush.

* If grid is displayed, BACK action is only to close the grid
  IF lv_size < 100.
    CALL METHOD go_splitter->set_row_height
      EXPORTING
        id     = 1
        height = 100.
    RETURN.
  ENDIF.

* Check if textedit is modified
  CALL METHOD gs_tab_active-textedit->get_textmodified_status
    IMPORTING
      status = lv_status.
  IF lv_status NE 0.
    IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
      lv_string = 'ABAP Source가 저장되지 않았습니다. 저장 후 종료하시겠습니까?'.
    ELSE.
      CONCATENATE 'Current query is not saved. Do you want'(m22)
'to exit without saving or save into history then exit ?'(m56)
                  INTO lv_string SEPARATED BY space.
    ENDIF.

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        text_question         = lv_string
        text_button_1         = 'Exit'(m23)
        icon_button_1         = '@2M@'
        text_button_2         = 'Save & exit'(m24)
        icon_button_2         = '@2L@'
        default_button        = '2'
        display_cancel_button = space
      IMPORTING
        answer                = lv_answer.
    IF lv_answer = '2'.
      IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
        lcl_toad_source_editor=>save_current_tab( ).
      ELSE.
        PERFORM repgo_save_current_query USING '0'.
      ENDIF.
    ENDIF.
  ENDIF.

  LEAVE TO SCREEN 0.

ENDFORM.                    " SCREEN_EXIT
*&---------------------------------------------------------------------*
*&      Form  SCREEN_DISPLAY_HELP
*&---------------------------------------------------------------------*
*       Display help for this program
*----------------------------------------------------------------------*
FORM screen_display_help.

  DATA: ls_report          TYPE string,
        lv_report_char1(1) TYPE c,
        lv_report_char3(3) TYPE c,
        lv_comment_found   TYPE i,
        lt_report          LIKE TABLE OF ls_report,
        lt_lines           TYPE rcl_bag_tline,
        ls_line            LIKE LINE OF lt_lines,
        ls_help            TYPE help_info,
        lt_exclude         TYPE STANDARD TABLE OF string.

* Get program source code
  READ REPORT sy-repid INTO lt_report.

  ls_line-tdformat = 'U1'.
  ls_line-tdline = sy-title.
  APPEND ls_line TO lt_lines.

  ls_line-tdformat = 'U3'.
  ls_line-tdline = '&PURPOSE&'.
  APPEND ls_line TO lt_lines.

  LOOP AT lt_report INTO ls_report.

    lv_report_char1 = ls_report.
    CHECK lv_report_char1 =  '*'.

* Keep only the second block of comment
* (first block is technical info, third is history)
    lv_report_char3 = ls_report.
    CHECK lv_report_char3 <> '***'.

    IF lv_report_char3 = '*&-'.
      lv_comment_found = lv_comment_found + 1.
      IF lv_comment_found LE 2.
        CONTINUE.
      ELSE. "l_comment_found > 2
        EXIT.
      ENDIF.
    ENDIF.

    IF lv_comment_found = 2.
      ls_report = ls_report+1.
      lv_report_char1 = ls_report.
      CASE lv_report_char1.
        WHEN '='.    ls_line-tdformat = '='.  " 구분선 (Horizontal line)
        WHEN '3'.    ls_line-tdformat = 'U3'. " 사용자 정의 스타일, 레벨(예: H1, H2, H3처럼 제목 계층)
        WHEN 'E'.    ls_line-tdformat = 'PE'. " 표의 끝(End of table)
        WHEN OTHERS. ls_line-tdformat = '*'.  " 일반 Text
      ENDCASE.
      IF NOT lv_report_char1 IS INITIAL.
        ls_report = ls_report+1.
      ENDIF.
      IF ls_report IS INITIAL.
        ls_line-tdformat = 'LZ'.
      ENDIF.
      ls_line-tdline = ls_report.
      APPEND ls_line TO lt_lines.
    ENDIF.

  ENDLOOP.

  CALL FUNCTION 'HELP_DOCULINES_SHOW'
    EXPORTING
      help_infos = ls_help
    TABLES
      excludefun = lt_exclude
      helplines  = lt_lines.

ENDFORM.                    " SCREEN_DISPLAY_HELP
*&---------------------------------------------------------------------*
*&      Form  QUERY_PARSE_NOSELECT
*&---------------------------------------------------------------------*
*       Check if query is a known SQL command and if user is allowed
*----------------------------------------------------------------------*
*      -->PV_QUERY   Query to check
*      <--PV_NOAUTH  Unallowed table or command entered
*      <--PV_COMMAND Command to execute (INSERT, DELETE, ...)
*      <--PV_TABLE   Target table of the query
*      <--PV_PARAM   Parameters for the command (WHERE, SET, ...)
*----------------------------------------------------------------------*
FORM query_parse_noselect  USING    pv_query   TYPE string
                           CHANGING pv_noauth  TYPE c
                                    pv_command TYPE string
                                    pv_table   TYPE string
                                    pv_param   TYPE string.
  DATA : lv_query TYPE string,
         lv_table TYPE tabname.

  CLEAR : pv_noauth,
          pv_table,
          pv_command,
          pv_param.

  lv_query = pv_query.
  SPLIT lv_query AT space INTO pv_command lv_query.
  TRANSLATE pv_command TO UPPER CASE.
  CASE pv_command.
    WHEN 'INSERT'.
      " pv_param 내에 into 가 있는 경우 삭제
      REPLACE FIRST OCCURRENCE OF 'INTO' IN lv_query WITH ''
             IGNORING CASE.
      SHIFT lv_query LEFT DELETING LEADING space.

      SPLIT lv_query AT space INTO pv_table pv_param.
      TRANSLATE pv_table TO UPPER CASE.

*      IF gs_customize-auth_object NE space.
*        lv_table = pv_table.
*        AUTHORITY-CHECK OBJECT gs_customize-auth_object
*                 ID 'TABLE' FIELD lv_table
*                 ID 'ACTVT' FIELD gs_customize-actvt_insert.
*      ELSEIF gs_customize-auth_insert NE '*'
*      AND pv_table NP gs_customize-auth_insert.
*        sy-subrc = 4.
*      ENDIF.
*      IF sy-subrc NE 0.
*        CONCATENATE 'No authorisation for table'(m13) pv_table
*                    INTO lv_query SEPARATED BY space.
*        MESSAGE lv_query TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
*        pv_noauth = abap_true.
*        RETURN.
*      ENDIF.

    WHEN 'UPDATE'.
      SPLIT lv_query AT space INTO pv_table pv_param.
      TRANSLATE pv_table TO UPPER CASE.

*      IF gs_customize-auth_object NE space.
*        lv_table = pv_table.
*        AUTHORITY-CHECK OBJECT gs_customize-auth_object
*                 ID 'TABLE' FIELD lv_table
*                 ID 'ACTVT' FIELD gs_customize-actvt_update.
*      ELSEIF gs_customize-auth_update NE '*'
*      AND pv_table NP gs_customize-auth_update.
*        sy-subrc = 4.
*      ENDIF.
*      IF sy-subrc NE 0.
*        CONCATENATE 'No authorisation for table'(m13) pv_table
*                    INTO lv_query SEPARATED BY space.
*        MESSAGE lv_query TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
*        pv_noauth = abap_true.
*        RETURN.
*      ENDIF.

    WHEN 'DELETE'.
      SPLIT lv_query AT space INTO pv_table pv_param.
      TRANSLATE pv_table TO UPPER CASE.
      IF pv_table = 'FROM'.
        SPLIT pv_param AT space INTO pv_table pv_param.
        TRANSLATE pv_table TO UPPER CASE.
      ENDIF.

    WHEN gc_native_command.
      CONCATENATE 'Native SQL is not supported.'(m71) pv_command
                  INTO lv_query.
      MESSAGE lv_query TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
      pv_noauth = abap_true.
      RETURN.

    WHEN OTHERS.
      CONCATENATE 'SQL command not allowed :'(m25) pv_command
                  INTO lv_query.
      MESSAGE lv_query TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
      pv_noauth = abap_true.
      RETURN.
  ENDCASE.

ENDFORM.                    " QUERY_PARSE_NOSELECT
*&---------------------------------------------------------------------*
*&      Form  QUERY_GENERATE_NOSELECT
*&---------------------------------------------------------------------*
*       Create all other than SELECT SQL query in a new generated
*       temp program
*----------------------------------------------------------------------*
*      -->pv_COMMAND Query type
*      -->pv_TABLE   Target table of the query
*      -->pv_PARAM   Parameters of the query
*      -->pv_DISPLAY   Display code instead of generated routine
*      <--pv_PROGRAM Name of the generated program
*----------------------------------------------------------------------*
FORM query_generate_noselect  USING    pv_command TYPE string
                                       pv_table TYPE string
                                       pv_param TYPE string
                                       pv_display TYPE c
                              CHANGING pv_program TYPE sy-repid.

  DATA : lt_code_string      TYPE TABLE OF string,
         lv_mess(255),
         lv_line             TYPE i,
         lv_word(30),
         lv_strlen_string    TYPE string,
         lv_explicit         TYPE string,
         lv_length           TYPE i,
         lv_pos              TYPE i,
         lv_fieldnum         TYPE i,
         lv_fieldval         TYPE string,
         lv_fieldname        TYPE string,
         lv_wait_name(1)     TYPE c,
         lv_char(1)          TYPE c,
         lv_started(1)       TYPE c,
         lv_started_field(1) TYPE c,
         lv_param            TYPE string.

* Write Header
  c 'PROGRAM SUBPOOL.'.                                     "#EC NOTEXT
  c ''.
  c '** Generated Program * Do Not Change It **'.           "#Ec Notext
  c ''.
  c 'TYPE-POOLS: SLIS.'.                                    "#EC NOTEXT
  c 'DATA: LV_TIMESTART TYPE TIMESTAMPL,'.                  "#EC NOTEXT
  c '      LV_TIMEEND   TYPE TIMESTAMPL.'.                  "#EC NOTEXT
  c ''.
  IF pv_command = 'INSERT'.
    c 'DATA LS_INSERT TYPE'.                                "#EC NOTEXT
    c pv_table.
    c '.'.                                                  "#EC NOTEXT
    c 'FIELD-SYMBOLS <LV_FS> TYPE ANY.'.                    "#EC NOTEXT
    c '.'.                                                  "#EC NOTEXT
  ENDIF.

* WRITE THE DYNAMIC SUBROUTINE THAT RUN THE SELECT
  c ''.
  c 'FORM RUN_SQL CHANGING PO_RESULT    TYPE REF TO DATA'.  "#EC NOTEXT
  c '                      PV_SHOW_RESULT  TYPE C'.         "#EC NOTEXT
  c '                      PV_TIME      TYPE P'.            "#EC NOTEXT
  c '                      PV_COUNT     TYPE I.'.           "#EC NOTEXT
  c ''.
  c '***************************************'.              "#EC NOTEXT
  c '*            BEGIN OF QUERY           *'.              "#EC NOTEXT
  c '***************************************'.              "#EC NOTEXT
  c ''.
  c 'CLEAR PV_COUNT.'.                                      "#EC NOTEXT
  c 'GET TIME STAMP FIELD LV_TIMESTART.'.                   "#EC NOTEXT
  c ''.

  CASE pv_command.
    WHEN 'UPDATE'.
      c pv_command.
      c pv_table.
      c pv_param.
      c '.'.

    WHEN 'DELETE'.
      c pv_command.
      c 'FROM'.                                             "#EC NOTEXT
      c pv_table.
      c pv_param.
      c '.'.

    WHEN 'INSERT'.
      lv_param = pv_param.

      IF lv_param(6) = 'VALUES'.
        lv_length = strlen( lv_param ).
        lv_pos = 6.
        lv_fieldnum = 0.
        WHILE lv_pos < lv_length.
          lv_char = lv_param+lv_pos(1).
          lv_pos = lv_pos + 1.
          IF lv_started = space.
            IF lv_char NE '('. "begin of the list
              CONTINUE.
            ENDIF.
            lv_started = abap_true.
            CONTINUE.
          ENDIF.
          IF lv_started_field = space.
            IF lv_char = ')'. "end of the list
              EXIT. "exit while
            ENDIF.

            IF lv_char NE ''''. "field value must start by '
              CONTINUE.
            ENDIF.
            lv_started_field = abap_true.
            lv_fieldval = lv_char.
            lv_fieldnum = lv_fieldnum + 1.
            CONTINUE.
          ENDIF.
          IF lv_char = space.
            CONCATENATE lv_fieldval lv_char INTO lv_fieldval
                        SEPARATED BY space.
          ELSE.
            CONCATENATE lv_fieldval lv_char INTO lv_fieldval.
          ENDIF.
          IF lv_char = ''''. "end of a field ?
            IF lv_pos < lv_length.
              lv_char = lv_param+lv_pos(1).
            ELSE.
              CLEAR lv_char.
            ENDIF.
            IF lv_char = ''''. "not end !
              CONCATENATE lv_fieldval lv_char INTO lv_fieldval.
              lv_pos = lv_pos + 1.
              CONTINUE.
            ELSE. "end of a field!
              c 'ASSIGN COMPONENT'.                         "#EC NOTEXT
              c lv_fieldnum.
              c 'OF STRUCTURE ls_insert TO <lv_fs>.'.       "#EC NOTEXT
              c '<lv_fs> = '.                               "#EC NOTEXT
              c lv_fieldval.
              c '.'.                                        "#EC NOTEXT
              lv_started_field = space.
            ENDIF.
          ENDIF.
        ENDWHILE.
      ELSEIF lv_param(3) = 'SET'.


        lv_length = strlen( lv_param ).
        lv_pos = 3.
        lv_fieldnum = 0.
        lv_wait_name = abap_true.
        WHILE lv_pos < lv_length.
          lv_char = lv_param+lv_pos(1).
          lv_pos = lv_pos + 1.
          IF lv_wait_name = abap_true.
            TRANSLATE lv_char TO UPPER CASE.
            IF lv_char = space OR NOT sy-abcde CS lv_char.
              CONTINUE. "not a begin of fieldname
            ENDIF.
            lv_wait_name = space.
            lv_started = abap_true.
            CONCATENATE 'ls_insert-' lv_char
                        INTO lv_fieldname.                  "#EC NOTEXT
            CONTINUE.
          ENDIF.

          IF lv_started = abap_true.
            IF lv_char = space.
              CONCATENATE lv_fieldname lv_char INTO lv_fieldname
                          SEPARATED BY space.
            ELSE.
              CONCATENATE lv_fieldname lv_char INTO lv_fieldname.
            ENDIF.
            IF lv_char = '='. "end of the field name
              lv_started = space.
            ENDIF.

            CONTINUE.
          ENDIF.

          IF lv_started_field NE abap_true.
            IF lv_char NE ''''. "field value must start by '
              CONTINUE.
            ENDIF.
            lv_started_field = abap_true.
            lv_fieldval = lv_char.
            CONTINUE.
          ENDIF.

          IF lv_char = space.
            CONCATENATE lv_fieldval lv_char INTO lv_fieldval
                        SEPARATED BY space.
          ELSE.
            CONCATENATE lv_fieldval lv_char INTO lv_fieldval.
          ENDIF.
          IF lv_char = ''''. "end of a field ?
            IF lv_pos < lv_length.
              lv_char = lv_param+lv_pos(1).
            ELSE.
              CLEAR lv_char.
            ENDIF.
            IF lv_char = ''''. "not end !
              CONCATENATE lv_fieldval lv_char INTO lv_fieldval.
              lv_pos = lv_pos + 1.
              CONTINUE.
            ELSE. "end of a field!
              c lv_fieldname.
              c lv_fieldval.
              c '.'.
              lv_started_field = space.
              lv_wait_name = abap_true.
            ENDIF.
          ENDIF.
        ENDWHILE.
      ELSE.
        MESSAGE 'Error in INSERT syntax : VALUES / SET required'(m26)
                TYPE gc_msg_error.
      ENDIF. "if lv_param(6) = 'VALUES'.
      c pv_command.
      c 'INTO'.                                             "#EC NOTEXT
      c pv_table.
      c 'VALUES ls_insert.'.                                "#EC NOTEXT
  ENDCASE.

  c '.'.
  c ''.
* Get query execution time & Changed lines
  c 'IF sy-subrc = 0.'.                                     "#EC NOTEXT
  c '  pv_count = sy-dbcnt.'.                               "#EC NOTEXT
  c '  COMMIT WORK AND WAIT.'.
  c 'ENDIF.'.                                               "#EC NOTEXT
  c ''.
  c 'GET TIME STAMP FIELD lv_timeend.'.                     "#EC NOTEXT
  c 'pv_time = lv_timeend - lv_timestart.'.                 "#EC NOTEXT
  c ''.
  c 'ENDFORM.'.                                             "#EC NOTEXT

  CLEAR : lv_line,
          lv_word,
          lv_mess.
  SYNTAX-CHECK FOR lt_code_string PROGRAM sy-repid
               MESSAGE lv_mess LINE lv_line WORD lv_word.
  IF sy-subrc NE 0 AND pv_display = space.
    MESSAGE lv_mess TYPE gc_msg_error.
  ENDIF.

  IF pv_display = space.
    GENERATE SUBROUTINE POOL lt_code_string NAME pv_program.
  ELSE.
    IF lv_mess IS NOT INITIAL.
      lv_explicit = lv_line.
      CONCATENATE lv_mess '(line'(m28) lv_explicit ',word'(m29)
                  lv_word ')'(m30)
                  INTO lv_mess SEPARATED BY space.
      MESSAGE lv_mess TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    ENDIF.
    EDITOR-CALL FOR lt_code_string DISPLAY-MODE
                TITLE 'Generated code for current query'(t01).
  ENDIF.

ENDFORM.                    " QUERY_GENERATE_NOSELECT
*&---------------------------------------------------------------------*
*&      Form  DDIC_GET_FIELD_FROM_NODE
*&---------------------------------------------------------------------*
*       Get text for a DDIC node
*       Format of the text : tablename~fieldname
*----------------------------------------------------------------------*
*      -->pv_NODE_KEY   DDIC node key
*      -->pv_RELAT_KEY  DDIC parent node key
*      -->pv_TEXT       Text
*----------------------------------------------------------------------*
FORM ddic_get_field_from_node  USING    pv_node_key TYPE tv_nodekey
                                        pv_relat_key TYPE tv_nodekey
                               CHANGING pv_text TYPE string.
  DATA : ls_item        LIKE LINE OF gs_tab_active-t_item_ddic,
         ls_item_parent LIKE LINE OF gs_tab_active-t_item_ddic,
         lv_table       TYPE string,
         lv_alias       TYPE string.

* Get field name
  READ TABLE gs_tab_active-t_item_ddic INTO ls_item
             WITH KEY node_key = pv_node_key
                      item_name = gc_ddic_col1.

* Get table name
  READ TABLE gs_tab_active-t_item_ddic INTO ls_item_parent
             WITH KEY node_key = pv_relat_key
                      item_name = gc_ddic_col1.

* Search for alias
  SPLIT ls_item_parent-text AT ' AS ' INTO lv_table lv_alias.
  IF NOT lv_alias IS INITIAL.
    lv_table = lv_alias.
  ENDIF.

* Build tablename~fieldname
  CONCATENATE lv_table '~' ls_item-text INTO pv_text.
  CONCATENATE space pv_text space INTO pv_text RESPECTING BLANKS.

ENDFORM.                    " DDIC_GET_FIELD_FROM_NODE

*&---------------------------------------------------------------------*
*&      Form  EDITOR_PASTE
*&---------------------------------------------------------------------*
*       Paste given text to SQL editor at given position
*----------------------------------------------------------------------*
*      -->pv_TEXT Text to paste in editor
*      -->pv_LINE Line in editor to paste
*      -->pv_POS  Position in the line in editor
*----------------------------------------------------------------------*
FORM editor_paste  USING pv_text TYPE string
                         pv_line TYPE i
                         pv_pos TYPE i.
  DATA : lt_text    TYPE TABLE OF string,
         lv_pos     TYPE i,
         lv_line    TYPE i,
         lv_message TYPE string.

*   Set text with new line
  APPEND pv_text TO lt_text.
  IF gs_customize-paste_break = abap_true.
    lv_pos = pv_pos - 1.
    CLEAR lv_message.
    DO lv_pos TIMES.
      CONCATENATE lv_message space INTO lv_message RESPECTING BLANKS.
    ENDDO.
    APPEND lv_message TO lt_text.
  ENDIF.

  CALL METHOD gs_tab_active-textedit->insert_block_at_position
    EXPORTING
      line     = pv_line
      pos      = pv_pos
      text_tab = lt_text
    EXCEPTIONS
      OTHERS   = 0.

* Set cursor at end of pasted field
  IF gs_customize-paste_break = abap_true.
    lv_pos = pv_pos.
    lv_line = pv_line + 1.
  ELSE.
    lv_pos = strlen( pv_text ).
    lv_pos = lv_pos + pv_pos.
    lv_line = pv_line.
  ENDIF.

  CALL METHOD gs_tab_active-textedit->set_selection_pos_in_line
    EXPORTING
      line   = lv_line
      pos    = lv_pos
    EXCEPTIONS
      OTHERS = 0.

* Focus on editor
  CALL METHOD cl_gui_control=>set_focus
    EXPORTING
      control = gs_tab_active-textedit
    EXCEPTIONS
      OTHERS  = 0.

  CONCATENATE pv_text 'pasted to SQL Editor'(m27)
              INTO lv_message SEPARATED BY space.
  MESSAGE lv_message TYPE gc_msg_success.

ENDFORM.                    " EDITOR_PASTE
*&---------------------------------------------------------------------*
*&      Form  QUERY_PROCESS_NATIVE
*&---------------------------------------------------------------------*
*       Execute a given native sql command
*----------------------------------------------------------------------*
*      -->pv_COMMAND Native SQL Command to execute
*----------------------------------------------------------------------*
* --- pruned unused FORM: query_process_native
* FORM query_process_native USING pv_command TYPE string.
*
*
* ENDFORM.                    " QUERY_PROCESS_NATIVE
* --- end pruned FORM: query_process_native
*&---------------------------------------------------------------------*
*&      Form  REPgo_DELETE_HISTORY
*&---------------------------------------------------------------------*
*       Delete given history entry
*----------------------------------------------------------------------*
*      -->pv_NODE_KEY Node key of history to delete
*      <--pv_SUBRC    Return code
*----------------------------------------------------------------------*
FORM repgo_delete_history USING pv_node_key TYPE tv_nodekey
                          CHANGING pv_subrc TYPE i.

  DATA ls_histo LIKE gs_node_repository.

  READ TABLE gt_node_repository INTO ls_histo
             WITH KEY node_key = pv_node_key.
  IF sy-subrc = 0 AND ls_histo-edit NE space.
    DELETE FROM ybt_toad WHERE queryid = ls_histo-queryid.
    IF sy-subrc = 0.
      DELETE gt_node_repository WHERE node_key = pv_node_key.
      CALL METHOD go_tree_repository->delete_node
        EXPORTING
          node_key = pv_node_key.
    ENDIF.
  ENDIF.
  pv_subrc = sy-subrc.

ENDFORM.                    " REPgo_DELETE_HISTORY
*&---------------------------------------------------------------------*
*&      Form  options_load
*&---------------------------------------------------------------------*
*       Get saved options from user parameters table
*----------------------------------------------------------------------*
FORM options_load.

  DATA : lv_options  TYPE usr05-parva,
         lv_rows(10) TYPE c.

  GET PARAMETER ID 'YBZ_TOAD' FIELD lv_options.             "#EC EXISTS
  IF sy-subrc = 0.
    SPLIT lv_options AT ';' INTO lv_rows
                                 gs_customize-paste_break
                                 gs_customize-techname
                                 gs_customize-no_convext
                                 lv_options. "dummy
    gs_customize-default_rows = lv_rows.
  ENDIF.

ENDFORM.                    " options_load
*&---------------------------------------------------------------------*
*&      Form  options_save
*&---------------------------------------------------------------------*
*       Save user options in standard user parameters table
*----------------------------------------------------------------------*
FORM options_save.

  DATA : lv_options  TYPE usr05-parva,
         lv_rows(10) TYPE c.

  lv_rows =   gs_customize-default_rows.
  CONDENSE lv_rows NO-GAPS.
  CONCATENATE lv_rows
              gs_customize-paste_break
              gs_customize-techname
              gs_customize-no_convext
              INTO lv_options
              SEPARATED BY ';'.

  CALL FUNCTION 'SMAN_SET_USER_PARAMETER'
    EXPORTING
      parameter_id    = 'YBZ_TOAD'
      parameter_value = lv_options
    EXCEPTIONS
      OTHERS          = 2.
  IF sy-subrc <> 0.
    MESSAGE e082(s1). "Error saving parameter changes
  ENDIF.

ENDFORM.                    "options_save
*&---------------------------------------------------------------------*
*&      Form  DDIC_REFRESH_TREE
*&---------------------------------------------------------------------*
*       Refresh DDIC tree with current query
*----------------------------------------------------------------------*
FORM ddic_refresh_tree.

  IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
    RETURN.
  ENDIF.

  DATA : lv_query         TYPE string,
         lv_query2        TYPE string,
         lv_select        TYPE string,
         lv_from          TYPE string,
         lv_from2         TYPE string,
         lv_where         TYPE string,
         lv_with          TYPE string,
         lv_union         TYPE string,
         lv_rows(6)       TYPE n,
         lv_noauth(1)     TYPE c,
         lv_newsyntax(1)  TYPE c,
         lv_error(1)      TYPE c,
         ls_inline_option TYPE tys_inline_option.

* Get only usefull code for current query
  PERFORM editor_get_query USING space CHANGING lv_query ls_inline_option.

* Parse Query
  PERFORM query_parse USING lv_query
                      CHANGING lv_select lv_from lv_where
                               lv_with lv_union lv_rows lv_noauth
                               lv_newsyntax lv_error.

  IF lv_noauth NE space OR lv_error NE space.
    RETURN.

  ELSEIF lv_select IS INITIAL.
    PERFORM query_parse_noselect USING lv_query
                                 CHANGING lv_noauth lv_select
                                          lv_from lv_where.
    IF lv_noauth NE space OR lv_select = gc_native_command.
      RETURN.
    ENDIF.
  ENDIF.

  PERFORM tab_update_title USING lv_query.

* Refresh ddic tree with list of table/fields of the actual query
  PERFORM ddic_set_tree USING lv_query lv_from lv_union.

ENDFORM.                    " DDIC_REFRESH_TREE
*&---------------------------------------------------------------------*
*&      Form  DDIC_FIND_IN_TREE
*&---------------------------------------------------------------------*
*       Display popup to search a table in DDIC tree
*----------------------------------------------------------------------*
FORM ddic_find_in_tree.
  DATA : ls_sval        TYPE sval,
         lt_sval        LIKE TABLE OF ls_sval,
         lv_returncode  TYPE c,
         lv_search      TYPE string,
         lt_search      LIKE TABLE OF lv_search,
         ls_item_ddic   LIKE LINE OF gs_tab_active-t_item_ddic,
         lv_search_term TYPE string,
         lv_search_line TYPE i,
         lv_rest        TYPE i,
         lv_node_key    TYPE tv_nodekey,
         lt_nodekey     TYPE TABLE OF tv_nodekey.

* Build search table
  REFRESH lt_search.
  LOOP AT gs_tab_active-t_item_ddic INTO ls_item_ddic.
    lv_search = ls_item_ddic-text.
    APPEND lv_search TO lt_search.
    APPEND ls_item_ddic-node_key TO lt_nodekey.
  ENDLOOP.

* Ask for selection search
  ls_sval-tabname = 'RSDXX'.
  ls_sval-fieldname = 'FINDSTR'.
  ls_sval-value = space.
  APPEND ls_sval TO lt_sval.
  DO.
    CALL FUNCTION 'POPUP_GET_VALUES'
      EXPORTING
        popup_title     = space
      IMPORTING
        returncode      = lv_returncode
      TABLES
        fields          = lt_sval
      EXCEPTIONS
        error_in_fields = 1
        OTHERS          = 2.
    IF sy-subrc NE 0 OR lv_returncode NE space.
      EXIT. "exit do
    ENDIF.
    READ TABLE lt_sval INTO ls_sval INDEX 1.
    IF ls_sval-value = space.
      EXIT. "exit do
    ENDIF.

* For new search, start from line 1
    IF lv_search_term NE ls_sval-value.
      lv_search_term = ls_sval-value.
      lv_search_line = 1.
* For next result of same search, start from next line
    ELSE.
      lv_rest = lv_search_line MOD 2.
      lv_search_line = lv_search_line + 1 + lv_rest.
    ENDIF.

    FIND FIRST OCCURRENCE OF ls_sval-value IN TABLE lt_search
         FROM lv_search_line
         IN CHARACTER MODE IGNORING CASE
         MATCH LINE lv_search_line.

* Search string &1 not found
    IF sy-subrc NE 0 AND lv_search_line = 1.
      MESSAGE s065(0k) WITH lv_search_term DISPLAY LIKE gc_msg_error.
      CLEAR lv_search_line.
      CLEAR lv_search_term.

* Last selected entry reached
    ELSEIF sy-subrc NE 0.
      MESSAGE s066(0k) DISPLAY LIKE gc_msg_error.
      CLEAR lv_search_line.
      CLEAR lv_search_term.

* Found
    ELSE.
      MESSAGE 'String found'(m04) TYPE gc_msg_success.
      READ TABLE lt_nodekey INTO lv_node_key INDEX lv_search_line.
      CALL METHOD gs_tab_active-tree_ddic->set_selected_node
        EXPORTING
          node_key = lv_node_key.
      CALL METHOD gs_tab_active-tree_ddic->ensure_visible
        EXPORTING
          node_key = lv_node_key.
    ENDIF.

  ENDDO.
ENDFORM.                    " DDIC_FIND_IN_TREE
*&---------------------------------------------------------------------*
*&      Form  OPTIONS_INIT
*&---------------------------------------------------------------------*
*       Create option panel
*----------------------------------------------------------------------*
FORM options_init.

  DATA : lt_ptab TYPE wdy_wb_property_tab,
         ls_ptab TYPE wdy_wb_property.

* Create a custom container linked to the custom controm on screen 300
  CREATE OBJECT go_container_options
    EXPORTING
      container_name              = 'CUSTCONT2'
    EXCEPTIONS
      cntl_error                  = 1
      cntl_system_error           = 2
      create_error                = 3
      lifetime_error              = 4
      lifetime_dynpro_dynpro_link = 5
      OTHERS                      = 6.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

* Create the property object and link it to the custom controm
  CREATE OBJECT go_options
    EXPORTING
      parent                    = go_container_options
    EXCEPTIONS
      cntl_error                = 1
      cntl_system_error         = 2
      illegal_event_combination = 3
      OTHERS                    = 4.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

* Define Column title of the property object
  CALL METHOD go_options->initialize
    EXPORTING
      property_column_title = 'Property'(m44)
      value_column_title    = 'Value'(m45)
      focus_row             = 1
      scrollable            = abap_true.

  go_options->set_enabled( abap_true ).

* paste_break
  ls_ptab-name = 'PB'.
  ls_ptab-type = cl_wdy_wb_property_box=>property_type_boolean.
  ls_ptab-enabled = abap_true.
  ls_ptab-value = gs_customize-paste_break.
  CONCATENATE '@74\Q'
    'Add break line after pasting ddic field into sql editor'(m46)
    '@' 'Line Break'(m47) INTO ls_ptab-display_name.
  APPEND ls_ptab TO lt_ptab.

* default up to xxx rows
  ls_ptab-name = 'MAXROWS'.
  ls_ptab-type = cl_wdy_wb_property_box=>property_type_integer.
  ls_ptab-enabled = abap_true.
  ls_ptab-value = gs_customize-default_rows.
  CONCATENATE '@3W\Q'
    'Default max number of displayed lines for SELECT'(m48)
    '@' 'Max Rows'(m49) INTO ls_ptab-display_name.
  APPEND ls_ptab TO lt_ptab.

* default up to xxx rows
  ls_ptab-name = 'TECH'.
  ls_ptab-type = cl_wdy_wb_property_box=>property_type_boolean.
  ls_ptab-enabled = abap_true.
  ls_ptab-value = gs_customize-techname.
  CONCATENATE '@AJ\Q'
    'Display technical name in query result display'(m52)
    '@' 'Technical name'(m53) INTO ls_ptab-display_name.
  APPEND ls_ptab TO lt_ptab.

* conversion exit
  ls_ptab-name    = 'NO_CONVEXT'.
  ls_ptab-type    = cl_wdy_wb_property_box=>property_type_boolean.
  ls_ptab-enabled = abap_true.
  ls_ptab-value   = gs_customize-no_convext.
  CONCATENATE '@AJ\Q'
    'Whether to apply conversion exit'(m68)
    '@' 'No Conversion Exit'(m67) INTO ls_ptab-display_name.
  APPEND ls_ptab TO lt_ptab.

* Fill properties/values
  CALL METHOD go_options->set_properties
    EXPORTING
      properties = lt_ptab
      refresh    = abap_true.

ENDFORM.                    " OPTIONS_INIT
*&---------------------------------------------------------------------*
*&      Form  OPTIONS_DISPLAY
*&---------------------------------------------------------------------*
*       Display options panel
*----------------------------------------------------------------------*
FORM options_display.

  DATA : lt_ptab TYPE wdy_wb_property_tab,
         ls_ptab TYPE wdy_wb_property.

* If not first display, refresh properties values
  IF NOT go_options IS INITIAL.
    lt_ptab = go_options->get_properties( ).
    LOOP AT lt_ptab INTO ls_ptab.
      CASE ls_ptab-name.
        WHEN 'PB'.
          ls_ptab-value = gs_customize-paste_break.
        WHEN 'MAXROWS'.
          ls_ptab-value = gs_customize-default_rows.
        WHEN 'TECH'.
          ls_ptab-value = gs_customize-techname.
        WHEN 'NO_CONVEXT'.
          ls_ptab-value = gs_customize-no_convext.
      ENDCASE.
      CALL METHOD go_options->update_property
        EXPORTING
          property = ls_ptab.
    ENDLOOP.
  ENDIF.

* Display properties panel
  CALL SCREEN 300 STARTING AT 60 10
                  ENDING AT 110 16.
  IF gv_save_ok NE 'OK'.
    RETURN.
  ENDIF.

* Update values if not well refreshed in go_options
  CALL METHOD go_options->dispatch
    EXPORTING
      cargo             = gv_save_ok
      eventid           = 18
      is_shellevent     = space
      is_systemdispatch = space
    EXCEPTIONS
      OTHERS            = 0.

* Update values in gs_customize
  lt_ptab = go_options->get_properties( ).
  LOOP AT lt_ptab INTO ls_ptab.
    CASE ls_ptab-name.
      WHEN 'PB'.
        gs_customize-paste_break  = ls_ptab-value.
      WHEN 'MAXROWS'.
        gs_customize-default_rows = ls_ptab-value.
      WHEN 'TECH'.
        gs_customize-techname     = ls_ptab-value.
      WHEN 'NO_CONVEXT'.
        gs_customize-no_convext   = ls_ptab-value.
    ENDCASE.
  ENDLOOP.

* Save values in user parameters
  PERFORM options_save.

ENDFORM.                    " OPTIONS_DISPLAY
*&---------------------------------------------------------------------*
*&      Form  RESULT_SAVE_FILE
*&---------------------------------------------------------------------*
*       Save results into local file
*       - 1 line of header is written with technical column name
*       - Fields are separated by TAB
*       - Blank at end of char fields are removed
*----------------------------------------------------------------------*
*      -->po_result    Reference to data to display
*      -->pt_FIELDS    Field list
*----------------------------------------------------------------------*
FORM result_save_file USING po_result TYPE REF TO data
                            pt_fields TYPE tyt_fieldlist.

  DATA : lv_filename TYPE string,
         lt_file_f4  TYPE filetable,
         ls_file_f4  LIKE LINE OF lt_file_f4,
         lv_rc       TYPE i,
         lv_filter   TYPE string,
         lv_title    TYPE string,
         BEGIN OF ls_field_out,
           name TYPE char30,
         END OF ls_field_out,
         lt_fields   LIKE TABLE OF ls_field_out,
         ls_field_in LIKE LINE OF pt_fields.

  FIELD-SYMBOLS: <lpt_data> TYPE ANY TABLE.

  lv_filter = 'CSV File (*.csv)|*.csv'(m51).
  lv_title = 'Download results into file'(m63).
  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title = lv_title
      file_filter  = lv_filter
    CHANGING
      file_table   = lt_file_f4
      rc           = lv_rc
    EXCEPTIONS
      OTHERS       = 0.
  READ TABLE lt_file_f4 INTO ls_file_f4 INDEX 1.
  IF sy-subrc = 0.
    lv_filename = ls_file_f4.
  ENDIF.
  IF lv_filename IS INITIAL.
    RETURN.
  ENDIF.

  ASSIGN po_result->* TO <lpt_data>.
  LOOP AT pt_fields INTO ls_field_in.
    APPEND ls_field_in-ref_field TO lt_fields.
  ENDLOOP.
  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      filename              = lv_filename
      write_field_separator = abap_true
      trunc_trailing_blanks = abap_true
      fieldnames            = lt_fields
    CHANGING
      data_tab              = <lpt_data>
    EXCEPTIONS
      OTHERS                = 0.

ENDFORM.                    " RESULT_SAVE_FILE
*&---------------------------------------------------------------------*
*&      Form  DDIC_F4
*&---------------------------------------------------------------------*
*       Display F4 help on selected DDIC tree field
*       Paste selected value in SQL Editor
*----------------------------------------------------------------------*
FORM ddic_f4.
  DATA : lv_table      TYPE dfies-tabname,
         lv_field      TYPE dfies-fieldname,
         lt_val        TYPE TABLE OF ddshretval,
         ls_val        LIKE LINE OF lt_val,
         lv_nodekey    TYPE tv_nodekey,
         lv_item       TYPE tv_itmname,                     "#EC NEEDED
         ls_node       LIKE LINE OF gs_tab_active-t_node_ddic,
         ls_item       LIKE LINE OF gs_tab_active-t_item_ddic,
         lv_line_start TYPE i,
         lv_pos_start  TYPE i,
         lv_line_end   TYPE i,
         lv_pos_end    TYPE i,
         lv_val        TYPE string,
         lv_dummy      TYPE c.                              "#EC NEEDED

* Get selection in ddic tree
  CALL METHOD gs_tab_active-tree_ddic->get_selected_node "line selected
    IMPORTING
      node_key = lv_nodekey.
  IF lv_nodekey IS INITIAL.
    CALL METHOD gs_tab_active-tree_ddic->get_selected_item "item selected
      IMPORTING
        node_key  = lv_nodekey
        item_name = lv_item.
  ENDIF.
  IF lv_nodekey IS INITIAL.
    RETURN.
  ENDIF.

* Check selection is a field
  READ TABLE gs_tab_active-t_node_ddic INTO ls_node
             WITH KEY node_key = lv_nodekey.
  IF sy-subrc NE 0 OR ls_node-isfolder = abap_true.
    RETURN.
  ENDIF.

* Get field name
  READ TABLE gs_tab_active-t_item_ddic INTO ls_item
             WITH KEY node_key = lv_nodekey
                      item_name = gc_ddic_col1.
  lv_field = ls_item-text.

* Get table name
  READ TABLE gs_tab_active-t_item_ddic INTO ls_item
             WITH KEY node_key = ls_node-relatkey
                      item_name = gc_ddic_col1.
  SPLIT ls_item-text AT ' AS ' INTO lv_table lv_dummy.
  SPLIT lv_table     AT ' ('   INTO lv_table lv_dummy.

* Display standard value-list
  CALL FUNCTION 'F4IF_FIELD_VALUE_REQUEST'
    EXPORTING
      fieldname  = lv_field
      tabname    = lv_table
    TABLES
      return_tab = lt_val
    EXCEPTIONS
      OTHERS     = 1.

  IF sy-subrc = 0.
    READ TABLE lt_val INTO ls_val INDEX 1.
    CONCATENATE '''' ls_val-fieldval '''' INTO lv_val.
    CONCATENATE space lv_val INTO lv_val RESPECTING BLANKS.

* Get current cursor position/selection in editor
    CALL METHOD gs_tab_active-textedit->get_selection_pos
      IMPORTING
        from_line = lv_line_start
        from_pos  = lv_pos_start
        to_line   = lv_line_end
        to_pos    = lv_pos_end
      EXCEPTIONS
        OTHERS    = 4.
    IF sy-subrc NE 0.
      MESSAGE 'Cannot get cursor position'(m35) TYPE gc_msg_error.
    ENDIF.

*   If text is selected/highlighted, delete it
    IF lv_line_start NE lv_line_end
    OR lv_pos_start NE lv_pos_end.
      CALL METHOD gs_tab_active-textedit->delete_text
        EXPORTING
          from_line = lv_line_start
          from_pos  = lv_pos_start
          to_line   = lv_line_end
          to_pos    = lv_pos_end.
    ENDIF.

    PERFORM editor_paste USING lv_val lv_line_start lv_pos_start.
  ENDIF.

ENDFORM.                    " DDIC_F4
*&---------------------------------------------------------------------*
*&      Form  EDITOR_GET_DEFAULT_QUERY
*&---------------------------------------------------------------------*
*       Get default query
*----------------------------------------------------------------------*
*      <--pt_QUERY  Default query content
*----------------------------------------------------------------------*
FORM editor_get_default_query  CHANGING pt_query TYPE table.

  DATA lv_string TYPE string.

  APPEND '* Type here your query title' TO pt_query.        "#EC NOTEXT
  APPEND '' TO pt_query.
  APPEND 'SELECT *' TO pt_query.                            "#EC NOTEXT
  APPEND 'FROM <table_name>' TO pt_query.                   "#EC NOTEXT

  IF gs_customize-default_rows NE 0.
    lv_string = gs_customize-default_rows.
    CONDENSE lv_string NO-GAPS.
    CONCATENATE 'UP TO'
                lv_string
                'ROWS'
                INTO lv_string SEPARATED BY space.
    APPEND lv_string TO pt_query.                           "#EC NOTEXT
  ENDIF.

  APPEND 'WHERE <conditions>' TO pt_query.                  "#EC NOTEXT
  APPEND '.' TO pt_query.                                   "#EC NOTEXT

ENDFORM.                    " EDITOR_GET_DEFAULT_QUERY
*&---------------------------------------------------------------------*
*&      Form  TAB_NEW
*&---------------------------------------------------------------------*
*       Open a new tab
*----------------------------------------------------------------------*
FORM tab_new.
  DATA : l_numb TYPE i,
         l_tab  TYPE string.

  DESCRIBE TABLE gt_tabs LINES l_numb.
  IF l_numb GE 30.
    MESSAGE 'You cannot open more than 30 tabs'(m64)
            TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    RETURN.
  ENDIF.

  PERFORM leave_current_tab.

* Hide alv pane if displayed
  gs_tab_active-row_height = 100.
  CALL METHOD go_splitter->set_row_height
    EXPORTING
      id     = 1
      height = gs_tab_active-row_height.

* Start new tab
  l_tab = l_numb + 1.
  CONCATENATE 'TAB' l_tab INTO l_tab.
  CONDENSE l_tab NO-GAPS.
  go_tabstrip-activetab = l_tab.
*  go_tabstrip-%_SCROLLPOSITION = l_tab. "bugged

* Initialize new editor / ddic / alv
  PERFORM ddic_init.
  PERFORM editor_init.
  PERFORM result_init.

* Tab management
  APPEND gs_tab_active TO gt_tabs.

ENDFORM.                    " TAB_NEW
*&---------------------------------------------------------------------*
*&      Form  LEAVE_CURRENT_TAB
*&---------------------------------------------------------------------*
*       Hide editor / ddic / alv for current tab and save state
*----------------------------------------------------------------------*
FORM leave_current_tab.

* Hide current editor / ddic / alv
  CALL METHOD gs_tab_active-textedit->set_visible
    EXPORTING
      visible = space.

  CALL METHOD gs_tab_active-tree_ddic->set_visible
    EXPORTING
      visible = space.

  IF NOT gs_tab_active-alv_result IS INITIAL.
    CALL METHOD gs_tab_active-alv_result->set_visible
      EXPORTING
        visible = space.
  ENDIF.
* Save ALV split height
  CALL METHOD go_splitter->get_row_height
    EXPORTING
      id     = 1
    IMPORTING
      result = gs_tab_active-row_height.
  CALL METHOD cl_gui_cfw=>flush.

  PERFORM tab_update_title USING space.

  MODIFY gt_tabs FROM gs_tab_active INDEX go_tabstrip-activetab+3.
  CLEAR gs_tab_active.

ENDFORM.                    " LEAVE_CURRENT_TAB
*&--------------------------------------------------------------------*
*&      Form  TAB_UPDATE_TITLE
*&---------------------------------------------------------------------*
*       Update tab title regarding current query
*       - Display first line query if it is a comment
*       - Display query as title in other cases
*----------------------------------------------------------------------*
*      -->pv_QUERY Complete query
*----------------------------------------------------------------------*
FORM tab_update_title USING pv_query TYPE string.

  DATA : lv_name(30)      TYPE c,
         lt_query         TYPE soli_tab,
         ls_query         LIKE LINE OF lt_query,
         lv_query         TYPE string,
         ls_inline_option TYPE tys_inline_option.

  FIELD-SYMBOLS <lv_fld_title> TYPE any.

  IF lcl_toad_source_editor=>is_source_tab( ) = abap_true.
    lcl_toad_source_editor=>set_active_title( ).
    RETURN.
  ENDIF.

  IF go_tabstrip-activetab IS INITIAL.
    lv_name = 'GS_TAB-TITLE1'.
  ELSE.
    CONCATENATE 'GS_TAB-TITLE' go_tabstrip-activetab+3 INTO lv_name.
  ENDIF.
  ASSIGN (lv_name) TO <lv_fld_title>.
  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

* Basic read query to check if first line is a comment
  CALL METHOD gs_tab_active-textedit->get_text
    IMPORTING
      table  = lt_query[]
    EXCEPTIONS
      OTHERS = 1.
  READ TABLE lt_query INTO ls_query INDEX 1.
  IF sy-subrc NE 0.
    <lv_fld_title> = 'Empty tab'(m65).
    RETURN.
  ENDIF.
  IF ls_query(1) = '*' OR ls_query(1) = '"'.
    <lv_fld_title> = ls_query+1.
    RETURN.
  ENDIF.

* Query given, use it as title
  IF NOT pv_query IS INITIAL.
    <lv_fld_title> = pv_query.
    RETURN.
  ENDIF.

* If no query given, try to read it
  PERFORM editor_get_query USING space CHANGING lv_query ls_inline_option.
  <lv_fld_title> = lv_query.

ENDFORM.                    " TAB_UPDATE_TITLE
*&---------------------------------------------------------------------*
*&      Form  Export_xml
*&---------------------------------------------------------------------*
*       Export Saved Queries in xml format
*----------------------------------------------------------------------*
FORM export_xml.

  DATA : BEGIN OF ls_xml,
           line(256) TYPE x,
         END OF ls_xml,
         lt_xml      LIKE TABLE OF ls_xml,

         lv_filename TYPE string,
         lv_path     TYPE string,
         lv_fullpath TYPE string.

  DATA : lo_xml           TYPE REF TO if_ixml,
         lo_document      TYPE REF TO if_ixml_document,
         lo_root          TYPE REF TO if_ixml_element,
         lo_element       TYPE REF TO if_ixml_element,
         lv_string        TYPE string,
         lo_streamfactory TYPE REF TO if_ixml_stream_factory,
         lo_ostream       TYPE REF TO if_ixml_ostream,
         lo_renderer      TYPE REF TO if_ixml_renderer,
         lv_title         TYPE string,
         lv_filter        TYPE string,
         lv_name          TYPE string,

         BEGIN OF ls_ybt_toad,
           queryid    TYPE ybt_toad-queryid,
           visibility TYPE ybt_toad-visibility_group,
           text       TYPE ybt_toad-text,
           query      TYPE ybt_toad-query,
         END OF ls_ybt_toad,
         lt_ybt_toad LIKE TABLE OF ls_ybt_toad.

* Ask name of file to generate
  lv_title = 'Choose file to create'(m57).
  lv_filter = 'XML File (*.xml)|*.xml'(m58).
  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title = lv_title
      file_filter  = lv_filter
    CHANGING
      path         = lv_path
      filename     = lv_filename
      fullpath     = lv_fullpath
    EXCEPTIONS
      OTHERS       = 1.
  IF sy-subrc NE 0 OR lv_filename IS INITIAL OR lv_path IS INITIAL.
    MESSAGE 'Action cancelled'(m14) TYPE gc_msg_success
            DISPLAY LIKE gc_msg_error.
    RETURN.
  ENDIF.

  CONCATENATE sy-uname '#%' INTO lv_name.
  CONDENSE lv_name NO-GAPS.

* Get all saved query (but not history)
  SELECT queryid visibility text query
    FROM ybt_toad
    INTO TABLE lt_ybt_toad
   WHERE owner = sy-uname
     AND visibility = '0'
     AND NOT queryid LIKE lv_name.

  lo_xml = cl_ixml=>create( ).
  lo_document = lo_xml->create_document( ).

  lo_root = lo_document->create_simple_element( name   = gc_xmlnode_root
                                                parent = lo_document ).
  LOOP AT lt_ybt_toad INTO ls_ybt_toad.
    lo_element = lo_document->create_simple_element( name   = gc_xmlnode_file
                                                     parent = lo_root ).
    lv_string = ls_ybt_toad-visibility.
    lo_element->set_attribute( name = gc_xmlattr_visibility value = lv_string ).

    lv_string = ls_ybt_toad-text.
    lo_element->set_attribute( name = gc_xmlattr_text value = lv_string ).

    lv_string = ls_ybt_toad-query.
    lo_element->set_value( lv_string ).
  ENDLOOP.

  lo_streamfactory = lo_xml->create_stream_factory( ).

  lo_ostream  = lo_streamfactory->create_ostream_itable( lt_xml ).

  lo_renderer = lo_xml->create_renderer( ostream  = lo_ostream
                                         document = lo_document ).
  lo_ostream->set_pretty_print( abap_true ).
  lo_renderer->render( ).

  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      filename = lv_fullpath
      filetype = 'BIN'
    CHANGING
      data_tab = lt_xml.

ENDFORM.                    "Export_xml
*&---------------------------------------------------------------------*
*&      Form  Import_xml
*&---------------------------------------------------------------------*
*       Import Saved Queries from xml format
*----------------------------------------------------------------------*
FORM import_xml.

  DATA : lt_filetab       TYPE filetable,
         ls_file          TYPE file_table,
         lv_filename      TYPE string,
         lv_subrc         LIKE sy-subrc,
         lv_xmldata       TYPE xstring,
         lo_xml           TYPE REF TO if_ixml,
         lo_document      TYPE REF TO if_ixml_document,
         lo_streamfactory TYPE REF TO if_ixml_stream_factory,
         lo_stream        TYPE REF TO if_ixml_istream,
         lo_parser        TYPE REF TO if_ixml_parser.
  DATA : lo_iterator  TYPE REF TO if_ixml_node_iterator,
         lo_node      TYPE REF TO if_ixml_node,
         lv_node_name TYPE string,
         lo_element   TYPE REF TO if_ixml_element,
         lv_title     TYPE string,
         lv_filter    TYPE string,
         lv_guid      TYPE guid_32,
         lv_group     TYPE usr02-class,
         lv_string    TYPE string,
         ls_ybt_toad  TYPE ybt_toad,
         lt_ybt_toad  LIKE TABLE OF ls_ybt_toad.

* Choose file to import
  lv_title = 'Choose file to import'(m59).
  lv_filter = 'XML File (*.xml)|*.xml'(m58).
  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title   = lv_title
      file_filter    = lv_filter
      multiselection = space
    CHANGING
      file_table     = lt_filetab
      rc             = lv_subrc.

* Check user action (1 OPEN, 2 CANCEL)
  IF lv_subrc NE 1.
    MESSAGE 'Action cancelled'(m14) TYPE gc_msg_success
            DISPLAY LIKE gc_msg_error.
    RETURN.
  ENDIF.

* Read filetable
  READ TABLE lt_filetab INTO ls_file INDEX 1.
  lv_filename = ls_file-filename.

* Get xml flow from file
* Or alternatively (if method does not exist) use the method
* cl_gui_frontend_services=>gui_upload and then convert the
* x-tab to xstring
  TRY.
      lv_xmldata = cl_openxml_helper=>load_local_file( lv_filename ).
    CATCH cx_openxml_not_found.
      MESSAGE 'Error when opening the input XML file'(m60)
              TYPE gc_msg_error.
      RETURN.
  ENDTRY.

  lo_xml = cl_ixml=>create( ).

  lo_document = lo_xml->create_document( ).
  lo_streamfactory = lo_xml->create_stream_factory( ).
  lo_stream = lo_streamfactory->create_istream_xstring( string = lv_xmldata ).

  lo_parser = lo_xml->create_parser( stream_factory = lo_streamfactory
                                     istream        = lo_stream
                                     document       = lo_document ).
*-- parse the stream
  IF lo_parser->parse( ) NE 0.
    IF lo_parser->num_errors( ) NE 0.
      MESSAGE 'Error when parsing the input XML file'(m61)
              TYPE gc_msg_error.
      RETURN.
    ENDIF.
  ENDIF.

*-- we don't need the stream any more, so let's close it...
  CALL METHOD lo_stream->close( ).
  CLEAR lo_stream.

* Rebuild itab t_zspro
  lo_iterator = lo_document->create_iterator( ).
  lo_node     = lo_iterator->get_next( ).

  WHILE NOT lo_node IS INITIAL.
    lv_node_name = lo_node->get_name( ).
    IF lv_node_name = gc_xmlnode_file.
* Cast node to element
      lo_element ?= lo_node. "->query_interface( ixml_iid_element ).
      CLEAR ls_ybt_toad.
      ls_ybt_toad-visibility_group = lv_group.
      ls_ybt_toad-owner            = sy-uname.
      CONCATENATE sy-datum sy-uzeit INTO lv_string.
      ls_ybt_toad-aedat            = lv_string.

* Generate new GUID
      DO 100 TIMES.
* Old function to get an unique id
        CALL FUNCTION 'GUID_CREATE'
          IMPORTING
            ev_guid_32 = lv_guid.
* New function to get an unique id (do not work on older sap system)
*    TRY.
*        lv_guid = cl_system_uuid=>create_uuid_c32_static( ).
*      CATCH cx_uuid_error.
*        EXIT. "exit do
*    ENDTRY.

* Check that this uid is not already used
        SELECT SINGLE queryid INTO ls_ybt_toad-queryid
               FROM ybt_toad
               WHERE queryid = lv_guid.
        IF sy-subrc NE 0.
          READ TABLE lt_ybt_toad WITH KEY queryid = lv_guid TRANSPORTING NO FIELDS.
          IF sy-subrc NE 0.
            EXIT. "exit do
          ENDIF.
        ENDIF.
      ENDDO.

      ls_ybt_toad-queryid    = lv_guid.
      lv_string              = lo_element->get_attribute( name = gc_xmlattr_visibility ).
      ls_ybt_toad-visibility = lv_string.
      lv_string              = lo_element->get_attribute( name = gc_xmlattr_text ).
      ls_ybt_toad-text       = lv_string.
      lv_string              = lo_element->get_value( ).
      ls_ybt_toad-query      = lv_string.
      APPEND ls_ybt_toad TO lt_ybt_toad.

    ENDIF.
    lo_node = lo_iterator->get_next( ).
  ENDWHILE.

  INSERT ybt_toad FROM TABLE lt_ybt_toad.
  IF sy-subrc = 0.
    MESSAGE s031(r9). "Query saved
  ELSE.
    MESSAGE e220(iqapi). "Error when saving the query
  ENDIF.

* Refresh repository to display new saved query
  PERFORM repgo_make_query_history.

ENDFORM.                    "import_xml
*&---------------------------------------------------------------------*
*&      Form  SET_STATUS_0010
*&---------------------------------------------------------------------*
*       Set PF-STATUS for main scren
*       Adjust list of visible tabs
*----------------------------------------------------------------------*
FORM set_status_0010 .

  DATA : lv_numb TYPE i,
         lv_max  TYPE i.

  SET PF-STATUS 'S0010'.
  SET TITLEBAR 'S0010'.

  DESCRIBE TABLE gt_tabs LINES lv_max.

  LOOP AT SCREEN.
    IF screen-name(7) = 'GS_TAB-'.
      lv_numb = screen-name+12.
      IF lv_numb > lv_max.
        screen-invisible = 1.
      ELSE.
        screen-invisible = 0.
      ENDIF.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.

ENDFORM.                    " SET_STATUS_0010
*&---------------------------------------------------------------------*
*& Form make_table_w
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> lv_WITH
*&      <-- gt_table_w
*&---------------------------------------------------------------------*
FORM make_table_w  USING    pv_with
                   CHANGING pt_table_w TYPE tyt_table_w.


  DATA: lv_with       TYPE string,
        ls_table_list TYPE string,
        lt_table_list TYPE STANDARD TABLE OF string WITH EMPTY KEY.

  DATA: ls_table_w TYPE tys_table_w,
        ls_field_w TYPE tys_fieldlist,
        lt_field_w TYPE tyt_field_w.

  DATA: ls_table_alias TYPE tys_table_alias,
        lt_table_alias TYPE tyt_table_alias.

  DATA: lt_field_tokens TYPE STANDARD TABLE OF string WITH EMPTY KEY.

  DATA: ls_dd03l       TYPE dd03l,
        lt_dd03l_cache TYPE SORTED TABLE OF dd03l
                        WITH UNIQUE KEY tabname fieldname.

  DATA lt_need TYPE SORTED TABLE OF tabname WITH UNIQUE KEY table_line.

  " 문자열/스캔용
  DATA: lv_src     TYPE string,
        lv_up      TYPE string,
        lv_upb     TYPE string,
        lv_from_up TYPE string,
        lv_cr      TYPE c LENGTH 1,
        lv_ch      TYPE c LENGTH 1.

  DATA: lv_n  TYPE i,
        lv_i  TYPE i,
        lv_i1 TYPE i,
        lv_j  TYPE i,
        lv_k  TYPE i.

  " CTE 경계
  DATA: lv_pos_as   TYPE i,
        lv_pos_lpar TYPE i,
        lv_pos_rpar TYPE i,
        lv_tab_len  TYPE i.

  " 본문·절 오프셋
  DATA: lv_off_body TYPE i,
        lv_len_body TYPE i,
        lv_off_i    TYPE i,
        lv_sel_off  TYPE i,
        lv_from_off TYPE i,
        cut         TYPE i.

  " SELECT/FROM/본문 문자열
  DATA: lv_body        TYPE string,
        lv_select_list TYPE string,
        lv_select_up   TYPE string,
        lv_from_all    TYPE string,
        lv_from_sql    TYPE string.

  " FROM/JOIN 파싱용
  DATA: lv_s         TYPE i,
        lv_e         TYPE i,
        lv_a         TYPE i,
        lv_b         TYPE i,
        lv_tbl_len   TYPE i,
        lv_alias_len TYPE i,
        lv_tbl       TYPE string,
        lv_alias_tbl TYPE string.

  " 상태
  DATA: lv_depth TYPE i,
        lv_in_q  TYPE abap_bool.

  " 임시
  DATA: lv_head    TYPE string,
        lv_head_up TYPE string,
        lv_sp      TYPE i,
        lv_space   TYPE c,
        lv_first   TYPE string,
        lv_l       TYPE string,
        lv_r       TYPE string.

  CLEAR: lv_space.

  "---------------------------------
  " WITH 문을 CTE 라인들로 분리
  "---------------------------------
  CLEAR pt_table_w.
  PERFORM split_with_sql USING pv_with CHANGING lt_table_list.

  LOOP AT lt_table_list INTO ls_table_list.

    "-----------------------------
    " 0) 한 줄 정규화(오프셋 보존)
    "-----------------------------
    lv_src = ls_table_list.
    lv_up  = to_upper( lv_src ).

    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_up WITH space.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_up WITH space.
    lv_cr = cl_abap_char_utilities=>cr_lf+0(1).
    REPLACE ALL OCCURRENCES OF lv_cr IN lv_up WITH space.

    lv_n        = strlen( lv_up ).
    lv_pos_as   = -1.
    lv_pos_lpar = -1.
    lv_pos_rpar = -1.

    "---------------------------------------------
    " 1) CTE 헤더: 'AS' 뒤 공백* 다음 '(' 빠르게 찾기 (+폴백)
    "---------------------------------------------
    DATA ls_as TYPE match_result.
    FIND FIRST OCCURRENCE OF REGEX 'AS[[:space:]]*\(' IN lv_up
         RESULTS ls_as IGNORING CASE ##REGEX_POSIX.
    IF sy-subrc = 0.
      lv_pos_as = ls_as-offset.
      lv_j = lv_pos_as + 2.
      WHILE lv_j < lv_n AND lv_up+lv_j(1) CA lv_space.
        lv_j = lv_j + 1.
      ENDWHILE.
      IF lv_j < lv_n AND lv_up+lv_j(1) = '('.
        lv_pos_lpar = lv_j.
      ENDIF.
    ENDIF.

    IF lv_pos_as < 0 OR lv_pos_lpar < 0.
      lv_i     = 0.
      lv_depth = 0.
      lv_in_q  = abap_false.
      WHILE lv_i < lv_n.
        lv_ch = lv_up+lv_i(1).
        lv_i1 = lv_i + 1.

        IF lv_ch = ''''.
          IF lv_in_q = abap_true AND lv_i1 < lv_n AND lv_up+lv_i1(1) = ''''.
            lv_i = lv_i + 2. CONTINUE.
          ELSE.
            lv_in_q = xsdbool( lv_in_q = abap_false ).
            lv_i = lv_i + 1. CONTINUE.
          ENDIF.
        ENDIF.

        IF lv_in_q = abap_false.
          IF lv_ch = '('.
            lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
          ELSEIF lv_ch = ')'.
            IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
            lv_i = lv_i + 1. CONTINUE.
          ENDIF.

          IF lv_depth = 0 AND lv_i + 2 <= lv_n.
            IF lv_up+lv_i(1) = 'A' AND lv_up+lv_i1(1) = 'S'.
              lv_j = lv_i + 2.
              WHILE lv_j < lv_n AND lv_up+lv_j(1) CA lv_space.
                lv_j = lv_j + 1.
              ENDWHILE.
              IF lv_j < lv_n AND lv_up+lv_j(1) = '('.
                lv_pos_as   = lv_i.
                lv_pos_lpar = lv_j.
                EXIT.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.

        lv_i = lv_i + 1.
      ENDWHILE.
    ENDIF.

    CHECK lv_pos_as >= 0 AND lv_pos_lpar >= 0.

    " CTE 이름
    lv_tab_len = lv_pos_as.
    IF lv_tab_len < 0. lv_tab_len = 0. ENDIF.
    CLEAR ls_table_w.
    ls_table_w-tabname = lv_src+0(lv_tab_len).
    SHIFT ls_table_w-tabname LEFT  DELETING LEADING  space.
    SHIFT ls_table_w-tabname RIGHT DELETING TRAILING space.
    IF strlen( ls_table_w-tabname ) >= 5 AND to_upper( ls_table_w-tabname+0(5) ) = 'WITH '.
      ls_table_w-tabname = ls_table_w-tabname+5.
      SHIFT ls_table_w-tabname LEFT  DELETING LEADING space.
    ENDIF.

    " 닫는 ')' 찾기
    lv_i     = lv_pos_lpar + 1.
    lv_depth = 1.
    lv_in_q  = abap_false.
    WHILE lv_i < lv_n.
      lv_ch = lv_up+lv_i(1).
      lv_i1 = lv_i + 1.
      IF lv_ch = ''''.
        IF lv_in_q = abap_true AND lv_i1 < lv_n AND lv_up+lv_i1(1) = ''''.
          lv_i = lv_i + 2. CONTINUE.
        ELSE.
          lv_in_q = xsdbool( lv_in_q = abap_false ).
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.
      ENDIF.

      IF lv_in_q = abap_false.
        IF lv_ch = '('.
          lv_depth = lv_depth + 1.
        ELSEIF lv_ch = ')'.
          lv_depth = lv_depth - 1.
          IF lv_depth = 0.
            lv_pos_rpar = lv_i. EXIT.
          ENDIF.
        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.
    CHECK lv_pos_rpar > lv_pos_lpar.

    " 본문 추출
    lv_off_body = lv_pos_lpar + 1.
    lv_len_body = lv_pos_rpar - lv_off_body.
    IF lv_len_body < 0. lv_len_body = 0. ENDIF.
    lv_body = lv_src+lv_off_body(lv_len_body).

    "---------------------------------------------------------
    " 2) 본문: SELECT ~ FROM 오프셋 찾기 (공백 유무 모두 허용)
    "---------------------------------------------------------
    lv_upb = to_upper( lv_body ).
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_upb WITH space.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_upb WITH space.
    REPLACE ALL OCCURRENCES OF lv_cr                                  IN lv_upb WITH space.

    lv_sel_off  = -1.
    lv_from_off = -1.

    lv_n     = strlen( lv_upb ).
    lv_i     = 0.
    lv_depth = 0.
    lv_in_q  = abap_false.

    WHILE lv_i < lv_n.
      lv_ch = lv_upb+lv_i(1).
      lv_i1 = lv_i + 1.

      IF lv_ch = ''''.
        IF lv_in_q = abap_true AND lv_i1 < lv_n AND lv_upb+lv_i1(1) = ''''.
          lv_i = lv_i + 2. CONTINUE.
        ELSE.
          lv_in_q = xsdbool( lv_in_q = abap_false ).
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.
      ENDIF.

      IF lv_in_q = abap_false.
        IF lv_ch = '('.
          lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
        ELSEIF lv_ch = ')'.
          IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.

        IF lv_depth = 0.
          " ' SELECT'
          lv_off_i = lv_i + 7.
          IF lv_sel_off < 0 AND lv_off_i <= lv_n AND lv_upb+lv_i(7) = ' SELECT'.
            lv_sel_off = lv_i + 7.
            lv_i = lv_sel_off. CONTINUE.
          ENDIF.

          " ' FROM ' 또는 ' FROM' + (끝/공백/구분자)
          IF lv_from_off < 0.
            lv_off_i = lv_i + 6.
            IF lv_off_i <= lv_n AND lv_upb+lv_i(6) = ' FROM '.
              lv_from_off = lv_i + 6. EXIT.
            ELSE.
              DATA(lv_chk5) = lv_i + 5.
              IF lv_chk5 <= lv_n AND lv_upb+lv_i(5) = ' FROM'.
                IF lv_chk5 = lv_n OR lv_upb+lv_chk5(1) CA lv_space OR lv_upb+lv_chk5(1) = '(' OR lv_upb+lv_chk5(1) = ','.
                  lv_from_off = lv_chk5. EXIT.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.

    CHECK lv_sel_off >= 0 AND lv_from_off > lv_sel_off.

    " SELECT 리스트 (정확히 FROM 직전까지)
    lv_off_i = lv_from_off - lv_sel_off - 5.
    IF lv_off_i < 0. lv_off_i = 0. ENDIF.
    lv_select_list = lv_body+lv_sel_off(lv_off_i).

    " FROM 이후
    lv_from_all = lv_body+lv_from_off.

    " 꼬리(WHERE/GROUP/ORDER/HAVING) 자르기 — 공백 유무 허용
    cut = -1.
    lv_up = to_upper( lv_from_all ).
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_up WITH space.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_up WITH space.
    REPLACE ALL OCCURRENCES OF lv_cr                                  IN lv_up WITH space.

    lv_n     = strlen( lv_up ).
    lv_i     = 0.
    lv_depth = 0.
    lv_in_q  = abap_false.

    WHILE lv_i < lv_n.
      lv_ch = lv_up+lv_i(1).
      lv_i1 = lv_i + 1.

      IF lv_ch = ''''.
        IF lv_in_q = abap_true AND lv_i1 < lv_n AND lv_up+lv_i1(1) = ''''.
          lv_i = lv_i + 2. CONTINUE.
        ELSE.
          lv_in_q = xsdbool( lv_in_q = abap_false ).
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.
      ENDIF.

      IF lv_in_q = abap_false AND lv_depth = 0.
        " WHERE
        DATA(lv_w6) = lv_i + 6.
        IF lv_i + 7 <= lv_n AND lv_up+lv_i(7) = ' WHERE '.
          cut = lv_i. EXIT.
        ELSEIF lv_i + 6 <= lv_n AND lv_up+lv_i(6) = ' WHERE'.
          IF lv_w6 = lv_n OR lv_up+lv_w6(1) CA lv_space.
            cut = lv_i. EXIT.
          ENDIF.
        ENDIF.

        " GROUP BY
        DATA(lv_g9) = lv_i + 9.
        IF lv_i + 10 <= lv_n AND lv_up+lv_i(10) = ' GROUP BY '.
          cut = lv_i. EXIT.
        ELSEIF lv_i + 9 <= lv_n AND lv_up+lv_i(9) = ' GROUP BY'.
          IF lv_g9 = lv_n OR lv_up+lv_g9(1) CA lv_space.
            cut = lv_i. EXIT.
          ENDIF.
        ENDIF.

        " ORDER BY
        DATA(lv_o9) = lv_i + 9.
        IF lv_i + 10 <= lv_n AND lv_up+lv_i(10) = ' ORDER BY '.
          cut = lv_i. EXIT.
        ELSEIF lv_i + 9 <= lv_n AND lv_up+lv_i(9) = ' ORDER BY'.
          IF lv_o9 = lv_n OR lv_up+lv_o9(1) CA lv_space.
            cut = lv_i. EXIT.
          ENDIF.
        ENDIF.

        " HAVING
        DATA(lv_h7) = lv_i + 7.
        IF lv_i + 8 <= lv_n AND lv_up+lv_i(8) = ' HAVING '.
          cut = lv_i. EXIT.
        ELSEIF lv_i + 7 <= lv_n AND lv_up+lv_i(7) = ' HAVING'.
          IF lv_h7 = lv_n OR lv_up+lv_h7(1) CA lv_space.
            cut = lv_i. EXIT.
          ENDIF.
        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.

    IF cut > 0.
      lv_from_sql = lv_from_all+0(cut).
    ELSE.
      lv_from_sql = lv_from_all.
    ENDIF.
    SHIFT lv_from_sql LEFT  DELETING LEADING  space.

    "---------------------------------------------
    " 3) SELECT 필드 토큰 분리(외부 FORM 사용)
    "---------------------------------------------
    lv_select_up = to_upper( lv_select_list ).
    PERFORM split_field_list_table USING lv_select_up CHANGING lt_field_tokens.

    "-------------------------------------------------------------
    " 4) FROM/JOIN 테이블·별칭 수집 → lt_table_alias
    "    ※ 이 단계에서는 '꼬리 자르기(4-0), 선두 테이블 재파싱(4-1)'을
    "       다시 하지 않습니다(이전 단계에서 이미 수행됨).
    "    - FROM 뒤 첫 테이블 및 각 JOIN에 대해
    "      '테이블 + [AS] 별칭'을 읽되, 별칭이 있는 경우에만 APPEND
    "-------------------------------------------------------------
    CLEAR lt_table_alias.

    lv_from_up = to_upper( lv_from_sql ).
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_from_up WITH space.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_from_up WITH space.
    REPLACE ALL OCCURRENCES OF lv_cr                                  IN lv_from_up WITH space.
    lv_n = strlen( lv_from_up ).

    CLEAR lv_tbl.
    CLEAR lv_alias_tbl.
    lv_s = 0.

    " (서브쿼리) 또는 일반 테이블
    IF lv_from_up+lv_s(1) = '('.
      lv_depth = 1.
      lv_e = lv_s + 1.
      WHILE lv_e < lv_n AND lv_depth > 0.
        lv_ch = lv_from_up+lv_e(1).
        IF lv_ch = '('.
          lv_depth = lv_depth + 1.
        ELSEIF lv_ch = ')'.
          lv_depth = lv_depth - 1.
        ENDIF.
        lv_e = lv_e + 1.
      ENDWHILE.
      lv_off_i = lv_e - lv_s.
      lv_tbl = lv_from_sql+lv_s(lv_off_i).

      lv_a = lv_e.
      WHILE lv_a < lv_n AND lv_from_up+lv_a(1) CA lv_space.
        lv_a = lv_a + 1.
      ENDWHILE.
    ELSE.
      lv_e = lv_s.
      WHILE lv_e < lv_n.
        lv_ch = lv_from_up+lv_e(1).
        IF lv_ch CA lv_space OR lv_ch = ')' OR lv_ch = '(' OR lv_ch = ','.
          EXIT.
        ENDIF.
        lv_e = lv_e + 1.
      ENDWHILE.
      lv_off_i = lv_e - lv_s.
      lv_tbl   = lv_from_sql+lv_s(lv_off_i).

      lv_a = lv_e.
      WHILE lv_a < lv_n AND lv_from_up+lv_a(1) CA lv_space.
        lv_a = lv_a + 1.
      ENDWHILE.
    ENDIF.

    " 'AS' 스킵
    IF lv_a + 2 <= lv_n AND lv_from_up+lv_a(2) = 'AS'.
      lv_a = lv_a + 2.
      WHILE lv_a < lv_n AND lv_from_up+lv_a(1) CA lv_space.
        lv_a = lv_a + 1.
      ENDWHILE.
    ENDIF.

    " 별칭 토큰
    lv_b = lv_a.
    WHILE lv_b < lv_n.
      lv_ch = lv_from_up+lv_b(1).
      IF lv_ch CA lv_space OR lv_ch = ',' OR lv_ch = ')' OR lv_ch = '(' OR lv_ch = ';'.
        EXIT.
      ENDIF.
      " ON/USING/JOIN/GROUP/ORDER/WHERE/HAVING 시작 추정(앞글자)
      IF lv_from_up+lv_b(1) = 'O' OR lv_from_up+lv_b(1) = 'U' OR
         lv_from_up+lv_b(1) = 'J' OR lv_from_up+lv_b(1) = 'G' OR
         lv_from_up+lv_b(1) = 'W' OR lv_from_up+lv_b(1) = 'H'.
        EXIT.
      ENDIF.
      lv_b = lv_b + 1.
    ENDWHILE.

    IF lv_b > lv_a.
      lv_off_i = lv_b - lv_a.
      lv_alias_tbl = lv_from_sql+lv_a(lv_off_i).
    ENDIF.

    " 키워드가 별칭으로 잡힌 경우 무효화
    lv_head_up = to_upper( lv_alias_tbl ).
    IF lv_head_up = 'INNER' OR lv_head_up = 'LEFT' OR lv_head_up = 'RIGHT' OR
       lv_head_up = 'FULL'  OR lv_head_up = 'OUTER' OR lv_head_up = 'CROSS' OR
       lv_head_up = 'JOIN'  OR lv_head_up = 'ON'    OR lv_head_up = 'USING' OR
       lv_head_up = 'WHERE' OR lv_head_up = 'GROUP' OR lv_head_up = 'ORDER' OR
       lv_head_up = 'HAVING'.
      CLEAR lv_alias_tbl.
    ENDIF.

    CLEAR ls_table_alias.
    ls_table_alias-table = lv_tbl.
    ls_table_alias-alias = lv_alias_tbl.
    APPEND ls_table_alias TO lt_table_alias.

    " 이후 JOIN 스캔 시작 위치
    lv_i = lv_b.

    " ---- JOIN 들 파싱 ----
    WHILE lv_i < lv_n.
      IF lv_i + 4 <= lv_n AND lv_from_up+lv_i(4) = 'JOIN'.
        lv_s = lv_i + 4.
        IF lv_s < lv_n AND lv_from_up+lv_s(1) CA lv_space.

          WHILE lv_s < lv_n AND lv_from_up+lv_s(1) CA lv_space.
            lv_s = lv_s + 1.
          ENDWHILE.

          " 테이블 토큰
          lv_e = lv_s.
          WHILE lv_e < lv_n.
            lv_ch = lv_from_up+lv_e(1).
            IF lv_ch CA lv_space OR lv_ch = ')' OR lv_ch = '(' OR lv_ch = ','.
              EXIT.
            ENDIF.
            lv_e = lv_e + 1.
          ENDWHILE.

          lv_off_i = lv_e - lv_s.
          lv_tbl   = lv_from_sql+lv_s(lv_off_i).

          " 별칭 시작
          lv_a = lv_e.
          WHILE lv_a < lv_n AND lv_from_up+lv_a(1) CA lv_space.
            lv_a = lv_a + 1.
          ENDWHILE.
          IF lv_a + 2 <= lv_n AND lv_from_up+lv_a(2) = 'AS'.
            lv_a = lv_a + 2.
            WHILE lv_a < lv_n AND lv_from_up+lv_a(1) CA lv_space.
              lv_a = lv_a + 1.
            ENDWHILE.
          ENDIF.

          " 별칭 토큰 (ON/USING/다음 JOIN 전까지)
          lv_b = lv_a.
          WHILE lv_b < lv_n.
            lv_ch = lv_from_up+lv_b(1).
            IF lv_ch CA lv_space OR lv_ch = ',' OR lv_ch = ')' OR
               lv_ch = '(' OR lv_ch = ';' OR lv_ch = 'O' OR lv_ch = 'U'.
              EXIT.
            ENDIF.
            lv_b = lv_b + 1.
          ENDWHILE.

          lv_off_i = lv_b - lv_a.
          IF lv_off_i > 0.
            lv_alias_tbl = lv_from_sql+lv_a(lv_off_i).
          ELSE.
            CLEAR lv_alias_tbl.
          ENDIF.

          " 별칭이 있는 경우에만 추가
          IF lv_tbl IS NOT INITIAL AND lv_alias_tbl IS NOT INITIAL.
            CLEAR ls_table_alias.
            ls_table_alias-table = lv_tbl.
            ls_table_alias-alias = lv_alias_tbl.
            APPEND ls_table_alias TO lt_table_alias.
          ENDIF.

          lv_i = lv_b.
          CONTINUE.
        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.

    "--------------------------------------------------------------------
    " 5) 필드 해석(각 generate_* 재사용) — 첫 토큰 추출 로직 보강
    "--------------------------------------------------------------------
    CLEAR lt_field_w.
    LOOP AT lt_field_tokens INTO lv_head.

      lv_head_up = to_upper( lv_head ).
      REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_head_up WITH space.
      REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_head_up WITH space.
      lv_cr = cl_abap_char_utilities=>cr_lf+0(1).
      REPLACE ALL OCCURRENCES OF lv_cr IN lv_head_up WITH space.
      SHIFT lv_head_up LEFT  DELETING LEADING  space.
      SHIFT lv_head_up RIGHT DELETING TRAILING space.

      CLEAR lv_first.
      FIND REGEX '^[[:space:]]*([A-Z_][A-Z0-9_]*)'
           IN lv_head_up IGNORING CASE
           SUBMATCHES lv_first ##REGEX_POSIX.
      IF sy-subrc <> 0.
        lv_first = lv_head_up.
      ENDIF.

      CLEAR: ls_field_w.
      DATA(lv_flag) = abap_true.
      CASE to_upper( lv_first ).
        WHEN 'CONCAT' OR 'CONCAT__SPACE' OR 'CONCAT_WITH_SPACE' OR 'SUBSTRING'.
          PERFORM generate_concat_w   USING    lv_head
                                      CHANGING lt_field_w.

        WHEN 'CAST'.
          PERFORM generate_cast_w     USING    lv_head pt_table_w
                                      CHANGING lt_field_w.

        WHEN 'CASE'.
          PERFORM generate_case_w     USING    lv_head pt_table_w
                                      CHANGING lt_field_w.

        WHEN 'SUM' OR 'MAX' OR 'MIN' OR 'AVG' OR 'COUNT' OR 'COALESCE'.
          PERFORM generate_agg_func_w USING    lv_head lt_table_alias
                                      CHANGING ls_field_w.
          APPEND ls_field_w TO lt_field_w.

        WHEN 'ROW_NUMBER' OR 'RANK' OR 'DENSE_RANK' OR 'LENGTH'.
          PERFORM generate_seq_func_w USING    lv_head
                                      CHANGING lt_field_w.

        WHEN OTHERS.
          IF matches( val = lv_head_up pcre = '.*\s[\+\-\*\/\<\>]\s.*' ).
            PERFORM generate_agg_func_w USING    lv_head lt_table_alias
                                        CHANGING ls_field_w.
            APPEND ls_field_w TO lt_field_w.

          ELSEIF lv_head+0(1) = '''' OR lv_head+0(1) = '@'.
            PERFORM generate_concat_w USING    lv_head
                                      CHANGING lt_field_w.
          ELSE.
            lv_flag = abap_false.
          ENDIF.

      ENDCASE.

      IF lv_flag = abap_true.
        CONTINUE.
      ENDIF.

      " 일반 컬럼: a~b [AS alias]
      CLEAR: lv_l, lv_r, ls_field_w.
      SPLIT lv_head AT ' AS ' INTO lv_l lv_r.
      SPLIT lv_l    AT '~'    INTO ls_field_w-ref_table ls_field_w-ref_field.
      IF ls_field_w-ref_field IS INITIAL.
        ls_field_w-ref_field = ls_field_w-ref_table.
        CLEAR ls_field_w-ref_table.
      ENDIF.

      IF lv_r IS INITIAL.
        ls_field_w-field = ls_field_w-ref_field.
      ELSE.
        ls_field_w-field     = lv_r.
        ls_field_w-field_txt = lv_r.
      ENDIF.

      CONDENSE ls_field_w-field      NO-GAPS.
      CONDENSE ls_field_w-ref_table  NO-GAPS.
      CONDENSE ls_field_w-ref_field  NO-GAPS.

      APPEND ls_field_w TO lt_field_w.

    ENDLOOP.

    "--------------------------------------------------------------------
    " 6) 별칭 → 실제 테이블명 매핑(빈 별칭은 찾지 않음)
    "    + CTE(+...) 참조면 사용자 폼 호출
    "--------------------------------------------------------------------
    FIELD-SYMBOLS: <ls_field_w> TYPE tys_fieldlist.
    LOOP AT lt_field_w ASSIGNING <ls_field_w>.

      IF <ls_field_w>-ref_field IS NOT INITIAL.
        READ TABLE lt_table_alias INTO ls_table_alias
             WITH KEY alias = <ls_field_w>-ref_table.
        IF sy-subrc = 0.
          <ls_field_w>-ref_table = ls_table_alias-table.
        ENDIF.
      ENDIF.

      IF <ls_field_w>-ref_table IS NOT INITIAL AND <ls_field_w>-ref_table+0(1) = '+'.
        DATA lv_dummy_sel TYPE string.
        PERFORM get_fieldname_from_cte CHANGING <ls_field_w> lv_dummy_sel.
      ENDIF.
    ENDLOOP.

    "---------------------------------------------
    " 7) DDIC 타입 채우기(간단 캐시)
    "---------------------------------------------
    CLEAR lt_need.
    LOOP AT lt_field_w INTO ls_field_w WHERE ref_table IS NOT INITIAL.
      IF ls_field_w-ref_table+0(1) <> '+'.
        INSERT CONV tabname( ls_field_w-ref_table ) INTO TABLE lt_need.
      ENDIF.
    ENDLOOP.

    IF lt_need IS NOT INITIAL.
      SELECT tabname fieldname position datatype reftable reffield
        FROM dd03l
        INTO CORRESPONDING FIELDS OF TABLE lt_dd03l_cache
        FOR ALL ENTRIES IN lt_need
       WHERE tabname  = lt_need-table_line
         AND as4local = 'A'
         AND as4vers  = ' '
         AND ( comptype = ' ' OR comptype = 'E' ).
    ENDIF.

    LOOP AT lt_field_w ASSIGNING <ls_field_w>.
      IF <ls_field_w>-ref_table IS INITIAL OR <ls_field_w>-ref_field IS INITIAL.
        CONTINUE.
      ENDIF.
      READ TABLE lt_dd03l_cache INTO ls_dd03l
           WITH KEY tabname   = <ls_field_w>-ref_table
                    fieldname = <ls_field_w>-ref_field.
      IF sy-subrc = 0.
        <ls_field_w>-field_type = ls_dd03l-datatype.
        <ls_field_w>-table_ref  = ls_dd03l-reftable.
        <ls_field_w>-field_ref  = ls_dd03l-reffield.
      ELSE.
        IF <ls_field_w>-field_type IS INITIAL.
          <ls_field_w>-field_type = 'STRING'.
        ENDIF.
      ENDIF.
    ENDLOOP.

    "---------------------------------------------
    " 8) '*' 확장
    "---------------------------------------------
    READ TABLE lt_field_w INTO ls_field_w INDEX 1.
    IF sy-subrc = 0 AND ls_field_w-field = '*'.
      CLEAR lt_field_w.
      SELECT fieldname AS field
             tabname   AS ref_table
             fieldname AS ref_field
        FROM dd03l
        INTO CORRESPONDING FIELDS OF TABLE lt_field_w
       WHERE tabname     = ls_field_w-ref_table
         AND ( fieldname <> 'MANDT' OR datatype <> 'CLNT' )
         AND as4local    = 'A'
         AND as4vers     = ' '
         AND ( comptype  = ' ' OR comptype = 'E' )
       ORDER BY position.
    ENDIF.

    "---------------------------------------------
    " 9) 결과 적재
    "---------------------------------------------
    CONDENSE ls_table_w-tabname NO-GAPS.
    ls_table_w-field_list = lt_field_w.
    APPEND ls_table_w TO pt_table_w.

  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form GENERATE_CASE
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_SPLIT
*&      --> lv_CURRENT_LINE
*&---------------------------------------------------------------------*
FORM generate_case   USING    pv_current_line TYPE i
                              pv_newsyntax pv_write
                     CHANGING pt_split        TYPE tyt_string
                              pv_string
                              pv_field_number
                              ps_fieldlist    TYPE tys_fieldlist
                              pt_fieldlist    TYPE tyt_fieldlist
                              pt_code_string  TYPE tyt_string
                              pt_table_alias  TYPE tyt_table_alias.

  DATA: lv_type             TYPE string,
        lv_select_field_txt TYPE string,
        lv_strlen_string    TYPE string,
        lv_struct_line      TYPE string,
        lv_select_field     TYPE string,
        lv_select_up        TYPE string,
        lv_ii               TYPE i,
        ls_field_w          TYPE tys_fieldlist,
        ls_table_w          TYPE tys_table_w.

  CHECK pv_write     = abap_true.
  CHECK pv_newsyntax = abap_true.

  CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.

  PERFORM change_case_type USING    pv_string
                                    pt_table_alias
                           CHANGING lv_type ps_fieldlist.

  " 결과 ref_table 정보 확인
  IF line_exists( pt_table_alias[ alias = ps_fieldlist-ref_table ] ).
    ps_fieldlist-ref_table = VALUE #( pt_table_alias[ alias = ps_fieldlist-ref_table ]-table OPTIONAL ).

    IF ps_fieldlist-ref_table+0(1) = '+'.
      PERFORM get_fieldname_from_cte  CHANGING ps_fieldlist
                                               lv_select_field_txt.
    ENDIF.
  ENDIF.


***  IF ps_fieldlist-ref_table IS NOT INITIAL AND
***     ps_fieldlist-ref_field IS NOT INITIAL.


***
***    " 진행은 워킹카피에서, 최종만 넘겨받은 ps_field_w에 반영
***    ls_field_w = ps_fieldlist.
***
***    " 사이클 방지용: (ref_table, ref_field) 방문 집합 + 세이프티 카운터
***    TYPES: BEGIN OF ty_vis,
***             tab   TYPE string,
***             field TYPE string,
***           END OF ty_vis.
***    DATA lt_visited TYPE HASHED TABLE OF ty_vis WITH UNIQUE KEY tab field.
***    DATA lv_hops TYPE i VALUE 0.
***
***    DO 100 TIMES.  " 세이프티 (무한루프 방지)
***      lv_hops += 1.
***
***      " 종료조건 1: 더 이상 CTE(+...)가 아님
***      IF ls_field_w-ref_table IS INITIAL OR ls_field_w-ref_table+0(1) <> '+'.
***        EXIT.
***      ENDIF.
***
***      " 사이클/재방문 차단
***      IF line_exists( lt_visited[ tab = ls_field_w-ref_table
***                                  field = ls_field_w-ref_field ] ).
***        EXIT.
***      ENDIF.
***      INSERT VALUE ty_vis( tab = ls_field_w-ref_table field = ls_field_w-ref_field )
***        INTO TABLE lt_visited.
***
***      " CTE 테이블 메타 찾기
***      READ TABLE gt_table_w INTO ls_table_w WITH KEY tabname = ls_field_w-ref_table.
***      IF sy-subrc <> 0.
***        EXIT.  " 더 못 따라감 → 안전 종료
***      ENDIF.
***
***      " ref_field에서 마지막 AS <alias> 분리 (대소문자 무관, 내부 '... as DATS'는 건너뛰기)
***      lv_select_field_txt = ``.  " 기본 초기화
***      lv_select_field = ls_field_w-ref_field.
***      lv_select_up    = to_upper( lv_select_field ).
***
***      " 마지막 ' AS ' 위치 찾기 (CAST ... as DATS) 같은 내부 AS는 무시하고, 맨 끝 alias만 분리
***      DATA lt_match TYPE match_result_tab.
***      FIND ALL OCCURRENCES OF ' AS ' IN lv_select_up RESULTS lt_match.
***      IF lt_match IS NOT INITIAL.
***        READ TABLE lt_match INDEX lines( lt_match ) INTO DATA(ls_last).
***        IF sy-subrc = 0 AND ls_last-length > 0.
***          " alias 추출
***          lv_ii = ls_last-offset + ls_last-length.
***          lv_select_field_txt = lv_select_field+lv_ii.
***          SHIFT lv_select_field_txt LEFT DELETING LEADING space.
***          " 본문(별칭 제거)
***          lv_select_field = lv_select_field(ls_last-offset).
***        ENDIF.
***      ENDIF.
***
***      CONDENSE lv_select_field NO-GAPS.
***
***      " 필드 리스트에서 매핑 전개
***      READ TABLE ls_table_w-field_list INTO ls_field_w
***           WITH KEY field = lv_select_field.
***      IF sy-subrc <> 0.
***        EXIT.  " 더 못 따라감 → 안전 종료
***      ENDIF.
***
***      " 종료조건 2: 더 이상 ref_field가 없으면(타입 직접정의) 종료
***      IF ls_field_w-ref_field IS INITIAL.
***        EXIT.
***      ENDIF.
***    ENDDO.

  " 최종 결과 반영
***  ps_fieldlist = ls_field_w.
***  ENDIF.

  IF ps_fieldlist-field IS INITIAL.
    CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
  ENDIF.

  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.

  IF ps_fieldlist-ref_table IS NOT INITIAL AND
     ps_fieldlist-ref_field IS NOT INITIAL.
    lv_type = |{ ps_fieldlist-ref_table }-{ ps_fieldlist-ref_field }|.
  ELSE.
    lv_type = ps_fieldlist-field_type.
  ENDIF.

  CONCATENATE lv_struct_line 'TYPE' lv_type                 "#EC NOTEXT
              INTO lv_struct_line SEPARATED BY space.

  c1 lv_struct_line.

  APPEND ps_fieldlist TO pt_fieldlist.
  pv_field_number = pv_field_number + 1.


ENDFORM.
*&---------------------------------------------------------------------*
*& Form GENERATE_SEQ_FUNCTION
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_SPLIT
*&      --> lv_CURRENT_LINE
*&---------------------------------------------------------------------*
FORM generate_seq_function USING    pv_current_line TYPE i
                                    pv_newsyntax
                                    pv_type pv_write
                           CHANGING pt_split        TYPE tyt_string
                                    pv_string       TYPE string
                                    pv_field_number
                                    ps_fieldlist    TYPE tys_fieldlist
                                    pt_fieldlist    TYPE tyt_fieldlist
                                    pt_code_string  TYPE tyt_string.

  DATA: lv_alias         TYPE string,
        lv_struct_line   TYPE string,
        lv_strlen_string TYPE string.

  CHECK pv_write = abap_true.

  PERFORM get_as_end_alias USING pv_string CHANGING lv_alias.

  " 별칭 폴백
  IF lv_alias IS INITIAL.
    CONCATENATE 'F' pv_field_number INTO lv_alias.
  ENDIF.

  "-------------------------------------------------------
  " 3) 결과 반영 (타입은 pv_type 그대로 사용)
  "-------------------------------------------------------
  ps_fieldlist-field      = |F{ pv_field_number }|.
  ps_fieldlist-field_txt  = lv_alias.
  ps_fieldlist-field_type = pv_type.
  CLEAR: ps_fieldlist-ref_table, ps_fieldlist-ref_field.

  lv_struct_line = |,{ ps_fieldlist-field } TYPE { pv_type }|.
  c1 lv_struct_line.

  APPEND ps_fieldlist TO pt_fieldlist.
  pv_field_number = pv_field_number + 1.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form GENERATE_SEQ_FUNC_W
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_SPLIT
*&      --> lv_CURRENT_LINE
*&---------------------------------------------------------------------*
FORM generate_seq_func_w   USING    pv_string
                           CHANGING pt_field_w  TYPE tyt_field_w.

  DATA: lv_alias   TYPE string,
        ls_field_w TYPE tys_fieldlist.

  PERFORM get_as_end_alias USING pv_string CHANGING lv_alias.

  CLEAR: ls_field_w.
  ls_field_w-field      = lv_alias.
  ls_field_w-field_txt  = lv_alias.
  ls_field_w-field_type = 'INT8'.

  APPEND ls_field_w TO pt_field_w.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form GENERATE_AGG_FUNC
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> lv_CURRENT_LINE
*&      <-- LT_SPLIT
*&      <-- lv_FIELD_NUMBER
*&      <-- pt_FIELDLIST
*&      <-- LT_CODE_STRING
*&---------------------------------------------------------------------*
FORM generate_agg_func     USING    pv_current_line TYPE i
                                    pv_newsyntax
                                    pv_write
                           CHANGING pt_split        TYPE tyt_string
                                    pv_string
                                    pv_field_number
                                    ps_fieldlist    TYPE tys_fieldlist
                                    pt_fieldlist    TYPE tyt_fieldlist
                                    pt_code_string  TYPE tyt_string
                                    pt_table_alias  TYPE tyt_table_alias.

  DATA: lv_index         TYPE i,
        lv_type          TYPE string,
        lv_len           TYPE i,
        lv_dec           TYPE i,
        lv_string2       TYPE string,
        lv_struct_line   TYPE string,
        lv_strlen_string TYPE string,
        ls_field_w       TYPE tys_fieldlist.

  CHECK pv_write = abap_true.

  CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.

  ls_field_w-field = ps_fieldlist-field.
  PERFORM generate_agg_func_w  USING    pv_string pt_table_alias
                               CHANGING ls_field_w.

  CLEAR: ls_field_w-ref_table, ls_field_w-ref_field.
  ps_fieldlist = CORRESPONDING #( ls_field_w ).
  IF ps_fieldlist-ref_table IS NOT INITIAL AND
     ps_fieldlist-ref_field IS NOT INITIAL.
    pv_string = ps_fieldlist-ref_table && '-' && ps_fieldlist-ref_field.
    ps_fieldlist-field_type = space.

  ELSEIF ps_fieldlist-ref_table IS INITIAL AND
         ps_fieldlist-ref_field IS NOT INITIAL.
    pv_string = ps_fieldlist-ref_field.

  ELSEIF ps_fieldlist-field_type IS NOT INITIAL.
    pv_string = ps_fieldlist-field_type .

  ELSE.
    pv_string = ps_fieldlist-field_txt .
  ENDIF.

  CONCATENATE lv_struct_line 'TYPE ' pv_string              "#EC NOTEXT
              INTO lv_struct_line SEPARATED BY space.
  c1 lv_struct_line.
  APPEND ps_fieldlist TO pt_fieldlist.
  pv_field_number = pv_field_number + 1.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_others
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_CURRENT_LINE
*&      --> PV_NEWSYNTAX
*&      <-- LT_SPLIT
*&      <-- LV_STRING
*&      <-- LV_FIELD_NUMBER
*&      <-- LS_FIELDLIST
*&      <-- PT_FIELDLIST
*&      <-- LT_CODE_STRING
*&---------------------------------------------------------------------*
FORM generate_others       USING    pv_current_line TYPE i
                                    pv_newsyntax
                                    pv_write
                           CHANGING pt_split        TYPE tyt_string
                                    pv_string
                                    pv_field_number
                                    ps_fieldlist    TYPE tys_fieldlist
                                    pt_fieldlist    TYPE tyt_fieldlist
                                    pt_code_string  TYPE tyt_string
                                    pv_flag.

  DATA: lv_struct_line   TYPE string,
        lv_strlen_string TYPE string,
        lv_type          TYPE string.

  DATA: lv_string TYPE string,
        ls_find   TYPE match_result,
        lo_regex  TYPE REF TO cl_abap_regex.

  pv_flag = abap_true.

  CHECK pv_write = abap_true.

  " 사칙연산이 있는 경우
  lv_string = `( \+ | \- | \* | \/ )`.

  CREATE OBJECT lo_regex
    EXPORTING
      pattern     = lv_string
      ignore_case = abap_true
      ##REGEX_POSIX.

  FIND FIRST OCCURRENCE OF REGEX lo_regex
       IN pv_string RESULTS ls_find. " IGNORING CASE.
  IF sy-subrc = 0.
    pv_flag = abap_false.

    SPLIT pv_string        AT ' AS ' INTO ps_fieldlist-field ps_fieldlist-field_txt.

    ps_fieldlist-ref_table  = ps_fieldlist-field_txt.
    ps_fieldlist-field_type = lv_type = 'BAPITKGXXX_31'.
  ENDIF.

  CHECK pv_flag = abap_true.

*  CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
*  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.
*  CONCATENATE lv_struct_line 'TYPE ' lv_type                "#EC NOTEXT
*              INTO lv_struct_line SEPARATED BY space.
*
*  c1 lv_struct_line.
*  ps_fieldlist-field_txt = ps_fieldlist-ref_table.
*  ps_fieldlist-ref_field = ps_fieldlist-ref_table.
*  ps_fieldlist-ref_table = space.
*  APPEND ps_fieldlist TO pt_fieldlist.
*  pv_field_number = pv_field_number + 1.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_ddlsource
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- LT_TABLE_LIST
*&---------------------------------------------------------------------*
FORM check_ddlsource  CHANGING pt_table_list TYPE tyt_table_list.

  DATA: lv_idx        TYPE sy-tabix,
        lv_tabname    TYPE tabname,
        lv_ctab       TYPE string,
        lv_ftab       TYPE string,
        lv_wtab       TYPE string,
        ls_table_list TYPE tys_table_list.

  " db table 이 있는 경우
  SELECT SINGLE tabname
    FROM dd02l
    INTO lv_tabname
   WHERE tabname = 'CDSSQLVIEW'.
  CHECK sy-subrc = 0 AND sy-dbcnt > 0.

  CONCATENATE 'CDSSQLVIEW AS A'
              'INNER JOIN DDLDEPENDENCY AS B ON B~DDLNAME = A~DDLSOURCENAME'
         INTO lv_ftab SEPARATED BY space.
  lv_wtab = 'B~OBJECTNAME = LS_TABLE_LIST-TABLE'.
  lv_ctab = 'A~SQLVIEWNAME'.

  " table_org, table
  LOOP AT pt_table_list INTO ls_table_list.

    lv_idx = sy-tabix.

    SELECT SINGLE (lv_ctab)
      FROM (lv_ftab)
      INTO lv_tabname
     WHERE (lv_wtab).
    IF sy-subrc = 0.
      ls_table_list-table_org = ls_table_list-table.
      ls_table_list-table     = lv_tabname.
      ls_table_list-is_ddls   = abap_true.
      MODIFY pt_table_list FROM ls_table_list INDEX lv_idx.
    ENDIF.

  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form User_group_management
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM user_group_management .

  DATA: lv_no(2)         TYPE n,
        lv_user          TYPE sy-uname,
        lv_dummy         TYPE scrfname,
        lv_groupnm       TYPE scrfname,
        lv_fld_group     TYPE scrfname,
        lv_timestamp(14) TYPE c,
        ls_ybt_toad      TYPE ybt_toad,
        lt_ybt_toad      TYPE TABLE OF ybt_toad.

  FIELD-SYMBOLS:
      <lv_fld_group> TYPE any.

  CLEAR: gs_s0400.
  CALL SCREEN 0400 STARTING AT 40 5
                   ENDING AT 100 12.
  CHECK gv_action_flag = 'S'.

  IF gv_action_flag = 'C' OR gs_s0400-user IS INITIAL.
    MESSAGE 'Action cancelled'(m14) TYPE gc_msg_success
            DISPLAY LIKE gc_msg_error.
    RETURN.
  ENDIF.

  lv_timestamp(8) = sy-datum.
  lv_timestamp+8 = sy-uzeit.

  CLEAR: lt_ybt_toad[].
  DO 12 TIMES.
    lv_no = sy-index.
    CONCATENATE 'GROUP' lv_no          INTO lv_groupnm.
    CONCATENATE 'GS_S0400-' lv_groupnm INTO lv_fld_group.
    ASSIGN (lv_fld_group) TO <lv_fld_group>.
    CHECK <lv_fld_group> IS ASSIGNED.

    CLEAR: ls_ybt_toad.
    CONCATENATE gs_s0400-user '_' lv_groupnm INTO ls_ybt_toad-queryid.
    ls_ybt_toad-owner            = gs_s0400-user.
    ls_ybt_toad-aedat            = lv_timestamp.
    ls_ybt_toad-visibility       = '3'.
    ls_ybt_toad-visibility_group = <lv_fld_group>.
    APPEND ls_ybt_toad TO lt_ybt_toad.
  ENDDO.

  MODIFY ybt_toad FROM TABLE lt_ybt_toad.
  COMMIT WORK AND WAIT.

  " Node History 갱신
  PERFORM repgo_make_query_history.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_user_group
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_user_group .

  DATA: lv_user      TYPE sy-uname,
        lv_dummy     TYPE scrfname,
        lv_groupnm   TYPE scrfname,
        lv_fld_group TYPE scrfname,
        ls_ybt_toad  TYPE ybt_toad,
        lt_ybt_toad  TYPE TABLE OF ybt_toad.

  FIELD-SYMBOLS:
      <lv_fld_group> TYPE any.

  lv_user = gs_s0400-user.
  CLEAR: gs_s0400.
  gs_s0400-user = lv_user.

  " 기존에 등록된 정보를 가지고 온다
  SELECT queryid, visibility_group
    FROM ybt_toad
    INTO CORRESPONDING FIELDS OF TABLE @lt_ybt_toad
   WHERE owner             = @lv_user
     AND visibility        = '3'
     AND visibility_group <> @space.
  CHECK sy-subrc = 0.

  LOOP AT lt_ybt_toad INTO ls_ybt_toad.
    SPLIT ls_ybt_toad-queryid AT '_' INTO lv_dummy lv_groupnm.
    CONCATENATE 'GS_S0400-' lv_groupnm INTO lv_fld_group.
    ASSIGN (lv_fld_group) TO <lv_fld_group>.
    CHECK <lv_fld_group> IS ASSIGNED.

    <lv_fld_group> = ls_ybt_toad-visibility_group.

  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form query_generate_noselect_new
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_COMMAND
*&      --> LV_FROM
*&      --> LV_WHERE
*&      --> PV_DISPLAY
*&      <-- LV_PROGRAM
*&---------------------------------------------------------------------*
FORM query_generate_noselect_new  USING    pv_command
                                           pv_table   TYPE string
                                           pv_query   TYPE string
                                           pv_display TYPE c
                                  CHANGING pv_program TYPE sy-repid.

  DATA: lv_mess(255),
        lv_line          TYPE i,
        lv_word(30),
        lv_strlen_string TYPE string,
        lv_explicit      TYPE string,
        lt_code_string   TYPE TABLE OF string.

* Write Header
  c 'PROGRAM SUBPOOL.'.                                     "#EC NOTEXT
  c ''.
  c '** Generated Program * Do Not Change It **'.           "#Ec Notext
  c ''.
  c 'TYPE-POOLS: SLIS.'.                                    "#EC NOTEXT
  c 'DATA : GV_TIMESTART TYPE TIMESTAMPL,'.                 "#EC NOTEXT
  c '       GV_TIMEEND   TYPE TIMESTAMPL.'.                 "#EC NOTEXT
  c ''.

  c 'FORM RUN_SQL CHANGING PO_RESULT    TYPE REF TO DATA'.  "#EC NOTEXT
  c '                      PV_DISPLAY_RESULT  TYPE C'.      "#EC NOTEXT
  c '                      PV_TIME      TYPE P'.            "#EC NOTEXT
  c '                      PV_COUNT     TYPE I.'.           "#EC NOTEXT
  c ''.
  c '***************************************'.              "#EC NOTEXT
  c '*            BEGIN OF QUERY           *'.              "#EC NOTEXT
  c '***************************************'.              "#EC NOTEXT
  c ''.
  c 'CLEAR PV_COUNT.'.                                      "#EC NOTEXT
  c 'GET TIME STAMP FIELD GV_TIMESTART.'.                   "#EC NOTEXT
  c ''.
  c pv_query.
  c '.'.
  c ''.
  c 'IF SY-SUBRC = 0.'.                                     "#EC NOTEXT
  c '  PV_COUNT = SY-DBCNT.'.                               "#EC NOTEXT
  c '  COMMIT WORK AND WAIT.'.
  c 'ENDIF.'.                                               "#EC NOTEXT
  c ''.
  c 'GET TIME STAMP FIELD GV_TIMEEND.'.                     "#EC NOTEXT
  c 'PV_TIME = GV_TIMEEND - GV_TIMESTART.'.                 "#EC NOTEXT
  c ''.
  c 'ENDFORM.'.                                             "#EC NOTEXT

  CLEAR : lv_line,
          lv_word,
          lv_mess.
  SYNTAX-CHECK FOR lt_code_string PROGRAM sy-repid
               MESSAGE lv_mess LINE lv_line WORD lv_word.
  IF sy-subrc NE 0 AND pv_display = space.
    MESSAGE lv_mess TYPE gc_msg_error.
  ENDIF.

  IF pv_display = space.
    GENERATE SUBROUTINE POOL lt_code_string NAME pv_program.
  ELSE.
    IF lv_mess IS NOT INITIAL.
      lv_explicit = lv_line.
      CONCATENATE lv_mess '(line'(m28) lv_explicit ',word'(m29)
                  lv_word ')'(m30)
                  INTO lv_mess SEPARATED BY space.
      MESSAGE lv_mess TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    ENDIF.
    EDITOR-CALL FOR lt_code_string DISPLAY-MODE
                TITLE 'Generated code for current query'(t01).
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_query_new_syntax
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_COMMAND
*&      --> LV_WHERE
*&      <-- LV_NEWSYNTAX
*&---------------------------------------------------------------------*
FORM check_query_new_syntax  USING    pv_command    TYPE string
                                      pv_where      TYPE string
                             CHANGING pv_newsyntax.

  DATA: lv_newsyntax.

  pv_newsyntax = abap_true.

  CASE pv_command.
    WHEN 'INSERT'.
      PERFORM check_query_new_syntax_insert USING    pv_where
                                            CHANGING lv_newsyntax.
    WHEN OTHERS.
  ENDCASE.
  CHECK lv_newsyntax = abap_false.

  pv_newsyntax = abap_false.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_query_new_syntax_insert
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_WHERE
*&      <-- LV_NEWSYNTAX
*&---------------------------------------------------------------------*
FORM check_query_new_syntax_insert  USING    pv_where      TYPE string
                                    CHANGING pv_newsyntax.

  DATA: lv_string      TYPE string,
        ls_find_select TYPE match_result,
        lo_regex       TYPE REF TO cl_abap_regex.
  " where 에 select 가 있는 경우
*  CONCATENATE '(SELECT)' '(\S*)'
*              INTO lv_string SEPARATED BY space.
  lv_string = `( SELECT )(\S*)`.
  CREATE OBJECT lo_regex
    EXPORTING
      pattern     = lv_string
      ignore_case = abap_true
      ##REGEX_POSIX.

  FIND FIRST OCCURRENCE OF REGEX lo_regex
       IN pv_where RESULTS ls_find_select.
  IF sy-subrc = 0.
    pv_newsyntax = abap_true.
    EXIT.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form edit_and_execute_source
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM edit_and_execute_source .

  DATA: lv_mess(255),
        lv_line          TYPE i,
        lv_word(30),
        lv_strlen_string TYPE string,
        lv_explicit      TYPE string,
        lt_code_string   TYPE TABLE OF string.

  DATA: lv_title(50),
        lv_line_length(3) TYPE n,
        lv_fcode          TYPE edfcode,
        lv_changed        TYPE edchanged,
        lv_type           TYPE edtexttype,
        lv_operation      TYPE seu_action,
        lv_objtype        TYPE seu_objtyp,
        ls_editor_state   TYPE sedi_editor_state.

  DATA: lv_program      TYPE sy-repid,
        lo_result       TYPE REF TO data,
        lt_fieldlist    TYPE tyt_fieldlist,
        lv_msg          TYPE string,
        lv_charnumb(12) TYPE c,
        lv_show_result  TYPE c,
        lv_time         TYPE p LENGTH 8 DECIMALS 2,
        lv_count        TYPE i.


  IF gt_code_string[] IS INITIAL.
    PERFORM initialize_execute_source CHANGING lt_code_string.
  ELSE.
    lt_code_string = gt_code_string.
  ENDIF.

  lv_title       = 'Editor and Run Query'(t05).
  lv_line_length = 255.
  lv_type        = 'TXT'.
  lv_operation   = 'EDIT'.
  lv_objtype     = 'TB'.


  DATA: lv_subrc TYPE sy-subrc.
  lv_subrc = 0.
  WHILE lv_subrc = 0.

    EXPORT title     = lv_title " title
           content   = lt_code_string " source table
           line_size = lv_line_length " 255
           text_type = lv_type  "TXT
      TO MEMORY ID 'EDITOR_TABLE_INPUT'.

    SUBMIT rs_edtr_start_new_mode AND RETURN
*    SUBMIT YBZ_edtr_start AND RETURN
      WITH objname  = space
      WITH objtype  = swbm_c_type_edit_table  "TB
      WITH op       = lv_operation "EDIT
      WITH line     = '1'
      WITH topline  = '1'
      WITH offset   = '0'
      WITH app_id   = 'FM'
*      WITH app_id   = 'PC' "'FM'
      WITH app_obj  = space
      WITH buf_name = space.

    "update the global settings variable if needed
    CALL FUNCTION 'RS_WORKBENCH_CUSTOMIZING_RESET'.

    IMPORT fcode   = lv_fcode
           changed = lv_changed
           content = lt_code_string
      FROM MEMORY ID 'EDITOR_TABLE_OUTPUT'.

    FREE MEMORY ID 'EDITOR_TABLE_OUTPUT'.

    CLEAR: lv_line, lv_word, lv_mess, lv_subrc.
    CASE lv_fcode.
      WHEN 'FMB'. " back or cancel
        MESSAGE i000(oo) WITH 'job has been canceled'.
        lv_subrc = 1. " 취소

      WHEN 'FMCH'. " Check
        SYNTAX-CHECK FOR lt_code_string PROGRAM sy-repid
                     MESSAGE lv_mess LINE lv_line WORD lv_word.
        IF sy-subrc NE 0.
          lv_charnumb = lv_line. CONDENSE lv_charnumb NO-GAPS.
          CONCATENATE '(' lv_charnumb ')' lv_mess INTO lv_mess.
          MESSAGE lv_mess TYPE 'S' DISPLAY LIKE 'E'.
        ELSE.
          MESSAGE s000(oo) WITH 'There are no errors in the syntax'.
        ENDIF.

      WHEN 'FMSA'. " SAVE
        SYNTAX-CHECK FOR lt_code_string PROGRAM sy-repid
                     MESSAGE lv_mess LINE lv_line WORD lv_word.

        IF sy-subrc NE 0.
          MESSAGE lv_mess TYPE gc_msg_error.
        ELSE.
          gt_code_string = lt_code_string.
          lv_subrc = 2.
        ENDIF.
      WHEN OTHERS.
    ENDCASE.

  ENDWHILE.

  CHECK lv_subrc = 2. " save

  GENERATE SUBROUTINE POOL lt_code_string NAME lv_program.
  CHECK sy-subrc = 0.

  PERFORM run_sql IN PROGRAM (lv_program)
                  CHANGING lo_result lv_show_result lv_time lv_count.

*--------------------------------------------------------------------*
  gt_code_string = lt_code_string.  " 실행된 프로그램 저장

* 수행 프로그램 저장
  EXPORT content   = lt_code_string " source table
      TO MEMORY ID 'YBZ_SOURCE_SAVE'.

  PERFORM repgo_save_current_query USING '4'.

  FREE MEMORY ID 'YBZ_SOURCE_SAVE'.
*--------------------------------------------------------------------*

  lv_charnumb = lv_time.  CONDENSE lv_charnumb NO-GAPS.
  CONCATENATE 'Query executed in'(m09) lv_charnumb INTO lv_msg
              SEPARATED BY space.
  lv_charnumb = lv_count.  CONDENSE lv_charnumb NO-GAPS.

  IF lv_show_result IS INITIAL.
    CONCATENATE lv_msg 'seconds.'(m10)
                lv_charnumb 'entries Changed'(m12)
                INTO lv_msg SEPARATED BY space.
    CONDENSE lv_msg.
    MESSAGE lv_msg TYPE gc_msg_information.

  ELSE.
    CONCATENATE lv_msg 'seconds.'(m10)
                lv_charnumb 'entries found'(m11)
                INTO lv_msg SEPARATED BY space.
    CONDENSE lv_msg.
    MESSAGE lv_msg TYPE gc_msg_success.

    lv_msg = 'Query Result of Execution Program '.
    PERFORM result_display USING lo_result lt_fieldlist lv_msg.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form initialize_execute_source
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- LT_CODE_STRING
*&---------------------------------------------------------------------*
FORM initialize_execute_source  CHANGING pt_code_string TYPE STANDARD TABLE.

  DATA: lv_strlen_string   TYPE string.

* Write Header
  c1 'PROGRAM SUBPOOL.'.                                    "#EC NOTEXT
  c1 ''.
  c1 '** Executed When Source Is Saved. **'.                "#Ec Notext
  c1 ''.
  c1 'TYPE-POOLS: SLIS.'.                                   "#EC NOTEXT
  c1 'DATA: BEGIN OF GS_RESULT'.                            "#EC NOTEXT
  c1 ', END OF GS_RESULT'.                                  "#EC NOTEXT
  c1 ', GT_RESULT LIKE TABLE OF GS_RESULT.'.                "#EC NOTEXT
  c1 'DATA : GV_TIMESTART TYPE TIMESTAMPL,'.                "#EC NOTEXT
  c1 '       GV_TIMEEND TYPE TIMESTAMPL.'.                  "#EC NOTEXT
  c1 ''.
  c1 'FORM RUN_SQL CHANGING PO_RESULT       TYPE REF TO DATA'. "#EC NOTEXT
  c1 '                      PV_SHOW_RESULT  TYPE C'.        "#EC NOTEXT
  c1 '                      PV_TIME         TYPE P'.        "#EC NOTEXT
  c1 '                      PV_COUNT        TYPE I.'.       "#EC NOTEXT
  c1 ''.
  c1 '***************************************'.             "#EC NOTEXT
  c1 '*            BEGIN OF QUERY           *'.             "#EC NOTEXT
  c1 '***************************************'.             "#EC NOTEXT
  c1 ''.
  c1 'CLEAR PV_COUNT.'.                                     "#EC NOTEXT
  c1 'GET TIME STAMP FIELD GV_TIMESTART.'.                  "#EC NOTEXT
  c1 ''.
  c1 '* PLEASE DESCRIBE YOUR QUERY HERE *'.
  c1 '.'.
  c1 ''.
  c1 'IF SY-SUBRC = 0.'.                                    "#EC NOTEXT
  c1 '  PV_COUNT = SY-DBCNT.'.                              "#EC NOTEXT
  c1 '  COMMIT WORK AND WAIT.'.
  c1 'ENDIF.'.                                              "#EC NOTEXT
  c1 ''.
  c1 'GET TIME STAMP FIELD GV_TIMEEND.'.                    "#EC NOTEXT
  c1 'PV_TIME        = GV_TIMEEND - GV_TIMESTART.'.         "#EC NOTEXT
  c1 'PV_SHOW_RESULT = ABAP_TRUE.'.                         "#EC NOTEXT
  c1 ''.
  c1 'GET REFERENCE OF GT_RESULT INTO PO_RESULT.'.          "#EC NOTEXT

  c1 'ENDFORM.'.                                            "#EC NOTEXT

ENDFORM.
*&---------------------------------------------------------------------*
*& Form tab_del
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM tab_del .

  " 현재 act 되어 있는 tab 의 정보 삭제

  DATA: lv_cur TYPE i,
        lv_max TYPE i.

  " 생성된 tab 의 갯수가 1개이면 작업취소
  lv_max = lines( gt_tabs ).
  IF lv_max = 1.
    MESSAGE 'There must be 1 tab'(m66)
            TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
    EXIT.
  ENDIF.

  lv_cur = go_tabstrip-activetab+3(2).
  READ TABLE gt_tabs INTO gs_tab_active INDEX lv_cur.
  CHECK sy-subrc = 0.

  gs_tab_active-textedit->free( ).
  gs_tab_active-tree_ddic->free( ).
  gs_tab_active-alv_result->free( ).

  DELETE gt_tabs INDEX lv_cur.

  " 변경 tab 정보 설정 : 앞으로 이동
  IF lv_cur > 1.
    lv_cur = lv_cur - 1.
  ENDIF.

  WRITE lv_cur TO go_tabstrip-activetab LEFT-JUSTIFIED.
  CONCATENATE 'TAB' go_tabstrip-activetab INTO go_tabstrip-activetab.
  CONDENSE go_tabstrip-activetab NO-GAPS.

  PERFORM show_new_tab.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form show_new_tab
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GV_SAVE_OK+3
*&---------------------------------------------------------------------*
FORM show_new_tab.

  READ TABLE gt_tabs INTO gs_tab_active INDEX go_tabstrip-activetab+3.
  CHECK sy-subrc = 0.

* Display editor / ddic / alv
  CALL METHOD gs_tab_active-textedit->set_visible
    EXPORTING
      visible = abap_true.

  CALL METHOD gs_tab_active-tree_ddic->set_visible
    EXPORTING
      visible = abap_true.

  IF NOT gs_tab_active-alv_result IS INITIAL.
    CALL METHOD gs_tab_active-alv_result->set_visible
      EXPORTING
        visible = abap_true.
  ENDIF.

  CALL METHOD go_splitter->set_row_height
    EXPORTING
      id     = 1
      height = gs_tab_active-row_height.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_usergroup
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM check_usergroup .

ENDFORM.
*&---------------------------------------------------------------------*
*& Form lct_ics_DELETE_QUERY
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM lct_ics_delete_query .

  DATA: lv_node_key TYPE tv_nodekey,
        lv_subrc    TYPE i.

  CALL METHOD go_tree_repository->get_selected_node
    IMPORTING
      node_key = lv_node_key.
  PERFORM repgo_delete_history USING    lv_node_key
                               CHANGING lv_subrc.
  IF lv_subrc = 0.
    MESSAGE 'Query deleted'(m02) TYPE gc_msg_success.
  ELSE.
    MESSAGE 'Error when deleting the query'(m03)
            TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form lct_ics_delete_hist
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM lct_ics_delete_hist USING pv_visibility.

  DATA: lv_subrc   TYPE i,
        ls_histo   LIKE gs_node_repository,
        lv_queryid LIKE ls_histo-queryid.

  CONCATENATE sy-uname '+++' INTO lv_queryid.
  LOOP AT gt_node_repository INTO ls_histo
          WHERE queryid    CP lv_queryid
            AND visibility  = pv_visibility.
    PERFORM repgo_delete_history USING    ls_histo-node_key
                                 CHANGING lv_subrc.
    IF lv_subrc NE 0.
      MESSAGE 'Error when deleting the query'(m03)
              TYPE gc_msg_success DISPLAY LIKE gc_msg_error.
      RETURN.
    ENDIF.
  ENDLOOP.
  MESSAGE 'All history entries deleted'(m37) TYPE gc_msg_success.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form search_from_in_query
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_QUERY
*&      <-- PV_QUERY
*&      <-- PV_FROM
*&      <-- PV_WHERE
*&      <-- PV_NEWSYNTAX
*&      <-- PV_ERROR
*&---------------------------------------------------------------------*
FORM search_from_in_query  USING    pv_query
                           CHANGING pv_select
                                    pv_from
                                    pv_where
                                    pv_newsyntax
                                    pv_error.

  DATA: lv_src           TYPE string,          " 원문
        lv_up            TYPE string,          " 대문자판(길이 동일 유지)
        lv_cr            TYPE c LENGTH 1,
        lv_lf            TYPE c LENGTH 1,
        lv_tab           TYPE c LENGTH 1,
        lv_n             TYPE i,
        lv_i             TYPE i,
        lv_j             TYPE i,
        lv_char          TYPE c LENGTH 1,
        lv_prev          TYPE c LENGTH 1,
        lv_next          TYPE c LENGTH 1,
        off_sel          TYPE i VALUE -1,      " SELECT 시작('S') 위치
        off_from         TYPE i VALUE -1,      " FROM 시작('F') 위치 (Top-level)
        off_fields       TYPE i VALUE -1,    " FIELDS 시작('F') 위치 (Top-level, 신문법)
        off_clause       TYPE i VALUE -1,    " WHERE/GROUP/HAVING/ORDER/끝
        kind_clause      TYPE string,       " 'WHERE' / 'GROUP BY' / 'HAVING' / 'ORDER BY'
        pos_after_select TYPE i,
        pos_after_from   TYPE i,
        pos_after_fields TYPE i,
        len_tmp          TYPE i.

  CLEAR: pv_select, pv_from, pv_where, pv_newsyntax, pv_error.

  " 0) 원문/대문자판 준비 (길이 보존, CONDENSE 금지)
  lv_src = pv_query.
  lv_up  = to_upper( lv_src ).

  lv_cr  = cl_abap_char_utilities=>cr_lf+0(1).         " '\r'
  lv_lf  = cl_abap_char_utilities=>newline.            " '\n'
  lv_tab = cl_abap_char_utilities=>horizontal_tab.     " '\t'

  REPLACE ALL OCCURRENCES OF lv_cr  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_lf  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_tab IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  " 1) SELECT 위치(간단 탐색; 일반적으로 문장 선두)
  FIND FIRST OCCURRENCE OF |SELECT | IN lv_up MATCH OFFSET off_sel IGNORING CASE.
  IF sy-subrc <> 0.
    " 'SELECT' 뒤에 공백이 없을 수도 있어 fallback
    FIND FIRST OCCURRENCE OF |SELECT| IN lv_up MATCH OFFSET off_sel IGNORING CASE.
    IF sy-subrc <> 0.
      pv_error = abap_true.
      RETURN.
    ENDIF.
  ENDIF.
  pos_after_select = off_sel + 6.
  IF pos_after_select > lv_n.
    pv_error = abap_true.
    RETURN.
  ENDIF.

  " 2) Top-level FROM 탐색 (따옴표/괄호 무시)
  DATA lv_depth TYPE i VALUE 0.
  DATA lv_in_q  TYPE abap_bool VALUE abap_false.

  lv_i = off_sel.  " SELECT 이후부터 훑되, 혹시 앞에 서브쿼리 대비 여유
  WHILE lv_i < lv_n.
    lv_char = lv_up+lv_i(1).

    " 따옴표('' 이스케이프)
    DATA(off_nxt) = lv_i + 1.
    IF lv_char = ''''.
      IF lv_in_q = abap_true AND off_nxt < lv_n AND lv_up+off_nxt(1) = ''''.
        lv_i = lv_i + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.

      IF lv_depth = 0 AND lv_i + 3 < lv_n AND lv_up+lv_i(4) = |FROM|.
        " 경계(이전/다음) 점검: 이전은 공백/괄호/구분자, 다음은 공백/+/"/( 또는 끝
        IF lv_i = 0.
          lv_prev = space.
        ELSE.
          DATA(off_prev) = lv_i - 1.
          lv_prev = lv_up+off_prev(1).
        ENDIF.
        DATA(off_after_f) = lv_i + 4.
        IF off_after_f < lv_n.
          lv_next = lv_up+off_after_f(1).
        ELSE.
          CLEAR lv_next.
        ENDIF.

        IF ( lv_prev = space OR lv_prev = ')' OR lv_prev = '(' OR lv_prev = ',' OR
             lv_prev = ';' OR lv_prev = lv_tab OR lv_prev = lv_lf )
        AND ( off_after_f = lv_n OR lv_next = space OR lv_next = '+' OR lv_next = '"' OR
              lv_next = '(' OR lv_next = ',' OR lv_next = lv_tab OR lv_next = lv_lf ).
          off_from = lv_i.
          EXIT.
        ENDIF.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  IF off_from < 0.
    pv_error = abap_true.
    RETURN.
  ENDIF.

  pos_after_from = off_from + 4.  " 'FROM' 뒤

  " 3) FROM 이후: Top-level 'FIELDS' 및 절(WHERE/GROUP/HAVING/ORDER) 위치 찾기
  off_fields = -1.
  off_clause = -1.
  CLEAR kind_clause.

  lv_i = pos_after_from.
  lv_depth = 0.
  lv_in_q  = abap_false.

  WHILE lv_i < lv_n.
    lv_char = lv_up+lv_i(1).

    " 따옴표
    off_nxt = lv_i + 1.
    IF lv_char = ''''.
      IF lv_in_q = abap_true AND off_nxt < lv_n AND lv_up+off_nxt(1) = ''''.
        lv_i = lv_i + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.

      IF lv_depth = 0.
        " FIELDS (신문법)
        IF off_fields < 0 AND lv_i + 5 < lv_n AND lv_up+lv_i(6) = |FIELDS|.
          " 이전/다음 경계 최소 점검
          IF lv_i = 0.
            lv_prev = space.
          ELSE.
            off_prev = lv_i - 1.
            lv_prev = lv_up+off_prev(1).
          ENDIF.
          off_nxt = lv_i + 6.
          IF off_nxt < lv_n.
            lv_next = lv_up+off_nxt(1).
          ELSE.
            CLEAR lv_next.
          ENDIF.

          IF ( lv_prev = space OR lv_prev = lv_tab OR lv_prev = lv_lf )
          AND ( off_nxt = lv_n OR lv_next = space OR lv_next = lv_tab OR lv_next = lv_lf ).
            off_fields = lv_i.
          ENDIF.
        ENDIF.

        " WHERE / GROUP BY / HAVING / ORDER BY
        IF lv_i + 5 < lv_n AND lv_up+lv_i(6) = |WHERE|.
          off_clause = lv_i. kind_clause = |WHERE|. EXIT.
        ENDIF.

        IF lv_i + 8 < lv_n AND lv_up+lv_i(9) = |GROUP BY|.
          off_clause = lv_i. kind_clause = |GROUP BY|. EXIT.
        ENDIF.

        IF lv_i + 6 < lv_n AND lv_up+lv_i(7) = |HAVING|.
          off_clause = lv_i. kind_clause = |HAVING|. EXIT.
        ENDIF.

        IF lv_i + 8 < lv_n AND lv_up+lv_i(9) = |ORDER BY|.
          off_clause = lv_i. kind_clause = |ORDER BY|. EXIT.
        ENDIF.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  " 4) 조각 내기 (원문 lv_src 기준 슬라이스)
  IF off_fields >= 0.
    " --- 신문법: SELECT FROM <from> FIELDS <select> [clause ...]
    " pv_from
    IF off_clause >= 0.
      len_tmp  = off_fields - pos_after_from.
      IF len_tmp < 0. len_tmp = 0. ENDIF.
      pv_from  = lv_src+pos_after_from(len_tmp).
    ELSE.
      pv_from  = lv_src+pos_after_from.
    ENDIF.

    " pv_select
    pos_after_fields = off_fields + 6.
    " FIELDS 뒤 공백류 스킵
    lv_j = pos_after_fields.
    WHILE lv_j < lv_n AND ( lv_up+lv_j(1) = space OR lv_up+lv_j(1) = lv_tab OR lv_up+lv_j(1) = lv_lf ).
      lv_j = lv_j + 1.
    ENDWHILE.

    IF off_clause >= 0.
      len_tmp  = off_clause - lv_j.
      IF len_tmp < 0. len_tmp = 0. ENDIF.
      pv_select = lv_src+lv_j(len_tmp).
      pv_where  = lv_src+off_clause.
    ELSE.
      pv_select = lv_src+lv_j.
      CLEAR pv_where.
    ENDIF.

    pv_newsyntax = abap_true.

  ELSE.
    " --- 클래식: SELECT <select> FROM <from> [clause ...]
    " pv_select
    lv_j = pos_after_select.
    WHILE lv_j < lv_n
      AND ( lv_up+lv_j(1) = space
         OR lv_up+lv_j(1) = lv_tab
         OR lv_up+lv_j(1) = lv_lf ).
      lv_j = lv_j + 1.
    ENDWHILE.

    IF off_from > lv_j.
      len_tmp = off_from - lv_j.
      IF len_tmp < 0. len_tmp = 0. ENDIF.
      pv_select = lv_src+lv_j(len_tmp).
    ELSE.
      CLEAR pv_select.
    ENDIF.

    " pv_from / pv_where
    IF off_clause >= 0.
      len_tmp = off_clause - pos_after_from.
      IF len_tmp < 0. len_tmp = 0. ENDIF.
      pv_from  = lv_src+pos_after_from(len_tmp).
      pv_where = lv_src+off_clause.
    ELSE.
      pv_from  = lv_src+pos_after_from.
      CLEAR pv_where.
    ENDIF.

    " 쉼표 기반(신문법 스타일) 필드목록 여부도 힌트로 표시
    IF pv_select CS ','.
      pv_newsyntax = abap_true.
    ENDIF.
    " WHERE 내 SUBSTRING 사용도 힌트로 유지
    IF pv_where CS | SUBSTRING(| OR pv_where CS | SUBSTR(|.
      pv_newsyntax = abap_true.
    ENDIF.
  ENDIF.

  " 5) 기본 유효성
  IF pv_from IS INITIAL.
    pv_error = abap_true.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form Create_alias_table_mapping
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_SPLIT
*&      --> LT_TABLE_ALIAS
*&---------------------------------------------------------------------*
FORM create_alias_table_mapping  TABLES   pt_split       TYPE STANDARD TABLE
                                          pt_table_alias TYPE tyt_table_alias.

  DATA: lv_index       TYPE sy-tabix,
        lv_string      TYPE string,
        ls_table_alias TYPE tys_table_alias.

  LOOP AT pt_split INTO lv_string.

    lv_index = sy-tabix.

    IF lv_string IS INITIAL OR lv_string CO space.
      DELETE pt_split.
    ENDIF.

    TRANSLATE lv_string TO UPPER CASE.
    IF lv_string = 'AS'.
      MODIFY pt_split FROM lv_string INDEX lv_index.
    ENDIF.
  ENDLOOP.

  DO.
    READ TABLE pt_split TRANSPORTING NO FIELDS WITH KEY = 'AS'.
    IF sy-subrc NE 0.
      EXIT. "exit do
    ENDIF.

    lv_index = sy-tabix - 1.
    READ TABLE pt_split INTO lv_string INDEX lv_index.
    ls_table_alias-table = lv_string.

    DELETE pt_split INDEX lv_index. "delete table field
    DELETE pt_split INDEX lv_index. "delete keywork AS

    READ TABLE pt_split INTO lv_string INDEX lv_index.
    ls_table_alias-alias = lv_string.

    DELETE pt_split INDEX lv_index. "delete alias field

    TRANSLATE ls_table_alias TO UPPER CASE.
    APPEND ls_table_alias TO pt_table_alias.

  ENDDO.

* If no alias table found, create just an entry for "*"
  IF pt_table_alias[] IS INITIAL.
    READ TABLE pt_split INTO lv_string INDEX 1.
    ls_table_alias-table = lv_string.
    ls_table_alias-alias = '*'.
    TRANSLATE ls_table_alias TO UPPER CASE.
    APPEND ls_table_alias TO pt_table_alias.
  ENDIF.

  SORT pt_table_alias BY alias.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form make_select_field_list
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LT_SPLIT
*&      <-- LV_SELECT
*&---------------------------------------------------------------------*
FORM make_select_field_list  USING    pv_write
                             CHANGING pv_newsyntax
                                      pv_select
                                      pt_split        TYPE tyt_string
                                      pt_fieldlist    TYPE tyt_fieldlist
                                      pt_table_alias  TYPE tyt_table_alias
                                      pt_code_string  TYPE tyt_string.

  DATA: lv_newsyntax        TYPE string,
        lv_string           TYPE string,
        lv_field_as         TYPE string,
        lv_current_line     TYPE i,
        lv_current_length   TYPE i,
        lv_len              TYPE i,
        lv_pos              TYPE i,
        ls_fieldlist        TYPE tys_fieldlist,
        ls_table_alias      TYPE tys_table_alias,
        ls_dd03l            TYPE dd03l,
        lv_char_10          TYPE char30,
        lv_flag             TYPE c,
        lv_dummy            TYPE string,
        lv_select_table     TYPE string,
        lv_select_field     TYPE string,
        lv_select_field_txt TYPE string,
        lv_field_number(6)  TYPE n,
        lv_explicit         TYPE string,
        lv_struct_line      TYPE string,
        lv_struct_line_type TYPE string,
        lv_strlen_string    TYPE string,
        lv_select           TYPE string,
        lv_comma            TYPE c.

  DATA: ls_table_w TYPE tys_table_w,
        ls_field_w TYPE tys_fieldlist.


  lv_newsyntax = pv_newsyntax.

  LOOP AT pt_split INTO lv_string.

    CLEAR: lv_field_as.
    SHIFT lv_string LEFT DELETING LEADING space.

    lv_current_line = sy-tabix.
    IF lv_string IS INITIAL OR lv_string CO space.
      CONTINUE.
    ENDIF.

    lv_current_length = strlen( lv_string ).

    CLEAR ls_fieldlist.
    ls_fieldlist-ref_field = lv_string.

    SPLIT lv_string AT space INTO lv_char_10 lv_dummy.
    REPLACE ALL OCCURRENCES OF '(' IN lv_char_10 WITH space.
    TRANSLATE lv_char_10 TO UPPER CASE.

    lv_flag    = space.

* Manage new syntax "Case"
    CASE lv_char_10.
      WHEN 'CONCAT__SPACE' OR 'CONCAT_WITH_SPACE' OR 'CONCAT' OR
           'SUBSTRING'.
        PERFORM generate_concat     USING    lv_current_line lv_newsyntax pv_write
                                    CHANGING pt_split
                                             lv_string
                                             lv_field_number
                                             ls_fieldlist
                                             pt_fieldlist
                                             pt_code_string
                                             pt_table_alias.

      WHEN 'CAST'.
        PERFORM generate_cast       USING    lv_current_line lv_newsyntax pv_write
                                    CHANGING pt_split
                                             lv_string
                                             lv_field_number
                                             ls_fieldlist
                                             pt_fieldlist
                                             pt_code_string
                                             pt_table_alias.
      WHEN 'CASE'.
        PERFORM generate_case       USING    lv_current_line lv_newsyntax pv_write
                                    CHANGING pt_split
                                             lv_string
                                             lv_field_number
                                             ls_fieldlist
                                             pt_fieldlist
                                             pt_code_string
                                             pt_table_alias.

      WHEN 'ROW_NUMBER' OR 'RANK' OR 'DENSE_RANK' OR 'LENGTH'.
        PERFORM generate_seq_function USING    lv_current_line lv_newsyntax
                                               'INT8'
                                               pv_write
                                      CHANGING pt_split
                                               lv_string
                                               lv_field_number
                                               ls_fieldlist
                                               pt_fieldlist
                                               pt_code_string.

      WHEN 'SUM' OR 'MAX' OR 'MIN' OR 'AVG' OR 'COUNT' OR
           'COALESCE'.  " null 문자 치환
        PERFORM generate_agg_func   USING    lv_current_line lv_newsyntax pv_write
                                    CHANGING pt_split
                                             lv_string
                                             lv_field_number
                                             ls_fieldlist
                                             pt_fieldlist
                                             pt_code_string
                                             pt_table_alias.

      WHEN OTHERS.
        IF matches( val = lv_string pcre = '.*\s[\+\-\*\/\<\>]\s.*' ).
          PERFORM generate_agg_func   USING    lv_current_line lv_newsyntax pv_write
                                      CHANGING pt_split
                                               lv_string
                                               lv_field_number
                                               ls_fieldlist
                                               pt_fieldlist
                                               pt_code_string
                                               pt_table_alias.

        ELSEIF lv_char_10+0(1) = `'` OR lv_char_10+0(1) = '@'.
          PERFORM generate_concat     USING    lv_current_line lv_newsyntax pv_write
                                      CHANGING pt_split
                                               lv_string
                                               lv_field_number
                                               ls_fieldlist
                                               pt_fieldlist
                                               pt_code_string
                                               pt_table_alias.
        ELSE.
          lv_flag = abap_true.
        ENDIF.

    ENDCASE.
    IF lv_flag = space.
      CONTINUE.
    ENDIF.

    " distinct 제거
    IF lv_string IS NOT INITIAL.
      lv_select = to_upper( lv_string ).
      IF lv_select = 'DISTINCT' OR lv_select CP 'DISTINCT *'.
        lv_string = lv_string+8.
        SHIFT lv_string LEFT DELETING LEADING space.

        IF lv_string IS INITIAL OR lv_string CO space.
          CONTINUE.
        ENDIF.
      ENDIF.
    ENDIF.

* Now lv_string contain a field name.
* We have to find the field description
    SPLIT lv_string AT '~' INTO lv_select_table lv_select_field.
    IF lv_select_field IS INITIAL.
      lv_select_field = lv_select_table.

      READ TABLE pt_table_alias INTO ls_table_alias INDEX 1.
      IF sy-subrc = 0.
        IF ls_table_alias-alias IS INITIAL.
          lv_select_table = ls_table_alias-table.
        ELSE.
          lv_select_table = ls_table_alias-alias.
        ENDIF.
      ELSE.
        lv_select_table = '*'.
      ENDIF.
    ELSE.
      ls_fieldlist-ref_field = lv_select_field.
    ENDIF.

* Search if alias table used
    CLEAR ls_table_alias.
    TRANSLATE lv_select_table TO UPPER CASE.
    READ TABLE pt_table_alias INTO ls_table_alias
               WITH KEY alias = lv_select_table             "#EC WARNOK
               BINARY SEARCH.
    IF sy-subrc = 0.
      lv_select_table = ls_table_alias-table.
    ENDIF.
    ls_fieldlist-ref_table = lv_select_table.
    IF lv_string = '*' OR lv_select_field = '*'. " expansion table~*

      CLEAR: lv_comma, lv_explicit.
      DATA(lv_select_ok) = '1'.
      WHILE lv_select_ok <> '9'.

        SELECT fieldname position datatype reftable reffield
          INTO CORRESPONDING FIELDS OF ls_dd03l
          FROM  dd03l
         WHERE  tabname    = lv_select_table
           AND ( fieldname <> 'MANDT' OR datatype <> 'CLNT' )
           AND   as4local   = gc_vers_active
           AND   as4vers    = space
           AND ( comptype   = gc_ddic_dtelm OR comptype   = space )
          ORDER BY position.

          lv_select_field = ls_dd03l-fieldname.

          IF pv_write = abap_true.
            CONCATENATE 'F' lv_field_number INTO ls_fieldlist-field.
            ls_fieldlist-ref_field   = lv_select_field.
            ls_fieldlist-field_type  = ls_dd03l-datatype.
            ls_fieldlist-table_ref   = ls_dd03l-reftable.
            ls_fieldlist-field_ref   = ls_dd03l-reffield.
            APPEND ls_fieldlist TO pt_fieldlist.

            CONCATENATE ',' ls_fieldlist-field INTO lv_struct_line.

            CONCATENATE lv_select_table '-' lv_select_field
                        INTO lv_struct_line_type.
            CONCATENATE lv_struct_line 'TYPE' lv_struct_line_type
                        INTO lv_struct_line
                        SEPARATED BY space.
            c1 lv_struct_line.
            lv_field_number = lv_field_number + 1.
          ENDIF.

* Explicit list of fields instead of *
* Generate longer query but mandatory in case of T1~* or MARA~*
* Required also in some special cases, for example if table use include
          IF ls_table_alias-alias = space OR ls_table_alias-alias = '*'.
            CONCATENATE lv_explicit lv_comma lv_select_table
                        INTO lv_explicit SEPARATED BY space.
          ELSE.
            CONCATENATE lv_explicit lv_comma ls_table_alias-alias
                        INTO lv_explicit SEPARATED BY space.
          ENDIF.
          CONCATENATE lv_explicit '~' lv_select_field INTO lv_explicit.

          IF lv_newsyntax = abap_true.
            lv_comma = ','.
          ENDIF.

        ENDSELECT.

        IF sy-subrc = 0.
          lv_select_ok = '9'.
        ELSE.
          " DDIC 에 Table 정보가 없는 경우
          CASE lv_select_ok.
            WHEN  '1'.
              SELECT SINGLE objectname
                FROM ddldependency
                INTO lv_select_table
               WHERE ddlname = lv_select_table
                 AND state   = 'A'
                 AND objecttype = 'VIEW'.
              IF sy-subrc = 0.
                lv_select_ok = '2'.
                lv_newsyntax = abap_true.
              ELSE.
                lv_select_ok = '3'.
              ENDIF.

            WHEN '3'.
              READ TABLE gt_table_w INTO ls_table_w WITH KEY tabname = lv_select_table.
              IF sy-subrc = 0.

                LOOP AT ls_table_w-field_list INTO ls_fieldlist.
                  CONCATENATE 'F' lv_field_number INTO ls_fieldlist-field.
                  APPEND ls_fieldlist TO pt_fieldlist.

                  CONCATENATE ',' ls_fieldlist-field INTO lv_struct_line.

                  IF ls_fieldlist-ref_table IS NOT INITIAL AND
                     ls_fieldlist-ref_field IS NOT INITIAL.

                    CONCATENATE ls_fieldlist-ref_table '-' ls_fieldlist-ref_field
                                INTO lv_struct_line_type.
                  ELSE.
                    lv_struct_line_type = ls_fieldlist-field_type.
                  ENDIF.

                  CONCATENATE lv_struct_line 'TYPE' lv_struct_line_type
                              INTO lv_struct_line
                              SEPARATED BY space.

                  c1 lv_struct_line.
                  lv_field_number = lv_field_number + 1.
                ENDLOOP.

                lv_select_ok = '9'.
                sy-subrc = 0.

              ELSE.
                lv_select_ok = '5'.
              ENDIF.

            WHEN OTHERS.
              lv_select_ok = '9'.
          ENDCASE.
        ENDIF.
      ENDWHILE.
      IF sy-subrc NE 0.
        MESSAGE e701(1r) WITH lv_select_table. "table does not exist
      ENDIF.
      IF NOT lv_explicit IS INITIAL.
        REPLACE FIRST OCCURRENCE OF lv_string
                IN pv_select WITH lv_explicit.
      ENDIF.

    ELSE. "Simple field

      CONCATENATE 'F' lv_field_number INTO ls_fieldlist-field.

      " with 에 지정된 table 인 경우
      IF ls_fieldlist-ref_table+0(1) = '+'.

        ls_field_w = CORRESPONDING #( ls_fieldlist ).
        PERFORM get_fieldname_from_cte CHANGING ls_field_w lv_select_field_txt.

        IF lv_select_field_txt IS INITIAL.
          lv_select_field_txt = ls_field_w-field_txt.
        ENDIF.

        IF ls_field_w-field_type IS INITIAL.
          ls_fieldlist-ref_table = ls_field_w-ref_table.
          IF ls_field_w-ref_field IS INITIAL.
            ls_fieldlist-ref_field = ls_field_w-field.
          ELSE.
            ls_fieldlist-ref_field = ls_field_w-ref_field.
          ENDIF.
          ls_fieldlist-field_txt = lv_select_field_txt.
          lv_select_table        = ls_field_w-ref_table.
          lv_select_field        = ls_field_w-ref_field.

        ELSE.
          ls_fieldlist-field_type = ls_field_w-field_type.
          ls_fieldlist-field_txt  = lv_select_field_txt.
        ENDIF.
      ELSE.

        DATA(lv_field_txt_save) = ls_fieldlist-field_txt.
        SPLIT lv_select_field AT ' AS ' INTO ls_fieldlist-ref_field ls_fieldlist-field_txt.
        IF lv_field_txt_save IS NOT INITIAL.
          ls_fieldlist-field_txt = lv_field_txt_save.
        ENDIF.
        SHIFT ls_fieldlist-ref_field LEFT DELETING LEADING space.
      ENDIF.

      IF pv_write = abap_true.

        APPEND ls_fieldlist TO pt_fieldlist.

        CONCATENATE ',' ls_fieldlist-field INTO lv_struct_line.

        IF lv_select_table IS INITIAL.
          lv_struct_line_type = ls_fieldlist-ref_field.
        ELSEIF ls_fieldlist-field_type IS NOT INITIAL.
          lv_struct_line_type = ls_fieldlist-field_type .
        ELSE.
          CONCATENATE lv_select_table '-' ls_fieldlist-ref_field
                      INTO lv_struct_line_type.
        ENDIF.
        CONCATENATE lv_struct_line 'TYPE' lv_struct_line_type
                    INTO lv_struct_line
                    SEPARATED BY space.
        c1 lv_struct_line.
        lv_field_number = lv_field_number + 1.
      ENDIF.
    ENDIF.

  ENDLOOP.

  pv_newsyntax = lv_newsyntax.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_case_w
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_SPLIT_02
*&      <-- LT_FIELD_W
*&---------------------------------------------------------------------*
FORM generate_case_w  USING    pv_string
                               pt_table_w  TYPE tyt_table_w
                      CHANGING pt_field_w  TYPE tyt_field_w.


  DATA: lt_table_alias TYPE tyt_table_alias,
        ls_fieldlist   TYPE tys_fieldlist,
        lv_type        TYPE string.
  PERFORM change_case_type USING pv_string lt_table_alias CHANGING lv_type ls_fieldlist.

  APPEND ls_fieldlist TO pt_field_w.

ENDFORM.
*&---------------------------------------------------------------------*
*& FORM GENERATE_AGG_FUNC_W
*&---------------------------------------------------------------------*
*& TEXT
*&---------------------------------------------------------------------*
*&      --> LV_SPLIT_02
*&      <-- LT_FIELD_W
*&---------------------------------------------------------------------*
FORM generate_agg_func_w  USING    pv_string
                                   pt_table_alias  TYPE tyt_table_alias
                          CHANGING ps_field_w      TYPE tys_fieldlist.

  DATA: lv_string  TYPE string,
        lv_alias   TYPE string,
        lv_rest    TYPE string,
        lv_fun     TYPE string,
        lv_operand TYPE string,
        lv_char    TYPE string,
        lv_char5   TYPE char5,
        lv_pos     TYPE i,
        lv_depth   TYPE i VALUE 0,
        lv_in_q    TYPE abap_bool VALUE abap_false,
        lv_start   TYPE i,
        lv_i       TYPE i,
        lv_j       TYPE i,
        lv_ii      TYPE i,
        lv_len     TYPE i.

  STATICS: lt_cand TYPE STANDARD TABLE OF string WITH EMPTY KEY,
           lt_skip TYPE STANDARD TABLE OF string WITH EMPTY KEY.

  "------------------------------------------------------------
  " 0) 전처리: 대문자/공백
  "------------------------------------------------------------
  lv_string = to_upper( pv_string ).
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_string WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_string WITH space.
  CONDENSE lv_string. " (NO-GAPS 금지)

  "------------------------------------------------------------
  " 1) 별칭 찾기: 괄호/따옴표 외부(depth=0)에서 마지막 ' AS ' 위치
  "------------------------------------------------------------
  DATA: lv_off_as TYPE i VALUE -1,
        lv_as_len TYPE i,
        lv_after  TYPE i,
        lv_k      TYPE i VALUE 0.
  DATA prev TYPE c LENGTH 1.
  DATA next TYPE c LENGTH 1.

  CLEAR: lv_in_q, lv_depth.

  WHILE lv_k < strlen( lv_string ).
    lv_char = lv_string+lv_k(1).

    " 따옴표 토글('' 이스케이프)
    IF lv_char = ''''.
      lv_ii = lv_k + 1.
      IF lv_in_q = abap_true
         AND lv_k + 1 < strlen( lv_string )
         AND lv_string+lv_ii(1) = ''''.
        lv_k = lv_k + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_k = lv_k + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      " 괄호 깊이
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_k = lv_k + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_k = lv_k + 1. CONTINUE.
      ENDIF.

      IF lv_depth = 0 AND ( lv_k + 1 ) < strlen( lv_string ).

        " (1) 정확히 ' AS ' (앞/뒤 공백)
        IF ( lv_k + 3 ) < strlen( lv_string ) AND lv_string+lv_k(4) = ' AS '.
          lv_off_as = lv_k.
          lv_as_len = 4.

          " (2) ' AS' + (끝/구분자)  ex) ') AS"CNT"', ') AS,'
        ELSEIF ( lv_k + 2 ) < strlen( lv_string ) AND lv_string+lv_k(3) = ' AS'.
          lv_after = lv_k + 3.
          IF lv_after >= strlen( lv_string )
          OR lv_string+lv_after(1) = space
          OR lv_string+lv_after(1) = ','
          OR lv_string+lv_after(1) = '"'.
            lv_off_as = lv_k.
            lv_as_len = 3.
          ENDIF.

          " (3) 'AS' 토큰(앞 공백 없음) ex) ')AS CNT', ')AS"CNT"'
        ELSEIF lv_string+lv_k(2) = 'AS'.
          " 앞/뒤 경계 확인
          lv_ii = lv_k - 1.
          prev = COND #( WHEN lv_k > 0 THEN lv_string+lv_ii(1) ELSE space ).
          lv_ii = lv_k + 2.
          next = COND #( WHEN ( lv_k + 2 ) < strlen( lv_string )
                                THEN lv_string+lv_ii(1)
                                ELSE space ).
          IF ( prev = space OR prev = ')' OR prev = ',' )
          AND ( next = space OR next = ',' OR next = '"' OR ( lv_k + 2 ) = strlen( lv_string ) ).
            lv_off_as = lv_k.
            lv_as_len = 2.
          ENDIF.
        ENDIF.

        " 같은 라인에 'AS'가 여러 개면 '마지막 AS'를 쓰고 싶다면 덮어쓰기 유지
        " (가장 마지막 것이 alias일 확률이 높음)
      ENDIF.
    ENDIF.

    lv_k = lv_k + 1.
  ENDWHILE.

  " --- 별칭 추출 ---
  PERFORM get_as_end_alias USING lv_string CHANGING lv_alias.

  IF ps_field_w-field_txt IS INITIAL AND lv_alias IS NOT INITIAL.
    ps_field_w-field_txt = lv_alias.
  ENDIF.

  IF ps_field_w-field IS INITIAL AND lv_alias IS NOT INITIAL.
    ps_field_w-field = lv_alias.
  ENDIF.

  " 별칭 제외한 본문(이후 모든 탐지는 여기서 수행)
  DATA(lv_stmt_wo_alias) = COND string( WHEN lv_off_as >= 0 THEN lv_string(lv_off_as)
                                        ELSE lv_string ).

  "------------------------------------------------------------
  " 2) 집계함수/산술식 판별
  "------------------------------------------------------------
  IF lt_cand IS INITIAL.
    lt_cand = VALUE #( ( |SUM| ) ( |MAX| ) ( |MIN| ) ( |AVG| ) ( |COALESCE| ) ( |COUNT| ) ).
  ENDIF.

  DATA: lv_best_fun TYPE string VALUE '',
        lv_best_off TYPE i      VALUE 0,
        lv_off      TYPE i.

  lv_best_off = strlen( lv_stmt_wo_alias ) + 1.   " 센티넬

  LOOP AT lt_cand INTO DATA(lv_cand).
    DATA(lv_rx) = |{ lv_cand }[[:space:]]*\\(|.  " ex) SUM[ ]*\(
    FIND REGEX lv_rx IN lv_stmt_wo_alias MATCH OFFSET lv_off ##REGEX_POSIX.
    IF sy-subrc = 0 AND lv_off < lv_best_off.
      lv_best_off = lv_off.
      lv_best_fun = lv_cand.
      IF lv_off = 0. EXIT. ENDIF.
    ENDIF.
  ENDLOOP.

  IF lv_best_fun IS INITIAL.
    lv_best_fun = 'SUM'.
  ENDIF.

  lv_fun = lv_best_fun.
  CHECK lv_fun IS NOT INITIAL.

  "------------------------------------------------------------
  " 3) 피연산자 추출
  "   - 집계함수인 경우: 함수 뒤 괄호의 내용
  "   - 폴백 SUM인 경우: 별칭 제외한 전체 식을 그대로 사용
  "------------------------------------------------------------
  IF lv_best_off <= strlen( lv_stmt_wo_alias ).
    " 함수 케이스: 함수명 뒤 '(' 의 짝이 맞는 ')' 까지
    DATA(lv_p) = lv_best_off.
    WHILE lv_p < strlen( lv_stmt_wo_alias ) AND lv_stmt_wo_alias+lv_p(1) <> '('.
      lv_p = lv_p + 1.
    ENDWHILE.
    IF lv_p >= strlen( lv_stmt_wo_alias ).
      CLEAR: lv_fun. RETURN.
    ENDIF.

    lv_i     = lv_p + 1. " after '('
    lv_start = lv_i.
    CLEAR: lv_in_q. lv_depth = 1.

    WHILE lv_i < strlen( lv_stmt_wo_alias ).
      lv_char = lv_stmt_wo_alias+lv_i(1).
      lv_ii   = lv_i + 1.

      IF lv_char = ''''.
        IF lv_in_q = abap_true AND lv_ii < strlen( lv_stmt_wo_alias ) AND lv_stmt_wo_alias+lv_ii(1) = ''''.
          lv_i = lv_i + 2. CONTINUE.
        ELSE.
          lv_in_q = xsdbool( lv_in_q = abap_false ).
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.
      ENDIF.

      IF lv_in_q = abap_false.
        IF lv_char = '('.
          lv_depth = lv_depth + 1.
        ELSEIF lv_char = ')'.
          lv_depth = lv_depth - 1.
          IF lv_depth = 0. EXIT. ENDIF.
        ENDIF.
      ENDIF.

      lv_i = lv_i + 1.
    ENDWHILE.

    lv_len     = lv_i - lv_start.
    lv_operand = lv_stmt_wo_alias+lv_start(lv_len).
    SHIFT lv_operand LEFT  DELETING LEADING  space.
    SHIFT lv_operand RIGHT DELETING TRAILING space.

    IF lv_operand CP 'DISTINCT*'.
      lv_operand = lv_operand+8.
      SHIFT lv_operand LEFT DELETING LEADING space.
    ENDIF.
  ELSE.
    " 폴백 SUM: 별칭 제외한 식 전체를 피연산자로
    lv_operand = lv_stmt_wo_alias.
  ENDIF.

  " COALESCE인 경우: 첫 인자만 남김
  IF lv_fun = 'COALESCE'.
    lv_i = 0. lv_depth = 0. lv_in_q = abap_false.
    WHILE lv_i < strlen( lv_operand ).
      lv_char = lv_operand+lv_i(1). lv_ii = lv_i + 1.
      IF lv_char = ''''.
        IF lv_in_q = abap_true AND lv_ii < strlen( lv_operand ) AND lv_operand+lv_ii(1) = ''''.
          lv_i = lv_i + 2. CONTINUE.
        ELSE.
          lv_in_q = xsdbool( lv_in_q = abap_false ).
          lv_i = lv_i + 1. CONTINUE.
        ENDIF.
      ENDIF.
      IF lv_in_q = abap_false.
        IF lv_char = '('.
          lv_depth = lv_depth + 1.
        ELSEIF lv_char = ')'.
          lv_depth = lv_depth - 1.
        ELSEIF lv_char = ',' AND lv_depth = 0.
          EXIT.
        ENDIF.
      ENDIF.
      lv_i = lv_i + 1.
    ENDWHILE.
    lv_rest = lv_operand+0(lv_i).
    SHIFT lv_rest LEFT  DELETING LEADING  space.
    SHIFT lv_rest RIGHT DELETING TRAILING space.
    lv_operand = lv_rest.
  ENDIF.

  "------------------------------------------------------------
  " 4) 원천 매핑 (a~field 우선)
  "------------------------------------------------------------
  DATA: lv_a TYPE string, lv_f TYPE string.

  DATA(lv_norm) = lv_operand.
  CONDENSE lv_norm NO-GAPS. " (tilde는 유지, 공백만 제거)

  FIND '~' IN lv_norm.
  IF sy-subrc = 0.
    SPLIT lv_norm AT '~' INTO lv_a lv_f.
    FIND REGEX '(^[A-Z0-9_\$]+)' IN lv_f SUBMATCHES lv_f ##REGEX_POSIX.
    ps_field_w-ref_table = lv_a.
    ps_field_w-ref_field = lv_f.
  ELSE.
    ps_field_w-ref_table = '*'.
  ENDIF.

  " field 토큰만 있는 경우(보수적 폴백) — 기존 블록 간소화
  DATA: lv_id      TYPE string,
        ls_field_x TYPE tys_fieldlist,
        lv_stringx TYPE string,
        lt_stringx TYPE STANDARD TABLE OF string WITH EMPTY KEY.

  CONDENSE lv_operand.
  IF strlen( lv_operand ) > 5 AND lv_operand+0(4) = 'CAST'.
    PERFORM split_sql_cast USING lv_operand CHANGING ls_field_x.
  ELSE.
    CLEAR: ls_field_x.

    lv_stringx = lv_operand.
    REPLACE ALL OCCURRENCES OF '(' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF ')' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF ',' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '+' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '-' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '*' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '/' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '=' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '<' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '>' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '"' IN lv_stringx WITH space.
    REPLACE ALL OCCURRENCES OF '.' IN lv_stringx WITH space.
    CONDENSE lv_stringx.
    SPLIT lv_stringx AT space INTO TABLE lt_stringx.

    IF lt_skip IS INITIAL.
      lt_skip = VALUE #(
        ( |CASE| ) ( |WHEN| ) ( |THEN| ) ( |ELSE| ) ( |END| )
        ( |COALESCE| ) ( |NULL| ) ( |DISTINCT| ) ( |GROUPING| )
        ( |SUM| ) ( |MAX| ) ( |MIN| ) ( |AVG| ) ( |COUNT| )
        ( |AS| ) ( |OVER| ) ( |PARTITION| ) ( |ORDER| ) ( |BY| ) ).
    ENDIF.

    IF ps_field_w-ref_field IS INITIAL.
      LOOP AT lt_stringx INTO DATA(lv_ok).
        IF lv_ok IS INITIAL. CONTINUE. ENDIF.
        IF lv_ok CP '''*''' OR lv_ok CP '@*' OR lv_ok CO '0123456789'. CONTINUE. ENDIF.
        READ TABLE lt_skip WITH KEY table_line = lv_ok TRANSPORTING NO FIELDS.
        IF sy-subrc = 0. CONTINUE. ENDIF.
        FIND REGEX '(^[A-Z0-9_\$]+)' IN lv_ok SUBMATCHES lv_id ##REGEX_POSIX.
        IF lv_id IS NOT INITIAL.
          ps_field_w-ref_field = lv_id.
          EXIT.
        ENDIF.
      ENDLOOP.
    ENDIF.

    " alias → 실테이블 매핑
    REPLACE ALL OCCURRENCES OF '(' IN ps_field_w-ref_table WITH ''.
    CONDENSE ps_field_w-ref_table NO-GAPS.
    READ TABLE pt_table_alias INTO DATA(ls_table_alias) WITH KEY alias = ps_field_w-ref_table.
    IF sy-subrc = 0.
      ps_field_w-ref_table = ls_table_alias-table.
    ENDIF.

    " alias 또는 '*'만 남은 경우 정리
    IF ps_field_w-ref_table = '*' AND ( ps_field_w-ref_field = '*' OR ps_field_w-ref_field = space ).
      CLEAR: ps_field_w-ref_table, ps_field_w-ref_field.
    ENDIF.
  ENDIF.
  "------------------------------------------------------------
  " 5) 타입 결정 (DDIC 조회 + 함수 규칙)
  "------------------------------------------------------------
  DATA: lv_type    TYPE string,
        lv_inttype TYPE c.

  IF ps_field_w-ref_table IS NOT INITIAL AND ps_field_w-ref_field IS NOT INITIAL.
    DATA: lt_dfies            TYPE STANDARD TABLE OF dfies,
          lv_tabname          TYPE ddobjname,
          lv_fieldname        TYPE dfies-fieldname,
          ls_field_w          TYPE tys_fieldlist,
          lv_select_field_txt TYPE string.

    ls_field_w-ref_table = ps_field_w-ref_table.
    ls_field_w-ref_field = ps_field_w-ref_field.

    IF ps_field_w-ref_table+0(1) = '*'.
      READ TABLE pt_table_alias INTO ls_table_alias WITH KEY alias = ps_field_w-ref_table.
      IF sy-subrc = 0. ls_field_w-ref_table = ls_table_alias-table. ENDIF.
    ENDIF.

    PERFORM get_fieldname_from_cte CHANGING ls_field_w lv_select_field_txt.

    lv_tabname   = ps_field_w-ref_table = ls_field_w-ref_table.
    lv_fieldname = ps_field_w-ref_field = ls_field_w-ref_field.

    CLEAR lt_dfies.
    lt_dfies = lcl_toad_util=>get_dfies_buffered(
                 iv_tabname   = lv_tabname
                 iv_fieldname = lv_fieldname
                 iv_all_types = abap_true ).

    CLEAR lv_inttype.
    READ TABLE lt_dfies INTO DATA(ls_dfies) INDEX 1.
    IF sy-subrc = 0.
      lv_inttype = ls_dfies-inttype.
    ENDIF.
  ENDIF.

  CASE lv_fun.
    WHEN 'SUM' OR 'AVG'.
      IF ls_field_x-field_type IS INITIAL.
        lv_type = 'BAPITKGXXX_31'.     " P(31,8) 등 프로젝트 표준 타입
      ELSE.
        lv_type = ls_field_x-field_type.
      ENDIF.

    WHEN 'COUNT'.
      lv_type = 'INT8'.
      CLEAR: ps_field_w-ref_field, ps_field_w-ref_table.

    WHEN 'MAX' OR 'MIN' OR 'COALESCE'.
      CASE lv_inttype.
        WHEN 'C' OR 'N'.
          lv_type = 'STRING'.
        WHEN 'P'.
          lv_type = 'BAPITKGXXX_31'.
        WHEN 'I'.
          lv_type = 'INT4'.
        WHEN 'D'.
          lv_type = 'DATS'.
        WHEN 'T'.
          lv_type = 'TIMS'.
        WHEN OTHERS.
          lv_type = 'STRING'.
      ENDCASE.

    WHEN OTHERS.
      lv_type = 'STRING'.
  ENDCASE.

  ps_field_w-field_type = lv_type.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form change_case_type
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_STRING
*&      <-- LV_TYPE
*&---------------------------------------------------------------------*
FORM change_case_type  USING    pv_string       TYPE string
                                pt_table_alias  TYPE tyt_table_alias
                       CHANGING pv_type         TYPE string
                                ps_fieldlist    TYPE tys_fieldlist.

  DATA: lv_string       TYPE string,
        lv_after_end    TYPE string,
        lv_rest         TYPE string,
        lv_alias        TYPE string,
        lv_pos_as       TYPE i,
        lv_i            TYPE i,
        lv_ii           TYPE i,
        lv_j            TYPE i VALUE 0,
        lv_depth        TYPE i VALUE 0,
        lv_pos_then     TYPE i VALUE -1,
        lv_pos_then_end TYPE i VALUE -1,
        lv_pos_else     TYPE i VALUE -1,
        lv_pos_term     TYPE i,
        lv_char         TYPE string,
        lv_len_then     TYPE i,
        lv_cv_then      TYPE string,
        lv_cv_else      TYPE string,
        lv_a            TYPE string,
        lv_f            TYPE string,
        lv_dummy        TYPE string,
        lv_in_q         TYPE abap_bool VALUE abap_false.

  DATA: lt_match TYPE match_result_tab,
        ls_last  TYPE match_result.

  lv_string = to_upper( pv_string ).
  CONDENSE lv_string.

  "------------------------------------------------------------
  " 1) 별칭 추출: 문장 내 마지막 ' AS '만 사용 (CAST 내부 AS는 무시)
  "------------------------------------------------------------
  CLEAR: lt_match, ls_last, lv_alias.
  PERFORM get_as_end_alias USING lv_string CHANGING lv_alias.
*****  FIND ALL OCCURRENCES OF ' AS ' IN lv_string RESULTS lt_match.
*****  IF lt_match IS NOT INITIAL.
*****    READ TABLE lt_match INDEX lines( lt_match ) INTO ls_last.
*****    IF sy-subrc = 0 AND ls_last-length > 0.
*****      lv_ii = ls_last-offset + ls_last-length.    " ' AS ' 바로 뒤
*****      lv_rest = lv_string+lv_ii.                   " alias + 뒤쪽
*****      SHIFT lv_rest LEFT  DELETING LEADING space.
*****      SHIFT lv_rest RIGHT DELETING TRAILING space.
*****
*****      lv_j = 0.
*****      WHILE lv_j < strlen( lv_rest )
*****         AND lv_rest+lv_j(1) <> ','
*****         AND lv_rest+lv_j(1) <> space.
*****        lv_j = lv_j + 1.
*****      ENDWHILE.
*****      lv_alias = lv_rest+0(lv_j).
*****    ENDIF.
*****  ENDIF.

  IF ps_fieldlist-field_txt IS INITIAL AND lv_alias IS NOT INITIAL.
    ps_fieldlist-field_txt = lv_alias.
  ENDIF.

  "------------------------------------------------------------
  " 2) GROUPING 가드:
  "    CASE ... GROUPING( col ) ... THEN '1' / '2' ... → 계산식 문자열로 고정
  "    - 원천 필드 추적 중단: ref_field/ref_table 비움
  "    - 타입: STRING (원하면 C(1)로 강제 가능)
  "    - 별칭이 있으면 field 에도 반영
  "------------------------------------------------------------
  IF lv_string CS 'CASE' AND lv_string CS 'GROUPING('.
    CLEAR: ps_fieldlist-ref_field,
           ps_fieldlist-ref_table.
    ps_fieldlist-field_type = 'STRING'.
    pv_type                 = 'STRING'.
    IF ps_fieldlist-field IS INITIAL AND lv_alias IS NOT INITIAL.
      ps_fieldlist-field = lv_alias.
    ENDIF.
    RETURN.
  ENDIF.

  "------------------------------------------------------------
  " 3) THEN / ELSE 표현식 안전 추출 (따옴표/괄호 깊이/키워드 고려)
  "------------------------------------------------------------
  WHILE lv_i < strlen( lv_string ).
    lv_char = lv_string+lv_i(1).
    lv_ii = lv_i + 1.

    " 따옴표 처리('' 이스케이프)
    IF lv_char = ''''.
      IF lv_in_q = abap_true AND lv_ii < strlen( lv_string ) AND
         lv_string+lv_ii(1) = ''''.
        lv_i = lv_i + 2.
        CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1.
        CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        lv_depth = lv_depth - 1. lv_i = lv_i + 1. CONTINUE.
      ENDIF.

      " 첫 THEN
      IF lv_pos_then < 0 AND ( lv_i + 5 ) <= strlen( lv_string ) AND
         lv_string+lv_i(5) = ' THEN' AND lv_depth = 0.
        lv_pos_then = lv_i + 5. " ' THEN' 다음
        WHILE lv_pos_then < strlen( lv_string ) AND lv_string+lv_pos_then(1) = space.
          lv_pos_then = lv_pos_then + 1.
        ENDWHILE.
        lv_i = lv_pos_then.
        CONTINUE.
      ENDIF.

      " THEN 끝 = 다음 WHEN/ELSE/END
      IF lv_pos_then >= 0 AND lv_pos_then_end < 0 AND lv_depth = 0.
        IF ( lv_i + 6 ) <= strlen( lv_string ) AND lv_string+lv_i(6) = ' WHEN '.
          lv_pos_then_end = lv_i.
        ELSEIF ( lv_i + 6 ) <= strlen( lv_string ) AND lv_string+lv_i(6) = ' ELSE '.
          lv_pos_then_end = lv_i.
          lv_pos_else     = lv_i + 6.
          WHILE lv_pos_else < strlen( lv_string ) AND lv_string+lv_pos_else(1) = space.
            lv_pos_else = lv_pos_else + 1.
          ENDWHILE.
        ELSEIF ( lv_i + 4 ) <= strlen( lv_string ) AND lv_string+lv_i(4) = ' END'.
          lv_pos_then_end = lv_i.
        ENDIF.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  IF lv_pos_then >= 0.
    lv_len_then = COND i( WHEN lv_pos_then_end > lv_pos_then THEN lv_pos_then_end - lv_pos_then
                                                             ELSE strlen( lv_string ) - lv_pos_then ).
    lv_cv_then = lv_string+lv_pos_then(lv_len_then).
    SHIFT lv_cv_then LEFT  DELETING LEADING  space.
    SHIFT lv_cv_then RIGHT DELETING TRAILING space.
  ENDIF.

  IF lv_pos_else > 0.
    " ELSE ~ END 까지
    lv_pos_term = strlen( lv_string ).
    FIND FIRST OCCURRENCE OF ' END' IN lv_string+lv_pos_else MATCH OFFSET DATA(lv_rel).
    IF sy-subrc = 0.
      lv_pos_term = lv_pos_else + lv_rel.
    ENDIF.
    lv_ii = lv_pos_term - lv_pos_else.
    lv_cv_else = lv_string+lv_pos_else(lv_ii).
    SHIFT lv_cv_else LEFT  DELETING LEADING space.
    SHIFT lv_cv_else RIGHT DELETING TRAILING space.
  ENDIF.

  "------------------------------------------------------------
  " 4) 출력 필드명 기본값
  "------------------------------------------------------------
  IF ps_fieldlist-field IS INITIAL.
    ps_fieldlist-field = COND string( WHEN lv_alias IS NOT INITIAL THEN lv_alias ELSE 'FIELD' ).
  ENDIF.

  "------------------------------------------------------------
  " 5) 원천 필드/테이블 추정 (THEN 우선, 없으면 ELSE)
  "------------------------------------------------------------
  DATA(lv_src) = lv_cv_then.
  IF lv_src IS INITIAL. lv_src = lv_cv_else. ENDIF.

  " 5-a) a~field 패턴 우선
  FIND '~' IN lv_src.
  IF sy-subrc = 0.
    SPLIT lv_src AT '~'   INTO lv_a lv_f.
    SPLIT lv_f   AT space INTO lv_f lv_dummy.

    " field 토큰만 남기기 (식별자 선두 토큰만)
    DATA(lv_id) = lv_f.
    FIND REGEX '^[A-Z0-9_\$]+' IN lv_id SUBMATCHES lv_id ##REGEX_POSIX.
    IF lv_id IS NOT INITIAL.
      lv_f = lv_id.
    ENDIF.

    ps_fieldlist-ref_table = lv_a.
    ps_fieldlist-ref_field = lv_f.

    READ TABLE pt_table_alias INTO DATA(ls_alias) WITH KEY alias = ps_fieldlist-ref_table.
    IF sy-subrc = 0.
      IF ls_alias-table+0(1) = '+'.
        DATA: ls_field_w          TYPE tys_fieldlist,
              lv_select_field_txt TYPE string.
        ls_field_w-ref_table = ls_alias-table.
        ls_field_w-ref_field = ps_fieldlist-ref_field.
        PERFORM get_fieldname_from_cte CHANGING ls_field_w lv_select_field_txt.
        ps_fieldlist-ref_table = ls_field_w-ref_table.
        ps_fieldlist-ref_field = ls_field_w-ref_field.

      ELSE.
        ps_fieldlist-ref_table = ls_alias-table.
      ENDIF.
    ENDIF.

  ELSE.
    " 5-b) a~ 없음 → 식에서 첫 컬럼 토큰 추출
    DATA(lv_s) = lv_src.
    REPLACE ALL OCCURRENCES OF '(' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF ')' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF ',' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '+' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '-' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '*' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '/' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '=' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '<' IN lv_s WITH space.
    REPLACE ALL OCCURRENCES OF '>' IN lv_s WITH space.
    CONDENSE lv_s.

    DATA lt_tok TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    SPLIT lv_s AT space INTO TABLE lt_tok.

    DATA: lt_skip TYPE STANDARD TABLE OF string WITH EMPTY KEY.
    APPEND 'CASE'     TO lt_skip.
    APPEND 'WHEN'     TO lt_skip.
    APPEND 'THEN'     TO lt_skip.
    APPEND 'ELSE'     TO lt_skip.
    APPEND 'END'      TO lt_skip.
    APPEND 'COALESCE' TO lt_skip.
    APPEND 'NULL'     TO lt_skip.
    APPEND 'GROUPING' TO lt_skip.

    LOOP AT lt_tok INTO DATA(lv_t).
      IF lv_t IS INITIAL. CONTINUE. ENDIF.
      " 리터럴/호스트/숫자 skip
      IF lv_t CP '''*''' OR lv_t CP '@*' OR lv_t CO '0123456789'. CONTINUE. ENDIF.
      READ TABLE lt_skip WITH KEY table_line = lv_t TRANSPORTING NO FIELDS.
      IF sy-subrc = 0. CONTINUE. ENDIF.

      ps_fieldlist-ref_field = lv_t.
      EXIT.
    ENDLOOP.

    " alias='*' 있으면 테이블 매핑
    IF ps_fieldlist-ref_table IS INITIAL.
      READ TABLE pt_table_alias INTO ls_alias WITH KEY alias = '*'.
      IF sy-subrc = 0.
        ps_fieldlist-ref_table = ls_alias-table.
      ENDIF.
    ENDIF.
  ENDIF.

  "------------------------------------------------------------
  " 6) 타입 추정 (기본 STRING, 일부 패턴만 덮어씀)
  "------------------------------------------------------------
  DATA(lv_type) = 'STRING'.

  " 아이콘 호스트 변수
  IF lv_cv_then CP '@ICON*' OR lv_cv_else CP '@ICON*'.
    lv_type = 'ICON_D'.
  ENDIF.

  " 집계: COUNT → I, 수식/합계 → 임의 DEC 타입
  IF lv_cv_then CS 'COUNT(' OR lv_cv_else CS 'COUNT('.
    lv_type = 'I'.
  ELSEIF lv_cv_then CS 'SUM(' OR lv_cv_else CS 'SUM(' OR
         lv_cv_then CS '+'    OR lv_cv_then CS '-'    OR
         lv_cv_then CS '*'    OR lv_cv_then CS '/'    OR
         lv_cv_else CS '+'    OR lv_cv_else CS '-'    OR
         lv_cv_else CS '*'    OR lv_cv_else CS '/'.
    lv_type = 'BAPITKGXXX_31'.
  ENDIF.

  " 리터럴 단일문자 패턴: ' ' / 'X'
  IF lv_type = 'STRING'.
    IF     lv_cv_then CP '''?''' AND ( lv_cv_else IS INITIAL OR lv_cv_else CP '''?''' ).
      lv_type = 'C(1)'.
    ELSEIF lv_cv_else CP '''?''' AND lv_cv_then IS INITIAL.
      lv_type = 'C(1)'.
    ENDIF.
  ENDIF.

  pv_type = lv_type.
  ps_fieldlist-field_type = lv_type.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_fieldinfo
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LS_FIELDLIST
*&      <-- LS_FIELDCAT
*&---------------------------------------------------------------------*
FORM get_fieldinfo  USING    ps_fieldlist  TYPE tys_fieldlist
                    CHANGING ps_fieldcat   TYPE lvc_s_fcat.

  DATA: lv_tabname   TYPE ddobjname,
        lv_fieldname TYPE dfies-fieldname,
        ls_dfies     TYPE dfies,
        lt_dfies     TYPE TABLE OF dfies.

  lv_tabname   = ps_fieldlist-ref_table.
  lv_fieldname = ps_fieldlist-ref_field.

  CLEAR lt_dfies.
  lt_dfies = lcl_toad_util=>get_dfies_buffered(
               iv_tabname   = lv_tabname
               iv_fieldname = lv_fieldname ).

  IF lt_dfies IS INITIAL.
    ps_fieldcat-coltext   = ps_fieldlist-ref_field.
    ps_fieldcat-reptext   = ps_fieldlist-ref_field.
    ps_fieldcat-scrtext_s = ps_fieldlist-ref_field.
    ps_fieldcat-scrtext_m = ps_fieldlist-ref_field.
    ps_fieldcat-scrtext_l = ps_fieldlist-ref_field.
    EXIT.
  ENDIF.

  READ TABLE lt_dfies INTO ls_dfies INDEX 1.
  CHECK sy-subrc = 0.

  ps_fieldcat-coltext   = ls_dfies-fieldtext.
  ps_fieldcat-reptext   = ls_dfies-reptext.
  ps_fieldcat-scrtext_s = ls_dfies-scrtext_s.
  ps_fieldcat-scrtext_m = ls_dfies-scrtext_m.
  ps_fieldcat-scrtext_l = ls_dfies-scrtext_l.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_cast
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_CURRENT_LINE
*&      --> LV_NEWSYNTAX
*&      --> PV_WRITE
*&      <-- PT_SPLIT
*&      <-- LV_STRING
*&      <-- LV_FIELD_NUMBER
*&      <-- LS_FIELDLIST
*&      <-- PT_FIELDLIST
*&      <-- PT_CODE_STRING
*&      <-- PT_TABLE_ALIAS
*&---------------------------------------------------------------------*
FORM generate_cast   USING    pv_current_line TYPE i
                              pv_newsyntax pv_write
                     CHANGING pt_split        TYPE tyt_string
                              pv_string
                              pv_field_number
                              ps_fieldlist    TYPE tys_fieldlist
                              pt_fieldlist    TYPE tyt_fieldlist
                              pt_code_string  TYPE tyt_string
                              pt_table_alias  TYPE tyt_table_alias.

  DATA: lv_strlen_string TYPE string,
        lv_struct_line   TYPE string.

  CHECK pv_write = abap_true.
  CHECK pv_newsyntax = abap_true.

  CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.

  DATA: ls_field_w TYPE tys_fieldlist.
  PERFORM split_sql_cast USING pv_string CHANGING ls_field_w.

  ps_fieldlist-field_txt  = ls_field_w-field_txt.
  ps_fieldlist-field_type = ls_field_w-field_type.
  CONCATENATE lv_struct_line 'TYPE' ps_fieldlist-field_type "#EC NOTEXT
              INTO lv_struct_line SEPARATED BY space.

  c1 lv_struct_line.

  APPEND ps_fieldlist TO pt_fieldlist.
  pv_field_number = pv_field_number + 1.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_cast_w
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_SPLIT_02
*&      --> PT_TABLE_W
*&      <-- LT_FIELD_W
*&---------------------------------------------------------------------*
FORM generate_cast_w  USING    pv_string
                               pt_table_w  TYPE tyt_table_w
                      CHANGING pt_field_w  TYPE tyt_field_w.


  DATA: ls_field_w     TYPE tys_fieldlist.

  PERFORM split_sql_cast USING pv_string CHANGING ls_field_w.

  APPEND ls_field_w TO pt_field_w.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_concat_w
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_SPLIT_02
*&      --> PT_TABLE_W
*&      <-- LT_FIELD_W
*&---------------------------------------------------------------------*
FORM generate_concat_w  USING    pv_string
                        CHANGING pt_field_w  TYPE tyt_field_w.

  DATA: lv_type    TYPE string,
        lv_host_up TYPE char20,
        lv_alias   TYPE string,
        ls_field_w TYPE tys_fieldlist.

  PERFORM get_as_end_alias USING pv_string CHANGING lv_alias.

  SPLIT pv_string AT space INTO lv_host_up lv_type.

  " type 매핑
  PERFORM decision_type USING lv_host_up CHANGING lv_type.


  CLEAR: ls_field_w.
  ls_field_w-field      = lv_alias.
  ls_field_w-field_txt  = lv_alias.
  ls_field_w-field_type = lv_type.

  APPEND ls_field_w TO pt_field_w.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form generate_concat
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_CURRENT_LINE
*&      --> LV_NEWSYNTAX
*&      --> PV_WRITE
*&      <-- PT_SPLIT
*&      <-- LV_STRING
*&      <-- LV_FIELD_NUMBER
*&      <-- LS_FIELDLIST
*&      <-- PT_FIELDLIST
*&      <-- PT_CODE_STRING
*&      <-- PT_TABLE_ALIAS
*&---------------------------------------------------------------------*
FORM generate_concat   USING    pv_current_line TYPE i
                                pv_newsyntax pv_write
                       CHANGING pt_split        TYPE tyt_string
                                pv_string
                                pv_field_number
                                ps_fieldlist    TYPE tys_fieldlist
                                pt_fieldlist    TYPE tyt_fieldlist
                                pt_code_string  TYPE tyt_string
                                pt_table_alias  TYPE tyt_table_alias.

  DATA: lv_strlen_string TYPE string,
        lv_struct_line   TYPE string.

  CHECK pv_write = abap_true.
  CHECK pv_newsyntax = abap_true.

  CONCATENATE 'F' pv_field_number    INTO ps_fieldlist-field.
  CONCATENATE ',' ps_fieldlist-field INTO lv_struct_line.

  DATA: lv_type    TYPE string,
        lv_host_up TYPE char20,
        lv_alias   TYPE string.

  PERFORM get_as_end_alias USING pv_string CHANGING lv_alias.

  SPLIT pv_string AT space INTO lv_host_up lv_type.

  " type 매핑
  PERFORM decision_type USING lv_host_up CHANGING lv_type.

  ps_fieldlist-field_txt  = lv_alias.
  ps_fieldlist-field_type = lv_type.

  CONCATENATE lv_struct_line 'TYPE' ps_fieldlist-field_type "#EC NOTEXT
              INTO lv_struct_line SEPARATED BY space.

  c1 lv_struct_line.

  APPEND ps_fieldlist TO pt_fieldlist.
  pv_field_number = pv_field_number + 1.

ENDFORM.
*--------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form join_syntax_concat
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_INDEX
*&      <-- LT_FIELD_L
*&---------------------------------------------------------------------*
FORM join_syntax_concat  USING    pv_index
                         CHANGING pt_split TYPE tyt_string.

  DATA: lv_next_index TYPE i,
        lv_dummy      TYPE string,
        lv_string2    TYPE string.

  READ TABLE pt_split INTO lv_string2 INDEX pv_index.
  CHECK sy-subrc = 0.

  " 동일라인에 ' AS' 가 있는 경우
  FIND ' AS ' IN lv_string2 IGNORING CASE.
  CHECK sy-subrc NE 0.

  lv_next_index = pv_index + 1.
  DO .
    READ TABLE pt_split INTO lv_dummy INDEX lv_next_index.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.

    FIND ' AS ' IN lv_dummy IGNORING CASE.
    IF sy-subrc = 0.
      DATA(lv_exit_flag) = abap_true.
    ELSE.
      lv_exit_flag = abap_false.
    ENDIF.

    CONCATENATE lv_string2 ',' lv_dummy INTO lv_string2.
    MODIFY pt_split FROM lv_string2 INDEX pv_index.
    DELETE pt_split INDEX lv_next_index.

    IF lv_exit_flag = abap_true.
      EXIT.
    ENDIF.
  ENDDO.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_with_sql
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_WITH
*&      <-- LT_TABLE_LIST
*&---------------------------------------------------------------------*
FORM split_with_sql  USING    pv_with       TYPE string
                     CHANGING pt_table_list TYPE tyt_string.

  CLEAR: pt_table_list.

  DATA(lv_sql) = to_upper( pv_with ).

  " 0) 개행을 공백으로만 치환(따옴표 별칭/문자열 안 공백을 살리기 위해 NO-GAPS는 쓰지 않음)
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf IN lv_sql WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline IN lv_sql WITH space.
  CONDENSE lv_sql.

  " 1) WITH 시작 위치
  DATA(lv_up) = lv_sql.
  FIND FIRST OCCURRENCE OF 'WITH' IN lv_up MATCH OFFSET DATA(lv_with_off).
  IF sy-subrc <> 0.
    RETURN. " WITH 없으면 종료
  ENDIF.

  " 2) WITH 다음부터 CTE 리스트~SELECT 시작 전까지 범위를 잡기 위해 스캔
  DATA(lv_from) = lv_with_off + 4. " 'WITH' 뒤
  DATA(lv_len)  = strlen( lv_sql ).

  DATA: lv_in_string TYPE abap_bool VALUE abap_false,
        lv_depth     TYPE i VALUE 0,
        lv_i         TYPE i,
        lv_end_cte   TYPE i VALUE -1.

  lv_i = lv_from.
  WHILE lv_i < lv_len.
    DATA(lv_char) = lv_sql+lv_i(1).

    IF lv_in_string = abap_true.
      " 문자열 리터럴: '' 이스케이프 처리
      IF lv_char = ''''.
        " 다음도 ' 면 이스케이프 -> 건너뜀
        DATA(lv_ii) = lv_i + 1.
        IF lv_i + 1 < lv_len AND lv_sql+lv_ii(1) = ''''.
          lv_i = lv_i + 2.
          CONTINUE.
        ELSE.
          lv_in_string = abap_false.
        ENDIF.
      ENDIF.
      lv_i = lv_i + 1.
      CONTINUE.
    ENDIF.

    " 문자열 시작
    IF lv_char = ''''.
      lv_in_string = abap_true.
      lv_i = lv_i + 1.
      CONTINUE.
    ENDIF.

    " 괄호 깊이 추적
    IF lv_char = '('.
      lv_depth = lv_depth + 1.
      lv_i = lv_i + 1.
      CONTINUE.

    ELSEIF lv_char = ')'.
      IF lv_depth > 0.
        lv_depth = lv_depth - 1.
      ENDIF.
      lv_i = lv_i + 1.
      CONTINUE.
    ENDIF.

    " 깊이 0에서 SELECT 시작을 만나면 CTE 목록 종료
    IF lv_depth = 0 AND lv_i + 6 <= lv_len.
      DATA(lv_tok6) = lv_sql+lv_i(6).
      IF lv_tok6 = 'SELECT'.
        lv_end_cte = lv_i - 1.
        EXIT.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  IF lv_end_cte < 0.
    " SELECT가 없다면 WITH 뒤 전부를 CTE 목록으로 간주
    lv_end_cte = lv_len - 1.
  ENDIF.

  " 3) CTE 목록 추출
  DATA(lv_from_len) = lv_end_cte - lv_from + 1.
  DATA(lv_cte_list) = lv_sql+lv_from(lv_from_len).

  " 4) 최상위 콤마 기준 분리 (괄호 밖 콤마만 split)
  DATA: lv_buf       TYPE string,
        lv_cte_depth TYPE i VALUE 0.

  lv_in_string = abap_false.
  DO strlen( lv_cte_list ) TIMES.
    DATA(lv_idx) = sy-index - 1.
    lv_char = lv_cte_list+lv_idx(1).

    IF lv_in_string = abap_true.
      IF lv_char = ''''.
        lv_ii = lv_idx + 1.
        IF lv_idx + 1 < strlen( lv_cte_list ) AND lv_cte_list+lv_ii(1) = ''''.
          lv_buf = lv_buf && ''''.
          lv_idx = lv_idx + 1. " (주의: DO 루프라 idx 증가는 무의미, 그냥 추가만)

        ELSE.
          lv_in_string = abap_false.
        ENDIF.
      ENDIF.

      lv_buf = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    IF lv_char = ''''.
      lv_in_string = abap_true.
      lv_buf = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    IF lv_char = '('.
      lv_cte_depth = lv_cte_depth + 1.
      lv_buf = lv_buf && lv_char.
      CONTINUE.

    ELSEIF lv_char = ')'.
      IF lv_cte_depth > 0.
        lv_cte_depth = lv_cte_depth - 1.
      ENDIF.

      lv_buf = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    " 최상위 콤마 -> 하나의 CTE 완결
    IF lv_char = ',' AND lv_cte_depth = 0.
      DATA(lv_piece) = lv_buf.
      CONDENSE lv_piece.
      IF lv_piece IS NOT INITIAL.
        APPEND lv_piece TO pt_table_list.
      ENDIF.
      CLEAR lv_buf.
      CONTINUE.
    ENDIF.

    lv_buf = lv_buf && lv_char.
  ENDDO.

  " 마지막 버퍼 플러시
  DATA(lv_last) = lv_buf.
  CONDENSE lv_last.
  IF lv_last IS NOT INITIAL.
    APPEND lv_last TO pt_table_list.
  ENDIF.

  " 5) 앞/뒤 공백 정리 + 결과 반환
  LOOP AT pt_table_list ASSIGNING FIELD-SYMBOL(<ls_table_list>).
    SHIFT <ls_table_list> LEFT DELETING LEADING space.
    SHIFT <ls_table_list> RIGHT DELETING TRAILING space.
  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_sql_cast
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_STRING
*&      <-- LS_FIELD_W
*&---------------------------------------------------------------------*
FORM split_sql_cast  USING    pv_string  TYPE string
                     CHANGING ps_field_w TYPE tys_fieldlist.

  DATA: lv_sql   TYPE string,
        lv_alias TYPE string,
        lv_type  TYPE string,
        lv_len   TYPE string,
        lv_dec   TYPE string.

  lv_sql = to_upper( pv_string ).

  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf IN lv_sql WITH space.
*  CONDENSE lv_sql NO-GAPS.

  " alias 찾기
  PERFORM get_as_alias USING lv_sql CHANGING lv_alias lv_type lv_len lv_dec.
  IF lv_alias IS INITIAL.
    lv_alias = 'var'. " alias가 없으면 임시
  ENDIF.

  " 2) CAST(...) 내부의 AS <sql_type>(len,dec)? 추출
  "    패턴 설명:
  "    CAST\(.*?AS([A-Z0-9_]+)(?:\((\d+)(?:,(\d+))?\))?\)
  "    - 그룹1: 타입명  ex) DATS, INT4, DEC, DECIMAL, CHAR, VARCHAR, NVARCHAR, DATE, TIMESTAMP ...
  "    - 그룹2: 길이 p/문자 길이
  "    - 그룹3: 소수
  FIND REGEX 'CAST\([^)]*AS([A-Z0-9_]+)(?:\((\d+)(?:,(\d+))?\))?\)'
       IN lv_sql IGNORING CASE
       SUBMATCHES lv_type lv_len lv_dec ##REGEX_POSIX.

  IF lv_type IS INITIAL.
    RAISE EXCEPTION TYPE cx_sy_regex.
  ENDIF.

  CLEAR: ps_field_w.
  ps_field_w-field     = lv_alias.
  ps_field_w-field_txt = lv_alias.


  CASE lv_type.
    WHEN 'DATS' OR 'DATE'.
      ps_field_w-field_type = 'DATS'.

    WHEN 'TIME' OR 'TIMS'.
      ps_field_w-field_type = 'TIMS'.

    WHEN 'INT' OR 'INTEGER' OR 'INT4'.
      ps_field_w-field_type = 'INT4'.

    WHEN 'SMALLINT' OR 'INT2'.
      ps_field_w-field_type = 'INT2'.

    WHEN 'BIGINT' OR 'INT8'.
      ps_field_w-field_type = 'INT8'.

    WHEN 'DEC' OR 'DECIMAL' OR 'NUMERIC' OR 'PACKED'.
      DATA(lv_len_i) = COND i( WHEN lv_len IS INITIAL THEN 31 ELSE lv_len ).
      DATA(lv_dec_i) = COND i( WHEN lv_dec IS INITIAL THEN 0  ELSE lv_dec ).
      ps_field_w-field_type = |P LENGTH { lv_len_i } DECIMALS { lv_dec_i }|.

    WHEN 'CHAR' OR 'NCHAR'.
      ps_field_w-field_type = COND #( WHEN lv_len IS INITIAL THEN 'C LENGTH 1'
                                                             ELSE |C LENGTH { lv_len }| ).
    WHEN 'VARCHAR' OR 'NVARCHAR'.
      ps_field_w-field_type = 'STRING'.

    WHEN 'VARBINARY' OR 'BINARY'.
      ps_field_w-field_type = 'STRING'.

    WHEN 'TIMESTAMP' OR 'SECONDDATE'.
      ps_field_w-field_type = 'DECFLOAT34'.

    WHEN OTHERS.
      ps_field_w-field_type = 'STRING'.

  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_field_list_table
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- LT_SPLIT
*&---------------------------------------------------------------------*
FORM split_field_list_table    USING    pv_string TYPE string
                               CHANGING pt_split  TYPE tyt_string.

  DATA: lv_depth  TYPE i VALUE 0,
        lv_in_str TYPE abap_bool VALUE abap_false,
        lv_buf    TYPE string,
        out       TYPE tyt_string.

  DATA(lv_string) = to_upper( pv_string ).

  " 공백은 1칸으로만 축약(문자열 리터럴 내부는 그대로 유지)
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf   IN lv_string WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline IN lv_string WITH space.
  CONDENSE lv_string.

  REPLACE ALL OCCURRENCES OF '( SELECT ' IN lv_string WITH ''  IN CHARACTER MODE.

  CLEAR: pt_split.
  DO strlen( lv_string ) TIMES.
    DATA(lv_i) = sy-index - 1.
    DATA(lv_char) = lv_string+lv_i(1).

    IF lv_in_str = abap_true.
      IF lv_char = ''''.
        DATA(lv_ii) = lv_i + 1.
        IF lv_i + 1 < strlen( lv_string ) AND lv_string+lv_ii(1) = ''''.
          lv_buf = lv_buf && ''''.
          CONTINUE. " 다음 루프에서 같은 위치+1 처리됨
        ELSE.
          lv_in_str = abap_false.
        ENDIF.
      ENDIF.

      lv_buf = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    IF lv_char = ''''.
      lv_in_str = abap_true.
      lv_buf    = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    IF lv_char = '('.
      lv_depth = lv_depth + 1.
      lv_buf = lv_buf && lv_char.
      CONTINUE.

    ELSEIF lv_char = ')'.
      IF lv_depth > 0.
        lv_depth = lv_depth - 1.
      ENDIF.

      lv_buf = lv_buf && lv_char.
      CONTINUE.
    ENDIF.

    IF lv_char = ',' AND lv_depth = 0.
      DATA(lv_piece) = lv_buf.
      SHIFT lv_piece LEFT  DELETING LEADING space.
      SHIFT lv_piece RIGHT DELETING TRAILING space.
      IF lv_piece IS NOT INITIAL.
        APPEND lv_piece TO pt_split.
      ENDIF.

      CLEAR lv_buf.
      CONTINUE.
    ENDIF.

    lv_buf = lv_buf && lv_char.
  ENDDO.

  DATA(lv_last) = lv_buf.
  SHIFT lv_last LEFT  DELETING LEADING space.
  SHIFT lv_last RIGHT DELETING TRAILING space.
  IF lv_last IS NOT INITIAL.
    APPEND lv_last TO pt_split.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_fieldname_from_cte
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- LS_FIELD_W
*&      <-- LV_SELECT_FIELD_TXT
*&---------------------------------------------------------------------*
FORM get_fieldname_from_cte  CHANGING ps_field_w          TYPE tys_fieldlist
                                      pv_select_field_txt TYPE string.

  DATA: lv_select_field TYPE string,
        ls_field_w      TYPE tys_fieldlist,
        ls_table_w      TYPE tys_table_w.

  ls_field_w = ps_field_w.
  WHILE ps_field_w-ref_table IS NOT INITIAL AND ps_field_w-ref_table+0(1) = '+'.

    READ TABLE gt_table_w INTO ls_table_w WITH KEY tabname = ps_field_w-ref_table.
    IF sy-subrc NE 0. EXIT. ENDIF.

    lv_select_field = ps_field_w-ref_field.

    CLEAR: pv_select_field_txt.
    SPLIT lv_select_field AT ' AS ' INTO lv_select_field pv_select_field_txt.
    SHIFT pv_select_field_txt LEFT DELETING LEADING space.
    CONDENSE lv_select_field NO-GAPS.

    " CTE View 정보가 없는 경우 종료
    READ TABLE ls_table_w-field_list INTO ps_field_w WITH KEY field = lv_select_field.
    IF sy-subrc NE 0. EXIT. ENDIF.

    IF ps_field_w-ref_field IS INITIAL.  " type 으로 정의됨
      EXIT.
    ENDIF.

  ENDWHILE.

  " field text 와 field name 복원
  IF ls_field_w-field_txt IS NOT INITIAL.
    ps_field_w-field_txt = ls_field_w-field_txt.
  ENDIF.

  IF ls_field_w-field IS NOT INITIAL.
    ps_field_w-field =  ls_field_w-field.
  ENDIF.

  " ref table 과 field 가 있는 경우 type clear
  IF ps_field_w-ref_field IS NOT INITIAL AND
     ps_field_w-ref_table IS NOT INITIAL.
    CLEAR: ps_field_w-field_type.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_with_clause
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_QUERY
*&      <-- PV_WITH
*&      <-- LV_QUERY
*&---------------------------------------------------------------------*
FORM split_with_clause  USING    pv_query_org
                        CHANGING pv_with
                                 pv_query
                                 pv_flag.

  DATA: lv_src       TYPE string,        " 원문 복사본
        lv_up        TYPE string,        " 대문자판(길이 동일 유지)
        lv_cr        TYPE c LENGTH 1,
        lv_lf        TYPE c LENGTH 1,
        lv_tab       TYPE c LENGTH 1,
        lv_off_with  TYPE i VALUE -1,
        lv_i         TYPE i,
        lv_j         TYPE i,
        lv_k         TYPE i,
        lv_n         TYPE i,
        lv_len_head  TYPE i,
        lv_char      TYPE c LENGTH 1,
        lv_prev      TYPE c LENGTH 1,
        lv_next      TYPE c LENGTH 1,
        lv_off_after TYPE i,
        lv_depth     TYPE i VALUE 0,
        lv_in_q      TYPE abap_bool VALUE abap_false,
        split        TYPE i VALUE -1.

  CLEAR: pv_with, pv_query, pv_flag.

  " 0) 원문/대문자판 준비 (길이 동일 유지, CONDENSE 금지)
  lv_src = pv_query_org.
  lv_up  = to_upper( lv_src ).

  lv_cr  = cl_abap_char_utilities=>cr_lf+0(1).         " '\r'
  lv_lf  = cl_abap_char_utilities=>newline.            " '\n'
  lv_tab = cl_abap_char_utilities=>horizontal_tab.     " '\t'

  " 길이 보존: 각 제어문자를 '공백 1개'로만 치환
  REPLACE ALL OCCURRENCES OF lv_cr  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_lf  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_tab IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  " 1) WITH 토큰 수동 탐색 (경계 허용: 시작/공백/괄호/콤마/세미콜론, 다음은 공백/+/"/()
  lv_i = 0.
  WHILE lv_i + 3 < lv_n.
    lv_char = lv_up+lv_i(1).

    IF lv_char = 'W' AND lv_up+lv_i(4) = |WITH|.
      IF lv_i = 0.
        lv_prev = space.
      ELSE.
        DATA(off_p) = lv_i - 1.
        lv_prev = lv_up+off_p(1).
      ENDIF.

      lv_off_after = lv_i + 4.
      IF lv_off_after < lv_n.
        lv_next = lv_up+lv_off_after(1).
      ELSE.
        CLEAR lv_next.
      ENDIF.

      IF ( lv_prev = space OR lv_prev = '(' OR lv_prev = ',' OR lv_prev = ';' OR
           lv_prev = lv_tab OR lv_prev = lv_lf )
      AND ( lv_off_after = lv_n OR lv_next = space OR lv_next = '+' OR lv_next = '"' OR
            lv_next = '(' OR lv_next = lv_tab OR lv_next = lv_lf ).
        lv_off_with = lv_i.
        EXIT.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  IF lv_off_with < 0.
    " WITH 없음 → 분리 안 함
    pv_query = lv_src.
    pv_flag  = abap_false.
    RETURN.
  ENDIF.

  " 2) WITH 뒤 CTE 리스트 스캔: ) [,] ... SELECT 경계 찾기
  lv_i = lv_off_with + 4.
  lv_in_q  = abap_false.
  lv_depth = 0.

  WHILE lv_i < lv_n.
    lv_char = lv_up+lv_i(1).

    " 따옴표('' 이스케이프)
    IF lv_char = ''''.
      DATA(off_q) = lv_i + 1.
      IF lv_in_q = abap_true AND off_q < lv_n AND lv_up+off_q(1) = ''''.
        lv_i = lv_i + 2.
        CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1.
        CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      IF lv_char = '('.
        lv_depth = lv_depth + 1.
        lv_i = lv_i + 1.
        CONTINUE.

      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_i = lv_i + 1.

        IF lv_depth = 0.
          " 닫는 괄호 뒤 공백류 스킵 (space / TAB / LF / CR)
          lv_j = lv_i.
          WHILE lv_j < lv_n.
            DATA(lv_ws) = lv_up+lv_j(1).
            IF lv_ws = space OR lv_ws = lv_tab OR lv_ws = lv_lf OR lv_ws = lv_cr.
              lv_j = lv_j + 1.
            ELSE.
              EXIT.
            ENDIF.
          ENDWHILE.

          " 콤마면 CTE 연속
          IF lv_j < lv_n AND lv_up+lv_j(1) = ','.
            lv_i = lv_j + 1.
            CONTINUE.
          ENDIF.

          " Robust: 'S'까지 전진 후 SELECT 확인
          lv_k = lv_j.
          WHILE lv_k < lv_n.
            lv_char = lv_up+lv_k(1).
            IF lv_char = 'S'.
              EXIT.
            ENDIF.
            " 여분 공백/구분자/기타 문자 한 글자씩 넘김
            lv_k = lv_k + 1.
          ENDWHILE.

          IF lv_k + 5 < lv_n.
            DATA lv_len_sel TYPE i.
            lv_len_sel = 6.
            IF lv_up+lv_k(lv_len_sel) = |SELECT|.
              split = lv_k.
              EXIT.
            ENDIF.
          ENDIF.
        ENDIF.

        CONTINUE.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  " 3) 결과 슬라이스 (원문 오프셋 그대로 사용)
  IF split >= 0.
    lv_len_head = split.
    pv_with  = lv_src+0(lv_len_head).  " WITH ~ ) 직전까지 (원문 유지)
    pv_query = lv_src+split.           " SELECT ~ 이후 (원문 유지)
    pv_flag  = abap_true.
  ELSE.
    " WITH는 있으나 경계 실패 → 안전 폴백(원문 반환)
    pv_with  = lv_src.
    CLEAR pv_query.
    pv_flag  = abap_true.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_union_clause
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_QUERY
*&      <-- LV_QUERY
*&      <-- PV_UNION
*&---------------------------------------------------------------------*
FORM split_union_clause  USING    pv_query
                         CHANGING pv_first
                                  pv_second.

  DATA: lv_src       TYPE string,          " 원문
        lv_up        TYPE string,          " 대문자판(길이 동일 유지)
        lv_cr        TYPE c LENGTH 1,
        lv_lf        TYPE c LENGTH 1,
        lv_tab       TYPE c LENGTH 1,
        lv_n         TYPE i,
        lv_i         TYPE i,
        lv_j         TYPE i,
        lv_k         TYPE i,
        lv_off_ba    TYPE i,
        lv_ch_ba     TYPE c,
        lv_off_bd    TYPE i,
        lv_ch_bd     TYPE c,
        lv_char      TYPE c LENGTH 1,
        lv_prev      TYPE c LENGTH 1,
        lv_next      TYPE c LENGTH 1,
        lv_off_prev  TYPE i,
        lv_off_after TYPE i,
        lv_depth     TYPE i VALUE 0,
        lv_in_q      TYPE abap_bool VALUE abap_false.

  DATA: lv_off_union    TYPE i VALUE -1,  " 'U' of UNION 위치
        lv_end_union    TYPE i,           " UNION(+ALL/DISTINCT) 끝 다음 위치
        lv_start_select TYPE i VALUE -1,  " 다음 SELECT 시작 위치
        lv_len_head     TYPE i,
        lv_kind         TYPE string.

  CLEAR: pv_first, pv_second.

  " 0) 원문/대문자판 준비 (길이 보존, CONDENSE 금지)
  lv_src = pv_query.
  lv_up  = to_upper( lv_src ).
  CONDENSE lv_up.

  lv_cr  = cl_abap_char_utilities=>cr_lf+0(1).         " '\r'
  lv_lf  = cl_abap_char_utilities=>newline.            " '\n'
  lv_tab = cl_abap_char_utilities=>horizontal_tab.     " '\t'

  " 길이 보존: 제어문자 → space (각각)
  REPLACE ALL OCCURRENCES OF lv_cr  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_lf  IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF lv_tab IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  " 1) 첫 번째 TOP-LEVEL UNION 탐색
  lv_i   = 0.
  lv_depth  = 0.
  lv_in_q   = abap_false.

  WHILE lv_i < lv_n.
    lv_char = lv_up+lv_i(1).

    " 따옴표('' 이스케이프)
    DATA(off_nxt) = lv_i + 1.
    IF lv_char = ''''.
      IF lv_in_q = abap_true AND off_nxt < lv_n AND lv_up+off_nxt(1) = ''''.
        lv_i = lv_i + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      " 괄호 깊이
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.

      " TOP-LEVEL UNION?
      IF lv_depth = 0 AND lv_i + 4 < lv_n AND lv_up+lv_i(5) = |UNION|.
        " 경계 검사 (이전/다음)
        IF lv_i = 0.
          lv_prev = space.
        ELSE.
          lv_off_prev = lv_i - 1.
          lv_prev  = lv_up+lv_off_prev(1).
        ENDIF.

        lv_off_after = lv_i + 5.
        IF lv_off_after < lv_n.
          lv_next = lv_up+lv_off_after(1).
        ELSE.
          CLEAR lv_next.
        ENDIF.

        IF ( lv_prev = space OR lv_prev = ')' OR lv_prev = '(' OR lv_prev = ',' OR
             lv_prev = ';'   OR lv_prev = lv_tab OR lv_prev = lv_lf )
        AND ( lv_off_after = lv_n  OR lv_next = space OR lv_next = lv_tab OR lv_next = lv_lf ).

          lv_off_union = lv_i.

          " UNION ALL / DISTINCT 식별 (다음 토큰 확인)
          lv_kind = ''.
          lv_j = lv_off_after.
          WHILE lv_j < lv_n AND lv_up+lv_j(1) = space.
            lv_j = lv_j + 1.
          ENDWHILE.

          " DISTINCT 우선
          IF lv_j + 7 < lv_n AND lv_up+lv_j(8) = |DISTINCT|.
            lv_off_bd = lv_j + 8.
            IF lv_off_bd < lv_n. lv_ch_bd = lv_up+lv_off_bd(1). ELSE. CLEAR lv_ch_bd. ENDIF.
            IF lv_off_bd = lv_n OR lv_ch_bd = space OR lv_ch_bd = lv_tab OR lv_ch_bd = lv_lf.
              lv_kind  = |DISTINCT|.
              lv_end_union = lv_off_bd.
            ELSE.
              lv_end_union = lv_off_after.  " 경계 불만족 → plain 취급
            ENDIF.
          ENDIF.

          IF lv_kind IS INITIAL.
            IF lv_j + 2 < lv_n AND lv_up+lv_j(3) = |ALL|.
              lv_off_ba = lv_j + 3.
              IF lv_off_ba < lv_n. lv_ch_ba = lv_up+lv_off_ba(1). ELSE. CLEAR lv_ch_ba. ENDIF.
              IF lv_off_ba = lv_n OR lv_ch_ba = space OR lv_ch_ba = lv_tab OR lv_ch_ba = lv_lf.
                lv_kind  = |ALL|.
                lv_end_union = lv_off_ba.
              ELSE.
                lv_end_union = lv_off_after.
              ENDIF.
            ENDIF.
          ENDIF.

          IF lv_end_union IS INITIAL.
            lv_end_union = lv_off_after.       " plain UNION
          ENDIF.

          EXIT. " 첫 UNION만
        ENDIF.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  IF lv_off_union < 0.
    " UNION 없음 → 분리 안 함
    pv_first  = lv_src.
    pv_second = ''.
    CLEAR lv_kind.
    RETURN.
  ENDIF.

  " 2) UNION 뒤: 다음 SELECT 시작 지점 탐색 (괄호 유무 불문, 견고 탐색)
  lv_k   = lv_end_union.
  lv_depth  = 0.
  lv_in_q   = abap_false.
  lv_start_select = -1.

  WHILE lv_k < lv_n.
    lv_char = lv_up+lv_k(1).

    " 따옴표('' 이스케이프)
    DATA(off_nxt2) = lv_k + 1.
    IF lv_char = ''''.
      IF lv_in_q = abap_true AND off_nxt2 < lv_n AND lv_up+off_nxt2(1) = ''''.
        lv_k = lv_k + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_k = lv_k + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      " 괄호 깊이는 참고만 (바로 괄호 후 SELECT 가능)
      IF lv_char = '('.
        lv_depth = lv_depth + 1. lv_k = lv_k + 1. CONTINUE.
      ELSEIF lv_char = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_k = lv_k + 1. CONTINUE.
      ENDIF.

      " 'S'까지 전진한 뒤 SELECT 확인
      IF lv_char = 'S'.
        IF lv_k + 5 < lv_n.
          DATA lv_len_sel TYPE i.
          lv_len_sel = 6.
          IF lv_up+lv_k(lv_len_sel) = |SELECT|.
            lv_start_select = lv_k.
            EXIT.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    lv_k = lv_k + 1.
  ENDWHILE.

  " 3) 결과 잘라내기 (원문 기준 오프셋 사용)
  lv_len_head = lv_off_union.
  pv_first  = lv_src+0(lv_len_head).             " UNION 앞까지
  pv_second = lv_src+lv_len_head.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form split_sql_sy_char
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_STRING
*&      <-- LS_FIELD_W
*&---------------------------------------------------------------------*
FORM split_sql_sy_char  USING    pv_string  TYPE string
                        CHANGING ps_field_w TYPE tys_fieldlist.

  DATA: lv_src         TYPE string,      " 원문(현재 라인)
        lv_up          TYPE string,      " 대문자판(길이 동일)
        lv_alias       TYPE string,      " AS 뒤 별칭
        lv_type        TYPE string,      " 결정 타입(DATS/TIMS/…)
        lv_struct_line TYPE string,
        lv_ch          TYPE c LENGTH 1.

  DATA: lv_n        TYPE i,
        lv_i        TYPE i,
        lv_j        TYPE i,
        lv_k        TYPE i,
        lv_off_as   TYPE i VALUE -1,      " 'AS'의 A 위치
        lv_after_as TYPE i,
        lv_len_tok  TYPE i,
        lv_cr       TYPE c LENGTH 1,
        lv_ws       TYPE c LENGTH 1,
        lv_nextch   TYPE c LENGTH 1,
        lv_depth    TYPE i VALUE 0,
        lv_in_q     TYPE abap_bool VALUE abap_false.

  "-------------------------------------------------------
  " 0) 대상 문자열 준비 (한 줄만 처리, 길이 보존 전처리)
  "-------------------------------------------------------
  lv_src     = pv_string.
  lv_up     = to_upper( lv_src ).

  " 공백류 → SPACE (길이 보존), CONDENSE 금지
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_up WITH space.
  lv_cr = cl_abap_char_utilities=>cr_lf+0(1).
  REPLACE ALL OCCURRENCES OF lv_cr IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  PERFORM get_as_end_alias USING pv_string CHANGING lv_alias.

  IF lv_alias IS INITIAL.
    lv_alias = |F_SY|.  " 폴백
  ENDIF.

  " 3) @SY-xxxx 호스트변수 타입 매핑
  "    - AS 앞 좌변에서 '@SY-...' 토큰 추출
  DATA: lv_off_end_left TYPE i,
        lv_off_at       TYPE i VALUE -1,
        lv_off_end_tok  TYPE i,
        lv_len_host     TYPE i,
        lv_host_tok     TYPE string,
        lv_host_up      TYPE string.

  IF lv_off_as >= 0.
    lv_off_end_left = lv_off_as - 1.         " 'AS' 앞까지
  ELSE.
    lv_off_end_left = lv_n - 1.              " AS가 없으면 전체에서 탐색
  ENDIF.

  IF lv_off_end_left < 0. lv_off_end_left = 0. ENDIF.

  " 좌변에서 '@' 찾기
  lv_i = 0. lv_off_at = -1.
  WHILE lv_i <= lv_off_end_left.

    IF lv_src+lv_i(1) = '@'.
      lv_off_at = lv_i. EXIT.
    ENDIF.
    lv_i = lv_i + 1.
  ENDWHILE.

  IF lv_off_at >= 0.
    " 토큰 끝(공백/콤마/괄호/세미콜론/문자열 끝)
    lv_k = lv_off_at + 1.
    WHILE lv_k <= lv_off_end_left.

      lv_ch = lv_up+lv_k(1).
      IF lv_ch = space OR lv_ch = ',' OR lv_ch = ')' OR lv_ch = '(' OR lv_ch = ';'.
        EXIT.
      ENDIF.

      lv_k = lv_k + 1.
    ENDWHILE.

    lv_len_host = lv_k - lv_off_at.
    IF lv_len_host < 0. lv_len_host = 0. ENDIF.
    lv_host_tok = lv_up+lv_off_at(lv_len_host).        " 예: @SY-DATUM
  ENDIF.

  " 기본값
  lv_host_up = lv_host_tok.  " 이미 대문자

  " 대표 매핑
  CASE lv_host_up.
    WHEN '@SY-DATUM' OR '@SY-DATE' OR '@SY-DATLO'.
      lv_type = 'DATS'.
    WHEN '@SY-UZEIT' OR '@SY-TIME' OR '@SY-TIMLO'.
      lv_type = 'TIMS'.
    WHEN '@SY-UNAME'.
      lv_type = 'SYUNAME'.  " (C length 12)
    WHEN '@SY-LANGU'.
      lv_type = 'SYLANGU'.  " (C length 1)
    WHEN '@SY-MANDT'.
      lv_type = 'MANDT'.    " (CLNT 3)
    WHEN OTHERS.
      lv_type = 'STRING'.
  ENDCASE.

  " 4) 결과 반영
  IF ps_field_w-field IS INITIAL.
    ps_field_w-field      = lv_alias.
  ENDIF.

  ps_field_w-field_txt  = lv_alias.
  ps_field_w-field_type = lv_type.
  CLEAR: ps_field_w-ref_table, ps_field_w-ref_field.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_as_alias
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_STRING
*&      <-- LV_ALIAS
*&---------------------------------------------------------------------*
FORM get_as_alias      USING    pv_string
                       CHANGING pv_alias
                                pv_type pv_len pv_dec.

  DATA: lv_string      TYPE string,
        lv_up          TYPE string,
        lv_ch          TYPE c LENGTH 1,
        lv_nch         TYPE c LENGTH 1,
        lv_ws          TYPE c LENGTH 1,
        lv_prev        TYPE c LENGTH 1,
        lv_cr          TYPE c LENGTH 1,
        lv_i           TYPE i,
        lv_j           TYPE i,
        lv_k           TYPE i,
        lv_n           TYPE i,
        lv_len         TYPE i,
        lv_pos_as      TYPE i VALUE -1,
        lv_pos_cast_as TYPE i VALUE -1,
        lv_after_as    TYPE i,
        lv_off         TYPE i,
        lv_depth       TYPE i VALUE 0,
        lv_in_sq       TYPE abap_bool VALUE abap_false,
        lv_in_dq       TYPE abap_bool VALUE abap_false,
        lv_left_ok     TYPE abap_bool,
        lv_right_ok    TYPE abap_bool,
        lv_num_len     TYPE string,
        lv_num_dec     TYPE string.

  DATA: BEGIN OF ls_result,
          alias TYPE string,
          type  TYPE string,
          len   TYPE string,
          dec   TYPE string,
        END OF ls_result.

  CLEAR ls_result.

  "-------------------------------------------------------
  " 0) 대상 문자열 준비 - 길이 보존
  "-------------------------------------------------------
  lv_string = pv_string.
  lv_up     = to_upper( lv_string ).

  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_up WITH space.

  lv_cr = cl_abap_char_utilities=>cr_lf+0(1).
  REPLACE ALL OCCURRENCES OF lv_cr IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  "-------------------------------------------------------
  " 1) 최종 Top-Level AS 탐색
  "    예: CAST( ' ' AS CHAR( 4 ) ) AS vkorg,
  "        CAST 내부 AS는 depth = 1 이므로 무시
  "        마지막 depth = 0 AS만 alias 기준
  "-------------------------------------------------------
  lv_i     = 0.
  lv_depth = 0.
  lv_in_sq = abap_false.
  lv_in_dq = abap_false.

  WHILE lv_i < lv_n.

    lv_ch = lv_up+lv_i(1).

    " Single quote 처리: '...'
    IF lv_in_dq = abap_false AND lv_ch = ''''.

      lv_off = lv_i + 1.

      IF lv_in_sq = abap_true
         AND lv_off < lv_n
         AND lv_up+lv_off(1) = ''''.
        lv_i = lv_i + 2.
        CONTINUE.
      ENDIF.

      lv_in_sq = xsdbool( lv_in_sq = abap_false ).
      lv_i = lv_i + 1.
      CONTINUE.

    ENDIF.

    " Double quote 처리: "..."
    IF lv_in_sq = abap_false AND lv_ch = '"'.

      lv_off = lv_i + 1.

      IF lv_in_dq = abap_true
         AND lv_off < lv_n
         AND lv_up+lv_off(1) = '"'.
        lv_i = lv_i + 2.
        CONTINUE.
      ENDIF.

      lv_in_dq = xsdbool( lv_in_dq = abap_false ).
      lv_i = lv_i + 1.
      CONTINUE.

    ENDIF.

    IF lv_in_sq = abap_false AND lv_in_dq = abap_false.

      IF lv_ch = '('.
        lv_depth = lv_depth + 1.
        lv_i = lv_i + 1.
        CONTINUE.
      ELSEIF lv_ch = ')'.
        IF lv_depth > 0.
          lv_depth = lv_depth - 1.
        ENDIF.
        lv_i = lv_i + 1.
        CONTINUE.
      ENDIF.

      IF lv_depth = 0
         AND lv_i + 1 < lv_n
         AND lv_up+lv_i(2) = 'AS'.

        CLEAR: lv_left_ok,
               lv_right_ok.

        " 왼쪽 경계 확인
        IF lv_i = 0.
          lv_left_ok = abap_true.
        ELSE.
          lv_off  = lv_i - 1.
          lv_prev = lv_up+lv_off(1).

          IF lv_prev = space
             OR lv_prev = ','
             OR lv_prev = ')'
             OR lv_prev = '('.
            lv_left_ok = abap_true.
          ENDIF.
        ENDIF.

        " 오른쪽 경계 확인
        lv_off = lv_i + 2.

        IF lv_off >= lv_n.
          lv_right_ok = abap_true.
        ELSE.
          lv_nch = lv_up+lv_off(1).

          IF lv_nch = space
             OR lv_nch = '"'.
            lv_right_ok = abap_true.
          ENDIF.
        ENDIF.

        IF lv_left_ok = abap_true AND lv_right_ok = abap_true.
          lv_pos_as = lv_i. " 마지막 Top-Level AS로 계속 갱신
          lv_i = lv_i + 2.
          CONTINUE.
        ENDIF.

      ENDIF.

    ENDIF.

    lv_i = lv_i + 1.

  ENDWHILE.

  "-------------------------------------------------------
  " 2) Alias 추출
  "-------------------------------------------------------
  IF lv_pos_as < 0.
    ls_result-alias = 'AS NOT FOUND'.
    RETURN.
  ENDIF.

  lv_after_as = lv_pos_as + 2.
  lv_j        = lv_after_as.

  " AS 뒤 공백 스킵
  WHILE lv_j < lv_n.
    lv_ws = lv_up+lv_j(1).

    IF lv_ws = space.
      lv_j = lv_j + 1.
    ELSE.
      EXIT.
    ENDIF.
  ENDWHILE.

  IF lv_j >= lv_n.
    RETURN.
  ENDIF.

  " 따옴표 Alias: AS "ALIAS NAME"
  IF lv_string+lv_j(1) = '"'.

    lv_k = lv_j + 1.

    WHILE lv_k < lv_n.

      IF lv_string+lv_k(1) = '"'.

        lv_off = lv_k + 1.

        " Double quote escape: ""
        IF lv_off < lv_n
           AND lv_string+lv_off(1) = '"'.
          lv_k = lv_k + 2.
          CONTINUE.
        ENDIF.

        EXIT.

      ENDIF.

      lv_k = lv_k + 1.

    ENDWHILE.

    lv_len = lv_k - lv_j - 1.

    IF lv_len > 0.
      lv_off = lv_j + 1.
      ls_result-alias = lv_string+lv_off(lv_len).
    ENDIF.

  ELSE.

    " 일반 Alias: 공백/콤마/세미콜론/괄호 전까지
    lv_k = lv_j.

    WHILE lv_k < lv_n.

      lv_ch = lv_up+lv_k(1).

      IF lv_ch = space
         OR lv_ch = ','
         OR lv_ch = ';'
         OR lv_ch = '('
         OR lv_ch = ')'.
        EXIT.
      ENDIF.

      lv_k = lv_k + 1.

    ENDWHILE.

    lv_len = lv_k - lv_j.

    IF lv_len > 0.
      ls_result-alias = lv_string+lv_j(lv_len).
    ENDIF.

  ENDIF.

  "-------------------------------------------------------
  " 3) CAST 내부 Type / Length / Decimal 추출
  "    예:
  "    CAST( ' ' AS CHAR( 4 ) ) AS vkorg,
  "      -> lv_type = CHAR, lv_len = 4, lv_dec = 0
  "
  "    CAST( amount AS DEC( 15, 2 ) ) AS amount,
  "      -> lv_type = DEC, lv_len = 15, lv_dec = 2
  "-------------------------------------------------------
  lv_i           = 0.
  lv_depth       = 0.
  lv_in_sq       = abap_false.
  lv_in_dq       = abap_false.
  lv_pos_cast_as = -1.

  WHILE lv_i < lv_pos_as.

    lv_ch = lv_up+lv_i(1).

    " Single quote 처리
    IF lv_in_dq = abap_false AND lv_ch = ''''.

      lv_off = lv_i + 1.

      IF lv_in_sq = abap_true
         AND lv_off < lv_n
         AND lv_up+lv_off(1) = ''''.
        lv_i = lv_i + 2.
        CONTINUE.
      ENDIF.

      lv_in_sq = xsdbool( lv_in_sq = abap_false ).
      lv_i = lv_i + 1.
      CONTINUE.

    ENDIF.

    " Double quote 처리
    IF lv_in_sq = abap_false AND lv_ch = '"'.

      lv_off = lv_i + 1.

      IF lv_in_dq = abap_true
         AND lv_off < lv_n
         AND lv_up+lv_off(1) = '"'.
        lv_i = lv_i + 2.
        CONTINUE.
      ENDIF.

      lv_in_dq = xsdbool( lv_in_dq = abap_false ).
      lv_i = lv_i + 1.
      CONTINUE.

    ENDIF.

    IF lv_in_sq = abap_false AND lv_in_dq = abap_false.

      IF lv_ch = '('.
        lv_depth = lv_depth + 1.
        lv_i = lv_i + 1.
        CONTINUE.
      ELSEIF lv_ch = ')'.
        IF lv_depth > 0.
          lv_depth = lv_depth - 1.
        ENDIF.
        lv_i = lv_i + 1.
        CONTINUE.
      ENDIF.

      " CAST 내부의 AS는 일반적으로 depth = 1
      IF lv_depth = 1
         AND lv_i + 1 < lv_pos_as
         AND lv_up+lv_i(2) = 'AS'.

        CLEAR: lv_left_ok,
               lv_right_ok.

        IF lv_i = 0.
          lv_left_ok = abap_true.
        ELSE.
          lv_off  = lv_i - 1.
          lv_prev = lv_up+lv_off(1).

          IF lv_prev = space
             OR lv_prev = ','
             OR lv_prev = ')'
             OR lv_prev = '('.
            lv_left_ok = abap_true.
          ENDIF.
        ENDIF.

        lv_off = lv_i + 2.

        IF lv_off >= lv_pos_as.
          lv_right_ok = abap_true.
        ELSE.
          lv_nch = lv_up+lv_off(1).

          IF lv_nch = space
             OR lv_nch = '"'.
            lv_right_ok = abap_true.
          ENDIF.
        ENDIF.

        IF lv_left_ok = abap_true AND lv_right_ok = abap_true.
          lv_pos_cast_as = lv_i.
          lv_i = lv_i + 2.
          CONTINUE.
        ENDIF.

      ENDIF.

    ENDIF.

    lv_i = lv_i + 1.

  ENDWHILE.

  IF lv_pos_cast_as < 0.
    RETURN.
  ENDIF.

  " CAST AS 뒤 공백 스킵
  lv_j = lv_pos_cast_as + 2.

  WHILE lv_j < lv_pos_as.
    lv_ws = lv_up+lv_j(1).

    IF lv_ws = space.
      lv_j = lv_j + 1.
    ELSE.
      EXIT.
    ENDIF.
  ENDWHILE.

  " Type 추출: CHAR, DEC, NUMC 등
  lv_k = lv_j.

  WHILE lv_k < lv_pos_as.

    lv_ch = lv_up+lv_k(1).

    IF lv_ch = space
       OR lv_ch = '('
       OR lv_ch = ')'
       OR lv_ch = ','.
      EXIT.
    ENDIF.

    lv_k = lv_k + 1.

  ENDWHILE.

  lv_len = lv_k - lv_j.

  IF lv_len > 0.
    ls_result-type = lv_up+lv_j(lv_len).
  ENDIF.

  " Type 뒤 공백 스킵
  lv_j = lv_k.

  WHILE lv_j < lv_pos_as.
    lv_ws = lv_up+lv_j(1).

    IF lv_ws = space.
      lv_j = lv_j + 1.
    ELSE.
      EXIT.
    ENDIF.
  ENDWHILE.

  " Length / Decimal 추출: ( 4 ) 또는 ( 15, 2 )
  IF lv_j < lv_pos_as AND lv_up+lv_j(1) = '('.

    lv_j = lv_j + 1.
    CLEAR: lv_num_len,
           lv_num_dec.

    " Length 숫자 추출
    WHILE lv_j < lv_pos_as.

      lv_ch = lv_up+lv_j(1).

      IF lv_ch CO '0123456789'.
        lv_num_len = lv_num_len && lv_ch.
      ELSEIF lv_ch = ','.
        lv_j = lv_j + 1.
        EXIT.
      ELSEIF lv_ch = ')'.
        EXIT.
      ENDIF.

      lv_j = lv_j + 1.

    ENDWHILE.

    " Decimal 숫자 추출
    WHILE lv_j < lv_pos_as.

      lv_ch = lv_up+lv_j(1).

      IF lv_ch CO '0123456789'.
        lv_num_dec = lv_num_dec && lv_ch.
      ELSEIF lv_ch = ')'.
        EXIT.
      ENDIF.

      lv_j = lv_j + 1.

    ENDWHILE.

    IF lv_num_len IS NOT INITIAL.
      ls_result-len = CONV i( lv_num_len ).
    ENDIF.

    IF lv_num_dec IS NOT INITIAL.
      ls_result-dec = CONV i( lv_num_dec ).
    ENDIF.

  ENDIF.

  pv_alias = ls_result-alias.
  pv_type  = ls_result-type.
  pv_len   = ls_result-len.
  pv_dec   = ls_result-dec.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_as_end_alias
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_STRING
*&      <-- LV_ALIAS
*&---------------------------------------------------------------------*
FORM get_as_end_alias  USING    pv_string
                       CHANGING pv_alias.

  DATA: lv_string        TYPE string,     " 작업대상(원문 보존)
        lv_up            TYPE string,     " 대문자판(길이 동일)
        lv_struct_line   TYPE string,
        lv_strlen_string TYPE string,
        lv_ch            TYPE c LENGTH 1.
*
  DATA: lv_i        TYPE i,
        lv_j        TYPE i,
        lv_off_j    TYPE i,
        lv_k        TYPE i,
        lv_n        TYPE i,
        lv_pos_as   TYPE i VALUE -1,
        lv_after_as TYPE i,
        lv_len      TYPE i,
        lv_cr       TYPE c LENGTH 1,
        lv_nch      TYPE c LENGTH 1,
        lv_ws       TYPE c LENGTH 1,
        lv_depth    TYPE i VALUE 0,
        lv_in_q     TYPE abap_bool VALUE abap_false.

  "-------------------------------------------------------
  " 0) 대상 문자열 준비 (한 줄만 처리, 길이 보존 전처리)
  "-------------------------------------------------------
  lv_string = pv_string.
  lv_up     = to_upper( lv_string ).

  " 공백류 → SPACE (길이 보존), CONDENSE 금지
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN lv_up WITH space.
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline        IN lv_up WITH space.
  lv_cr = cl_abap_char_utilities=>cr_lf+0(1).
  REPLACE ALL OCCURRENCES OF lv_cr IN lv_up WITH space.

  lv_n = strlen( lv_up ).

  "-------------------------------------------------------
  " 1) AS 탐색 (Top-level, 따옴표/괄호 외부) — 한 줄만 스캔
  "-------------------------------------------------------
  lv_i = 0. lv_depth = 0. lv_in_q = abap_false. lv_pos_as = -1.

  WHILE lv_i < lv_n.
    lv_ch = lv_up+lv_i(1).

    " 따옴표('' 이스케이프) 처리
    DATA(lv_off_n) = lv_i + 1.
    IF lv_ch = ''''.
      IF lv_in_q = abap_true AND lv_off_n < lv_n AND lv_up+lv_off_n(1) = ''''.
        lv_i = lv_i + 2. CONTINUE.
      ELSE.
        lv_in_q = xsdbool( lv_in_q = abap_false ).
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.
    ENDIF.

    IF lv_in_q = abap_false.
      " 괄호 깊이
      IF lv_ch = '('.
        lv_depth = lv_depth + 1. lv_i = lv_i + 1. CONTINUE.
      ELSEIF lv_ch = ')'.
        IF lv_depth > 0. lv_depth = lv_depth - 1. ENDIF.
        lv_i = lv_i + 1. CONTINUE.
      ENDIF.

      " ' AS ' 또는 ' AS' (+ 경계) 허용
      IF lv_depth = 0 AND lv_i + 3 < lv_n AND lv_up+lv_i(4) = | AS |.
        lv_pos_as = lv_i + 1. " 'AS'의 A 위치
        EXIT.
      ELSEIF lv_depth = 0 AND lv_i + 2 < lv_n AND lv_up+lv_i(3) = | AS|.
        DATA(lv_off_after3) = lv_i + 3.
        IF lv_off_after3 >= lv_n.
          lv_pos_as = lv_i + 1.
          EXIT.
        ELSE.
          lv_nch = lv_up+lv_off_after3(1).
          IF lv_nch = space OR lv_nch = ',' OR lv_nch = '"' OR lv_nch = '('.
            lv_pos_as = lv_i + 1.
            EXIT.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    lv_i = lv_i + 1.
  ENDWHILE.

  "-------------------------------------------------------
  " 2) 별칭 추출 (AS 뒤) — 한 줄에서만 파싱
  "-------------------------------------------------------
  CLEAR pv_alias.
  IF lv_pos_as >= 0.
    lv_after_as = lv_pos_as + 2.       " 'AS' 뒤

    " 공백 스킵 (TAB/LF/CR는 이미 SPACE로 치환됨)
    lv_j = lv_after_as.
    WHILE lv_j < lv_n.
      lv_ws = lv_up+lv_j(1).
      IF lv_ws = space.
        lv_j = lv_j + 1.
      ELSE.
        EXIT.
      ENDIF.
    ENDWHILE.

    " 따옴표 별칭 "ALIAS NAME"
    IF lv_j < strlen( lv_string ) AND lv_string+lv_j(1) = '"'.
      lv_k = lv_j + 1.
      WHILE lv_k < strlen( lv_string ) AND lv_string+lv_k(1) <> '"'.
        lv_k = lv_k + 1.
      ENDWHILE.
      lv_len   = lv_k - ( lv_j + 1 ).
      IF lv_len < 0. lv_len = 0. ENDIF.
      lv_off_j = lv_j + 1.
      pv_alias = lv_string+lv_off_j(lv_len).
      " 닫는 따옴표가 없으면 여기서 끝난 범위만이라도 사용 (빈문자 방지)
      IF pv_alias IS INITIAL AND lv_k > lv_j + 1.
        lv_off_j = lv_j + 1.
        pv_alias = lv_string+lv_off_j(lv_len).
      ENDIF.
    ELSE.
      " 일반 별칭: 공백/콤마/세미콜론/괄호 전까지
      lv_k = lv_j.
      WHILE lv_k < lv_n.
        lv_ch = lv_up+lv_k(1).
        IF lv_ch = space OR lv_ch = ',' OR lv_ch = ';' OR lv_ch = '(' OR lv_ch = ')'.
          EXIT.
        ENDIF.
        lv_k = lv_k + 1.
      ENDWHILE.
      lv_len = lv_k - lv_j.
      IF lv_len < 0. lv_len = 0. ENDIF.
      pv_alias = lv_string+lv_j(lv_len).
    ENDIF.

  ELSE.
    pv_alias = 'END AS NOT FOUND'.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form decision_type
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_HOST_UP
*&      <-- LV_TYPE
*&---------------------------------------------------------------------*
FORM decision_type  USING    pv_host_up
                    CHANGING pv_type.

  pv_type = 'STRING'.
  CASE pv_host_up.
    WHEN '@SY-DATUM' OR '@SY-DATE' OR '@SY-DATLO'.
      pv_type = 'DATS'.
    WHEN '@SY-UZEIT' OR '@SY-TIME' OR '@SY-TIMLO'.
      pv_type = 'TIMS'.
    WHEN '@SY-UNAME'.
      pv_type = 'SYUNAME'.  " (C length 12)
    WHEN '@SY-LANGU'.
      pv_type = 'SYLANGU'.  " (C length 1)
    WHEN '@SY-MANDT'.
      pv_type = 'MANDT'.    " (CLNT 3)
    WHEN OTHERS.
      IF pv_host_up+0(5) = '@ICON'. pv_type = 'ICON_D'. ENDIF.
  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form editor_source
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM editor_source .

  lcl_toad_source_editor=>create_tab( ).

ENDFORM.
