*"* use this source file for any macro definitions you need
*"* in the implementation part of the class
DEFINE _com_xls_msg.

  IF sy-subrc NE 0.
    CASE sy-subrc.
      WHEN 0.
      WHEN 1.
        " SAPGUI communication error.
        MESSAGE s000(oo) WITH TEXT-e01 DISPLAY LIKE 'E'.

      WHEN 2.
        " SAPGUI function call error. The frontend ports of SAP’s OLE implementation modules
        "                   are implemented only under Windows and Apple Macintosh
        MESSAGE s000(oo) WITH TEXT-e02 DISPLAY LIKE 'E'.

      WHEN 3.
        " The OLE-API call resulted in an error - possibly a storage space problem.
        MESSAGE s000(oo) WITH TEXT-e03 DISPLAY LIKE 'E'.

      WHEN 4.
        " The object is not registered with SAP.
        MESSAGE s000(oo) WITH TEXT-e04 DISPLAY LIKE 'E'.

      WHEN OTHERS.
*        MESSAGE ID 'SOFFICEINTEGRATION' TYPE 'I' NUMBER &1
*                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDCASE.

*    CALL METHOD OF go_application 'QUIT'.
*    FREE OBJECT go_application.
*    CLEAR go_application.
    EXIT. " raise upload_ole.
  ENDIF.

END-OF-DEFINITION.

*----------------------------------------------------------------------*
* Possable Entry 값 설정..
*----------------------------------------------------------------------*
* possable 의 기본적인 값 설정...
*  &1 : 화면번호..
*  &2 : Search help object
*  &3 : Search Help Field
*  &4 : 참조 Table.
*  &5 : 참조 Table 의 Field
*----------------------------------------------------------------------*
DEFINE _com_set_f4.
  CLEAR: gs_f4_info.
  gs_f4_info-repid     = gv_repid.
  gs_f4_info-dynnr     = &1.

  gs_f4_info-shlpname  = &2.
  gs_f4_info-shlpfield = &3.

  gs_f4_info-tabname   = &4.
  gs_f4_info-fieldname = &5.

*
*  GET CURSOR FIELD  gs_set_cursor-field
*             LINE   gs_set_cursor-line
*             OFFSET gs_set_cursor-offset
*             VALUE  gs_set_cursor-value.
*
*  gs_f4_info-line = gs_set_cursor-line.
*
*  LOOP AT SCREEN.
*    IF screen-name = gs_set_cursor-field.
*      IF screen-input = '1'.
*      ELSE.
*        gs_f4_info-display = c_x.
*      ENDIF.
*    ENDIF.
*  ENDLOOP.

END-OF-DEFINITION.
