class ZCL_ZMDM_MM_ALV_INFO definition
  public
  create public .

public section.

  types:
    BEGIN OF ts_flavor,
        flavor    TYPE cndd_flavor,
        dr_source TYPE char1,
        dr_target TYPE char1,
        effect    TYPE i,
      END OF ts_flavor .
  types:
    tt_flavor          TYPE TABLE OF ts_flavor .
  types:
    BEGIN OF ts_dynnr,
        main_dynnr TYPE sydynnr,
        sub_dynnr  TYPE sydynnr,
        data_dynnr TYPE sydynnr,
      END OF ts_dynnr .
  types:
    tt_dynnr          TYPE TABLE OF ts_dynnr .
  types:
    BEGIN OF ts_selscr_field,
        ftype   TYPE screen-group3,
        fseq    TYPE screen-group4,
        fname   TYPE screen-name,
        fname2  TYPE screen-name,  " 동일라인에 두번째 field
        fname3  TYPE screen-name,  " 동일라인에 세번째 Field
        title   TYPE text72,
        text    TYPE text72,
        pos     TYPE i,
        pos_s   TYPE i,
        rbgname TYPE char4,
        dtype   TYPE char1,  " Field 의 data type
      END OF ts_selscr_field .
  types:
    tt_selscr_field TYPE TABLE OF ts_selscr_field .
  types:
    BEGIN OF ts_selscr_rbg,
        rbgname TYPE char4,
        fname   TYPE screen-name,
        text    TYPE text72,
      END OF ts_selscr_rbg .
  types:
    tt_selscr_rbg TYPE TABLE OF ts_selscr_rbg .
  types:
    tyv_amt TYPE p LENGTH 16 DECIMALS 6 .

  constants GC_EXIT_ALV_FORM type FORMNAME value 'COM_EXIT_' ##NO_TEXT.
  constants GC_OK_BACK_EXIT type SY-UCOMM value 'BACK_EXIT' ##NO_TEXT.
  constants GC_OK_CANC_EXIT type SY-UCOMM value 'CANC_EXIT' ##NO_TEXT.
  constants GC_OK_DISP_EXIT type SY-UCOMM value 'DISP_EXIT' ##NO_TEXT.
  constants GC_OK_EXIT type SY-UCOMM value 'EXIT' ##NO_TEXT.
  constants GC_MSGID type SYMSGID value 'ZMDM01' ##NO_TEXT.
  data GV_MSGID type SYMSGID .
  data GV_REPID type SYREPID .
  data GV_SET_ERROR_DATA type STRING .
  data GV_SET_NEW_OKCODE type STRING .
  data GV_SET_OKCODE type STRING .
  data GV_SET_NO_REFRESH type STRING .
  data GV_SET_NO_CHANGE type STRING .
  data GV_SELSCR_MAX_LEN type I .
  data GO_COMFUNC type ref to ZCL_ZMDM_MM_COMFUNC .
  data GT_SELSCR_FIELD type TT_SELSCR_FIELD .
  data GT_SELSCR_RBG type TT_SELSCR_RBG .

  methods ADD_BUTTON
    importing
      !IV_COMMAND type UI_FUNC
      !IV_ICON type ICON_L2
      !IV_TEXT type ANY
      !IV_QUICK type ANY
    changing
      !CV_INDEX type I
      !CO_OBJECT type ref to CL_ALV_EVENT_TOOLBAR_SET .
  methods ADD_BUTTON_SEPARATION
    changing
      !CV_INDEX type I
      !CO_OBJECT type ref to CL_ALV_EVENT_TOOLBAR_SET .
  methods ADD_F4_FIELD
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_REGISTER type LVC_REGIS default 'X'
      !IV_GETBEFORE type LVC_COMPL default SPACE
      !IV_CHNGEAFTER type LVC_COMPL default SPACE
    returning
      value(RT_F4) type LVC_T_F4 .
  methods CALL_EVENT
    importing
      !IO_GRID type ref to CL_GUI_ALV_GRID
      !IO_DOCU type ref to CL_DD_DOCUMENT
      !IV_EVENT type CHAR30 .
  methods CHECK_CHANGED_DATA
    importing
      !IO_GRID type ref to CL_GUI_ALV_GRID
    returning
      value(RV_ERROR_IN_DATA) type CHAR01 .
  methods COL_CFIELD
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_CFIELD type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_CHECKBOX
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_IS_EDITOR type C default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_COLOR
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_COLOR type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_CURRENCY
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_CURRENCY type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_DELETE
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_DOSUM
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_SUM_FLAG type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_DROPDN
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_HANDLE type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_DROPDN_ALIAS
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_ALIAS_FIELD type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_EDIT
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_EDIT type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_EDITMASK
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_EDITMASK type ANY optional
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_F4
    importing
      !IV_FIELDNAME type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_F4A
    importing
      !IV_FIELDNAME type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_F4X
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_REF_TABNAME type TABNAME
      !IV_REF_FIELD type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_KEY
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_KEY type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_HOTSPOT
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_HOTSPOT type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_HIDE
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_HIDE type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_JUST
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_JUST type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_POS
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_KEY type ANY
      !IV_LEN type ANY
      !IV_TEXT type ANY
      !IV_HOTSPOT type ANY
      !IV_EDITOR type ANY
      !IV_GRAPH type ANY
    changing
      !CV_COL_POS type I
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_QFIELD
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_QFIELD type FIELDNAME
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_QUANTITY
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_QUANTITY type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_SORT
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_SORT type ANY default 'U'
      !IV_SUBTOTAL type ANY default SPACE
      !IV_EXPA type ANY default SPACE
    changing
      !CV_COL_POS type I
      !CT_SORTFIELDS type LVC_T_SORT .
  methods COL_TECH
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_TECH type ANY default 'X'
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_TEXT
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_TEXT_L type ANY optional
      !IV_TEXT_M type ANY optional
      !IV_TEXT_S type ANY optional
      !IV_TEXT_Q type ANY optional
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods COL_TOOLTIP
    importing
      !IV_FIELDNAME type FIELDNAME
      !IV_TOOLTIP type ANY
    changing
      !CT_FIELDCAT type LVC_T_FCAT .
  methods CONSTRUCTOR
    importing
      !IV_REPID type SY-REPID optional
      !IV_MSGID type SYMSGID optional
      !IO_COMFUNC type ref to ZCL_ZMDM_MM_COMFUNC optional .
  methods CONVERT_FIELDCATALOG
    changing
      !CT_FCAT type LVC_T_FCAT
      !CT_SCAT type SLIS_T_FIELDCAT_ALV
    exceptions
      NOT_A_STRUCTURE
      NO_DDIC .
  methods CREATE_ON_CON
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_CONTNM type SCRFNAME optional
    exporting
      !EO_CCON type ref to CL_GUI_CUSTOM_CONTAINER
      !EO_GRID type ref to CL_GUI_ALV_GRID .
  methods CREATE_ON_CON_SPLIT
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_CONTNM type SCRFNAME optional
      !IV_GRID_ORIENTATION type I default 0
      !IV_GRID_SASH type I default 50
      !IV_GRID_BORDER type I default 0
    exporting
      !EO_CONT1 type ref to CL_GUI_CONTAINER
      !EO_CONT2 type ref to CL_GUI_CONTAINER
      !EO_CCON type ref to CL_GUI_CUSTOM_CONTAINER .
  methods CREATE_ON_CON_SPLIT2
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_CONTNM type SCRFNAME optional
      !IV_GRID_ORIENTATION type I default 0
      !IV_GRID_SASH type I default 50
      !IV_GRID_BORDER type I default 0
    exporting
      !EO_GRID1 type ref to CL_GUI_ALV_GRID
      !EO_GRID2 type ref to CL_GUI_ALV_GRID
      !EO_CCON type ref to CL_GUI_CUSTOM_CONTAINER .
  methods CREATE_ON_DOC
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_EXTENSION type I default 32000
      !IV_SIDE type ANY default 'TOP'
    exporting
      !EO_DCON type ref to CL_GUI_DOCKING_CONTAINER
      !EO_GRID type ref to CL_GUI_ALV_GRID .
  methods CREATE_ON_DOC_H
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_EXTENSION type I default 32000
      !IV_SASH_POSITION type I default 10
    exporting
      !EO_HEAD type ref to CL_GUI_CONTAINER
      !EO_DOCU type ref to CL_DD_DOCUMENT
      !EO_DCON type ref to CL_GUI_DOCKING_CONTAINER
      !EO_GRID type ref to CL_GUI_ALV_GRID .
  methods CREATE_ON_DOC_SPLIT_H
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_EXTENSION type I default 32000
      !IV_SASH_POSITION type I default 10
      !IV_GRID_ORIENTATION type I default 0
      !IV_GRID_BORDER type I default 0
      !IV_GRID_SASH type I default 50
    exporting
      !EO_HEAD type ref to CL_GUI_CONTAINER
      !EO_DOCU type ref to CL_DD_DOCUMENT
      !EO_DCON type ref to CL_GUI_DOCKING_CONTAINER
      !EO_CONT1 type ref to CL_GUI_CONTAINER
      !EO_CONT2 type ref to CL_GUI_CONTAINER .
  methods CREATE_ON_DOC_WITH_EASY
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_EXTENSION type I default 32000
      !IV_ORIENTATION type I default 1
      !IV_SASH_POSITION type I default 25
      !IV_WITH_BORDER type I default 0
    exporting
      !EO_DCON type ref to CL_GUI_DOCKING_CONTAINER
      !EO_GRID_TOP type ref to CL_GUI_ALV_GRID
      !EO_GRID_BOT type ref to CL_GUI_ALV_GRID .
  methods CREATE_ON_DOC_WITH_EASY_H
    importing
      !IV_REPID type SYREPID
      !IV_DYNNR type SYDYNNR
      !IV_EXTENSION type I default 32000
      !IV_SASH_POSITION type I default 10
      !IV_GRID_ORIENTATION type I default 0
      !IV_GRID_BORDER type I default 0
      !IV_GRID_SASH type I default 50
    exporting
      !EO_HEAD type ref to CL_GUI_CONTAINER
      !EO_DOCU type ref to CL_DD_DOCUMENT
      !EO_DCON type ref to CL_GUI_DOCKING_CONTAINER
      !EO_GRID1 type ref to CL_GUI_ALV_GRID
      !EO_GRID2 type ref to CL_GUI_ALV_GRID .
  methods CREATE_ON_SPLIT
    importing
      !IO_CONT type ref to CL_GUI_CONTAINER
      !IV_GRID_ORIENTATION type I default 0
      !IV_GRID_BORDER type I default 0
      !IV_GRID_SASH type I default 50
    exporting
      !EO_SPLIT_CONT type ref to CL_GUI_SPLITTER_CONTAINER
      !EO_CONT1 type ref to CL_GUI_CONTAINER
      !EO_CONT2 type ref to CL_GUI_CONTAINER .
  methods DISPATCH
    returning
      value(RV_EXIT_FORM) type CHAR01 .
  methods DISPLAY_GRID
    importing
      !IV_SCRNO type SYDYNNR .
  methods EXCLUDE_FUNCTIONS
    importing
      !IV_UI_FUNC type SYCHAR70
    changing
      value(CT_TABLE) type UI_FUNCTIONS .
  methods EXCLUDE_FUNCTIONS_DEFAULT
    returning
      value(RT_TABLE) type UI_FUNCTIONS .
  methods EXIT_PROGRAM
    importing
      !IV_SAVE_FLAG type CHAR1 default SPACE
      !IV_MSG type CHAR1 default 'E'
      !IT_DYNNR type TT_DYNNR optional
    returning
      value(RV_EXIT_FLAG) type CHAR1 .
  methods F4_ALV_VARIANT
    importing
      !IV_HANDLE type ANY
    returning
      value(RV_VARIANT) type SLIS_VARI .
  methods GET_ALV_LAYOUT_DEFAULT
    returning
      value(RV_VARIANT) type SLIS_VARI .
  methods GET_ELEMENTS
    importing
      !IT_COMP type CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE
    returning
      value(RT_COMP) type CL_ABAP_STRUCTDESCR=>COMPONENT_TABLE .
  methods GET_FIELDCATALOG
    importing
      !IT_TAB type ANY TABLE
    returning
      value(RT_FIELDCATALOG) type LVC_T_FCAT
    exceptions
      NOT_A_STRUCTURE
      NO_DDIC .
  methods GET_FIELD_INFO
    importing
      !IV_TABNAME type TABNAME
      !IV_FIELDNAME type FIELDNAME
      !IV_LANGU type SY-LANGU
    exporting
      !ES_FCAT type LVC_S_FCAT
      !ES_DFIES type DFIES
    exceptions
      FIELD_INFO_NOT_FOUND .
  methods GET_FIRST_ROWS
    importing
      !IO_GRID type ref to CL_GUI_ALV_GRID
      !IV_MSG type CHAR1 default 'X'
      !IV_MESSAGE type ANY default SPACE
    returning
      value(RV_INDEX) type I .
  methods GET_LAYOUT_DEFAULT
    importing
      !IV_HANDLE type ANY
    returning
      value(RV_VARIANT) type SLIS_VARI .
  methods GET_ROWS
    importing
      !IO_GRID type ref to CL_GUI_ALV_GRID
      !IV_MSG type CHAR1 default 'X'
      !IV_MESSAGE type ANY default SPACE
    returning
      value(RT_ROWS) type LVC_T_ROW .
  methods GET_SELSCR_FIELDS .
  methods INSERT_CELLCOLOR
    importing
      !IV_FIELDNAME type C optional
      !IV_COLOR type LVC_COL optional
      !IV_INTENSIFIED type LVC_INT default 0
      !IV_INVERSE type LVC_INV default 0
      !IT_CELLCOLOR type LVC_T_SCOL optional
    changing
      !CT_CELLCOLOR type LVC_T_SCOL .
  methods INSERT_CELLTAB
    importing
      !IV_STYLE type CHAR1 optional
      !IV_FIELDNAME type C optional
      !IT_CELLTAB type LVC_T_STYL optional
    changing
      !CT_CELLTAB type LVC_T_STYL .
  methods NEW_ADD_COLUMN
    importing
      !IV_TEXT type ANY optional
      !IV_TEXT_WIDTH type ANY optional
      !IV_ICON type ANY optional
      !IV_ICON_WIDTH type ANY optional
      !IV_ICON_FIRST type FLAG default SPACE
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA
      !CO_COL_NO type I .
  methods NEW_ADD_LINE
    importing
      !IV_TITLE type ANY
      !IV_MAXLEN type I
      !IV_TEXT type ANY optional
      !IV_ICON type ANY optional
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods NEW_HEADER_INIT
    importing
      !IO_DOCU type ref to CL_DD_DOCUMENT
      !IV_BORDER type ANY default '0'
      !IV_WIDTH_COL1 type ANY default '10%'
      !IV_WIDTH_COL2 type ANY default '90%'
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods REFRESH_GRID
    importing
      !IV_SCRNO type SYDYNNR .
  methods SET_DISPLAY_MODE
    importing
      !IV_SCRNO type SYDYNNR .
  methods SET_DRAGDROP_HANDLE
    importing
      !IV_TYPE type CHAR1 default 'R'
      !IT_FLAVOR type TT_FLAVOR
    changing
      !CS_LAYOUT type LVC_S_LAYO
      !CO_DRAGDROP type ref to CL_DRAGDROP
      !CT_FCAT type LVC_T_FCAT .
  methods SET_ERR_MSG
    importing
      !IV_MSGID type ANY optional
      !IV_MSGNO type ANY
      !IV_MSGV1 type ANY optional
      !IV_MSGV2 type ANY optional
      !IV_MSGV3 type ANY optional
      !IV_MSGV4 type ANY optional
      !IS_MODI_CELL type LVC_S_MODI
      !IO_DATA_CHANGED type ref to CL_ALV_CHANGED_DATA_PROTOCOL .
  methods SET_ERR_MSGS
    importing
      !IS_MODI_CELL type LVC_S_MODI
      !IV_MSGV1 type ANY
      !IO_DATA_CHANGED type ref to CL_ALV_CHANGED_DATA_PROTOCOL .
  methods SET_EVENT
    importing
      !IV_OBJECT_TEXT type CHAR30
      !IV_ORG_REPID type SY-REPID default SPACE
      !IO_GRID type ref to CL_GUI_ALV_GRID
    changing
      !CO_ALV_EVENT type ref to ZCL_ZMDM_MM_ALV_EVENT
      !CT_FCAT type LVC_T_FCAT
      !CT_DROP type LVC_T_DRAL optional .
  methods SET_FTD_LAYOUT
    importing
      !IV_SCRNO type SYDYNNR .
  methods SET_HEADER_SHOW
    importing
      !IV_DYNNR type ANY optional
      !IV_SHOW_BACKGRAND type FLAG default ' '
      !IV_SHOW_DEFAULT type FLAG default 'X'
      !IV_FORMAT type CHAR1 default 'L'
    changing
      !CO_DOCU type ref to CL_DD_DOCUMENT
      !CO_HEAD type ref to CL_GUI_CONTAINER
      !CO_HTML type ref to CL_GUI_HTML_VIEWER .
  methods SET_HEADER_TEXT_I
    importing
      !IV_TITLE type ANY
      !IV_FORMAT type CHAR1 default 'L'
      !IV_VALUE type ANY
      !IV_VALUE2 type ANY default SPACE
      !IV_VALUE3 type ANY default SPACE
      !IV_VTEXT type ANY default SPACE
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods SET_HEADER_TEXT_P
    importing
      !IV_TITLE type ANY
      !IV_FORMAT type CHAR1 default 'L'
      !IV_VALUE type ANY
      !IV_VALUE2 type ANY default SPACE
      !IV_VALUE3 type ANY default SPACE
      !IV_VTEXT type ANY default SPACE
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods SET_SELSCR_EXCEPT
    importing
      !IV_FIELD01 type ANY
      !IV_FIELD02 type ANY default SPACE
      !IV_FIELD03 type ANY default SPACE
      !IV_FIELD04 type ANY default SPACE
      !IV_FIELD05 type ANY default SPACE
      !IV_FIELD06 type ANY default SPACE
      !IV_FIELD07 type ANY default SPACE
      !IV_FIELD08 type ANY default SPACE
      !IV_FIELD09 type ANY default SPACE .
  methods SET_SELSCR_FIELDTYPE
    importing
      !IV_FIELD01 type ANY
      !IV_FIELD02 type ANY default SPACE
      !IV_FIELD03 type ANY default SPACE
      !IV_FIELD04 type ANY default SPACE
      !IV_FIELD05 type ANY default SPACE
      !IV_FIELD06 type ANY default SPACE
      !IV_FIELD07 type ANY default SPACE
      !IV_FIELD08 type ANY default SPACE
      !IV_FIELD09 type ANY default SPACE
      !IV_DTYPE01 type ANY
      !IV_DTYPE02 type ANY default SPACE
      !IV_DTYPE03 type ANY default SPACE
      !IV_DTYPE04 type ANY default SPACE
      !IV_DTYPE05 type ANY default SPACE
      !IV_DTYPE06 type ANY default SPACE
      !IV_DTYPE07 type ANY default SPACE
      !IV_DTYPE08 type ANY default SPACE
      !IV_DTYPE09 type ANY default SPACE .
  methods SET_SELSCR_RADIOBUTTONGROUP
    importing
      !IV_GROUP_NAME type ANY
      !IV_GROUP_TEXT type ANY
      !IV_RADIO_FIELD01 type ANY
      !IV_RADIO_FIELD02 type ANY
      !IV_RADIO_FIELD03 type ANY default SPACE
      !IV_RADIO_FIELD04 type ANY default SPACE
      !IV_RADIO_FIELD05 type ANY default SPACE
      !IV_RADIO_FIELD06 type ANY default SPACE
      !IV_RADIO_FIELD07 type ANY default SPACE
      !IV_RADIO_FIELD08 type ANY default SPACE
      !IV_RADIO_FIELD09 type ANY default SPACE .
protected section.
private section.

  data GV_SET_TABLE type STRING .
  data GV_SET_TABLE_DEL type STRING .
  data GV_SET_ALVGRID type STRING .
  data GV_SET_LAYOUT type STRING .
  data GV_SET_SAVEFLAG type STRING .
  data GV_SET_DISPMODE type STRING .
  data GV_SET_VARIANT type STRING .
  data GV_SET_TOOLS type STRING .
  data GV_SET_FIELDCAT type STRING .
  data GV_SET_SORT type STRING .
  data GV_SET_ALVDCON type STRING .
  data GV_SET_ALVCCON type STRING .

  methods EDIT_HEADER_P
    importing
      !IV_VALUE type ANY
      !IV_DTYPE type ANY
    returning
      value(RV_VALUE) type STRING .
  methods EDIT_HEADER_S
    importing
      !IT_SEL type STANDARD TABLE
      !IV_OPT type ANY
    returning
      value(RV_TXT) type SDYDO_TEXT_ELEMENT .
  methods EXIT_ALV_SCREEN
    importing
      !IV_SCRNO type SYDYNNR .
  methods SET_HEADER_INIT
    importing
      !IO_DOCU type ref to CL_DD_DOCUMENT
      !IV_NO_OF_COLUMNS type I default 3
      !IV_BORDER type ANY default '0'
      !IV_FORMAT type CHAR1 default 'L'
      !IV_WIDTH_TAB type ANY default '70%'
      !IV_WIDTH_COL1 type ANY default '10%'
      !IV_WIDTH_COL2 type ANY default '35%'
      !IV_WIDTH_COL3 type ANY default '55%'
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods SET_HEADER_SHOW_DEFAULT
    importing
      !IV_FORMAT type CHAR1 default 'L'
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods SET_HEADER_TEXT_S
    importing
      !IV_TITLE type ANY
      !IV_FORMAT type CHAR1 default 'L'
      !IT_SELTAB type STANDARD TABLE
      !IV_SELTAB_TYPE type ANY
      !IV_REMARK type ANY optional
    changing
      !CO_TAREA type ref to CL_DD_TABLE_AREA .
  methods SET_LOCAL_FIELDS .
  methods SET_LOCAL_FIELDS_WITH_SCRNO
    importing
      !IV_SCRNO type SYDYNNR .
  methods SET_SELSCR_MAX_LEN .
ENDCLASS.



CLASS ZCL_ZMDM_MM_ALV_INFO IMPLEMENTATION.


METHOD ADD_BUTTON.

    DATA: ls_toolbar TYPE stb_button.

    ADD   1             TO cv_index.

    CLEAR ls_toolbar.
    ls_toolbar-function  = iv_command.
    ls_toolbar-icon      = iv_icon.
    ls_toolbar-quickinfo = iv_quick.
    ls_toolbar-text      = iv_text.
    ls_toolbar-disabled  = ''.
    INSERT ls_toolbar  INTO co_object->mt_toolbar INDEX cv_index.

  ENDMETHOD.


METHOD ADD_BUTTON_SEPARATION.

    DATA: ls_toolbar TYPE stb_button.

    ADD   1             TO cv_index.

    CLEAR ls_toolbar.
    ls_toolbar-butn_type = 3.
    INSERT ls_toolbar  INTO co_object->mt_toolbar INDEX cv_index.

  ENDMETHOD.


METHOD ADD_F4_FIELD.

    DATA: ls_f4        TYPE lvc_s_f4.

    CLEAR: ls_f4.
    ls_f4-fieldname      = iv_fieldname.
    ls_f4-register       = iv_register.
    ls_f4-getbefore      = iv_getbefore.
    ls_f4-chngeafter     = iv_chngeafter.

    INSERT ls_f4 INTO TABLE rt_f4.

  ENDMETHOD.


METHOD CALL_EVENT.

* Initializing document
    CALL METHOD io_docu->initialize_document.

    CALL METHOD io_grid->list_processing_events
      EXPORTING
        i_event_name = iv_event
        i_dyndoc_id  = io_docu.

  ENDMETHOD.


METHOD CHECK_CHANGED_DATA.

    DATA: lv_valid TYPE c.

    CLEAR: rv_error_in_data.

    CHECK io_grid IS BOUND.

    CALL METHOD io_grid->check_changed_data
      IMPORTING
        e_valid = lv_valid.

    IF lv_valid IS INITIAL.
      rv_error_in_data = 'X'.
    ENDIF.

  ENDMETHOD.


METHOD COL_CFIELD.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-cfieldname = iv_cfield.
    ls_fieldcat-currency   = space.
    MODIFY ct_fieldcat FROM ls_fieldcat
              TRANSPORTING cfieldname currency
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_CHECKBOX.

    DATA: ls_fieldcat TYPE lvc_s_fcat.

    ls_fieldcat-checkbox    = 'X'.
    ls_fieldcat-edit        = iv_is_editor.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING checkbox edit
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_COLOR.

*- 1st char = C (color property)
*- 2nd char = color code (from 0 to 7)
*0 = background color
*1 = blue
*2 = gray
*3 = yellow
*4 = blue/gray
*5 = green
*6 = red
*7 = orange
*- 3rd char = intensified (0=off, 1=on)
*- 4th char = inverse display (0=off, 1=on)

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-emphasize = iv_color.
    IF ls_fieldcat-emphasize+0(1) <> 'C'.
      CONCATENATE 'C' iv_color '00' INTO ls_fieldcat-emphasize.
    ENDIF.

    MODIFY ct_fieldcat FROM ls_fieldcat
      TRANSPORTING emphasize
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_CURRENCY.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-currency   = iv_currency.
    ls_fieldcat-cfieldname = space.
    MODIFY ct_fieldcat FROM ls_fieldcat
          TRANSPORTING cfieldname currency
          WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_DELETE.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    CLEAR: ls_fieldcat.
    MODIFY ct_fieldcat FROM ls_fieldcat
               TRANSPORTING domname f4availabl checktable ref_field
                            ref_table
               WHERE fieldname <> space
                 AND edit      =  space
                 AND ( f4availabl <> 'Y' AND f4availabl <> 'A' ).

    ls_fieldcat-f4availabl = 'X'.
    MODIFY ct_fieldcat FROM ls_fieldcat
               TRANSPORTING f4availabl
               WHERE f4availabl = 'A'.

    "  화면에는 보이지 않고 Layout 에서는 사용불가함..
    ls_fieldcat-tech = 'X'.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING tech
          WHERE ( col_pos = 0 OR col_pos = 999 )
            AND no_out  = space.  " hide 된 field 제외

  ENDMETHOD.


METHOD COL_DOSUM.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-do_sum = iv_sum_flag.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING do_sum
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_DROPDN.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*    ls_fieldcat-edit        = 'X'.
    ls_fieldcat-drdn_hndl   = iv_handle.
*    ls_fieldcat-drdn_alias  = 'X'.
    ls_fieldcat-ref_field   = space.
    ls_fieldcat-ref_table   = space.
    ls_fieldcat-checktable  = space.

    MODIFY ct_fieldcat FROM ls_fieldcat
*        TRANSPORTING edit drdn_hndl drdn_alias checktable ref_field  ref_table
        TRANSPORTING drdn_hndl checktable ref_field  ref_table
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_DROPDN_ALIAS.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*    ls_fieldcat-edit        = 'X'.
    ls_fieldcat-drdn_field = iv_alias_field.
    ls_fieldcat-drdn_alias  = 'X'.
    ls_fieldcat-ref_field   = space.
    ls_fieldcat-ref_table   = space.
    ls_fieldcat-checktable  = space.

    MODIFY ct_fieldcat FROM ls_fieldcat
*        TRANSPORTING edit drdn_field drdn_alias checktable ref_field  ref_table
        TRANSPORTING drdn_field drdn_alias checktable ref_field  ref_table
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_EDIT.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-edit    = iv_edit.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING edit
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_EDITMASK.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-edit_mask    = iv_editmask.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING edit_mask
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_F4.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-f4availabl  = 'Y'.
    ls_fieldcat-ref_field   = space.
    ls_fieldcat-ref_table   = space.
    ls_fieldcat-checktable  = space.
    MODIFY ct_fieldcat FROM ls_fieldcat
           TRANSPORTING f4availabl ref_field ref_table checktable
           WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_F4A.

* Domain Value 로 search help구현시 해당 domain 은 table(structure) 에 연결되어 있어야 한다

    DATA: ls_fieldcat    TYPE lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-f4availabl  = 'A'.
    MODIFY ct_fieldcat FROM ls_fieldcat
           TRANSPORTING f4availabl
           WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_F4X.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-f4availabl  = 'X'.
    ls_fieldcat-ref_field   = iv_ref_field.
    ls_fieldcat-ref_table   = iv_ref_tabname.
    MODIFY ct_fieldcat FROM ls_fieldcat
           TRANSPORTING f4availabl ref_field ref_table
           WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_HIDE.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*  화면에는 보이지 않고 Layout 에서는 사용가능함.
    ls_fieldcat-no_out    = iv_hide.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING no_out
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_JUST.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-just = iv_just.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING just
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD col_pos.


  DATA: lv_text     TYPE lvc_txtcol,
        ls_fieldcat TYPE lvc_s_fcat.      " FIELD CATALOG

  READ TABLE ct_fieldcat INTO ls_fieldcat WITH KEY fieldname = iv_fieldname.
  CHECK sy-subrc = 0.

  cv_col_pos             = cv_col_pos + 1.
  ls_fieldcat-col_pos    = cv_col_pos.

  CASE iv_len.
    WHEN '-' OR space.    " IF CHANGE FIELD LENGTH.
      ls_fieldcat-col_opt     = 'X'.

    WHEN OTHERS.
      ls_fieldcat-outputlen   = iv_len.
      ls_fieldcat-col_opt     = space.
  ENDCASE.

  CASE iv_text .
    WHEN space.

*    WHEN `!`.
*      ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
*      ls_fieldcat-scrtext_m =
*      ls_fieldcat-scrtext_s = ls_fieldcat-coltext = space.

    WHEN OTHERS.
      ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m =
      ls_fieldcat-scrtext_l =
      ls_fieldcat-reptext   = iv_text.
      ls_fieldcat-coltext   = iv_text.
*        ls_fieldcat-scrtext_s = ls_fieldcat-coltext = iv_text.
  ENDCASE.

  " field key 설정
  CASE iv_key.
    WHEN 'X'.  " Key
      ls_fieldcat-key         = 'X'.
      ls_fieldcat-fix_column  = 'X'.

    WHEN 'F'." FIXED COLUMN.
      ls_fieldcat-fix_column  = 'X'.

    WHEN OTHERS.
  ENDCASE.

  " 날자와 시간은 가운데 정렬
  IF ls_fieldcat-inttype = 'D' OR " JUST CENTER DATE/TIME TYPE.
     ls_fieldcat-inttype = 'T' OR
     ls_fieldcat-datatype = 'UNIT'.

    ls_fieldcat-just     = 'C'.
  ENDIF.

  CASE iv_graph.
    WHEN 'I'.  " icon
      ls_fieldcat-icon    = 'X'.
      ls_fieldcat-just    = 'C'.

      " text 길이가 4 이하인 경우
      IF strlen( ls_fieldcat-scrtext_l ) < 4.
        IF ls_fieldcat-outputlen < 4. " 최소길이 4로 설정
          ls_fieldcat-outputlen = 4.
        ENDIF.

        CASE strlen( ls_fieldcat-scrtext_l ).
          WHEN 0. lv_text = `　　　　`.  " ㄱ 의 특수문자 1번
          WHEN 1. CONCATENATE `　` ls_fieldcat-scrtext_l `　　` INTO lv_text.
          WHEN 2. CONCATENATE `　` ls_fieldcat-scrtext_l `　`   INTO lv_text.
          WHEN 3. CONCATENATE      ls_fieldcat-scrtext_l `　`   INTO lv_text.
        ENDCASE.

        ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
        ls_fieldcat-scrtext_m =
*          ls_fieldcat-scrtext_s = ls_fieldcat-coltext = lv_text.
        ls_fieldcat-scrtext_s = lv_text.
      ENDIF.

    WHEN 'C'.  " checkbox
      ls_fieldcat-checkbox  = 'X'.
      ls_fieldcat-just      = 'C'.

    WHEN '1'.  " jest:center
      ls_fieldcat-just      = 'C'.

    WHEN '2'.  " jest:right
      ls_fieldcat-just      = 'R'.
  ENDCASE.

  ls_fieldcat-hotspot    = iv_hotspot.
  ls_fieldcat-edit       = iv_editor.

  MODIFY ct_fieldcat FROM ls_fieldcat
         TRANSPORTING col_pos outputlen key coltext scrtext_l scrtext_m
                      reptext scrtext_s fix_column just col_opt
                      icon checkbox
                      hotspot
                      edit
            WHERE fieldname = iv_fieldname.

ENDMETHOD.


METHOD COL_QFIELD.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-qfieldname = iv_qfield.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING qfieldname
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_QUANTITY.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-quantity = iv_quantity.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING quantity
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_SORT.

    DATA: ls_sortfield    TYPE lvc_s_sort.      " Sort Field list

    CLEAR: ls_sortfield.
    cv_col_pos             = cv_col_pos + 1.
    ls_sortfield-spos      = cv_col_pos.
    ls_sortfield-fieldname = iv_fieldname.

    CASE iv_sort.
      WHEN 'D'.    ls_sortfield-down = 'X'.
      WHEN OTHERS. ls_sortfield-up   = 'X'.
    ENDCASE.

    IF iv_expa = 'X'.
      ls_sortfield-group = 'UL'.
    ENDIF.

*  ls_sortfield-expa   = iv_expa.
    ls_sortfield-subtot = iv_subtotal.

    APPEND ls_sortfield  TO ct_sortfields.

  ENDMETHOD.


METHOD COL_TECH.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*  화면과 layout 에는 보이지 않음.
    ls_fieldcat-tech    = iv_tech.
    MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING tech
        WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_TEXT.

    DATA: ls_fieldcat    TYPE lvc_s_fcat.      " FIELD CATALOG

    READ TABLE ct_fieldcat INTO ls_fieldcat WITH KEY fieldname = iv_fieldname.
    CHECK sy-subrc = 0.

    CASE iv_text_l . " 40자
      WHEN space.
        ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
        ls_fieldcat-scrtext_m = ls_fieldcat-coltext   =
        ls_fieldcat-scrtext_m =
*        ls_fieldcat-scrtext_s = ls_fieldcat-coltext = `_`.
        ls_fieldcat-scrtext_s = `_`.

      WHEN OTHERS.
        ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m =
        ls_fieldcat-scrtext_l =
        ls_fieldcat-reptext   = iv_text_l.
        ls_fieldcat-coltext   = iv_text_l.
    ENDCASE.

    " middle text 가 입력된 경우
    IF iv_text_m IS NOT INITIAL. " 20자
      ls_fieldcat-scrtext_m = iv_text_m.
    ENDIF.

    " short text 가 입력된 경우
    IF iv_text_s IS NOT INITIAL. " 10 자
      ls_fieldcat-scrtext_s = iv_text_s.
      IF ls_fieldcat-outputlen = '00'.
        ls_fieldcat-outputlen = strlen( iv_text_s ).
      ENDIF.
    ENDIF.

    " tooltip
    IF iv_text_q IS NOT INITIAL. " 40자
      ls_fieldcat-tooltip = iv_text_q.
    ENDIF.

    MODIFY ct_fieldcat FROM ls_fieldcat
              TRANSPORTING coltext   reptext scrtext_l scrtext_m scrtext_s
                           outputlen tooltip
              WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD COL_TOOLTIP.

    DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

    ls_fieldcat-tooltip    = iv_tooltip.
    ls_fieldcat-tipddictxt = 'X'.

    MODIFY ct_fieldcat FROM ls_fieldcat
      TRANSPORTING tooltip tipddictxt
      WHERE fieldname = iv_fieldname.

  ENDMETHOD.


METHOD CONSTRUCTOR.

    " 메시지 id
    IF iv_msgid IS INITIAL.
      gv_msgid = gc_msgid.
    ELSE.
      gv_msgid = iv_msgid.
    ENDIF.

    IF iv_repid IS INITIAL.
      gv_repid = sy-repid.
    ELSE.
      gv_repid = iv_repid.
    ENDIF.

    " Common Function\
    IF io_comfunc IS BOUND.
      go_comfunc = io_comfunc.
    ELSE.
      CREATE OBJECT go_comfunc
        EXPORTING
          iv_repid = gv_repid.
    ENDIF.

    " 기타 변수 지정
    me->set_local_fields( ).

  ENDMETHOD.


METHOD CONVERT_FIELDCATALOG.

    DATA: ls_fcat TYPE lvc_s_fcat,
          ls_scat TYPE slis_fieldcat_alv.

    CHECK ( ct_fcat[] IS NOT INITIAL AND ct_scat[] IS INITIAL ) OR
          ( ct_fcat[] IS INITIAL     AND ct_scat[] IS NOT INITIAL ).

    IF ct_fcat[] IS NOT INITIAL .
      LOOP AT ct_fcat INTO ls_fcat.
        CLEAR: ls_scat.
        MOVE-CORRESPONDING ls_fcat TO ls_scat.
        APPEND ls_scat TO ct_scat.
      ENDLOOP.

    ELSE.
      LOOP AT ct_scat INTO ls_scat.
        CLEAR: ls_fcat.
        MOVE-CORRESPONDING ls_scat TO ls_fcat.
        APPEND ls_fcat TO ct_fcat.
      ENDLOOP.

    ENDIF.

  ENDMETHOD.


METHOD CREATE_ON_CON.

*  Customer container 생성..
    CREATE OBJECT eo_ccon
      EXPORTING
*       repid                       = pv_repid
*       dynnr                       = pv_dynnr
        container_name              = iv_contnm
        no_autodef_progid_dynnr     = 'X'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    " Grid 생성..
    CREATE OBJECT eo_grid
      EXPORTING
        i_parent          = eo_ccon
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

  ENDMETHOD.


METHOD CREATE_ON_CON_SPLIT.

    DATA: lo_split_grid TYPE REF TO cl_gui_easy_splitter_container.

*  Customer container 생성..
    CREATE OBJECT eo_ccon
      EXPORTING
*       repid                       = pv_repid
*       dynnr                       = pv_dynnr
        container_name              = iv_contnm
        no_autodef_progid_dynnr     = 'X'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    " Grid 분리
    CREATE OBJECT lo_split_grid
      EXPORTING
        parent        = eo_ccon
        orientation   = iv_grid_orientation
        sash_position = iv_grid_sash
        with_border   = iv_grid_border.       " With Border = 1 Without Border = 0

    eo_cont1 = lo_split_grid->top_left_container.
    eo_cont2 = lo_split_grid->bottom_right_container.

  ENDMETHOD.


METHOD CREATE_ON_CON_SPLIT2.

    DATA: lo_split_grid TYPE REF TO cl_gui_easy_splitter_container,
          lo_cont1      TYPE REF TO cl_gui_container,
          lo_cont2      TYPE REF TO cl_gui_container.

*  Customer container 생성..
    CREATE OBJECT eo_ccon
      EXPORTING
*       repid                       = pv_repid
*       dynnr                       = pv_dynnr
        container_name              = iv_contnm
        no_autodef_progid_dynnr     = 'X'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    " Grid 분리
    CREATE OBJECT lo_split_grid
      EXPORTING
        parent        = eo_ccon
        orientation   = iv_grid_orientation
        sash_position = iv_grid_sash
        with_border   = iv_grid_border.       " With Border = 1 Without Border = 0

    lo_cont1 = lo_split_grid->top_left_container.
    lo_cont2 = lo_split_grid->bottom_right_container.

    " Grid 생성..
    CREATE OBJECT eo_grid1
      EXPORTING
        i_parent          = lo_cont1
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

    " Grid 생성..
    CREATE OBJECT eo_grid2
      EXPORTING
        i_parent          = lo_cont2
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.
  ENDMETHOD.


METHOD CREATE_ON_DOC.

    DATA: lv_side TYPE i.

    CASE iv_side.
      WHEN 'TOP'.    lv_side = cl_gui_docking_container=>dock_at_top.
      WHEN 'BOTTOM'. lv_side = cl_gui_docking_container=>dock_at_bottom.
      WHEN 'LEFT'.   lv_side = cl_gui_docking_container=>dock_at_left.
      WHEN 'RIGHT'.  lv_side = cl_gui_docking_container=>dock_at_right.
      WHEN OTHERS.   lv_side = cl_gui_docking_container=>dock_at_top.
    ENDCASE.

*  Docking container 생성..
    CREATE OBJECT eo_dcon
      EXPORTING
        repid                       = iv_repid
        dynnr                       = iv_dynnr
        side                        = lv_side
        extension                   = iv_extension
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    " Grid 생성..
    CREATE OBJECT eo_grid
      EXPORTING
        i_parent          = eo_dcon
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

  ENDMETHOD.


METHOD CREATE_ON_DOC_H.
    DATA: lo_split_cont TYPE REF TO cl_gui_easy_splitter_container,
          lo_body       TYPE REF TO cl_gui_container.

*  Docking container #己..
    CREATE OBJECT eo_dcon
      EXPORTING
        repid                       = iv_repid
        dynnr                       = iv_dynnr
        side                        = cl_gui_docking_container=>dock_at_top
        extension                   = iv_extension
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    CREATE OBJECT lo_split_cont
      EXPORTING
        parent        = eo_dcon
        orientation   = 0   " 0 수평, 1 수직.
        sash_position = iv_sash_position.

    eo_head = lo_split_cont->top_left_container.
    lo_body = lo_split_cont->bottom_right_container.

    " Header Area 생성.
    CREATE OBJECT eo_docu
      EXPORTING
        style = 'ALV_GIRD'.

    " Grid 생성.
    CREATE OBJECT eo_grid
      EXPORTING
        i_parent          = lo_body
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

  ENDMETHOD.


METHOD CREATE_ON_DOC_SPLIT_H.


    DATA: lo_split_cont TYPE REF TO cl_gui_easy_splitter_container,
          lo_split_grid TYPE REF TO cl_gui_easy_splitter_container,
          lo_body       TYPE REF TO cl_gui_container,
          lo_grid1      TYPE REF TO cl_gui_container,
          lo_grid2      TYPE REF TO cl_gui_container.

*  Docking container 积己.
    CREATE OBJECT eo_dcon
      EXPORTING
        repid                       = iv_repid
        dynnr                       = iv_dynnr
        side                        = cl_gui_docking_container=>dock_at_top
        extension                   = iv_extension
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    CREATE OBJECT lo_split_cont
      EXPORTING
        parent        = eo_dcon
        orientation   = 0   " (0) 가로, (1)세로
        sash_position = iv_sash_position.

    eo_head = lo_split_cont->top_left_container.
    lo_body = lo_split_cont->bottom_right_container.

    " Header Area 생성
    CREATE OBJECT eo_docu
      EXPORTING
        style = 'ALV_GIRD'.

    " Grid 분리
    CREATE OBJECT lo_split_grid
      EXPORTING
        parent        = lo_body
        orientation   = iv_grid_orientation   " 0 = Vertical, 1 = Horizontal
        sash_position = iv_grid_sash
        with_border   = iv_grid_border.       " With Border = 1 Without Border = 0

    eo_cont1 = lo_split_grid->top_left_container.
    eo_cont2 = lo_split_grid->bottom_right_container.

  ENDMETHOD.


METHOD CREATE_ON_DOC_WITH_EASY.


    DATA: lo_easy_split TYPE REF TO cl_gui_easy_splitter_container,
          lo_tcon       TYPE REF TO cl_gui_container,   "TOP CONTAINER
          lo_bcon       TYPE REF TO cl_gui_container.   "Bottom CONTAINER

*  Docking container 생성..
    CREATE OBJECT eo_dcon
      EXPORTING
        repid                       = iv_repid
        dynnr                       = iv_dynnr
        side                        = cl_gui_docking_container=>dock_at_top
        extension                   = iv_extension
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    CREATE OBJECT lo_easy_split
      EXPORTING
        parent        = eo_dcon
        orientation   = iv_orientation   " 0 = Vertical, 1 = Horizontal
        sash_position = iv_sash_position " Position of Splitter Bar (in Percent)
        with_border   = iv_with_border.  " With Border = 1 Without Border = 0

    lo_tcon  = lo_easy_split->top_left_container .
    lo_bcon  = lo_easy_split->bottom_right_container .

    " Grid 생성..
    CREATE OBJECT eo_grid_top
      EXPORTING
        i_parent          = lo_tcon
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

    " Grid 생성..
    CREATE OBJECT eo_grid_bot
      EXPORTING
        i_parent          = lo_bcon
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

  ENDMETHOD.


METHOD CREATE_ON_DOC_WITH_EASY_H.


    DATA: lo_split_cont TYPE REF TO cl_gui_easy_splitter_container,
          lo_split_grid TYPE REF TO cl_gui_easy_splitter_container,
          lo_body       TYPE REF TO cl_gui_container,
          lo_grid1      TYPE REF TO cl_gui_container,
          lo_grid2      TYPE REF TO cl_gui_container.

*  Docking container 积己.
    CREATE OBJECT eo_dcon
      EXPORTING
        repid                       = iv_repid
        dynnr                       = iv_dynnr
        side                        = cl_gui_docking_container=>dock_at_top
        extension                   = iv_extension
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.

    CREATE OBJECT lo_split_cont
      EXPORTING
        parent        = eo_dcon
        orientation   = 0   " (0) 가로, (1)세로
        sash_position = iv_sash_position.

    eo_head = lo_split_cont->top_left_container.
    lo_body = lo_split_cont->bottom_right_container.

    " Header Area 생성
    CREATE OBJECT eo_docu
      EXPORTING
        style = 'ALV_GIRD'.

    " Grid 분리
    CREATE OBJECT lo_split_grid
      EXPORTING
        parent        = lo_body
        orientation   = iv_grid_orientation   " 0 = Vertical, 1 = Horizontal
        sash_position = iv_grid_sash
        with_border   = iv_grid_border.       " With Border = 1 Without Border = 0

    lo_grid1 = lo_split_grid->top_left_container.
    lo_grid2 = lo_split_grid->bottom_right_container.

    " Grid 생성
    CREATE OBJECT eo_grid1
      EXPORTING
        i_parent          = lo_grid1
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.

    CREATE OBJECT eo_grid2
      EXPORTING
        i_parent          = lo_grid2
        i_appl_events     = space
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4.


  ENDMETHOD.


METHOD CREATE_ON_SPLIT.

*  DATA: lo_split_grid TYPE REF TO cl_gui_easy_splitter_container.
*  DATA: lo_split_grid TYPE REF TO cl_gui_splitter_container.

    " Grid 분리
*  CREATE OBJECT lo_split_grid
*    EXPORTING
*      parent        = io_cont
*      orientation   = iv_grid_orientation   " 0 = Vertical, 1 = Horizontal
*      sash_position = iv_grid_sash
*      with_border   = iv_grid_border.       " With Border = 1 Without Border = 0
    DATA: lv_row TYPE i,
          lv_col TYPE i.

    IF iv_grid_orientation = 0.
      lv_row = 1.
      lv_col = 2.
    ELSE.
      lv_row = 2.
      lv_col = 1.
    ENDIF.

    CREATE OBJECT eo_split_cont
      EXPORTING
        link_dynnr = sy-dynnr
        parent     = io_cont
        rows       = lv_row
        columns    = lv_col
        width      = iv_grid_sash.
*      no_autodef_progid_dynnr = 'X'.
*      orientation   = iv_grid_orientation   " 0 = Vertical, 1 = Horizontal
*      sash_position = iv_grid_sash
*      with_border   = iv_grid_border.       " With Border = 1 Without Border = 0

    IF iv_grid_orientation = 0.
      eo_cont1 = eo_split_cont->get_container( EXPORTING row = 1 column = 1 ).
      eo_cont2 = eo_split_cont->get_container( EXPORTING row = 1 column = 2 ).
    ELSE.
      eo_cont1 = eo_split_cont->get_container( EXPORTING row = 1 column = 1 ).
      eo_cont2 = eo_split_cont->get_container( EXPORTING row = 2 column = 1 ).
    ENDIF.

*  eo_cont1 = lo_split_grid->top_left_container.
*  eo_cont2 = lo_split_grid->bottom_right_container.

  ENDMETHOD.


METHOD DISPATCH.


    DATA: lv_return_code TYPE i.

    FIELD-SYMBOLS:
      <lv_no_refresh> TYPE any,
      <lv_ok_code>    TYPE any.

    ASSIGN (gv_set_no_refresh) TO <lv_no_refresh>.
    CHECK sy-subrc = 0 AND <lv_no_refresh> IS ASSIGNED.

    ASSIGN (gv_set_okcode) TO <lv_ok_code>.
    CHECK sy-subrc = 0 AND <lv_ok_code> IS ASSIGNED.

    CLEAR: rv_exit_form.
    CALL METHOD cl_gui_cfw=>dispatch
      IMPORTING
        return_code = lv_return_code.
    IF lv_return_code <> cl_gui_cfw=>rc_noevent.
      CASE <lv_ok_code>+9(1).
        WHEN '9'.       <lv_no_refresh> = 'X'.
        WHEN OTHERS.    <lv_no_refresh> = space.
      ENDCASE.

*    CLEAR <lv_ok_code>.
*    rv_exit_form = 'X'.
*    EXIT.
    ENDIF.

  ENDMETHOD.


METHOD DISPLAY_GRID.


    FIELD-SYMBOLS:
      <ls_layout>   TYPE lvc_s_layo,
      <ls_vari>	    TYPE disvariant,
      <lt_tool>	    TYPE ui_functions,
      <lt_fieldcat>	TYPE lvc_t_fcat,
      <lt_sort>	    TYPE lvc_t_sort,
      <lt_table>    TYPE STANDARD TABLE,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_layout)     TO <ls_layout>." Layout
    CHECK <ls_layout> IS ASSIGNED.

    ASSIGN (gv_set_table)      TO <lt_table>." Work Table
    CHECK <lt_table> IS ASSIGNED.

    ASSIGN (gv_set_variant)    TO <ls_vari>." Variant
    CHECK <ls_vari> IS ASSIGNED.

    ASSIGN (gv_set_tools)      TO <lt_tool>." excluding Function
    CHECK <lt_tool> IS ASSIGNED.

    ASSIGN (gv_set_fieldcat)   TO <lt_fieldcat>." Field Catalog
    CHECK <lt_fieldcat> IS ASSIGNED.

    ASSIGN (gv_set_sort)      TO <lt_sort>." sort Table
    CHECK <lt_sort> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.


    CALL METHOD <lo_alv_grid>->set_table_for_first_display
      EXPORTING
        is_layout                     = <ls_layout>
        i_save                        = 'A'
        i_default                     = 'X'
        is_variant                    = <ls_vari>
        it_toolbar_excluding          = <lt_tool>[]
      CHANGING
        it_outtab                     = <lt_table>[]
        it_fieldcatalog               = <lt_fieldcat>[]
        it_sort                       = <lt_sort>[]
      EXCEPTIONS
        invalid_parameter_combination = 1
        program_error                 = 2
        too_many_lines                = 3
        OTHERS                        = 4.

    CALL METHOD cl_gui_control=>set_focus
      EXPORTING
        control = <lo_alv_grid>.

    CALL METHOD cl_gui_cfw=>flush.

  ENDMETHOD.


METHOD EDIT_HEADER_P.

    DATA: lv_txt TYPE char100.

    CASE iv_dtype.
      WHEN 'N'. " Number.
        WRITE: iv_value TO lv_txt LEFT-JUSTIFIED NO-ZERO.

      WHEN 'D'. " 일자.
*        WRITE: iv_value TO lv_txt LEFT-JUSTIFIED USING EDIT MASK '____.__.__'.
        lv_txt = go_comfunc->ce_date_o( iv_value ).

      WHEN 'T'. " 시간.
        WRITE: iv_value TO lv_txt LEFT-JUSTIFIED USING EDIT MASK '__:__:__'.

      WHEN 'M'. " 년월
        WRITE: iv_value TO lv_txt LEFT-JUSTIFIED USING EDIT MASK '____.__'.

      WHEN OTHERS.
        lv_txt = iv_value.

    ENDCASE.

    rv_value = lv_txt.

  ENDMETHOD.


METHOD EDIT_HEADER_S.

    CONSTANTS:
      lc_text_parm1 TYPE txt70 VALUE '&1',
      lc_text_parm2 TYPE txt70 VALUE '&1 ~ &2'.

    DATA: lv_txt      TYPE string,
          lv_comma(2) TYPE c,
          lv_txt101   TYPE char100,
          lv_txt102   TYPE char100.

    FIELD-SYMBOLS:
      <lv_sign>   TYPE any,
      <lv_option> TYPE any,
      <lv_low>    TYPE any,
      <lv_high>   TYPE any,
      <ls_sel>    TYPE any.

    IF it_sel IS INITIAL.
      rv_txt = '*'.
      EXIT.
    ENDIF.

    CLEAR: rv_txt.

    LOOP AT it_sel ASSIGNING <ls_sel>.

      ASSIGN ('<LS_SEL>-SIGN') TO <lv_sign>.
      CHECK <lv_sign> IS ASSIGNED.
      ASSIGN ('<LS_SEL>-OPTION') TO <lv_option>.
      CHECK <lv_option> IS ASSIGNED.
      ASSIGN ('<LS_SEL>-LOW') TO <lv_low>.
      CHECK <lv_low> IS ASSIGNED.
      ASSIGN ('<LS_SEL>-HIGH') TO <lv_high>.
      CHECK <lv_high> IS ASSIGNED.

      lv_txt101 = me->edit_header_p( iv_value = <lv_low> iv_dtype = iv_opt ).
      IF <lv_high> IS NOT INITIAL.
        lv_txt102 = me->edit_header_p( iv_value = <lv_high> iv_dtype = iv_opt ).
      ENDIF.

      IF <lv_sign> = 'E' OR <lv_option> = 'NE'.
        CONCATENATE '(' lv_txt101 ')' INTO lv_txt101.
      ENDIF.

      IF lv_txt101 IS NOT INITIAL AND lv_txt102 IS INITIAL.
        lv_txt = lc_text_parm1.
      ELSE.
        lv_txt = lc_text_parm2.
      ENDIF.

      REPLACE '&1' IN lv_txt    WITH lv_txt101.
      REPLACE '&2' IN lv_txt    WITH lv_txt102  .

      CONCATENATE rv_txt lv_comma lv_txt INTO rv_txt.
      IF strlen( rv_txt ) > 230.
        EXIT.
      ENDIF.
      lv_comma = `, `.
    ENDLOOP.


  ENDMETHOD.


METHOD EXCLUDE_FUNCTIONS.

    DATA : lv_ui_func TYPE ui_func.

    lv_ui_func = iv_ui_func.

    APPEND lv_ui_func TO ct_table.

  ENDMETHOD.


METHOD EXCLUDE_FUNCTIONS_DEFAULT.

    CLEAR: rt_table.

    APPEND cl_gui_alv_grid=>mc_fc_graph             TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_info              TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_check             TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_refresh           TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_append_row    TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_cut           TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_copy          TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_undo          TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_paste_new_row TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_paste         TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_copy_row      TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_insert_row    TO rt_table.
    APPEND cl_gui_alv_grid=>mc_fc_loc_delete_row    TO rt_table.
*  APPEND cl_gui_alv_grid=>mc_fc_subtot            TO rt_table.
*  APPEND cl_gui_alv_grid=>mc_fc_sum               TO rt_table.
*  APPEND cl_gui_alv_grid=>mc_mb_subtot            TO rt_table.
*  APPEND cl_gui_alv_grid=>mc_mb_sum               TO rt_table.

*    me->exclude_functions(
*      EXPORTING
*        iv_ui_func = cl_gui_alv_grid=>mc_fg_edit
*      CHANGING
*        ct_table   = rt_table ).
*
*    me->exclude_functions(
*      EXPORTING
*        iv_ui_func = cl_gui_alv_grid=>mc_fc_info
*      CHANGING
*        ct_table   = rt_table ).
*
*    me->exclude_functions(
*      EXPORTING
*        iv_ui_func = cl_gui_alv_grid=>mc_fc_graph
*      CHANGING
*        ct_table   = rt_table ).
*
*    me->exclude_functions(
*      EXPORTING
*        iv_ui_func = cl_gui_alv_grid=>mc_fc_detail
*      CHANGING
*        ct_table   = rt_table ).
*
*    me->exclude_functions(
*      EXPORTING
*        iv_ui_func = cl_gui_alv_grid=>mc_fc_help
*      CHANGING
*        ct_table   = rt_table ).

  ENDMETHOD.


METHOD EXIT_ALV_SCREEN.

    FIELD-SYMBOLS:
      <lo_alv_dcon> TYPE REF TO cl_gui_docking_container,
      <lo_alv_ccon> TYPE REF TO cl_gui_custom_container,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_alvdcon) TO <lo_alv_dcon>.   " Docking

    ASSIGN (gv_set_alvccon) TO <lo_alv_ccon>.   " Customer

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    IF <lo_alv_grid> IS BOUND.
      IF <lo_alv_dcon> IS BOUND OR <lo_alv_ccon> IS BOUND.
        CALL METHOD <lo_alv_grid>->finalize.
        CALL METHOD <lo_alv_grid>->free.
      ENDIF.
      CLEAR: <lo_alv_grid>.
    ENDIF.

    IF <lo_alv_dcon> IS BOUND.
      CALL METHOD <lo_alv_dcon>->finalize.
      CALL METHOD <lo_alv_dcon>->free.
      CLEAR: <lo_alv_dcon>.
    ENDIF.

    IF <lo_alv_ccon> IS BOUND.
      CALL METHOD <lo_alv_ccon>->finalize.
      CALL METHOD <lo_alv_ccon>->free.
      CLEAR: <lo_alv_ccon>.
    ENDIF.

    CALL METHOD cl_gui_cfw=>flush.

  ENDMETHOD.


METHOD exit_program.

  DATA: lv_exit_alv_form TYPE txt40,
        lv_title         TYPE string,
        lv_text          TYPE string,
        ls_dynnr         TYPE ts_dynnr.

  FIELD-SYMBOLS:
     <lv_ok_code> TYPE any.

  ASSIGN (gv_set_okcode) TO <lv_ok_code>.
  CHECK <lv_ok_code> IS ASSIGNED.

  IF iv_save_flag = 'X'.
    DATA: lv_msg TYPE char1.
    lv_msg = iv_msg.
    IF lv_msg IS INITIAL.
      lv_msg = 'E'.
    ENDIF.

* 종료확인 메세지
    rv_exit_flag = go_comfunc->check_message( iv_msg = lv_msg ).

  ELSE.
    rv_exit_flag = 'X'.

  ENDIF.
  CHECK rv_exit_flag = abap_true.

  " 종료시 공통에서 처리 하지 않는, 프로그램마다 개별로 넣야 하는
  " 로직이 있는경우 FORM LUC_EXIT 을 만들어 사용한다.
*  IF rv_exit_flag = 'X'.
  PERFORM luc_exit IN PROGRAM (gv_repid) IF FOUND.
*  ENDIF.

*  종료인경우 프로그램 종료
*  CHECK ( <lv_ok_code> = gc_ok_exit      OR <lv_ok_code>  = gc_ok_canc_exit OR
*          <lv_ok_code> = gc_ok_back_exit OR  <lv_ok_code> = gc_ok_disp_exit   ) OR
*        rv_exit_flag = 'X'.

  me->exit_alv_screen( sy-dynnr ).

  LOOP AT it_dynnr INTO ls_dynnr WHERE main_dynnr = sy-dynnr.
    me->exit_alv_screen( ls_dynnr-sub_dynnr ).
  ENDLOOP.

  CALL METHOD cl_gui_cfw=>flush.

  " 종료 Button 실행시 프로그램 종료한다.
  IF <lv_ok_code> = gc_ok_exit.
    LEAVE PROGRAM.
  ENDIF.

ENDMETHOD.


METHOD F4_ALV_VARIANT.


    DATA: lv_exit,
          ls_variant           TYPE disvariant.

    CLEAR: ls_variant.
    ls_variant-report    = gv_repid.
    ls_variant-handle    = iv_handle.
    ls_variant-username  = sy-uname.

    CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
      EXPORTING
        is_variant = ls_variant
        i_save     = 'A'
      IMPORTING
        e_exit     = lv_exit
        es_variant = ls_variant
      EXCEPTIONS
        OTHERS     = 2.
    IF sy-subrc = 2.
      MESSAGE ID sy-msgid TYPE 'I'      NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ELSE.
      IF lv_exit = space.
        rv_variant = ls_variant-variant.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD GET_ALV_LAYOUT_DEFAULT.

    DATA: ls_variant      TYPE disvariant.

    CLEAR: ls_variant.
    ls_variant-report   = gv_repid.
    ls_variant-username = sy-uname.
    CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
      EXPORTING
        i_save     = 'A'
      CHANGING
        cs_variant = ls_variant
      EXCEPTIONS
        not_found  = 2.
    IF sy-subrc = 0.
      rv_variant = ls_variant-variant.
    ENDIF.

  ENDMETHOD.


METHOD GET_ELEMENTS.

    DATA: lo_clss_ref TYPE REF TO cl_abap_classdescr,
          lt_comp     TYPE cl_abap_structdescr=>component_table,
          ls_comp     LIKE LINE OF lt_comp,
          lt_comp_d   LIKE lt_comp,
          lt_comp_r   LIKE lt_comp,
          ls_comp_d   LIKE ls_comp,
          lo_stru_ref TYPE REF TO cl_abap_structdescr,
          lv_index    TYPE sy-index.

    lt_comp[] = it_comp[].
    LOOP AT lt_comp INTO ls_comp WHERE as_include <> space.
      lv_index = sy-tabix.

      DELETE lt_comp.
      lo_stru_ref ?= ls_comp-type.
      lt_comp_d = lo_stru_ref->get_components( ).            "Recursive Point

      IF ls_comp-suffix IS NOT INITIAL.
        LOOP AT lt_comp_d INTO ls_comp_d.

          IF ls_comp_d-as_include = space.
            CONCATENATE ls_comp_d-name ls_comp-suffix INTO ls_comp_d-name.
          ELSE.
            ls_comp_d-suffix = ls_comp-suffix.
          ENDIF.
          MODIFY lt_comp_d FROM ls_comp_d.

        ENDLOOP.
      ENDIF.

      lt_comp_r = me->get_elements( lt_comp_d ).

      LOOP AT lt_comp_r INTO ls_comp_d.

        CASE ls_comp-as_include.
          WHEN 'Y'. CONCATENATE ls_comp-name '-' ls_comp_d-name INTO ls_comp_d-name.
          WHEN OTHERS.
        ENDCASE.

        INSERT ls_comp_d INTO lt_comp INDEX lv_index.
        lv_index = lv_index + 1.

      ENDLOOP.
      CLEAR : ls_comp, lt_comp_r[].

    ENDLOOP.

    rt_comp = lt_comp.

  ENDMETHOD.


METHOD get_fieldcatalog.


  FIELD-SYMBOLS: <wa> TYPE any,
                 <cp> TYPE any.
  DATA: lo_sref        TYPE REF TO data.

  DATA: lo_stru_ele   TYPE REF TO cl_abap_structdescr,
        lo_stru_ref   TYPE REF TO cl_abap_structdescr,
        lo_stru_ref_t TYPE REF TO cl_abap_structdescr,
        lo_clss_ref   TYPE REF TO cl_abap_classdescr,
        lo_elem_ref   TYPE REF TO cl_abap_elemdescr,
        lo_tab_ref    TYPE REF TO cl_abap_tabledescr,
        lt_comp       TYPE cl_abap_structdescr=>component_table,
        lt_comp_      LIKE lt_comp,
        lt_comp_ele   LIKE lt_comp,
        ls_comp       LIKE LINE OF lt_comp,
        ls_comp_ele   LIKE LINE OF lt_comp_ele,
        lv_size       TYPE i,
        lv_index      TYPE i,
        lv_ind_comp   TYPE i,
        lv_typ1       TYPE string,
        lv_hlpid      TYPE string,
        lv_sname      TYPE string,
        ls_fcat       TYPE lvc_s_fcat,
        ls_dfies      TYPE dfies,
        lt_tab        TYPE TABLE OF string,
        lv_refstruct  TYPE swcontdef-refstruct,
        lv_reffield   TYPE swcontdef-reffield,
        ls_dd04v      TYPE dd04v,
        lv_len        TYPE i.

  DATA: lv_str TYPE string.

  lo_tab_ref  ?= cl_abap_typedescr=>describe_by_data( it_tab ).
  lo_stru_ref ?= lo_tab_ref->get_table_line_type( ).

*-- Check Reference
  lo_clss_ref ?= cl_abap_typedescr=>describe_by_object_ref( lo_stru_ref ).
  IF lo_clss_ref->get_relative_name( ) <> 'CL_ABAP_STRUCTDESCR'.
    RAISE not_a_structure.
  ENDIF.

*-- Recursive Search for Include.
  lt_comp_ = lo_stru_ref->get_components( ).
* Table Type ##
  LOOP AT lt_comp_ INTO ls_comp.
    lo_clss_ref ?= cl_abap_typedescr=>describe_by_object_ref( ls_comp-type ).
    IF lo_clss_ref->get_relative_name( ) = 'CL_ABAP_TABLEDESCR'.
      DELETE lt_comp_.
    ENDIF.

    " field 가 구조체 이면서 구조체 구분이 없는 것은
    IF lo_clss_ref->get_relative_name( ) = 'CL_ABAP_STRUCTDESCR' AND
       ls_comp-as_include = space.
      ls_comp-as_include = 'Y'.
      MODIFY lt_comp_ FROM ls_comp TRANSPORTING as_include.
    ENDIF.
  ENDLOOP.

  lt_comp  = me->get_elements( lt_comp_ ).

  lv_size = lines( lt_comp ).
  lv_sname = lo_stru_ref->absolute_name."get_relative_name( ).

*-- get memebers
  TRY .
      CREATE DATA lo_sref TYPE (lv_sname).
    CATCH cx_sy_create_data_error.
      CALL METHOD cl_abap_structdescr=>create
        EXPORTING
          p_components = lt_comp
        RECEIVING
          p_result     = lo_stru_ref_t.

      CREATE DATA lo_sref TYPE HANDLE lo_stru_ref_t.

  ENDTRY.
  ASSIGN lo_sref->* TO <wa>.

  CLEAR: lv_index.
  DO lv_size TIMES.

    lv_ind_comp = sy-index.

    DO.
      lv_index    = lv_index + 1.

      UNASSIGN <cp>.
      ASSIGN COMPONENT lv_index OF STRUCTURE <wa> TO <cp>.
      DESCRIBE FIELD: <cp> HELP-ID lv_hlpid,
                      <cp> TYPE lv_typ1.

      CASE lv_typ1.
        WHEN 'h'.
        WHEN OTHERS.        EXIT.
      ENDCASE.
    ENDDO.

    " XXX-VVV, VVV, SPACE
    SPLIT lv_hlpid AT '-' INTO TABLE lt_tab.
    lv_len = lines( lt_tab ).
    READ TABLE lt_comp INTO ls_comp INDEX lv_ind_comp.
    CHECK sy-subrc = 0.

    CASE lv_len.
      WHEN 2.     "struct + field
        READ TABLE lt_tab INTO lv_refstruct INDEX 1.
        READ TABLE lt_tab INTO lv_reffield  INDEX 2.

        " field 의 정보를 가지고 온다.
        CALL METHOD me->get_field_info
          EXPORTING
            iv_tabname           = lv_refstruct
            iv_fieldname         = lv_reffield
            iv_langu             = sy-langu
          IMPORTING
*           es_dfies             = ls_dfies
            es_fcat              = ls_fcat
          EXCEPTIONS
            field_info_not_found = 1
            OTHERS               = 2.
        IF sy-subrc = 0.
          ls_fcat-tabname   = space.
          ls_fcat-fieldname = ls_comp-name.
          APPEND ls_fcat TO rt_fieldcatalog.
*            MOVE-CORRESPONDING ls_dfies TO ls_fcat.
*
*            " field label 이 없는 경우
*            IF ls_fcat-reptext IS INITIAL AND ls_dfies-fieldtext IS INITIAL.
*              SELECT SINGLE ddtext
*                FROM dd03t
*                INTO ls_fcat-reptext
*               WHERE tabname    = lv_refstruct
*                 AND ddlanguage = sy-langu
*                 AND as4local   = 'A'
*                 AND fieldname  = lv_reffield.
*              IF sy-subrc NE 0.
*                ls_fcat-reptext = lv_hlpid.
*              ENDIF.
*
*              ls_fcat-scrtext_l = ls_fcat-scrtext_m =
**              ls_fcat-scrtext_s = ls_fcat-coltext   = ls_fcat-reptext.
*              ls_fcat-scrtext_s = ls_fcat-reptext.
*
*            ELSEIF ls_dfies-fieldtext IS NOT INITIAL.
*              ls_fcat-scrtext_l = ls_fcat-scrtext_m =
**              ls_fcat-scrtext_s = ls_fcat-coltext   = ls_dfies-fieldtext.
*              ls_fcat-scrtext_s = ls_dfies-fieldtext.
*            ENDIF.
*
**       Data Type : Currency, Quanitity  Field
*            CASE ls_dfies-datatype.
*              WHEN 'INT4'.
*                ls_fcat-inttype = 'I'.
*              WHEN 'CURR' OR 'QUAN'.
*                READ TABLE lt_comp WITH KEY name = ls_dfies-reffield
*                     TRANSPORTING NO FIELDS.
*                IF sy-subrc = 0.
*                  CASE ls_dfies-datatype.
*                    WHEN 'CURR' .
*                      ls_fcat-cfieldname = ls_dfies-reffield.
*                    WHEN 'QUAN'.
*                      ls_fcat-qfieldname = ls_dfies-reffield.
*                  ENDCASE.
*                ENDIF.
*            ENDCASE.
*
*            ls_fcat-ref_table = lv_refstruct.
*            ls_fcat-ref_field = lv_reffield.
*            ls_fcat-tabname   = space.
*            ls_fcat-fieldname = ls_comp-name.
*
*            APPEND ls_fcat TO rt_fieldcatalog.
        ELSE.
          RAISE no_ddic.
        ENDIF.

      WHEN 1.   "DataElement
        READ TABLE lt_tab INTO lv_reffield INDEX 1.

        CALL FUNCTION 'DDIF_DTEL_GET'
          EXPORTING
            name          = lv_reffield
*           STATE         = 'A'
            langu         = sy-langu
          IMPORTING
*           GOTSTATE      =
            dd04v_wa      = ls_dd04v
*           TPARA_WA      =
          EXCEPTIONS
            illegal_input = 1
            OTHERS        = 2.

        IF sy-subrc = 0.
          MOVE-CORRESPONDING ls_dd04v TO ls_fcat.

          ls_fcat-reptext   = ls_fcat-scrtext_l =
          ls_fcat-scrtext_m = ls_fcat-scrtext_s = ls_dd04v-ddtext.
*            ls_fcat-coltext   = ls_dd04v-ddtext.
          ls_fcat-ref_table = ''.
          ls_fcat-tabname   = ''.
          ls_fcat-fieldname = ls_comp-name.

          IF ls_dd04v-shlpname IS NOT INITIAL.
            ls_fcat-f4availabl = 'X'.
          ENDIF.

          APPEND ls_fcat      TO rt_fieldcatalog.
        ELSE.
          RAISE no_ddic.
        ENDIF.

*    ELSEIF LV_LEN = 0 AND I_CFIELD = 'X'.    "Custom Field
      WHEN OTHERS.

        CASE ls_comp-type->kind.
          WHEN 'S'.   " Structure..
            lo_stru_ele ?= ls_comp-type.
            lt_comp_ele = lo_stru_ele->get_components( ).
            LOOP AT lt_comp_ele INTO ls_comp_ele.
              lo_elem_ref ?= ls_comp_ele-type.
              CONCATENATE ls_comp-name '-' ls_comp_ele-name INTO ls_fcat-fieldname.

              ls_fcat-inttype   = lo_elem_ref->type_kind.
              ls_fcat-intlen    = lo_elem_ref->length.
              ls_fcat-decimals  = ls_fcat-decimals_o = lo_elem_ref->decimals.
              ls_fcat-outputlen = lo_elem_ref->output_length.
              APPEND ls_fcat   TO rt_fieldcatalog.
            ENDLOOP.
*              lt_comp_ele  = ls_comp-type->

          WHEN 'T'.   " Table.

          WHEN OTHERS.
            lo_elem_ref ?= ls_comp-type.
            ls_fcat-fieldname = ls_comp-name.

            ls_fcat-inttype   = lo_elem_ref->type_kind.
            ls_fcat-intlen    = lo_elem_ref->length.
            ls_fcat-decimals  = ls_fcat-decimals_o = lo_elem_ref->decimals.
            ls_fcat-outputlen = lo_elem_ref->output_length.
            APPEND ls_fcat   TO rt_fieldcatalog.
        ENDCASE.
    ENDCASE.

    CLEAR: ls_fcat, ls_comp, lv_reffield, lv_refstruct, ls_dd04v, ls_dfies, lo_elem_ref, lt_tab[].

  ENDDO.

  " Col pos 를 '999'로 변경한다.
  ls_fcat-col_pos = '999'.
  MODIFY rt_fieldcatalog FROM ls_fcat
         TRANSPORTING col_pos
         WHERE col_pos <> ls_fcat-col_pos.

  " check Table 변경
  ls_fcat-checktable = '!'.
  MODIFY rt_fieldcatalog FROM ls_fcat
         TRANSPORTING checktable
         WHERE checktable <> space.

ENDMETHOD.


METHOD get_field_info.

  DATA: lv_tabname           TYPE ddobjname,
        lv_fieldname         TYPE dfies-fieldname,
        ls_dfies             TYPE dfies,
        ls_table_header_info TYPE x030l,
        ls_dd02l             TYPE dd02l,
        ls_fcat              TYPE lvc_s_fcat,
        lt_dfies             TYPE TABLE OF dfies.

  CLEAR: es_fcat.

  IF iv_tabname IS INITIAL OR iv_fieldname IS INITIAL.
    RAISE field_info_not_found.
  ENDIF.

  DATA(lv_langu) = COND sylangu( WHEN iv_langu IS INITIAL THEN sy-langu
                                                          ELSE iv_langu
                               ).

  CLEAR: ls_dfies.
  lv_tabname   = iv_tabname.    "type conversion
  lv_fieldname = iv_fieldname.  "type conversion

  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname        = lv_tabname
      fieldname      = lv_fieldname
      langu          = lv_langu
      all_types      = 'X'
    IMPORTING
      x030l_wa       = ls_table_header_info
    TABLES
      dfies_tab      = lt_dfies[]
    EXCEPTIONS
      not_found      = 01
      internal_error = 02
      OTHERS         = 99.

  IF sy-subrc NE 0.

    " 입력받은 Table 의 정보를 가지고 온다.
    " TABCLASS 조회 (DD02L + CDS VIEW 대응)
    CLEAR: ls_dd02l.
    SELECT SINGLE tabclass
      FROM dd02l
     WHERE tabname  = @lv_tabname
       AND as4local = 'A'
      INTO @ls_dd02l-tabclass.
    IF sy-subrc <> 0.
      SELECT SINGLE 'VIEW'
        FROM ddldependency
       WHERE objectname = @lv_tabname
         AND state      = 'A'
        INTO @ls_dd02l-tabclass.
    ENDIF.

    CASE ls_dd02l-tabclass.
      WHEN 'INTTAB' OR 'APPEND'.

        SELECT SINGLE
               l3~tabname       AS tabname,
               l3~fieldname     AS fieldname,
               l4~rollname      AS rollname,
               l1~domname       AS domname,
               l3~position      AS position,
               l3~keyflag       AS keyflag,
               l3~checktable    AS checktable,
               l3~inttype       AS inttype,
               l3~intlen        AS intlen,
               l3~reftable      AS reftable,
               l3~precfield     AS precfield,
               l3~reffield      AS reffield,
               l4~memoryid      AS memoryid,
               l4~logflag       AS logflag,
               l4~headlen       AS headlen,
               l4~scrlen1       AS scrlen1,
               l4~scrlen2       AS scrlen2,
               l4~scrlen3       AS scrlen3,
               l1~datatype      AS datatype,
               l1~leng          AS leng,
               l1~outputlen     AS outputlen,
               l1~decimals      AS decimals,
               l1~lowercase     AS lowercase,
               l1~valexi        AS valexi,
               l1~convexit      AS convexit,
               l1~mask          AS mask,
               l1~masklen       AS masklen,
               t4~ddtext        AS fieldtext,
               t4~reptext       AS reptext,
               t4~scrtext_s     AS scrtext_s,
               t4~scrtext_m     AS scrtext_m,
               t4~scrtext_l     AS scrtext_l
          FROM dd03l AS l3
               INNER JOIN dd04l AS l4 ON  l4~rollname   = l3~rollname
               INNER JOIN dd04t AS t4 ON  t4~rollname   = l3~rollname
                                      AND t4~ddlanguage = @lv_langu
               INNER JOIN dd01l AS l1 ON  l1~domname    = l4~domname
         WHERE l3~tabname    = @ls_dfies-tabname
           AND l3~fieldname  = @ls_dfies-fieldname
          INTO CORRESPONDING FIELDS OF @ls_dfies.

        IF sy-subrc NE 0.
          RAISE field_info_not_found.
        ENDIF.

      WHEN OTHERS.
        RAISE field_info_not_found.

    ENDCASE.

  ELSE.
*   now read the field info for the requested field
    READ TABLE lt_dfies[] WITH KEY fieldname = lv_fieldname
       INTO ls_dfies.
    IF sy-subrc NE 0.
      CLEAR: ls_dfies.
    ENDIF.
  ENDIF.

  CHECK ls_dfies IS NOT INITIAL.
  MOVE-CORRESPONDING ls_dfies TO ls_fcat.
  MOVE-CORRESPONDING ls_dfies TO es_dfies.

  " field label 이 없는 경우
  IF ls_fcat-reptext IS INITIAL AND ls_dfies-fieldtext IS INITIAL.
    SELECT SINGLE ddtext
      FROM dd03t
      INTO ls_fcat-reptext
     WHERE tabname    = lv_tabname
       AND ddlanguage = sy-langu
       AND as4local   = 'A'
       AND fieldname  = lv_fieldname.
    IF sy-subrc NE 0.
      ls_fcat-reptext = |{ lv_tabname }-{ lv_fieldname }|.
    ENDIF.

    ls_fcat-coltext   =
    ls_fcat-scrtext_l = ls_fcat-scrtext_m =
*              ls_fcat-scrtext_s = ls_fcat-coltext   = ls_fcat-reptext.
    ls_fcat-scrtext_s = ls_fcat-reptext.

  ELSEIF ls_dfies-fieldtext IS NOT INITIAL.
    ls_fcat-coltext   =
    ls_fcat-scrtext_l = ls_fcat-scrtext_m =
*              ls_fcat-scrtext_s = ls_fcat-coltext   = ls_dfies-fieldtext.
    ls_fcat-scrtext_s = ls_dfies-fieldtext.
  ENDIF.

*       Data Type : Currency, Quanitity  Field
  CASE ls_dfies-datatype.
    WHEN 'INT4'.
      ls_fcat-inttype = 'I'.
    WHEN 'CURR' OR 'QUAN'.
      CASE ls_dfies-datatype.
        WHEN 'CURR' .
          ls_fcat-cfieldname = ls_dfies-reffield.
        WHEN 'QUAN'.
          ls_fcat-qfieldname = ls_dfies-reffield.
      ENDCASE.
  ENDCASE.

  ls_fcat-ref_table = lv_tabname.
  ls_fcat-ref_field = lv_fieldname.
  ls_fcat-tabname   = space.
  ls_fcat-fieldname = space.

  es_fcat = ls_fcat.

ENDMETHOD.


METHOD get_first_rows.

  DATA: ls_row  TYPE lvc_s_row,
        lt_rows TYPE lvc_t_row.

  CLEAR: rv_index.
  lt_rows = me->get_rows( io_grid    = io_grid
                          iv_msg     = iv_msg
                          iv_message = iv_message
                        ).

  IF lt_rows[] IS INITIAL.
    " Please select the line.
    CASE iv_msg.
      WHEN 'X'.    MESSAGE s539(zmdm01) DISPLAY LIKE 'E'. " 선택된 라인이 없습니다..
      WHEN OTHERS.
    ENDCASE.

    IF iv_message IS NOT INITIAL.
      MESSAGE s000(zmdm01) WITH iv_message DISPLAY LIKE 'E'.
    ENDIF.

  ELSEIF lines( lt_rows ) > 1.
    " 1개 라인만 선택 하십시오.
    CASE iv_msg.
      WHEN 'X'.    MESSAGE s538(zmdm01) DISPLAY LIKE 'E'.
      WHEN OTHERS.
        READ TABLE lt_rows INTO ls_row INDEX 1.
        CHECK sy-subrc = 0.
        rv_index = ls_row-index.

    ENDCASE.

  ELSE.
    READ TABLE lt_rows INTO ls_row INDEX 1.
    CHECK sy-subrc = 0.
    rv_index = ls_row-index.
  ENDIF.

ENDMETHOD.


METHOD GET_LAYOUT_DEFAULT.


    DATA: ls_variant      TYPE disvariant.

    CLEAR: ls_variant.
    ls_variant-report   = gv_repid.
    ls_variant-handle   = iv_handle.
    ls_variant-username = sy-uname.

    CALL FUNCTION 'REUSE_ALV_VARIANT_DEFAULT_GET'
      EXPORTING
        i_save     = 'A'
      CHANGING
        cs_variant = ls_variant
      EXCEPTIONS
        not_found  = 2.
    IF sy-subrc = 0.
      rv_variant = ls_variant-variant.
    ELSE.
      CLEAR: rv_variant.
    ENDIF.

  ENDMETHOD.


METHOD get_rows.

  CLEAR : rt_rows[].

  CHECK sy-batch = space.

  CALL METHOD io_grid->get_selected_rows
    IMPORTING
      et_index_rows = rt_rows.

  IF rt_rows[] IS INITIAL.
    CASE iv_msg.
        " Please select the line.
      WHEN 'X'.
        MESSAGE s539(zmdm01) DISPLAY LIKE 'E'. " 선택된 라인이 없습니다..
      WHEN 'I'.
        MESSAGE i539(zmdm01). " 선택된 라인이 없습니다..
      WHEN OTHERS.
        IF iv_message IS NOT INITIAL.
          MESSAGE s000(zmdm01) WITH iv_message DISPLAY LIKE 'E'.
        ENDIF.
    ENDCASE.
  ELSE.
    SORT rt_rows BY index.
    DELETE ADJACENT DUPLICATES FROM rt_rows
           COMPARING index.
  ENDIF.

ENDMETHOD.


METHOD GET_SELSCR_FIELDS.

    DATA: lv_idx              TYPE sy-tabix,
          lv_pos              TYPE i,
          lv_len              TYPE i,
          lv_gubun            TYPE fieldname,
          lv_fieldname        TYPE fieldname,
          lv_screen_name      TYPE scrfname,
          lv_screen_txt       TYPE scrfname,
          lv_line             TYPE screen-group4,
          ls_selscr_field     TYPE ts_selscr_field,
          ls_selscr_field_tmp TYPE ts_selscr_field,
          lt_selscr_field     TYPE TABLE OF ts_selscr_field
                              WITH NON-UNIQUE SORTED KEY zi01
                                   COMPONENTS pos.

    DATA: ls_screen_info    TYPE zmdmmms9050,
          ls_cur_screen     TYPE zmdmmms9040,
          ls_cur_screen_tmp TYPE zmdmmms9040,
          lt_cur_screen     TYPE TABLE OF zmdmmms9040.

    DATA: BEGIN OF ls_id,
            p TYPE progname,
            d TYPE sydynnr,
          END OF ls_id.

*        lv_dummy TYPE string,
*        BEGIN OF ls_scr_fld,
*          fnam TYPE d021s-fnam,
*          line TYPE d021s-line,
*          fill TYPE d021s-fill,
*          ityp TYPE d021s-ityp,
*        END OF ls_scr_fld,
*        lt_scr_fld LIKE TABLE OF ls_scr_fld.

    DATA: ls_header    TYPE d020s,
          ls_fields    TYPE d021s,
          lt_fields    TYPE TABLE OF d021s,
          lt_logics    TYPE TABLE OF d022s,
          lt_matchcode TYPE TABLE OF d023s.

    FIELD-SYMBOLS:
      <lv_scrname> TYPE any,
      <lv_txt>     TYPE any.

    ls_id-p = gv_repid.
    ls_id-d = sy-dynnr.
    IMPORT DYNPRO ls_header lt_fields lt_logics lt_matchcode ID ls_id.
    CHECK sy-subrc = 0.

    CLEAR: lt_cur_screen, ls_cur_screen, gt_selscr_field.

*  LOOP AT lt_fields INTO DATA(ls_field).
*
*    CLEAR: ls_scr_fld.
*    CASE ls_field-grp3.
*      WHEN 'PAR'. ls_scr_fld-fnam = ls_field-fnam.
*      WHEN 'LOW'. SPLIT ls_field-fnam AT '-' INTO ls_scr_fld-fnam lv_dummy.
*      WHEN OTHERS. CONTINUE.
*    ENDCASE.
*
*    ls_scr_fld-line = ls_field-line.
*    ls_scr_fld-fill = ls_field-fill.
*    ls_scr_fld-ityp = ls_field-ityp.
*    APPEND ls_scr_fld TO lt_scr_fld.
*
*
*  ENDLOOP.

    LOOP AT SCREEN.

      CHECK screen-active = '1'.
      CHECK screen-group3 IS NOT INITIAL.
      CHECK screen-group3 <> 'BLK'.

      READ TABLE lt_fields INTO ls_fields WITH KEY fnam = screen-name.
      CHECK sy-subrc = 0.

      READ TABLE lt_cur_screen INTO ls_cur_screen WITH KEY group4 = screen-group4.
      IF sy-subrc NE 0.
        CLEAR: ls_cur_screen.
        ls_cur_screen-line    = ls_fields-line.
        IF ls_fields-fill = 'C'.
          ls_cur_screen-ftype  = 'CHK'.
        ENDIF.
        ls_cur_screen-group4 = screen-group4.

        CLEAR: ls_screen_info.
        ls_screen_info-screen = screen.
        ls_screen_info-dtype  = ls_fields-ityp.
        APPEND ls_screen_info TO ls_cur_screen-screen.

        APPEND ls_cur_screen TO lt_cur_screen.
      ELSE.
        CLEAR: ls_screen_info.
        ls_screen_info-screen = screen.
        ls_screen_info-dtype  = ls_fields-ityp.
        APPEND ls_screen_info TO ls_cur_screen-screen.
        MODIFY lt_cur_screen FROM ls_cur_screen
               TRANSPORTING screen
               WHERE group4 = screen-group4.
      ENDIF.

    ENDLOOP.

*****  LOOP AT SCREEN.
*****
*****    CHECK screen-active = '1'.
*****    CHECK screen-group3 IS NOT INITIAL.
*****    CHECK screen-group3 <> 'BLK'.
*****
******      CHECK screen-group4 IS NOT INITIAL.
*****
*****    " line 정보
*****    " 선행 text 정보가 있는지 여부
*****    READ TABLE lt_fields INTO ls_fields WITH KEY fnam = screen-name.
*****    CHECK sy-subrc = 0.
*****
*****    IF ls_cur_screen-line <> ls_fields-line OR ls_fields-fill = 'C'.
*****      IF ls_cur_screen-line IS NOT INITIAL.
*****        IF ls_fields-fill = 'C'.
*****          ls_cur_screen-ftype  = 'CHK'.
*****          ls_cur_screen-group4 = screen-group4.
*****
*****          CLEAR: ls_screen_info.
*****          ls_screen_info-screen = screen.
*****          ls_screen_info-dtype  = ls_fields-ityp.
*****          APPEND ls_screen_info TO ls_cur_screen-screen.
*****        ENDIF.
*****        APPEND ls_cur_screen TO lt_cur_screen.
*****        CLEAR: ls_cur_screen.
*****      ENDIF.
*****      ls_cur_screen-line = ls_fields-line.
*****      IF ls_fields-fill = 'C'.
*****        CONTINUE.
*****      ENDIF.
*****    ENDIF.
*****
*****    CLEAR: ls_screen_info.
*****    ls_screen_info-screen = screen.
*****    ls_screen_info-dtype  = ls_fields-ityp.
*****
*****    " 이미 등록된 라인인지 확인 한다
*****    READ TABLE lt_cur_screen INTO ls_cur_screen_tmp WITH KEY line   = ls_fields-line
*****                                                             group4 = screen-group4.
*****    IF sy-subrc = 0.
*****      lv_idx = sy-tabix.
*****      APPEND ls_screen_info TO ls_cur_screen_tmp-screen.
*****      MODIFY lt_cur_screen FROM ls_cur_screen_tmp INDEX lv_idx.
*****    ELSE.
*****      APPEND ls_screen_info TO ls_cur_screen-screen.
*****    ENDIF.
*****  ENDLOOP.
*****  IF ls_cur_screen-line IS NOT INITIAL AND ls_cur_screen-screen[] IS NOT INITIAL.
*****    APPEND ls_cur_screen TO lt_cur_screen.
*****  ENDIF.

    " 불필요한 정보 삭제
    LOOP AT lt_cur_screen INTO ls_cur_screen.
      lv_idx = sy-tabix.
      CHECK ls_cur_screen-ftype = 'CHK'.
      DELETE ls_cur_screen-screen WHERE group3 = 'COM'.
      MODIFY lt_cur_screen FROM ls_cur_screen INDEX lv_idx.
    ENDLOOP.

    CLEAR: ls_selscr_field, gt_selscr_field, gv_selscr_max_len,
           gt_selscr_rbg. " 이후 지정되는 field table clear

    CLEAR: lv_pos.

    CONCATENATE `(` gv_repid `)SCREEN-NAME` INTO lv_screen_name .
    LOOP AT lt_cur_screen INTO ls_cur_screen.

      CLEAR  ls_selscr_field.

      LOOP AT ls_cur_screen-screen INTO ls_screen_info.

        screen = ls_screen_info-screen.

        UNASSIGN: <lv_scrname>, <lv_txt>.
        ASSIGN (lv_screen_name) TO <lv_scrname>.
        IF <lv_scrname> IS ASSIGNED.
          CONCATENATE `(` gv_repid `)` <lv_scrname> INTO lv_screen_txt .
          ASSIGN (lv_screen_txt)   TO <lv_txt>.
        ENDIF.
        CHECK screen-active = '1'.
        CHECK <lv_txt> IS ASSIGNED.

        CASE screen-group3.
          WHEN 'TXT' OR 'COM' OR 'COF'.
            IF ls_selscr_field-title IS INITIAL.
              MOVE <lv_txt>       TO ls_selscr_field-title.
            ELSE.
              MOVE <lv_txt>       TO ls_selscr_field-text.
            ENDIF.
            MOVE ls_cur_screen-line   TO ls_selscr_field-pos.

          WHEN 'PAR'.
            IF ls_selscr_field-fname IS INITIAL.
              MOVE: screen-name      TO ls_selscr_field-fname,
                    screen-group3    TO ls_selscr_field-ftype,
                    screen-group4    TO ls_selscr_field-fseq.

            ELSEIF ls_selscr_field-fname2 IS INITIAL.
              MOVE: screen-name      TO ls_selscr_field-fname2.

            ELSEIF ls_selscr_field-fname3 IS INITIAL.
              MOVE: screen-name      TO ls_selscr_field-fname3.

            ENDIF.

            MOVE ls_screen_info-dtype TO ls_selscr_field-dtype.
            MOVE ls_cur_screen-line   TO ls_selscr_field-pos.

          WHEN 'LOW'.
            SPLIT screen-name AT '-' INTO lv_fieldname lv_gubun.
            MOVE lv_fieldname          TO ls_selscr_field-fname.
            MOVE screen-group3         TO ls_selscr_field-ftype.
            MOVE ls_screen_info-dtype  TO ls_selscr_field-dtype.
            MOVE ls_cur_screen-line    TO ls_selscr_field-pos.

        ENDCASE.
      ENDLOOP.
      APPEND ls_selscr_field TO gt_selscr_field.

    ENDLOOP.

    " 라인별 정리
    lt_selscr_field = gt_selscr_field.
    SORT gt_selscr_field BY pos.
    DELETE ADJACENT DUPLICATES FROM gt_selscr_field
           COMPARING pos.
    LOOP AT gt_selscr_field ASSIGNING FIELD-SYMBOL(<ls_selscr_field>).

      DATA(lt_selscr_field_tmp) = FILTER #( lt_selscr_field USING KEY zi01
                                                            WHERE pos = <ls_selscr_field>-pos
                                          ).
      CHECK lines( lt_selscr_field_tmp ) > 1.
      SORT lt_selscr_field_tmp BY fseq.
      LOOP AT lt_selscr_field_tmp INTO ls_selscr_field FROM 2.

        IF <ls_selscr_field>-fname IS INITIAL.
          MOVE: ls_selscr_field-fname      TO <ls_selscr_field>-fname,
                ls_selscr_field-ftype      TO <ls_selscr_field>-ftype,
                ls_selscr_field-fseq       TO <ls_selscr_field>-fseq,
                ls_screen_info-dtype       TO <ls_selscr_field>-dtype.

        ELSEIF <ls_selscr_field>-fname2 IS INITIAL.
          MOVE: ls_selscr_field-fname      TO <ls_selscr_field>-fname2.

        ELSEIF <ls_selscr_field>-fname3 IS INITIAL.
          MOVE: ls_selscr_field-fname      TO <ls_selscr_field>-fname3.

        ENDIF.

        IF ls_selscr_field-title IS NOT INITIAL AND
           <ls_selscr_field>-text IS INITIAL.
          MOVE: ls_selscr_field-title TO <ls_selscr_field>-text.
        ENDIF.

      ENDLOOP.
    ENDLOOP.

    " pos 가 없는것은 삭제
    DELETE gt_selscr_field WHERE pos = 0.

    " selection screen field title의 최대길이 산출
    me->set_selscr_max_len( ).

  ENDMETHOD.


METHOD INSERT_CELLCOLOR.

    " color
    "  1 = blue,      2 = gray,     3 = yellow
    "  4 = blue/gray, 5 = green,    6 = red
    "  7 = orange

    DATA: lv_fieldname TYPE fieldname,
          ls_cellcolor TYPE lvc_s_scol.

    CHECK ( iv_color IS NOT INITIAL AND iv_fieldname IS NOT INITIAL ) OR
            it_cellcolor IS NOT INITIAL.

    " field정보가 입력된 경우
    IF iv_fieldname IS NOT INITIAL.
      lv_fieldname =  iv_fieldname .

      " 기존 등록된 정보가 있는 경우 삭제 한다.
      DELETE ct_cellcolor WHERE fname = lv_fieldname.

      ls_cellcolor-fname      = lv_fieldname.
      ls_cellcolor-color-col  = iv_color.
      ls_cellcolor-color-int  = iv_intensified.
      ls_cellcolor-color-inv  = iv_inverse.
      INSERT ls_cellcolor INTO TABLE ct_cellcolor.
    ENDIF.

    " table 정보가 입력된 경우
    LOOP AT it_cellcolor INTO ls_cellcolor .
      " 기존 등록된 정보가 있는 경우 삭제 한다.
      DELETE ct_cellcolor WHERE fname = ls_cellcolor-fname.
      INSERT ls_cellcolor INTO TABLE ct_cellcolor.
    ENDLOOP.

  ENDMETHOD.


METHOD INSERT_CELLTAB.


    DATA: lv_fieldname TYPE fieldname,
          ls_celltab   TYPE lvc_s_styl.

    CHECK ( iv_style IS NOT INITIAL AND iv_fieldname IS NOT INITIAL ) OR
          it_celltab IS NOT INITIAL.

    IF iv_fieldname IS NOT INITIAL.
      lv_fieldname =  iv_fieldname .

      " 기존 등록된 정보가 있는 경우 삭제 한다.
      DELETE ct_celltab WHERE fieldname = lv_fieldname.

      ls_celltab-fieldname      = lv_fieldname.
      CASE iv_style.
        WHEN 'B'. ls_celltab-style = cl_gui_alv_grid=>mc_style_button.
        WHEN 'D'. ls_celltab-style = cl_gui_alv_grid=>mc_style_disabled.
        WHEN 'E'. ls_celltab-style = cl_gui_alv_grid=>mc_style_enabled.
      ENDCASE.
      INSERT ls_celltab INTO TABLE ct_celltab.
    ENDIF.

    LOOP AT it_celltab INTO ls_celltab .
      " 기존 등록된 정보가 있는 경우 삭제 한다.
      DELETE ct_celltab WHERE fieldname = ls_celltab-fieldname.
      INSERT ls_celltab INTO TABLE ct_celltab.
    ENDLOOP.

  ENDMETHOD.


METHOD NEW_ADD_COLUMN.

    " text or icon
    IF iv_icon_first IS INITIAL.
      IF iv_text IS INITIAL.
        EXIT.
      ENDIF.

      CALL METHOD co_tarea->add_text
        EXPORTING
          text         = CONV sdydo_text_element( iv_text )
          sap_fontsize = cl_dd_area=>medium.

      " column 의 폭을 설정한다
      ADD 1   TO co_col_no.
      CALL METHOD co_tarea->set_column_width
        EXPORTING
          col_no = co_col_no
          width  = CONV sdydo_value( iv_text_width ).

      IF iv_icon IS NOT INITIAL.
        CALL METHOD co_tarea->add_icon
          EXPORTING
            sap_icon = CONV iconname( iv_icon )
            sap_size = cl_dd_area=>medium.

        " column 의 폭을 설정한다
        ADD 1   TO co_col_no.
        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = co_col_no
            width  = CONV sdydo_value( iv_icon_width ).
      ENDIF.

    ELSE.
      IF iv_icon IS INITIAL.
        EXIT.
      ENDIF.

      CALL METHOD co_tarea->add_icon
        EXPORTING
          sap_icon = CONV iconname( iv_icon )
          sap_size = cl_dd_area=>medium.

      " column 의 폭을 설정한다
      ADD 1   TO co_col_no.
      CALL METHOD co_tarea->set_column_width
        EXPORTING
          col_no = co_col_no
          width  = CONV sdydo_value( iv_icon_width ).

      IF iv_text IS NOT INITIAL.
        CALL METHOD co_tarea->add_text
          EXPORTING
            text         = CONV sdydo_text_element( iv_text )
            sap_fontsize = cl_dd_area=>medium.

        " column 의 폭을 설정한다
        ADD 1   TO co_col_no.
        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = co_col_no
            width  = CONV sdydo_value( iv_text_width ).
      ENDIF.

    ENDIF.

  ENDMETHOD.


METHOD NEW_ADD_LINE.

    DATA: lv_pos    TYPE i,
          lv_len    TYPE i,
          lv_space  TYPE sychar02,
          lv_text   TYPE sdydo_text_element,
          lv_textd  TYPE sdydo_text_element,
          lv_txt101 TYPE string,
          lv_txt102 TYPE string.

    lv_space = go_comfunc->get_uc_text( go_comfunc->gc_type_x00a0 ).

    " title
    lv_text  = iv_title.

    lv_len = go_comfunc->strlenx( lv_text ).
    WHILE lv_len <= iv_maxlen .
      ADD 1  TO lv_len.
      CONCATENATE lv_text lv_space INTO lv_text.
    ENDWHILE.

    lv_pos = go_comfunc->strlenx( lv_text ).
    lv_text+lv_pos(1) = ':'.

    CALL METHOD co_tarea->add_text
      EXPORTING
        text         = lv_text
        sap_fontsize = cl_dd_area=>medium.

    " text or icon
    IF iv_text IS NOT INITIAL.
      CALL METHOD co_tarea->add_text
        EXPORTING
          text         = CONV sdydo_text_element( iv_text )
          sap_fontsize = cl_dd_area=>medium.

    ELSEIF iv_icon IS NOT INITIAL.
      CALL METHOD co_tarea->add_icon
        EXPORTING
          sap_icon = CONV iconname( iv_icon )
          sap_size = cl_dd_area=>medium.
    ENDIF.

    CALL METHOD co_tarea->new_row.

  ENDMETHOD.


METHOD NEW_HEADER_INIT.

    " Table 을 선언한다.
    CALL METHOD io_docu->add_table
      EXPORTING
        no_of_columns      = 2
        border             = iv_border " '0' " 선표시 하지 않음
        width              = '100%'
      IMPORTING
*       table              = co_tab
        tablearea          = co_tarea
      EXCEPTIONS
        table_already_used = 1.

    " column 의 폭을 설정한다
    CALL METHOD co_tarea->set_column_width
      EXPORTING
        col_no = 1
        width  = iv_width_col1.

    CALL METHOD co_tarea->set_column_width
      EXPORTING
        col_no = 2
        width  = iv_width_col2.


  ENDMETHOD.


METHOD REFRESH_GRID.


    DATA: lv_soft_refresh,
          ls_stbl         TYPE lvc_s_stbl.

    FIELD-SYMBOLS:
      <lv_no_refresh>    TYPE any,
      <lv_error_in_data> TYPE any,
      <ls_layout>        TYPE lvc_s_layo,
      <lo_alv_grid>      TYPE REF TO cl_gui_alv_grid.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_layout)     TO <ls_layout>." Layout
    CHECK <ls_layout> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    ASSIGN (gv_set_no_refresh) TO <lv_no_refresh>.    " gv_no_refresh
    ASSIGN (gv_set_error_data) TO <lv_error_in_data>. " gv_error_in_data

*  if gs_set_cursor-is_set = 'X'.
*    clear: gt_cells, gs_cells.
*    loop at gs_set_cursor-fields into gs_set_field.
*      gs_cells-col_id-fieldname = gs_set_field-field.
*      gs_cells-row_id-index     = gs_set_field-line.
*      append gs_cells to gt_cells.
*    endloop.
*    call method &1->set_selected_cells
*      exporting
*        it_cells = gt_cells.
*    clear: gs_set_cursor.

    CHECK <lv_no_refresh> <> 'X' AND <lv_error_in_data> = space.

    lv_soft_refresh = abap_true.
    IF <lv_no_refresh> = space.
      ls_stbl-row     = abap_true.
      ls_stbl-col     = abap_true.
      lv_soft_refresh = abap_false.
    ENDIF.

    me->set_ftd_layout( iv_scrno ).

    CALL METHOD <lo_alv_grid>->refresh_table_display
      EXPORTING
        is_stable      = ls_stbl
        i_soft_refresh = lv_soft_refresh.

  ENDMETHOD.


METHOD SET_DISPLAY_MODE.


    DATA: lv_set_dispmode TYPE string.

    FIELD-SYMBOLS:
      <lv_dispmode> TYPE any,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    ASSIGN (gv_set_dispmode) TO <lv_dispmode>.   " display mode
    CHECK <lv_dispmode> IS ASSIGNED.

    CASE <lv_dispmode>.
      WHEN 'X'. " Display MODE SETTING
        CALL METHOD <lo_alv_grid>->set_ready_for_input
          EXPORTING
            i_ready_for_input = '0'.

      WHEN OTHERS.  " Editor MODE ENABLE SETTING
        CALL METHOD <lo_alv_grid>->set_ready_for_input
          EXPORTING
            i_ready_for_input = '1'.
    ENDCASE.


  ENDMETHOD.


METHOD SET_DRAGDROP_HANDLE.


    DATA: lv_dragdrop_handle TYPE i,
          lv_index           TYPE sy-tabix,
          ls_flavor          TYPE ts_flavor,
          ls_fieldcat        TYPE lvc_s_fcat,
          ls_dragdrop        TYPE lvc_s_dd01.

    CHECK it_flavor[] IS NOT INITIAL.

    CREATE OBJECT co_dragdrop.

    LOOP AT it_flavor INTO ls_flavor.
      CALL METHOD co_dragdrop->add
        EXPORTING
          flavor     = ls_flavor-flavor
          dragsrc    = ls_flavor-dr_source
          droptarget = ls_flavor-dr_target
          effect     = ls_flavor-effect.
    ENDLOOP.

    CALL METHOD co_dragdrop->get_handle
      IMPORTING
        handle = lv_dragdrop_handle.

    CLEAR: ls_dragdrop.
    ls_dragdrop-cntr_ddid     = lv_dragdrop_handle. "auch bei leerem Grid
    ls_dragdrop-grid_ddid     = space.

    CASE iv_type.
      WHEN 'R'.  " Line
        ls_dragdrop-col_ddid      = space.
        ls_dragdrop-row_ddid      = lv_dragdrop_handle.
        ls_dragdrop-fieldname     = space.

      WHEN 'C'.
        ls_dragdrop-col_ddid      = lv_dragdrop_handle.
        ls_dragdrop-row_ddid      = space.
        ls_dragdrop-fieldname     = space.

        LOOP AT ct_fcat INTO ls_fieldcat WHERE dragdropid = 1.

          lv_index                = sy-tabix.
          ls_fieldcat-dragdropid  = lv_dragdrop_handle.

          MODIFY ct_fcat FROM ls_fieldcat INDEX lv_index
                 TRANSPORTING dragdropid.

        ENDLOOP.

    ENDCASE.

    cs_layout-s_dragdrop   = ls_dragdrop.

  ENDMETHOD.


METHOD SET_ERR_MSG.

    DATA: lv_msgid     TYPE symsgid,
          lv_msgno(03) TYPE n,
          lv_type,
          lv_msg       TYPE bapi_msg.

    " message id 설정
    IF gv_msgid IS INITIAL AND iv_msgid IS INITIAL.
      lv_msgid = gc_msgid.
    ELSEIF iv_msgid IS NOT INITIAL.
      lv_msgid = iv_msgid.
    ELSE.
      lv_msgid = gv_msgid.
    ENDIF.

    " 입력된 Field 정보를 가지고 온다.
    DESCRIBE FIELD iv_msgno TYPE lv_type.

    CASE lv_type.
      WHEN 'I'.
        lv_msgno = iv_msgno.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input  = lv_msgno
          IMPORTING
            output = lv_msgno.

      WHEN OTHERS.
        IF strlen( iv_msgno ) = 3.
          lv_msgno = iv_msgno.
        ELSE.
          lv_msgno = iv_msgno+1(3).
        ENDIF.
    ENDCASE.


    MESSAGE ID lv_msgid TYPE 'S'  NUMBER lv_msgno
            WITH iv_msgv1 iv_msgv2 iv_msgv3 iv_msgv4
            INTO lv_msg.

    me->set_err_msgs( is_modi_cell    = is_modi_cell
                      iv_msgv1        = lv_msg
                      io_data_changed = io_data_changed ).

  ENDMETHOD.


METHOD SET_ERR_MSGS.

    DATA: lv_msg   TYPE bapi_msg.

    FIELD-SYMBOLS:
      <lv_error_in_data> TYPE any.

    ASSIGN (gv_set_error_data) TO <lv_error_in_data>. " gv_error_in_data

    MESSAGE ID 'OO' TYPE 'S'  NUMBER '000'
            WITH iv_msgv1
            INTO lv_msg.

    <lv_error_in_data> = 'X'.
    CALL METHOD io_data_changed->add_protocol_entry
      EXPORTING
        i_msgid     = 'OO'
        i_msgno     = '000'
        i_msgty     = 'E'
        i_msgv1     = lv_msg
        i_fieldname = is_modi_cell-fieldname
        i_row_id    = is_modi_cell-row_id.

  ENDMETHOD.


METHOD SET_EVENT.

    DATA: lv_org_repid TYPE sy-repid,
          ls_fieldcat  TYPE lvc_s_fcat,
          ls_f4        TYPE lvc_s_f4,
          lt_f4        TYPE lvc_t_f4.

    IF iv_org_repid IS INITIAL.
      lv_org_repid = gv_repid.
    ELSE.
      lv_org_repid = iv_org_repid.
    ENDIF.

*  CREATE LOCAL CLASS
    CREATE OBJECT co_alv_event
      EXPORTING
        iv_object_text = iv_object_text
        iv_repid       = gv_repid
        iv_org_repid   = lv_org_repid.

* SET EVENT .
    CALL METHOD io_grid->register_edit_event
      EXPORTING
        i_event_id = cl_gui_alv_grid=>mc_evt_enter.

    CALL METHOD io_grid->register_edit_event
      EXPORTING
        i_event_id = cl_gui_alv_grid=>mc_evt_modified.

    SET HANDLER co_alv_event->handle_data_changed          FOR io_grid.
    SET HANDLER co_alv_event->handle_toolbar               FOR io_grid.
    SET HANDLER co_alv_event->handle_user_command          FOR io_grid.
    SET HANDLER co_alv_event->handle_onf4                  FOR io_grid.
    SET HANDLER co_alv_event->handle_hotspot_click         FOR io_grid.
    SET HANDLER co_alv_event->handle_double_click          FOR io_grid.
    SET HANDLER co_alv_event->handle_button_click          FOR io_grid.
    SET HANDLER co_alv_event->handle_ondrag                FOR io_grid.
    SET HANDLER co_alv_event->handle_ondrop                FOR io_grid.
    SET HANDLER co_alv_event->handle_ondropcomplete        FOR io_grid.
    SET HANDLER co_alv_event->handle_ondropgetflavor       FOR io_grid.
    SET HANDLER co_alv_event->handle_data_changed_finished FOR io_grid.
    SET HANDLER co_alv_event->handle_context_menu          FOR io_grid.
    SET HANDLER co_alv_event->handle_top_of_page           FOR io_grid.
    SET HANDLER co_alv_event->handle_after_refresh         FOR io_grid.
    SET HANDLER co_alv_event->handle_subtotal_text         FOR io_grid.


*  CREATE POSSABLE ENTRY
    REFRESH lt_f4.
    LOOP AT ct_fcat INTO ls_fieldcat  WHERE f4availabl  = 'Y'.

      ls_fieldcat-f4availabl  = 'X'.
      MODIFY ct_fcat FROM ls_fieldcat
             TRANSPORTING f4availabl ref_field ref_table
             WHERE fieldname = ls_fieldcat-fieldname.

      CLEAR ls_f4.
      ls_f4-fieldname      = ls_fieldcat-fieldname.
      ls_f4-register       = 'X'.
      ls_f4-getbefore      = space.
      ls_f4-chngeafter     = space.
      INSERT ls_f4 INTO TABLE lt_f4.

    ENDLOOP.

    IF lt_f4[] IS NOT INITIAL.
      CALL METHOD io_grid->register_f4_for_fields
        EXPORTING
          it_f4 = lt_f4.
    ENDIF.

*  IF EXIST LISTBOX INFOMATION
    IF ct_drop IS SUPPLIED AND ct_drop[] IS NOT INITIAL.
      CALL METHOD io_grid->set_drop_down_table
        EXPORTING
          it_drop_down_alias = ct_drop.
    ENDIF.

  ENDMETHOD.


METHOD SET_FTD_LAYOUT.

    FIELD-SYMBOLS:
      <ls_layout>   TYPE lvc_s_layo,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    me->set_local_fields_with_scrno( iv_scrno ).

    ASSIGN (gv_set_layout)     TO <ls_layout>." Layout
    CHECK <ls_layout> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    CALL METHOD <lo_alv_grid>->set_frontend_layout
      EXPORTING
        is_layout = <ls_layout>.

  ENDMETHOD.


METHOD SET_HEADER_INIT.

    " Table 을 선언한다.
    CASE iv_format.
      WHEN 'L'.
        CALL METHOD io_docu->add_table
          EXPORTING
            no_of_columns      = 1
            border             = iv_border " '0' " 선표시 하지 않음
            width              = iv_width_tab
          IMPORTING
            tablearea          = co_tarea
          EXCEPTIONS
            table_already_used = 1.

        " column 의 폭을 설정한다
        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = 1
            width  = '100%'.

      WHEN 'T'.
        CALL METHOD io_docu->add_table
          EXPORTING
            no_of_columns      = iv_no_of_columns
            border             = iv_border " '0' " 선표시 하지 않음
            width              = iv_width_tab
          IMPORTING
*           table              = co_tab
            tablearea          = co_tarea
          EXCEPTIONS
            table_already_used = 1.

        " column 의 폭을 설정한다
        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = 1
            width  = iv_width_col1.

        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = 2
            width  = iv_width_col2.

        CALL METHOD co_tarea->set_column_width
          EXPORTING
            col_no = 3
            width  = iv_width_col3.

      WHEN OTHERS.
    ENDCASE.

  ENDMETHOD.


METHOD SET_HEADER_SHOW.

    " 참고 program : DD_ADD_TABLE 2.1

    DATA: lo_tarea        TYPE REF TO cl_dd_table_area.

    DATA: lv_formnm TYPE char30.

    CONCATENATE 'ADD_BEF_TOPPAGE_'  iv_dynnr INTO lv_formnm.
    PERFORM (lv_formnm) IN PROGRAM (gv_repid) IF FOUND
                           USING    gv_selscr_max_len.


    " Header 초기화
    CALL METHOD me->set_header_init
      EXPORTING
        io_docu   = co_docu
        iv_format = iv_format
        iv_border = '0'
      CHANGING
        co_tarea  = lo_tarea.

* SelScr 정보 출력
    IF iv_show_default = abap_true.
      me->set_header_show_default( EXPORTING iv_format = iv_format
                                   CHANGING  co_tarea  = lo_tarea ).
    ENDIF.

* 추가로 설정해야 하는 Header line 이 있는 경우
    CONCATENATE 'ADD_AFT_TOPPAGE_'  iv_dynnr INTO lv_formnm.
    PERFORM (lv_formnm) IN PROGRAM (gv_repid) IF FOUND
                           USING    gv_selscr_max_len
                           CHANGING lo_tarea.

    " row 단위 Data 를 Table 로 생성한다.
    CALL METHOD co_docu->merge_document.

* Background Image 설정
    IF iv_show_backgrand = abap_true.
      CALL METHOD co_docu->set_document_background
        EXPORTING
          picture_id = 'ALV_BACKGROUND'.
    ENDIF.

    "  Display Screen(HTML 영역)
    IF co_html IS INITIAL.
      CREATE OBJECT co_html
        EXPORTING
          parent = co_head.
    ENDIF.

    " HTML 영역을 연결한다.
    co_docu->html_control = co_html.

    " 화면에 표시한다.
    CALL METHOD co_docu->display_document
      EXPORTING
        reuse_control      = 'X'
        parent             = co_head "표시할 컨테이너부분
      EXCEPTIONS
        html_display_error = 1.

  ENDMETHOD.


METHOD SET_HEADER_SHOW_DEFAULT.

    DATA: lo_seltab_w     TYPE REF TO data,
          lv_dtype        TYPE c,
          lv_screen_name  TYPE scrfname,
          lv_fld_par2     TYPE scrfname,
          lv_vtext        TYPE scrfname,
          lv_fld_par1_v   TYPE scrfname,
          lv_fld_par2_v   TYPE scrfname,
          lv_fld_par3     TYPE scrfname,
          lv_fld_par3_v   TYPE scrfname,
          lv_seltab_name  TYPE scrfname,
          ls_selscr_field TYPE ts_selscr_field.

    FIELD-SYMBOLS:
      <lv_scrname>  TYPE any,
      <lv_fld_par2> TYPE any,
      <lv_fld_par3> TYPE any,
      <ls_seltab>   TYPE any,
      <lt_seltab>   TYPE STANDARD TABLE.

    LOOP AT gt_selscr_field INTO ls_selscr_field.

      UNASSIGN: <lv_scrname>, <ls_seltab>, <lt_seltab>.


      CASE ls_selscr_field-ftype.
        WHEN 'LOW'.
          CONCATENATE `(` gv_repid `)` ls_selscr_field-fname '[]' INTO lv_screen_name .
          ASSIGN (lv_screen_name) TO <lt_seltab>.

          IF ls_selscr_field-dtype IS INITIAL.
            CREATE DATA lo_seltab_w LIKE LINE OF <lt_seltab>.
            ASSIGN lo_seltab_w->* TO <ls_seltab>.

            ASSIGN ('<LS_SELTAB>-LOW') TO <lv_scrname>.

            DESCRIBE FIELD <lv_scrname> TYPE lv_dtype.

          ELSE.
            lv_dtype = ls_selscr_field-dtype .
          ENDIF.

          CALL METHOD me->set_header_text_s
            EXPORTING
              iv_title       = ls_selscr_field-title
              iv_format      = iv_format
              it_seltab      = <lt_seltab>
              iv_seltab_type = lv_dtype
            CHANGING
              co_tarea       = co_tarea.

        WHEN 'PAR' OR 'RBG'.
          CLEAR: lv_fld_par1_v.
          CONCATENATE `(` gv_repid `)` ls_selscr_field-fname INTO lv_screen_name .
          ASSIGN (lv_screen_name) TO <lv_scrname>.
          CHECK sy-subrc = 0 AND <lv_scrname> IS NOT INITIAL.
          DESCRIBE FIELD <lv_scrname> TYPE ls_selscr_field-dtype.
          lv_fld_par1_v = me->edit_header_p( iv_value = <lv_scrname> iv_dtype = ls_selscr_field-dtype ).

          IF ls_selscr_field-fname2 IS INITIAL.
            CLEAR: lv_fld_par2_v.
          ELSE.
            CONCATENATE `(` gv_repid `)` ls_selscr_field-fname2 INTO lv_fld_par2 .
            ASSIGN (lv_fld_par2) TO <lv_fld_par2>.
            IF sy-subrc = 0 AND <lv_fld_par2> IS NOT INITIAL.
              DESCRIBE FIELD <lv_fld_par2> TYPE ls_selscr_field-dtype.
              lv_fld_par2_v = me->edit_header_p( iv_value = <lv_fld_par2> iv_dtype = ls_selscr_field-dtype ).
            ENDIF.
          ENDIF.

          IF ls_selscr_field-fname3 IS INITIAL.
            CLEAR: lv_fld_par3_v.
          ELSE.
            CONCATENATE `(` gv_repid `)` ls_selscr_field-fname3 INTO lv_fld_par3 .
            ASSIGN (lv_fld_par3) TO <lv_fld_par3>.
            IF sy-subrc = 0 AND <lv_fld_par3> IS NOT INITIAL.
              DESCRIBE FIELD <lv_fld_par3> TYPE ls_selscr_field-dtype.
              lv_fld_par3_v = me->edit_header_p( iv_value = <lv_fld_par3> iv_dtype = ls_selscr_field-dtype ).
            ENDIF.
          ENDIF.

          CASE ls_selscr_field-ftype..
            WHEN 'RBG'.
              lv_fld_par1_v = ls_selscr_field-text.
              CLEAR ls_selscr_field-text.
            WHEN OTHERS. lv_vtext = ls_selscr_field-text.
          ENDCASE.

          CALL METHOD me->set_header_text_p
            EXPORTING
              iv_title  = ls_selscr_field-title
              iv_format = iv_format
              iv_value  = lv_fld_par1_v
              iv_value2 = lv_fld_par2_v
              iv_value3 = lv_fld_par3_v
              iv_vtext  = ls_selscr_field-text
            CHANGING
              co_tarea  = co_tarea.

        WHEN OTHERS. CONTINUE.

      ENDCASE.

    ENDLOOP.

  ENDMETHOD.


METHOD SET_HEADER_TEXT_I.

    DATA: lv_pos    TYPE i,
          lv_len    TYPE i,
          lv_space  TYPE sychar02,
          lv_text   TYPE sdydo_text_element,
          lv_textd  TYPE sdydo_text_element,
          lv_txt101 TYPE string,
          lv_txt102 TYPE string.

    lv_space = go_comfunc->get_uc_text( go_comfunc->gc_type_x00a0 ).

*  CASE iv_format.
*    WHEN 'L'.
    lv_text  = iv_title.
*  CONCATENATE iv_value iv_vtext iv_value2 iv_value3
*         INTO lv_textd SEPARATED BY space.

    lv_len = go_comfunc->strlenx( lv_text ).
    WHILE lv_len <= gv_selscr_max_len .
      ADD 1  TO lv_len.
      CONCATENATE lv_text lv_space INTO lv_text.
    ENDWHILE.

    lv_pos = go_comfunc->strlenx( lv_text ).
    lv_text+lv_pos(1) = ':'.

    CALL METHOD co_tarea->add_text
      EXPORTING
        text         = lv_text
        sap_fontsize = cl_dd_area=>medium.

*  CALL METHOD co_tarea->add_gap
*    EXPORTING
*      width = 150.

    CALL METHOD co_tarea->add_icon
      EXPORTING
        sap_icon = CONV iconname( iv_value )
        sap_size = cl_dd_area=>medium.

*  lv_pos   = lv_pos + 3.
*  lv_text+lv_pos = lv_textd.

*    WHEN 'T'.
*      " title
*      lv_text = iv_title.
*      CALL METHOD co_tarea->add_text
*        EXPORTING
*          text         = lv_text
*          sap_fontsize = cl_dd_area=>medium.
*
*      IF iv_value2 IS NOT INITIAL.
*        " value
*        lv_text =  iv_value.
*        CALL METHOD co_tarea->add_text
*          EXPORTING
*            text         = lv_text
*            sap_fontsize = cl_dd_area=>medium.
*
*        " text
*        lv_text =  iv_vtext.
*
*      ELSE.
*        CALL METHOD co_tarea->span_columns
*          EXPORTING
*            col_start_span = 2
*            no_of_cols     = 2.
*
*        CONCATENATE iv_value iv_vtext iv_value2 iv_value3
*               INTO lv_text SEPARATED BY space.
*      ENDIF.
*  ENDCASE.
*
*  CALL METHOD co_tarea->add_text
*    EXPORTING
*      text         = lv_text
*      sap_fontsize = cl_dd_area=>medium.

    CALL METHOD co_tarea->new_row.

  ENDMETHOD.


METHOD SET_HEADER_TEXT_P.

    DATA: lv_pos    TYPE i,
          lv_len    TYPE i,
          lv_space  TYPE sychar02,
          lv_text   TYPE sdydo_text_element,
          lv_textd  TYPE sdydo_text_element,
          lv_txt101 TYPE string,
          lv_txt102 TYPE string.

    lv_space = go_comfunc->get_uc_text( go_comfunc->gc_type_x00a0 ).

    CASE iv_format.
      WHEN 'L'.
        lv_text  = iv_title.
        CONCATENATE iv_value iv_vtext iv_value2 iv_value3
               INTO lv_textd SEPARATED BY space.

        lv_len = go_comfunc->strlenx( lv_text ).
        WHILE lv_len <= gv_selscr_max_len .
          ADD 1  TO lv_len.
          CONCATENATE lv_text lv_space INTO lv_text.
        ENDWHILE.

        lv_pos = go_comfunc->strlenx( lv_text ).
        lv_text+lv_pos(1) = ':'.

        lv_pos   = lv_pos + 3.
        lv_text+lv_pos = lv_textd.

      WHEN 'T'.
        " title
        lv_text = iv_title.
        CALL METHOD co_tarea->add_text
          EXPORTING
            text         = lv_text
            sap_fontsize = cl_dd_area=>medium.

        IF iv_value2 IS INITIAL AND iv_value3 IS INITIAL.
          " value
          lv_text =  iv_value.
          CALL METHOD co_tarea->add_text
            EXPORTING
              text         = lv_text
              sap_fontsize = cl_dd_area=>medium.

          " text
          lv_text =  iv_vtext.

        ELSE.
          CALL METHOD co_tarea->span_columns
            EXPORTING
              col_start_span = 2
              no_of_cols     = 2.

          CONCATENATE iv_value iv_vtext iv_value2 iv_value3
                 INTO lv_text SEPARATED BY space.
        ENDIF.
    ENDCASE.

    CALL METHOD co_tarea->add_text
      EXPORTING
        text         = lv_text
        sap_fontsize = cl_dd_area=>medium.

    CALL METHOD co_tarea->new_row.

  ENDMETHOD.


METHOD SET_HEADER_TEXT_S.

    DATA: lv_pos    TYPE i,
          lv_len    TYPE i,
          lv_space  TYPE sychar02,
          lv_text   TYPE sdydo_text_element,
          lv_textd  TYPE sdydo_text_element,
          lv_txt101 TYPE string,
          lv_txt102 TYPE string.

    lv_space = go_comfunc->get_uc_text( go_comfunc->gc_type_x00a0 ).

    CASE iv_format.
      WHEN 'L'.
        lv_text  = iv_title.
        lv_textd = me->edit_header_s( it_sel = it_seltab[] iv_opt = iv_seltab_type ).

        lv_len = go_comfunc->strlenx( lv_text ).
        WHILE lv_len <= gv_selscr_max_len .
          ADD 1  TO lv_len.
          CONCATENATE lv_text lv_space INTO lv_text.
        ENDWHILE.

        lv_pos = go_comfunc->strlenx( lv_text ).
        lv_text+lv_pos(1) = ':'.

        lv_pos   = lv_pos + 3.
        lv_text+lv_pos = lv_textd.

      WHEN 'T'.
        CALL METHOD co_tarea->span_columns
          EXPORTING
            col_start_span = 2
            no_of_cols     = 2.

*  lv_text = me->set_header( iv_gubun = 'H'
*                            iv_parm1 = iv_title
*                            iv_parm2 = space ).
        lv_text = iv_title.
        CALL METHOD co_tarea->add_text
          EXPORTING
            text         = lv_text
            sap_fontsize = cl_dd_area=>medium.

        lv_text = me->edit_header_s( it_sel = it_seltab[] iv_opt = iv_seltab_type ).

*  IF co_col_remark IS BOUND.
*    lv_text =  iv_remark.
*    CALL METHOD co_col_remark->add_text
*      EXPORTING
*        text         = lv_text
*        sap_fontsize = cl_dd_area=>medium.
*  ENDIF.
      WHEN OTHERS.
    ENDCASE.

    CALL METHOD co_tarea->add_text
      EXPORTING
        text         = lv_text
        sap_fontsize = cl_dd_area=>medium.

    CALL METHOD co_tarea->new_row.

  ENDMETHOD.


METHOD SET_LOCAL_FIELDS.

    " gv_error_in_data
    CONCATENATE `(` gv_repid `)GV_ERROR_IN_DATA` INTO gv_set_error_data .

    " gv_new_ok_code
    CONCATENATE `(` gv_repid `)GV_NEW_OK_CODE` INTO gv_set_new_okcode .

    " gv_ok_code
    CONCATENATE `(` gv_repid `)GV_OK_CODE` INTO gv_set_okcode .

    " gv_no_refresh
    CONCATENATE `(` gv_repid `)GV_NO_REFRESH` INTO gv_set_no_refresh .

    " gv_no_change
    CONCATENATE `(` gv_repid `)GV_NO_CHANGE` INTO gv_set_no_change .


  ENDMETHOD.


METHOD SET_LOCAL_FIELDS_WITH_SCRNO.


    FIELD-SYMBOLS:
      <lt_table>     TYPE STANDARD TABLE,
      <lt_table_del> TYPE STANDARD TABLE.

    " 일반적인 Table.
    CONCATENATE `(` gv_repid `)GT_S` iv_scrno `[]` INTO gv_set_table.
    ASSIGN (gv_set_table) TO <lt_table>.


    IF <lt_table> IS NOT ASSIGNED.
      CONCATENATE `(` gv_repid `)GT_S` iv_scrno INTO gv_set_table.
      ASSIGN (gv_set_table) TO <lt_table>.
      IF <lt_table> IS NOT ASSIGNED.
        CONCATENATE `(` gv_repid `)<GT_S` iv_scrno `>` INTO gv_set_table.
        ASSIGN (gv_set_table) TO <lt_table>.
        IF <lt_table> IS NOT ASSIGNED.
          CLEAR: gv_set_table.
        ENDIF.
      ENDIF.
    ENDIF.

**박승현 사원
**IF iv_search_clicked = abap_true AND iv_atnam_empty = abap_true.
**  IF <lt_table> IS ASSIGNED.
**    CLEAR <lt_table>.
**  ENDIF.
**  MESSAGE '특성 이름을 입력 하세요' TYPE 'S' DISPLAY LIKE 'E'.
**ENDIF.

    " Del Table
    CONCATENATE `(` gv_repid `)GT_S` iv_scrno `_DEL[]` INTO gv_set_table_del.
    ASSIGN (gv_set_table_del) TO <lt_table_del>.
    IF <lt_table_del> IS NOT ASSIGNED.
      CONCATENATE `(` gv_repid `)GT_S` iv_scrno `_DEL` INTO gv_set_table_del.
      ASSIGN (gv_set_table_del) TO <lt_table_del>.
      IF <lt_table_del> IS NOT ASSIGNED.
        CONCATENATE `(` gv_repid `)<GT_S` iv_scrno `_DEL>` INTO gv_set_table_del.
        ASSIGN (gv_set_table_del) TO <lt_table_del>.
        IF <lt_table_del> IS NOT ASSIGNED.
          CLEAR: gv_set_table_del.
        ENDIF.
      ENDIF.
    ENDIF.

    " ALV Grid
    CONCATENATE `(` gv_repid `)GO_GRID_` iv_scrno INTO gv_set_alvgrid.

    " ALV Docking
    CONCATENATE `(` gv_repid `)GO_DCON_` iv_scrno INTO gv_set_alvdcon.

    " ALV Customer Container
    CONCATENATE `(` gv_repid `)GO_CCON_` iv_scrno INTO gv_set_alvccon.

    " layout
    CONCATENATE `(` gv_repid `)GS_LAYOUT_` iv_scrno INTO gv_set_layout.

    " variant
    CONCATENATE `(` gv_repid `)GS_VARI_` iv_scrno INTO gv_set_variant.

    " Function Code Table
    CONCATENATE `(` gv_repid `)GT_TOOL_` iv_scrno `[]` INTO gv_set_tools.

    " Field cATALOG
    CONCATENATE `(` gv_repid `)GT_FIELDCAT_` iv_scrno `[]` INTO gv_set_fieldcat.

    " SortTable
    CONCATENATE `(` gv_repid `)GT_SORT_` iv_scrno `[]` INTO gv_set_sort.

    " display Mode
    CONCATENATE `(` gv_repid `)GV_DISPLAY_MODE_` iv_scrno INTO gv_set_dispmode.

  ENDMETHOD.


METHOD SET_SELSCR_EXCEPT.

    DATA: lv_pos          TYPE numc2,
          lv_len          TYPE i,
          lv_fieldname    TYPE fieldname,
          ls_selscr_rbg   TYPE ts_selscr_rbg,
          ls_selscr_field TYPE ts_selscr_field.

    FIELD-SYMBOLS:
        <lv_fieldname> TYPE any.

    SORT gt_selscr_field BY fname.

    DO 9 TIMES.
      lv_pos = sy-index.
      CONCATENATE 'IV_FIELD' lv_pos INTO lv_fieldname.
      ASSIGN (lv_fieldname) TO <lv_fieldname>.
      IF <lv_fieldname> IS ASSIGNED AND <lv_fieldname> IS NOT INITIAL.
        " 지정된 Field를 삭제한다
        DELETE  gt_selscr_field WHERE fname = <lv_fieldname>.
      ENDIF.
    ENDDO.

    " selection screen field title의 최대길이 산출
    me->set_selscr_max_len( ).

    SORT gt_selscr_field BY pos.

  ENDMETHOD.


METHOD SET_SELSCR_FIELDTYPE.

    DATA: lv_pos       TYPE numc2,
          lv_len       TYPE i,
          lv_fld_field TYPE fieldname,
          lv_fld_dtype TYPE char1.

    FIELD-SYMBOLS:
      <ls_selscr_field> TYPE ts_selscr_field,
      <lv_fld_field>    TYPE any,
      <lv_fld_dtype>    TYPE any.

    SORT gt_selscr_field BY fname.

    DO 9 TIMES.
      lv_pos = sy-index.
      CONCATENATE 'IV_FIELD' lv_pos INTO lv_fld_field.
      ASSIGN (lv_fld_field) TO <lv_fld_field>.
      CONCATENATE 'IV_DTYPE' lv_pos INTO lv_fld_dtype.
      ASSIGN (lv_fld_dtype) TO <lv_fld_dtype>.
      CHECK <lv_fld_field> IS ASSIGNED    AND <lv_fld_dtype> IS ASSIGNED.
      CHECK <lv_fld_field> IS NOT INITIAL AND <lv_fld_dtype> IS NOT INITIAL.


      READ TABLE gt_selscr_field ASSIGNING <ls_selscr_field> WITH KEY fname = <lv_fld_field>
           BINARY SEARCH.
      CHECK sy-subrc = 0.

      <ls_selscr_field>-dtype = <lv_fld_dtype>.

    ENDDO.

    " selection screen field title의 최대길이 산출
    me->set_selscr_max_len( ).

    SORT gt_selscr_field BY pos.

  ENDMETHOD.


METHOD SET_SELSCR_MAX_LEN.

    DATA: lv_no(2)        TYPE n,
          lv_fieldname    TYPE scrfname,
          lv_len          TYPE i,
          ls_selscr_rbg   TYPE ts_selscr_rbg,
          ls_selscr_field TYPE ts_selscr_field.

    CLEAR: gv_selscr_max_len.

    " screen
    LOOP AT gt_selscr_field INTO ls_selscr_field.

      lv_len = go_comfunc->strlenx( ls_selscr_field-title ).
*      lv_len = strlen( ls_selscr_field-title ).

      IF lv_len > gv_selscr_max_len.
        gv_selscr_max_len = lv_len.
      ENDIF.

    ENDLOOP.

    " radio group
    LOOP AT gt_selscr_rbg INTO ls_selscr_rbg.

      lv_len = go_comfunc->strlenx( ls_selscr_rbg-text ).
*    lv_len = strlen( ls_selscr_rbg-text ).

      IF lv_len > gv_selscr_max_len.
        gv_selscr_max_len = lv_len.
      ENDIF.

    ENDLOOP.


    " 추가 head text 로 지정된 값이 있는지 확인
    DO 99 TIMES.
      lv_no = sy-index.
      CONCATENATE `(` gv_repid `)TEXT-Z` lv_no INTO lv_fieldname .
      ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<lv_fieldname>).
      CHECK sy-subrc = 0 AND <lv_fieldname> IS ASSIGNED.

      lv_len = go_comfunc->strlenx( <lv_fieldname> ).
      IF lv_len > gv_selscr_max_len.
        gv_selscr_max_len = lv_len.
      ENDIF.

    ENDDO.

  ENDMETHOD.


METHOD SET_SELSCR_RADIOBUTTONGROUP.

    DATA: lv_pos          TYPE numc2,
          lv_len          TYPE i,
          lv_fieldname    TYPE fieldname,
          lv_screen_txt   TYPE scrfname,
          ls_selscr_rbg   TYPE ts_selscr_rbg,
          ls_selscr_field TYPE ts_selscr_field.

    DATA: BEGIN OF ls_id,
            p TYPE progname,
            d TYPE sydynnr,
          END OF ls_id.

    DATA: ls_header    TYPE d020s,
          ls_fields    TYPE d021s,
          lt_fields    TYPE TABLE OF d021s,
          lt_logics    TYPE TABLE OF d022s,
          lt_matchcode TYPE TABLE OF d023s.

    FIELD-SYMBOLS:
      <lv_fieldname> TYPE any,
      <lv_txt>       TYPE any.

    ls_id-p = gv_repid.
    ls_id-d = sy-dynnr.
    IMPORT DYNPRO ls_header lt_fields lt_logics lt_matchcode ID ls_id.
    CHECK sy-subrc = 0.

    SORT gt_selscr_field BY fname.

    CLEAR: ls_selscr_field.

    DO 9 TIMES.
      lv_pos = sy-index.
      CONCATENATE 'IV_RADIO_FIELD' lv_pos INTO lv_fieldname.
      ASSIGN (lv_fieldname) TO <lv_fieldname>.
      IF <lv_fieldname> IS ASSIGNED AND <lv_fieldname> IS NOT INITIAL.
        SORT gt_selscr_rbg BY rbgname fname.
        READ TABLE gt_selscr_rbg WITH KEY rbgname = iv_group_name
                                          fname   = <lv_fieldname>
             BINARY SEARCH TRANSPORTING NO FIELDS.
        IF sy-subrc NE 0.
          CLEAR: ls_selscr_rbg .
          MOVE: iv_group_name  TO ls_selscr_rbg-rbgname,
                iv_group_text  TO ls_selscr_rbg-text,
                <lv_fieldname> TO ls_selscr_rbg-fname.
          APPEND ls_selscr_rbg TO gt_selscr_rbg.

          lv_len = strlen( iv_group_text ).
          IF lv_len > gv_selscr_max_len.
            gv_selscr_max_len = lv_len.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDDO.

    DATA: lv_idx1 TYPE sy-tabix,
          lv_idx2 TYPE sy-tabix.

    " 기존에 등록된 정보
    LOOP AT gt_selscr_rbg INTO ls_selscr_rbg WHERE rbgname = iv_group_name.

      READ TABLE gt_selscr_field INTO ls_selscr_field WITH KEY fname = ls_selscr_rbg-fname.
      IF sy-subrc = 0.
        EXIT.
      ENDIF.

    ENDLOOP.

    CLEAR: ls_selscr_field-fname2, ls_selscr_field-fname3.
    MOVE: iv_group_name  TO ls_selscr_field-rbgname,
          iv_group_text  TO ls_selscr_field-title,
          'RBG'          TO ls_selscr_field-ftype.

    LOOP AT gt_selscr_rbg INTO ls_selscr_rbg WHERE rbgname = iv_group_name.

      lv_idx1 = sy-tabix.

      READ TABLE gt_selscr_field WITH KEY fname = ls_selscr_rbg-fname
           TRANSPORTING NO FIELDS.
      IF sy-subrc = 0.
        lv_idx2 = sy-tabix.
      ELSE.
        lv_idx2 = 0.
      ENDIF.

      ls_selscr_field-fname = ls_selscr_rbg-fname.

      " lt_fields 에서 해당 field 라인을 찾는다
      " 동일 group4 와 group3 COF 없는경우 group4 와 group3 TXT 없으면 fieldname
      " 해당 field 의 text
      READ TABLE lt_fields INTO ls_fields WITH KEY fnam = ls_selscr_field-fname.
      CHECK sy-subrc = 0.

      READ TABLE lt_fields INTO ls_fields WITH KEY grp4 = ls_fields-grp4
                                                   grp3 = 'COF'.
      IF sy-subrc NE 0.
        READ TABLE lt_fields INTO ls_fields WITH KEY grp4 = ls_fields-grp4
                                                     grp3 = 'TXT'.
        IF sy-subrc NE 0.
          ls_fields-fnam = ls_selscr_field-fname.
        ENDIF.
      ENDIF.

      CONCATENATE `(` gv_repid `)` ls_fields-fnam INTO lv_screen_txt .
      ASSIGN (lv_screen_txt)   TO <lv_txt>.
      CHECK <lv_txt> IS ASSIGNED.

      ls_selscr_field-text  = <lv_txt>.
      ls_selscr_field-pos_s = lv_idx1.

      IF lv_idx2 = 0.
        APPEND ls_selscr_field TO gt_selscr_field.
      ELSE.
        MODIFY gt_selscr_field FROM ls_selscr_field INDEX lv_idx2.
      ENDIF.

    ENDLOOP.

    SORT gt_selscr_field BY pos pos_s.

  ENDMETHOD.


METHOD col_hotspot.

  DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*  Hotspot 지정
  ls_fieldcat-hotspot    = iv_hotspot.
  MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING hotspot
      WHERE fieldname = iv_fieldname.

ENDMETHOD.


METHOD col_key.

  DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

*  Key 지정
  ls_fieldcat-key         = iv_key.
  ls_fieldcat-fix_column  = iv_key.
  MODIFY ct_fieldcat FROM ls_fieldcat TRANSPORTING key fix_column
      WHERE fieldname = iv_fieldname.

ENDMETHOD.
ENDCLASS.
