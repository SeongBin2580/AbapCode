*----------------------------------------------------------------------*
***INCLUDE LZMDMMMFG91F02.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Form  SET_FCODE_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_fcode_0100 .

  CLEAR: gt_fcode[].
  IF gv_display_mode_0100 = space.
    APPEND 'BACK_EXIT'  TO gt_fcode.

  ELSE.
    APPEND 'CANC_EXIT'  TO gt_fcode.
    APPEND 'SAVE'       TO gt_fcode.
  ENDIF.


  " 제외 button
  IF gv_exclude_save = abap_true.
    APPEND 'SAVE'  TO gt_fcode.
  ENDIF.

  LOOP AT gt_fcode_in INTO DATA(ls_fcode_in).
    IF ls_fcode_in-ficon IS INITIAL AND ls_fcode_in-ftext IS INITIAL.
      APPEND ls_fcode_in-fcode TO gt_fcode.
    ENDIF.
  ENDLOOP.

  SORT gt_fcode.
  DELETE ADJACENT DUPLICATES FROM gt_fcode
         COMPARING ALL FIELDS.

ENDFORM.                    " SET_FCODE_0100
*&---------------------------------------------------------------------*
*&      Form  set_alv_layout_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_alv_layout_0100.

  gs_layout_0100-sel_mode   = 'A'.
  gs_layout_0100-cwidth_opt = 'X'.

ENDFORM.                    "SET_ALV_LAYOUT_0100
*&---------------------------------------------------------------------*
*&      Form  set_alv_toolbar_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_alv_toolbar_0100.

  CHECK gt_tool_0100[] IS INITIAL.

  IF gv_exclude_tb_all = 'X'.
    go_alv_info->exclude_functions(
                 EXPORTING iv_ui_func = cl_gui_alv_grid=>mc_fc_excl_all
                 CHANGING  ct_table   = gt_tool_0100 ).

  ELSE.
    gt_tool_0100 = go_alv_info->exclude_functions_default( ).

  ENDIF.

ENDFORM.                    "SET_ALV_TOOLBAR_0100
*&---------------------------------------------------------------------*
*&      Form  set_alv_varient_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_alv_varient_0100.

  CLEAR: gs_vari_0100.
  gs_vari_0100-report   = gv_repid.
  gs_vari_0100-username = sy-uname.
  gs_vari_0100-handle   = '0100'.

ENDFORM.                    "SET_ALV_VARIENT_0100
*&---------------------------------------------------------------------*
*&      Form  set_alv_fieldcat_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_alv_fieldcat_0100.

  DATA: ls_fieldcat TYPE lvc_s_fcat.


* FIELDCATALOG 정의
  CHECK gt_fieldcat_0100[] IS INITIAL.

  gt_fieldcat_0100[] = go_alv_info->get_fieldcatalog( it_tab  = <gt_s0100>[] ).

  CLEAR: gv_col_pos.
  LOOP AT gt_fieldcat_0100 INTO ls_fieldcat.
    gv_col_pos             = gv_col_pos + 1.
    ls_fieldcat-col_pos    = gv_col_pos.

    " 선택 Field 인 경우.
    IF gv_selection_field IS NOT INITIAL AND
       gv_selection_field = ls_fieldcat-fieldname.

      ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
      ls_fieldcat-scrtext_m =
      ls_fieldcat-scrtext_s = ls_fieldcat-coltext = TEXT-l01. " Return Value

      ls_fieldcat-key         = 'X'.

    ENDIF.

    MODIFY gt_fieldcat_0100 FROM ls_fieldcat INDEX sy-tabix
              TRANSPORTING col_pos key coltext scrtext_l scrtext_m
                             reptext scrtext_s .

  ENDLOOP.

  " Selection field 가 있는 경우..
*    IF gv_selection_field IS NOT INITIAL AND
*       gv_display_mode_0100 = space.
*      PERFORM com_alv_col_checkbox TABLES gt_fieldcat_0100 USING:
*              gv_selection_field c_x.
**      PERFORM com_alv_col_edit     TABLES gt_fieldcat_0100 USING:
**              gv_selection_field.
*    ENDIF.

* 보여지지 않는 FIELD 감추기
  go_alv_info->col_delete( CHANGING ct_fieldcat = gt_fieldcat_0100 ).

ENDFORM.                    "SET_ALV_FIELDCAT_0100
*&---------------------------------------------------------------------*
*&      Form  set_alv_sortcat_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM set_alv_sortcat_0100.

  CLEAR: gt_sort_0100[].

ENDFORM.                    "SET_ALV_SORTCAT_0100
*&---------------------------------------------------------------------*
*&      Form  check_callback_s0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PT_TABLE       text
*      -->PF_ERROR_FLAG  text
*----------------------------------------------------------------------*
FORM check_callback_s0100  TABLES   pt_table TYPE STANDARD TABLE
                           CHANGING pv_error_flag.

*  DATA: lv_exit_alv_form(40) VALUE 'CHECK_CALLBACK_ALV_'.
*
*  lv_exit_alv_form = lv_exit_alv_form && gv_cb_scr.
*  PERFORM (lv_exit_alv_form) IN PROGRAM (gv_cb_repid) IF FOUND
*                             TABLES   pt_table
*                             CHANGING pf_error_flag.

ENDFORM.                    " CHECK_CALLBACK_S0100
*&---------------------------------------------------------------------*
*& Form set_save_button_0100
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- PT_FCODE
*&---------------------------------------------------------------------*
FORM set_save_button_0100  CHANGING pt_fcode TYPE zmdmmmy9070.

  DATA: lv_no(2)        TYPE n,
        lv_ok_icon      TYPE icon_d,
        lv_ok_text      TYPE bapi_msg,
        lv_ok_quickinfo TYPE bapi_msg.

  " 저장버튼
  IF pt_fcode[] IS INITIAL OR
     NOT line_exists( pt_fcode[ fcode = 'SAVE' ] ).
    lv_ok_icon      = icon_system_save.
    lv_ok_text      = space.
    lv_ok_quickinfo = space.
  ELSE.
    DATA(ls_fcode) = VALUE #( pt_fcode[ fcode = 'SAVE' ] OPTIONAL ).
    IF ls_fcode-ficon IS INITIAL AND ls_fcode-ftext IS INITIAL.
      lv_ok_icon      = icon_system_save.
      lv_ok_text      = space.
      lv_ok_quickinfo = space.
    ELSE.
      lv_ok_icon      = ls_fcode-ficon.
      lv_ok_text      = ls_fcode-ftext.
      lv_ok_quickinfo = space.
    ENDIF.
  ENDIF.
  PERFORM append_icon_to_button USING    lv_ok_icon
                                         lv_ok_text
                                         lv_ok_quickinfo
                                CHANGING gv_save_bt.

  " 취소버튼
  IF pt_fcode[] IS INITIAL OR
     NOT line_exists( pt_fcode[ fcode = 'CANC_EXIT' ] ).
    lv_ok_icon      = icon_cancel.
    lv_ok_text      = space.
    lv_ok_quickinfo = space.
  ELSE.
    ls_fcode = VALUE #( pt_fcode[ fcode = 'CANC_EXIT' ] OPTIONAL ).
    IF ls_fcode-ficon IS INITIAL AND ls_fcode-ftext IS INITIAL.
      lv_ok_icon      = icon_cancel.
      lv_ok_text      = space.
      lv_ok_quickinfo = space.
    ELSE.
      lv_ok_icon      = ls_fcode-ficon.
      lv_ok_text      = ls_fcode-ftext.
      lv_ok_quickinfo = space.
    ENDIF.
  ENDIF.
  PERFORM append_icon_to_button USING    lv_ok_icon
                                         lv_ok_text
                                         lv_ok_quickinfo
                                CHANGING gv_cancel_bt.

ENDFORM.
