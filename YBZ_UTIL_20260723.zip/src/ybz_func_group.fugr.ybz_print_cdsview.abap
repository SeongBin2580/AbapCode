FUNCTION YBZ_PRINT_CDSVIEW.
*"----------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     REFERENCE(IV_VIEWNAME) TYPE  OBJECTNAME
*"  EXPORTING
*"     REFERENCE(EV_DDLSOURCENAME) TYPE  DDLNAME
*"     REFERENCE(EV_DDTEXT) TYPE  DDTEXT
*"     REFERENCE(EV_SUBRC) TYPE  SY-SUBRC
*"  TABLES
*"      ET_DTAB TYPE  EFG_TAB_ASCIILINE
*"----------------------------------------------------------------------
" 구분에 따라서 검색 위치 변경

*  CASE iv_gubun.
*    WHEN space.
*      SELECT SINGLE ddlname
*        FROM ddldependency
*        INTO ev_ddlsourcename
*       WHERE objectname = iv_viewname
*         AND state      = 'A'.
*
*    WHEN OTHERS.
*      SELECT SINGLE ddlsourcename
*        FROM cds_sql_view
*        INTO @ev_ddlsourcename
*       WHERE sqlviewname = @iv_viewname.
*
*  ENDCASE.

  SELECT SINGLE ddlsourcename
    FROM cds_sql_view " table 은 ddldependency
   WHERE sqlviewname   = @iv_viewname OR
         ddlsourcename = @iv_viewname
    INTO @ev_ddlsourcename.

  ev_subrc = sy-subrc.
  CHECK sy-subrc = 0.

  SELECT SINGLE ddtext
    FROM ddddlsrct
    INTO ev_ddtext
   WHERE ddlname = ev_ddlsourcename
     AND ddlanguage = sy-langu.

  TRY.
      cl_dd_ddl_handler_factory=>create( )->read(
            EXPORTING
              name         = CONV ddlname( to_upper( ev_ddlsourcename ) )
            IMPORTING
              ddddlsrcv_wa = DATA(ddlsrcv_wa) ).
    CATCH cx_dd_ddl_read INTO DATA(exc).
      cl_demo_output=>display( exc->get_text( ) ).
  ENDTRY.

  DATA: lt_string TYPE TABLE OF char512.
  SPLIT ddlsrcv_wa-source AT cl_abap_char_utilities=>cr_lf
      INTO TABLE lt_string.
  IF lt_string[] IS NOT INITIAL.
    WRITE sy-uline   TO et_dtab.
    APPEND et_dtab.  CLEAR et_dtab.
    APPEND LINES OF lt_string TO et_dtab.
  ENDIF.





ENDFUNCTION.
