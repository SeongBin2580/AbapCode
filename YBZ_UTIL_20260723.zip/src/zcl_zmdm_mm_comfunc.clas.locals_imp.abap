CLASS lcl_active_sheet DEFINITION FINAL CREATE PRIVATE FRIENDS zcl_zmdm_mm_comfunc.

  PUBLIC SECTION.
    CLASS-METHODS get_active
      IMPORTING i_xlsx_xstr   TYPE xstring
      EXPORTING e_active_name TYPE string
                e_active_idx  TYPE i     " 1-based
      RAISING   cx_root.

ENDCLASS.

CLASS lcl_active_sheet IMPLEMENTATION.

  METHOD get_active.

    DATA(lo_zip) = NEW cl_abap_zip( ).
    lo_zip->load( zip = i_xlsx_xstr ).

    DATA: lv_workbook TYPE xstring,
          lv_act      TYPE string,
          lv_name     TYPE string.

    TRY.
        lo_zip->get( EXPORTING name = 'xl/workbook.xml' IMPORTING content = lv_workbook ).

      CATCH cx_root.
        CLEAR lv_workbook.
    ENDTRY.

    DATA lv_idx0  TYPE i VALUE -1.       " activeTab (0-based)
    DATA lt_names TYPE STANDARD TABLE OF string WITH EMPTY KEY.

    IF lv_workbook IS NOT INITIAL.

      " iXML 파싱
      DATA(lo_ixml) = cl_ixml=>create( ).
      DATA(lo_doc)  = lo_ixml->create_document( ).
      DATA(lo_sf)   = lo_ixml->create_stream_factory( ).
      DATA(lo_is)   = lo_sf->create_istream_xstring( lv_workbook ).
      DATA(lo_p)    = lo_ixml->create_parser( stream_factory = lo_sf
                                              istream        = lo_is
                                              document       = lo_doc ).
      IF lo_p->parse( ) = 0.
        DATA(lo_root) = lo_doc->get_root_element( ).  " <workbook>
        IF lo_root IS BOUND.

          " 1) bookViews/workbookView/@activeTab (문자열 리턴 시그니처)
          DATA(lo_n) = lo_root->get_first_child( ).
          WHILE lo_n IS BOUND.
            DATA(lo_e) = CAST if_ixml_element( lo_n ).
            IF lo_e IS BOUND AND lo_e->get_name( ) = 'bookViews'.
              DATA(lo_bv) = lo_e->get_first_child( ).
              WHILE lo_bv IS BOUND.
                DATA(lo_bve) = CAST if_ixml_element( lo_bv ).
                IF lo_bve IS BOUND AND lo_bve->get_name( ) = 'workbookView'.

                  lv_act = lo_bve->get_attribute( 'activeTab' ).  " ← 문자열 리턴
                  IF lv_act IS NOT INITIAL.
                    lv_idx0 = CONV i( lv_act ).                 " 0-based
                  ENDIF.
                  EXIT.
                ENDIF.
                lo_bv = lo_bv->get_next( ).
              ENDWHILE.
            ENDIF.
            lo_n = lo_n->get_next( ).
          ENDWHILE.

          " 2) sheets/sheet/@name 목록 (문자열 리턴 시그니처)
          lo_n = lo_root->get_first_child( ).
          WHILE lo_n IS BOUND.
            lo_e = CAST if_ixml_element( lo_n ).
            IF lo_e IS BOUND AND lo_e->get_name( ) = 'sheets'.
              DATA(lo_s) = lo_e->get_first_child( ).
              WHILE lo_s IS BOUND.
                DATA(lo_se) = CAST if_ixml_element( lo_s ).
                IF lo_se IS BOUND AND lo_se->get_name( ) = 'sheet'.

                  lv_name = lo_se->get_attribute( 'name' ).      " ← 문자열 리턴
                  IF lv_name IS NOT INITIAL.
                    APPEND lv_name TO lt_names.
                  ENDIF.
                ENDIF.
                lo_s = lo_s->get_next( ).
              ENDWHILE.
            ENDIF.
            lo_n = lo_n->get_next( ).
          ENDWHILE.

        ENDIF.
      ENDIF.
    ENDIF.

    " 3) 활성 시트 결정(없으면 1번 시트 폴백)
    IF lv_idx0 >= 0 AND lv_idx0 < lines( lt_names ).
      e_active_idx  = lv_idx0 + 1.                     " 1-based로 변환
      e_active_name = lt_names[ e_active_idx ].
    ELSE.
      e_active_idx  = 1.
      e_active_name = COND string( WHEN lines( lt_names ) > 0 THEN lt_names[ 1 ] ELSE '' ).
    ENDIF.

  ENDMETHOD.
ENDCLASS.
