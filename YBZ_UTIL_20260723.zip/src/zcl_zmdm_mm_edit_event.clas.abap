class ZCL_ZMDM_MM_EDIT_EVENT definition
  public
  final
  create public .

public section.

  constants GC_CH type CHAR2 value 'CH' ##NO_TEXT.
  constants GC_FM_DG type CHAR40 value 'LCE_DG_&1' ##NO_TEXT.
  constants GC_FM_DP type CHAR40 value 'LCE_DP_&1' ##NO_TEXT.
  data GV_DATA_SCR type SY-DYNNR .
  data GV_FORM_NAME type CHAR40 .
  data GV_OBJECT_TEXT type CHAR30 .
  data GV_OBJ_NAME type CHAR40 .
  data GV_ORG_REPID type SYREPID .
  data GV_PROG_SCR type SY-DYNNR .
  data GV_REPID type SYREPID .
  data GV_SET_EDITOR type STRING .
  data GV_SET_OKCODE type STRING .

  methods CONSTRUCTOR
    importing
      !IV_OBJECT_TEXT type CHAR30
      !IV_REPID type SY-REPID
      !IV_ORG_REPID type SY-REPID optional .
  methods HANDLE_ONDRAG
    for event ON_DRAG of CL_GUI_TEXTEDIT
    importing
      !FROM_INDEX
      !FROM_LINE
      !FROM_POS
      !DRAGDROP_OBJECT
      !TO_INDEX
      !TO_LINE
      !TO_POS .
  methods HANDLE_ONDROP
    for event ON_DROP of CL_GUI_TEXTEDIT
    importing
      !INDEX
      !LINE
      !POS
      !DRAGDROP_OBJECT .
  methods HANDLE_ONDROPCOMPLETE
    for event ON_DROP_COMPLETE of CL_GUI_TEXTEDIT
    importing
      !FROM_INDEX
      !FROM_LINE
      !FROM_POS
      !DRAGDROP_OBJECT
      !TO_INDEX
      !TO_LINE
      !TO_POS .
protected section.
private section.

  methods SET_LOCAL_FIELDS .
ENDCLASS.



CLASS ZCL_ZMDM_MM_EDIT_EVENT IMPLEMENTATION.


METHOD CONSTRUCTOR.
  ENDMETHOD.


METHOD HANDLE_ONDRAG.
  ENDMETHOD.


METHOD HANDLE_ONDROP.
  ENDMETHOD.


METHOD HANDLE_ONDROPCOMPLETE.
  ENDMETHOD.


METHOD SET_LOCAL_FIELDS .
  ENDMETHOD.
ENDCLASS.
