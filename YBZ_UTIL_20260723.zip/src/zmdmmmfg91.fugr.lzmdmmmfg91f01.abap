*----------------------------------------------------------------------*
***INCLUDE LZMDMMMFG91F01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form initialization
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM initialization .

  gv_repid             = gc_prog_id.

  IF go_comfunc IS INITIAL.
    CREATE OBJECT go_comfunc
      EXPORTING
        iv_repid = gv_repid.
  ENDIF.

  IF go_alv_info IS INITIAL.
    CREATE OBJECT go_alv_info
      EXPORTING
        iv_repid   = gv_repid
        io_comfunc = go_comfunc.
  ENDIF.

  IF go_edit_info IS INITIAL.
    CREATE OBJECT go_edit_info
      EXPORTING
        iv_repid   = gv_repid
        io_comfunc = go_comfunc.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form append_icon_to_button
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
FORM append_icon_to_button USING    pv_button_icon
                                    pv_button_text
                                    pv_button_quickinfo
                           CHANGING ps_button STRUCTURE smp_dyntxt.

  CLEAR ps_button.
  ps_button-icon_id   = pv_button_icon.
  ps_button-text      = pv_button_text.
  ps_button-quickinfo = pv_button_quickinfo.

  IF ps_button-icon_id IS NOT INITIAL.
    ps_button-icon_text = pv_button_text.
  ENDIF.

ENDFORM.                    " APPEND_ICON_TO_BUTTON
*&---------------------------------------------------------------------*
*& Form change_bt_text
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> IT_FCODE
*&---------------------------------------------------------------------*
FORM change_bt_text            CHANGING pt_fcode TYPE zmdmmmy9070.

  DATA: lv_no(2)        TYPE n,
        lv_ok_icon      TYPE icon_d,
        lv_ok_text      TYPE bapi_msg,
        lv_ok_quickinfo TYPE bapi_msg.

  FIELD-SYMBOLS:
      <lv_fcode_nm> TYPE smp_dyntxt.

  IF gv_display_mode_0100 = abap_false.
    PERFORM set_save_button_0100 CHANGING pt_fcode.
  ENDIF.

  " ADD_BT_01 ~ 09
  DO 9 TIMES.
    lv_no = sy-index.
    DATA(lv_fcode) = |ADD_BT_{ lv_no }|.

    DATA(ls_fcode) = VALUE #( pt_fcode[ fcode = lv_fcode ] OPTIONAL ).

    IF ls_fcode-ficon IS INITIAL AND ls_fcode-ftext IS INITIAL.
      IF ls_fcode-fcode IS INITIAL.
        APPEND VALUE #( fcode = lv_fcode ) TO pt_fcode.
      ENDIF.
    ELSE.
      UNASSIGN <lv_fcode_nm>.
      DATA(lv_fcode_nm) = |GV_ADD_BT_{ lv_no }|.
      ASSIGN (lv_fcode_nm) TO <lv_fcode_nm>.
      CHECK sy-subrc = 0.

      lv_ok_icon      = ls_fcode-ficon.
      lv_ok_text      = ls_fcode-ftext.
      lv_ok_quickinfo = ls_fcode-fquick.  " Quickinfo

      PERFORM append_icon_to_button USING    lv_ok_icon
                                             lv_ok_text
                                             lv_ok_quickinfo
                                    CHANGING <lv_fcode_nm>.

    ENDIF.

  ENDDO.

ENDFORM.
