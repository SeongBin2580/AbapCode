FUNCTION zmdmmmf_popup_editor.
*"----------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     REFERENCE(IV_TITLE)
*"     REFERENCE(IV_DISPLAY_MODE) TYPE  CHAR1 DEFAULT 'X'
*"     REFERENCE(IV_SAVE_MSG) TYPE  CHAR1 DEFAULT SPACE
*"     REFERENCE(IV_START_COLUMN) TYPE  I DEFAULT 15
*"     REFERENCE(IV_START_LINE) TYPE  I DEFAULT 3
*"     REFERENCE(IV_END_COLUMN) TYPE  I DEFAULT 100
*"     REFERENCE(IV_END_LINE) TYPE  I DEFAULT 20
*"     REFERENCE(IV_LINE_LENGTH) TYPE  I DEFAULT 80
*"  EXPORTING
*"     REFERENCE(EV_ACTION_FLAG) TYPE  CHAR1
*"  TABLES
*"      IT_DATA TYPE  STANDARD TABLE
*"      IT_FCODE STRUCTURE  ZMDMMMS9070 OPTIONAL
*"      IT_SCRFIELD STRUCTURE  ZMDMMMS9080 OPTIONAL
*"----------------------------------------------------------------------

  DATA: lv_end_line   TYPE i,
        lv_end_column TYPE i,
        lv_cur_length TYPE i,
        lv_max_length TYPE i,
        lv_max_title  TYPE i.

  PERFORM initialization.

  IF iv_title IS INITIAL.
    gv_title = '[POP]Text Editor'.                          "#EC NOTEXT
  ELSE.
    gv_title = iv_title.
  ENDIF.

  gv_display_mode_0200 = iv_display_mode.
  gv_line_length       = iv_line_length.
  gv_save_msg          = iv_save_msg.
  gt_fcode_in          = it_fcode[].
  gt_scrfield_in       = it_scrfield[].

  " application button
  PERFORM change_bt_text       CHANGING gt_fcode_in.

  CLEAR: gt_s0200[].
  APPEND LINES OF it_data TO gt_s0200.

  gv_action_flag_0200 = space.

  lv_cur_length = iv_end_column - iv_start_column + 1.
  lv_end_line   = iv_end_line.
  lv_end_column = iv_end_column.
  gv_subscr     = '9000'.

  CLEAR: gs_s9200.
  IF lines( gt_scrfield_in ) > 0.
    PERFORM set_scrfield_text_0200 CHANGING lv_max_length lv_max_title.

    IF lv_max_title BETWEEN 1 AND 10.
      gv_subscr  = '9210'.
    ELSEIF lv_max_title BETWEEN 11 AND 15.
      gv_subscr  = '9215'.
    ELSEIF lv_max_title BETWEEN 16 AND 20.
      gv_subscr  = '9220'.
    ELSEIF lv_max_title BETWEEN 21 AND 25.
      gv_subscr  = '9225'.
    ELSEIF lv_max_title BETWEEN 26 AND 30.
      gv_subscr  = '9230'.
    ELSEIF lv_max_title BETWEEN 31 AND 35.
      gv_subscr  = '9235'.
    ELSE.
      gv_subscr  = '9240'.
    ENDIF.

    lv_end_line = lv_end_line + 2 + lines( gt_scrfield_in ).

    IF lv_max_length > lv_cur_length.
      lv_end_column = lv_end_column + ( lv_max_length - lv_cur_length ) + 5.
    ENDIF.
  ENDIF.

  CALL SCREEN '0200'
       STARTING AT iv_start_column iv_start_line
       ENDING AT   lv_end_column   lv_end_line.

  ev_action_flag = gv_action_flag_0200.

  IF gv_action_flag_0200 = 'S'.
    CLEAR: it_data[].
    APPEND LINES OF gt_s0200 TO it_data.
    PERFORM get_scrfield_text_0200 CHANGING it_scrfield[].
  ENDIF.

ENDFUNCTION.
