FUNCTION YBZ_READ_DYNPRO.
*"--------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     VALUE(IV_PROGID) TYPE  PROGRAMM
*"     VALUE(IV_DYNNR) TYPE  SY-DYNNR
*"     VALUE(IV_LANGU) TYPE  SYST_LANGU DEFAULT SY-LANGU
*"  EXPORTING
*"     VALUE(ES_HEADER) TYPE  D020S
*"     VALUE(EV_DTXT) TYPE  AS4TEXT
*"  TABLES
*"      ET_FIELD STRUCTURE  D021S
*"      ET_LOGIC STRUCTURE  D022S
*"      ET_MEMID STRUCTURE  D023S
*"  EXCEPTIONS
*"      NOTFOUND
*"--------------------------------------------------------------------
DATA: lv_dynpro_id(44),
        lv_langu TYPE sy-langu.

  IF iv_langu IS INITIAL.
    lv_langu = sy-langu.
  ELSE.
    lv_langu = iv_langu.
  ENDIF.

  " 입력 program check
  SELECT COUNT( * )
    FROM trdir
    INTO sy-dbcnt
   WHERE name = iv_progid
     AND subc IN ('1','M','F').
  IF sy-subrc <> 0 OR sy-dbcnt = 0.
    MESSAGE 'Program ID Not Found' TYPE 'E' RAISING notfound.
  ENDIF.

  " 입력 screen No check
  SELECT COUNT( * )
    FROM d020s
    INTO sy-dbcnt
   WHERE prog = iv_progid
     AND dnum = iv_dynnr.
  IF sy-subrc <> 0 OR sy-dbcnt = 0.
    MESSAGE 'Screen No Not Found' TYPE 'E' RAISING notfound.
  ENDIF.

  " Screen text
  SELECT SINGLE dtxt
    FROM d020t
    INTO ev_dtxt
   WHERE prog = iv_progid
     AND dynr = iv_dynnr
     AND lang = lv_langu.
  IF sy-subrc NE 0 AND lv_langu <> sy-langu.
    SELECT SINGLE dtxt
      FROM d020t
      INTO ev_dtxt
     WHERE prog = iv_progid
       AND dynr = iv_dynnr
       AND lang = sy-langu.
  ENDIF.

  "Format Screen ID
  lv_dynpro_id       = iv_progid.
  lv_dynpro_id+40(4) = iv_dynnr.

  " 화면 정보 가지고 오기.
  IMPORT DYNPRO es_header
                et_field
                et_logic
                et_memid
             ID lv_dynpro_id.





ENDFUNCTION.
