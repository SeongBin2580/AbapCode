FUNCTION YBZ_F4_COMCODE.
*"--------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  TABLES
*"      SHLP_TAB TYPE  SHLP_DESCT
*"      RECORD_TAB STRUCTURE  SEAHLPRES
*"  CHANGING
*"     VALUE(SHLP) TYPE  SHLP_DESCR
*"     VALUE(CALLCONTROL) LIKE  DDSHF4CTRL STRUCTURE  DDSHF4CTRL
*"--------------------------------------------------------------------
* EXIT immediately, if you do not want to handle this step
  " example : F4IF_SHLP_EXIT_EXAMPLE


  IF callcontrol-step <> 'SELONE' AND
     callcontrol-step <> 'SELECT' AND
     " AND SO ON
     callcontrol-step <> 'DISP'.
    EXIT.
  ENDIF.

* STEP SELONE  (Select one of the elementary searchhelps)
* This step is only called for collective searchhelps. It may be used
* to reduce the amount of elementary searchhelps given in SHLP_TAB.
* The compound searchhelp is given in SHLP.
* If you do not change CALLCONTROL-STEP, the next step is the
* dialog, to select one of the elementary searchhelps.
* If you want to skip this dialog, you have to return the selected
* elementary searchhelp in SHLP and to change CALLCONTROL-STEP to
* either to 'PRESEL' or to 'SELECT'.
  IF callcontrol-step = 'SELONE'.
*   PERFORM SELONE .........
    EXIT.
  ENDIF.

* STEP PRESEL  (Enter selection conditions)
* This step allows you, to influence the selection conditions either
* before they are displayed or in order to skip the dialog completely.
* If you want to skip the dialog, you should change CALLCONTROL-STEP
* to 'SELECT'.
* Normaly only SHLP-SELOPT should be changed in this step.
  IF callcontrol-step = 'PRESEL'.
*   PERFORM PRESEL ..........
    EXIT.
  ENDIF.
* STEP SELECT    (Select values)
* This step may be used to overtake the data selection completely.
* To skip the standard seletion, you should return 'DISP' as following
* step in CALLCONTROL-STEP.
* Normally RECORD_TAB should be filled after this step.
* Standard function module F4UT_RESULTS_MAP may be very helpfull in this
* step.
  IF callcontrol-step = 'SELECT'.
    PERFORM select_comcode   TABLES   record_tab shlp_tab
                             CHANGING shlp callcontrol gv_rc.
    IF gv_rc = 0.
      callcontrol-step = 'DISP'.
    ELSE.
      callcontrol-step = 'EXIT'.
    ENDIF.
    EXIT. "Don't process STEP DISP additionally in this call.
  ENDIF.
* STEP DISP     (Display values)
* This step is called, before the selected data is displayed.
* You can e.g. modify or reduce the data in RECORD_TAB
* according to the users authority.
* If you want to get the standard display dialog afterwards, you
* should not change CALLCONTROL-STEP.
* If you want to overtake the dialog on you own, you must return
* the following values in CALLCONTROL-STEP:
* - "RETURN" if one line was selected. The selected line must be
*   the only record left in RECORD_TAB. The corresponding fields of
*   this line are entered into the screen.
* - "EXIT" if the values request should be aborted
* - "PRESEL" if you want to return to the selection dialog
* Standard function modules F4UT_PARAMETER_VALUE_GET and
* F4UT_PARAMETER_RESULTS_PUT may be very helpfull in this step.
  IF callcontrol-step = 'DISP'.
*   PERFORM AUTHORITY_CHECK TABLES RECORD_TAB SHLP_TAB
*                           CHANGING SHLP CALLCONTROL.
    EXIT.
  ENDIF.

FORM select_comcode    TABLES   pt_record_tab   STRUCTURE seahlpres
                                pt_shlp_tab     TYPE shlp_desct
                       CHANGING ps_shlp         TYPE shlp_descr
                                ps_callcontrol  TYPE ddshf4ctrl
                                pv_rc           TYPE sy-subrc.

*  Select용 Table정의....

*  입력받은 값..
  gt_fielddescr = ps_shlp-fielddescr.
  gt_fieldprop  = ps_shlp-fieldprop.
  gt_selopt     = ps_shlp-selopt.

  PERFORM set_field_comcode.
*---------------------------------------------------------------------*
*  Create to Select Result Table
  PERFORM com_set_result_table.

*---------------------------------------------------------------------*
  SELECT SINGLE x~low
    FROM @ps_shlp-selopt AS x
   WHERE shlpfield = 'IDX_GROUP'
    INTO @DATA(lv_group)
    ##ITAB_KEY_IN_SELECT ##ITAB_DB_SELECT.
  pv_rc = sy-subrc.
  CHECK sy-subrc = 0.

  SELECT SINGLE x~low
    FROM @ps_shlp-selopt AS x
   WHERE shlpfield = 'IDX_CODE'
    INTO @DATA(lv_code)
    ##ITAB_KEY_IN_SELECT ##ITAB_DB_SELECT.
  pv_rc = sy-subrc.
  CHECK sy-subrc = 0.

* window title
  SELECT SINGLE idx_desc
    FROM zppt0010t
   WHERE idx_group = @lv_group
     AND idx_code  = @lv_code
     AND spras     = @sy-langu
    INTO @ps_shlp-intdescr-title.

  " field title
  LOOP AT ps_shlp-fielddescr ASSIGNING FIELD-SYMBOL(<ls_desc>).

    SELECT SINGLE fieldtext
      FROM zppt0020t
       WHERE idx_group = @lv_group
         AND idx_code  = @lv_code
         AND spras     = @sy-langu
         AND fieldname = @<ls_desc>-fieldname
        INTO @<ls_desc>-reptext.

  ENDLOOP.

*  값 가지고 오기..
  TRY.
      SELECT *
        FROM zppv0030d
       WHERE (gt_wtab)
         AND idx_notused = @space
        INTO CORRESPONDING FIELDS OF TABLE @<gt_table>.
      pv_rc = sy-subrc.

    CATCH cx_sy_dynamic_osql_semantics.
      pv_rc = 4.

  ENDTRY.
*--------------------------------------------------------------------*
  " outer join 으로 연결된 조건이 입력된 경우..
  PERFORM com_check_other_option.
*--------------------------------------------------------------------*

  " 최종 검색자료..
  IF lines( <gt_table> ) IS INITIAL.
    " 검색된 자료가 없습니다.
    MESSAGE i502 WITH TEXT-e01. " Data Not Found
    pv_rc = 4.
  ENDIF.

*   F4 표준 형태로..Display..
    TABLES
      shlp_tab    = pt_shlp_tab
      record_tab  = pt_record_tab
      source_tab  = <gt_table>
    CHANGING
      shlp        = ps_shlp
      callcontrol = ps_callcontrol.

*---------------------------------------------------------------------*
  PERFORM com_free_memory.
*---------------------------------------------------------------------*


ENDFORM.                    " SELECT_COMCODE

FORM set_field_comcode.

  CHECK gt_fieldlist[] IS INITIAL.

*  %set_field: 'DEPCD'      'A'  'I',
*              'DEPCDNM'    'A'  'I',
*              'COMCODE'    'A'  'I',
*              'HRCODENM'   'A'  'I',
*              'HRCODE'     'A'  'I'.
*
*  SORT gt_fieldlist BY fieldname.

ENDFORM.      " SET_FIELD_COMCODE

FORM sort_comcode      TABLES   pt_record_tab   STRUCTURE seahlpres
                                pt_shlp_tab     TYPE shlp_desct
                       CHANGING ps_shlp         TYPE shlp_descr
                                ps_callcontrol  TYPE ddshf4ctrl.

*  CALL FUNCTION 'F4UT_PARAMETER_SORT'
** EXPORTING
**   PARAMETER_SORT        = ' '
**   LEADING_COLUMNS       = '0'
**   DESCENDING            = ' '
*    TABLES
*      shlp_tab    = pt_shlp_tab
*      record_tab  = pt_record_tab
*    CHANGING
*      shlp        = ps_shlp
*      callcontrol = ps_callcontrol.

  ps_callcontrol-sortoff = 'X'. " 자동 sort 하지 않음

ENDFORM.





ENDFUNCTION.
