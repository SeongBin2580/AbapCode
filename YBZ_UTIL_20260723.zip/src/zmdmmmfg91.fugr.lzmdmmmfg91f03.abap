*----------------------------------------------------------------------*
***INCLUDE LZMDMMMFG91F03.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form set_fcode_0200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM set_fcode_0200 .

  CLEAR: gt_fcode[].
  IF gv_display_mode_0100 = space.
    MOVE 'BACK_EXIT' TO gs_fcode. APPEND gs_fcode TO gt_fcode.
  ELSE.
    MOVE 'CANC_EXIT' TO gs_fcode. APPEND gs_fcode TO gt_fcode.
    MOVE 'SAVE'      TO gs_fcode. APPEND gs_fcode TO gt_fcode.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_scrfield_text_0200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM set_scrfield_text_0200  CHANGING pv_max_length pv_max_title.

  CLEAR: pv_max_length, pv_max_title.

  LOOP AT gt_scrfield_in INTO gs_scrfield_in.

    " field 총길이
    IF pv_max_length < ( gs_scrfield_in-length_ti + gs_scrfield_in-length_va ).
      pv_max_length = gs_scrfield_in-length_ti + gs_scrfield_in-length_va.
    ENDIF.

    " title 의 최종길이
    IF pv_max_title < gs_scrfield_in-length_ti.
      pv_max_title = gs_scrfield_in-length_ti.
    ENDIF.


    DATA(lv_title) = |GS_S9200-TITLE_{ gs_scrfield_in-seqno }|.
    DATA(lv_value) = |GS_S9200-VALUE_{ gs_scrfield_in-seqno }|.

    ASSIGN (lv_title) TO FIELD-SYMBOL(<lv_title>).
    CHECK sy-subrc = 0 AND <lv_title> IS ASSIGNED.
    ASSIGN (lv_value) TO FIELD-SYMBOL(<lv_value>).
    CHECK sy-subrc = 0 AND <lv_value> IS ASSIGNED.

    IF gs_scrfield_in-value_ti IS NOT INITIAL.
      <lv_title> = gs_scrfield_in-value_ti.
    ENDIF.

    IF gs_scrfield_in-value_va IS NOT INITIAL.
      <lv_value> = gs_scrfield_in-value_va.
    ENDIF.

  ENDLOOP.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen_attr_leng_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GS_SCRATTR_IN
*&      <-- SCREEN
*&---------------------------------------------------------------------*
FORM set_screen_attr_leng_9200  USING    ps_scrattr_in TYPE zmdmmms9082
                                CHANGING ps_screen     TYPE screen.

  DATA: lv_length_i TYPE i.

  lv_length_i = ps_screen-length.
  IF ps_scrattr_in-length > 0.
    ps_screen-length = ps_scrattr_in-length.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen_attr_obl_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GS_SCRATTR_IN
*&      <-- SCREEN
*&---------------------------------------------------------------------*
FORM set_screen_attr_obl_9200   USING    ps_scrattr_in TYPE zmdmmms9082
                                CHANGING ps_screen     TYPE screen.

  ps_screen-required = '0'.
  CASE ps_scrattr_in-field_obl. " 필수여부
    WHEN abap_true.
      ps_screen-required = '1'.

    WHEN '2'.  " 화면에만 필수 표시
      screen-required = '2'.

    WHEN OTHERS.
  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen_attr_attr_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GS_SCRATTR_IN
*&      <-- SCREEN
*&---------------------------------------------------------------------*
FORM set_screen_attr_attr_9200  USING    ps_scrattr_in TYPE zmdmmms9082
                                CHANGING ps_screen     TYPE screen.

  CASE ps_scrattr_in-field_attr. " field 의 속성
    WHEN space.  " 일반 Field

    WHEN '1'. " 입력, 밝은색
      screen-intensified = '1'.
      screen-input       = '1'.

    WHEN '2'. " 조회용, 입력 Field 표기됨
      screen-display_3d  = '1'.
      ps_screen-input    = '0'.

    WHEN '3'.  " 색있는, 조회용, 입력 Field 표기됨
      screen-intensified = '1'.
      screen-input       = '0'.
      screen-display_3d  = '1'.

    WHEN '4'.  " 기본, 조회용, 입력 field 조회안됨
      screen-input       = '0'.
      screen-display_3d  = '0'.

    WHEN '5'.  " 색있는, 조회용, 입력 field 조회안됨
      screen-intensified = '1'.
      screen-input       = '0'.
      screen-display_3d  = '0'.

    WHEN 'P'. " passwork field
      screen-input     = '1'.
      screen-invisible = '1'.

    WHEN OTHERS.
  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen_attr_help_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GS_SCRATTR_IN
*&      <-- SCREEN
*&---------------------------------------------------------------------*
FORM set_screen_attr_help_9200  USING    ps_scrattr_in TYPE zmdmmms9082
                                CHANGING ps_screen     TYPE screen.

  IF ps_scrattr_in-help_form   IS NOT INITIAL OR
     ps_scrattr_in-help_object IS NOT INITIAL.
    ps_screen-value_help = '1'.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_scrfield_text_0200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- IT_SCRFIELD
*&---------------------------------------------------------------------*
FORM get_scrfield_text_0200  CHANGING pt_scrfield TYPE zmdmmmy9080.

  LOOP AT gt_scrfield_in INTO gs_scrfield_in.

    DATA(lv_idx) = sy-tabix.

    DATA(lv_value) = |GS_S9200-VALUE_{ gs_scrfield_in-seqno }|.

    ASSIGN (lv_value) TO FIELD-SYMBOL(<lv_value>).
    CHECK sy-subrc = 0 AND <lv_value> IS ASSIGNED.

    gs_scrfield_in-value_va = <lv_value>.
    MODIFY gt_scrfield_in FROM gs_scrfield_in INDEX lv_idx.

  ENDLOOP.

  pt_scrfield = gt_scrfield_in.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form f4_search_help_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> GS_SCRFIELD_IN_HELP_OBJECT
*&      <-- GS_S9200_VALUE_01
*&---------------------------------------------------------------------*
FORM f4_search_help_9200  USING    pv_help_object pv_ret_field
                                   pv_display
                          CHANGING pv_selected pv_value.

  CLEAR: gs_f4_info.
  gs_f4_info-display = pv_display.

  DATA(ls_return) = go_comfunc->f4_search_help( iv_search_help  = pv_help_object
                                                iv_fn_ret_field = pv_ret_field
                                                is_f4_info      = gs_f4_info ).
  pv_value    = ls_return-value.
  pv_selected = ls_return-selected.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form execute_f4_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- GS_S9200_VALUE_01
*&---------------------------------------------------------------------*
FORM execute_f4_9200  CHANGING pv_return_value.

  DATA: lv_selected,
        lv_display.

  lv_display = SWITCH #( gs_scrfield_in-field_attr_va WHEN ' ' THEN abap_false " 입력
                                                      WHEN '1' THEN abap_false " 입력,색있는
                                                               ELSE abap_true ).

  IF gs_scrfield_in-cb_repid_va  IS NOT INITIAL AND
     gs_scrfield_in-help_form_va IS NOT INITIAL.

    PERFORM (gs_scrfield_in-help_form_va) IN PROGRAM (gs_scrfield_in-cb_repid_va) IF FOUND
                                    CHANGING lv_selected pv_return_value.


  ELSEIF gs_scrfield_in-help_object_va    IS NOT INITIAL AND
         gs_scrfield_in-help_ret_field_va IS NOT INITIAL.

    PERFORM f4_search_help_9200 USING    gs_scrfield_in-help_object_va
                                         gs_scrfield_in-help_ret_field_va
                                         lv_display
                                CHANGING lv_selected pv_return_value.

  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_value_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- GS_S9200_VALUE_01
*&---------------------------------------------------------------------*
FORM check_value_9200  CHANGING pv_value.

  DATA: lv_type    TYPE bapi_mtype,
        lv_message TYPE bapi_msg.

  " 입력된 값 check
  CLEAR: lv_type, lv_message.

  "  1. 입력된 check form 이 있는 경우
  IF gs_scrfield_in-cb_repid_va   IS NOT INITIAL AND
     gs_scrfield_in-check_form_va IS NOT INITIAL.

    PERFORM (gs_scrfield_in-check_form_va) IN PROGRAM (gs_scrfield_in-cb_repid_va) IF FOUND
                                     USING    pv_value
                                     CHANGING lv_type lv_message.

  ELSEIF gs_scrfield_in-ref_table_va IS NOT INITIAL AND
         gs_scrfield_in-ref_field_va IS NOT INITIAL.

    PERFORM check_ref_fieldvalue_9200 USING    pv_value
                                      CHANGING lv_type lv_message.

  ENDIF.

  " 작업결과 메시지
  CASE lv_type.
    WHEN 'A'. MESSAGE e000 WITH lv_message.
    WHEN 'I'. MESSAGE i000 WITH lv_message.
    WHEN 'E'. MESSAGE s000 WITH lv_message DISPLAY LIKE 'E'.
    WHEN 'W'. MESSAGE w000 WITH lv_message.
    WHEN 'M'. MESSAGE s000 WITH lv_message.  " 성공 메시지 출력
    WHEN OTHERS.
  ENDCASE.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_ref_fieldvalue_9200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> PV_VALUE
*&      <-- LV_TYPE
*&      <-- LV_MESSAGE
*&---------------------------------------------------------------------*
FORM check_ref_fieldvalue_9200  CHANGING pv_value
                                         pv_type   pv_message.

  DATA: lv_fieldname TYPE scrfname,
        lo_data_ref  TYPE REF TO data.

  DATA: ls_table_field TYPE tabfield.

  FIELD-SYMBOLS:
    <lv_fieldname>  TYPE any,
    <lv_fieldvalue> TYPE c.

  CLEAR: pv_type, pv_message.

  CHECK gs_scrfield_in-ref_table_va IS NOT INITIAL AND
        gs_scrfield_in-ref_field_va IS NOT INITIAL.

  CONCATENATE gs_scrfield_in-ref_table_va gs_scrfield_in-ref_field_va
              INTO lv_fieldname SEPARATED BY '-'.
  SHIFT lv_fieldname LEFT DELETING LEADING '*'.

  CREATE DATA lo_data_ref TYPE (lv_fieldname).

  ASSIGN lo_data_ref->* TO <lv_fieldname>.
  ASSIGN pv_value+0(gs_scrfield_in-length_va) TO <lv_fieldvalue>.

  CALL FUNCTION 'RS_CONV_EX_2_IN'
    EXPORTING
      input_external               = <lv_fieldvalue>
      table_field                  = ls_table_field
      currency                     = gs_scrfield_in-ref_currency_va       "CURRENCY
    IMPORTING
      output_internal              = <lv_fieldname>
    EXCEPTIONS
      input_not_numerical          = 1
      too_many_decimals            = 2
      more_than_one_sign           = 3
      ill_thousand_separator_dist  = 4
      too_many_digits              = 5
      sign_for_unsigned            = 6
      too_large                    = 7
      too_small                    = 8
      invalid_date_format          = 9
      invalid_date                 = 10
      invalid_time_format          = 11
      invalid_time                 = 12
      invalid_hex_digit            = 13
      unexpected_error             = 14
      invalid_fieldname            = 15
      field_and_descr_incompatible = 16
      input_too_long               = 17
      no_decimals                  = 18
      invalid_float                = 19
      conversion_exit_error        = 20
      OTHERS                       = 21.
  IF sy-subrc <> 0.
    pv_type = 'A'.
    MESSAGE ID sy-msgid TYPE 'S' NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
            INTO pv_message.
    EXIT.
  ENDIF.

  " 금액인 경우 : 확인해야함
**  IF svali-datatype = 'CURR' AND
**     svali-decimals <> 2.
**
**    IF wa_svali-value IS INITIAL.
**      <f1> = <f1> * 10 ** ( 2 - svali-decimals ).
**    ELSE.
**      SELECT SINGLE * FROM tcurx
**             INTO lv_tcurx
**             WHERE currkey = wa_svali-value.
**      IF sy-subrc = 0.
*** Die Währung hat Dezimalstellen <> 2. In dem Fall funktioniert
*** der Konvertierungsbaustein korrekt.
**      ELSE.
**        <f1> = <f1> * 10 ** ( 2 - svali-decimals ).
**      ENDIF.
**    ENDIF.
**
**  ENDIF.

**  통화키인 경우
**  IF svali-datatype = 'CUKY'.
**    MOVE <f1> TO lv_cuky.
**    PERFORM adapt_currency_to_cuky USING svali-value
**                                         lv_cuky.
**    svali-value = lv_cuky.
**  ELSE.

  MOVE <lv_fieldname> TO pv_value.
**  ENDIF.

ENDFORM.
