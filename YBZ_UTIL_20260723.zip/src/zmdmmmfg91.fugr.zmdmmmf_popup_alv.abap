FUNCTION zmdmmmf_popup_alv.
*"----------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     REFERENCE(IV_TITLE)
*"     REFERENCE(IV_SELECTION_FIELD) TYPE  FIELDNAME DEFAULT SPACE
*"     REFERENCE(IV_DISPLAY_MODE) TYPE  CHAR1 DEFAULT SPACE
*"     REFERENCE(IV_CB_REPID) TYPE  SY-REPID OPTIONAL
*"     REFERENCE(IV_CB_DYNNR) TYPE  SY-DYNNR OPTIONAL
*"     REFERENCE(IV_EXCLUDE_TB_ALL) TYPE  CHAR1 DEFAULT SPACE
*"     REFERENCE(IV_START_COLUMN) TYPE  I DEFAULT 15
*"     REFERENCE(IV_START_LINE) TYPE  I DEFAULT 3
*"     REFERENCE(IV_END_COLUMN) TYPE  I DEFAULT 100
*"     REFERENCE(IV_END_LINE) TYPE  I DEFAULT 20
*"     REFERENCE(IS_LAYOUT) TYPE  LVC_S_LAYO OPTIONAL
*"     REFERENCE(IV_EXCLUDE_SAVE) TYPE  CHAR1 DEFAULT SPACE
*"  EXPORTING
*"     REFERENCE(EV_SELECTED) TYPE  CHAR1
*"  TABLES
*"      IT_DATA TYPE  STANDARD TABLE
*"      IT_FIELDCAT TYPE  LVC_T_FCAT OPTIONAL
*"      IT_EXCLUDING TYPE  UI_FUNCTIONS OPTIONAL
*"      IT_FCODE STRUCTURE  ZMDMMMS9070 OPTIONAL
*"      IT_DROPDOWN TYPE  LVC_T_DRAL OPTIONAL
*"----------------------------------------------------------------------


  PERFORM initialization.

  " 조회 모드에 조회 대상 정보가 없는 경우
  IF iv_display_mode = abap_true AND it_data[] IS INITIAL.
    EXIT.
  ENDIF.

  " Program id.
  gv_org_repid       = gv_repid.
  IF iv_cb_repid IS INITIAL.
    gv_cb_repid        = sy-cprog.
  ELSE.
    gv_repid           = iv_cb_repid.
    gv_cb_repid        = iv_cb_repid.
  ENDIF.

  " Screen No
  IF iv_cb_dynnr IS INITIAL.
    gv_dynnr = '0100'.
  ELSE.
    gv_dynnr = gv_cb_scr = iv_cb_dynnr.
  ENDIF.

  " Object Type
  CONCATENATE gc_object_type_0100 gv_dynnr INTO gv_object_text.
  gv_check_form = |LUC_{ gv_dynnr }_{ gc_check_form }|.
  gv_save_form  = |LUC_{ gv_dynnr }_{ gc_save_form }|.

  gv_title           = iv_title.
  IF gv_title IS INITIAL.
    gv_title = TEXT-t01. " Display Data
  ENDIF.

  gv_exclude_tb_all  = iv_exclude_tb_all.
  gv_selection_field = iv_selection_field.
  gv_exclude_save    = iv_exclude_save.
  gt_fcode_in        = it_fcode[].

  gs_layout_0100     = is_layout.
  gt_tool_0100       = it_excluding[].
  gt_fieldcat_0100   = it_fieldcat[].
  gt_dropdown_0100   = it_dropdown[].

  ASSIGN ('IT_DATA[]') TO <gt_s0100>.

  gv_exit_mode_0100 = abap_true.
  CASE iv_display_mode.
    WHEN '1'.  " 변경모드/종료확인 없음
      gv_display_mode_0100 = space.
      gv_exit_mode_0100    = space.

    WHEN '2'. " 변경모드/입력된 Data 저장 확인
      gv_display_mode_0100 = space.
      gv_save_flag_0100    = abap_true.

    WHEN OTHERS.
      gv_display_mode_0100 = iv_display_mode.
      gv_save_flag_0100    = space.
  ENDCASE.

  gv_selected_0100     = space.

  " application button
  PERFORM change_bt_text       CHANGING gt_fcode_in.

  CALL SCREEN '0100'
       STARTING AT iv_start_column iv_start_line
       ENDING AT   iv_end_column   iv_end_line.

  " gv_selected_0100
  "   S : 저장된

  ev_selected = gv_selected_0100.

ENDFUNCTION.
