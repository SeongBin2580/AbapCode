FUNCTION YBZ_READ_TEXTPOOL.
*"--------------------------------------------------------------------
*"*"로컬 인터페이스:
*"  IMPORTING
*"     VALUE(IV_PROGID) TYPE  PROGRAMM
*"     VALUE(IV_LANGU) TYPE  SYST_LANGU DEFAULT SY-LANGU
*"  TABLES
*"      ET_DATA STRUCTURE  TEXTPOOL
*"  EXCEPTIONS
*"      NOTFOUND
*"--------------------------------------------------------------------
DATA: lv_langu TYPE sy-langu.

  CLEAR: et_data[].

  IF iv_langu IS INITIAL.
    lv_langu = sy-langu.
  ELSE.
    lv_langu = iv_langu.
  ENDIF.

  " 입력 program check
  SELECT COUNT( * )
    FROM trdir
    INTO sy-dbcnt
   WHERE name = iv_progid
     AND subc IN ('1','M','F').
  IF sy-subrc <> 0 OR sy-dbcnt = 0.
    MESSAGE 'Program ID Not Found' TYPE 'E' RAISING notfound.
  ENDIF.

  READ TEXTPOOL iv_progid INTO et_data LANGUAGE lv_langu.





ENDFUNCTION.
