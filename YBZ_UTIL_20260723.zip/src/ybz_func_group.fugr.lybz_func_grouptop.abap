FUNCTION-POOL YBZ_FUNC_GROUP.              "MESSAGE-ID ..

* INCLUDE LYB_Z_FUNC_GROUPD...               " Local class definition
