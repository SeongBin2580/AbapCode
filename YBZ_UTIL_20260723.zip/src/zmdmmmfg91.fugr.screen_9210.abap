PROCESS BEFORE OUTPUT.
  MODULE init_9200.
  MODULE modify_screen_9200.

PROCESS AFTER INPUT.
  FIELD gs_s9200-value_01 MODULE check_value_01_9200 ON REQUEST.
  FIELD gs_s9200-value_02 MODULE check_value_02_9200 ON REQUEST.
  FIELD gs_s9200-value_03 MODULE check_value_03_9200 ON REQUEST.
  FIELD gs_s9200-value_04 MODULE check_value_04_9200 ON REQUEST.
  FIELD gs_s9200-value_05 MODULE check_value_05_9200 ON REQUEST.
  FIELD gs_s9200-value_06 MODULE check_value_06_9200 ON REQUEST.
  FIELD gs_s9200-value_07 MODULE check_value_07_9200 ON REQUEST.
  FIELD gs_s9200-value_08 MODULE check_value_08_9200 ON REQUEST.
  FIELD gs_s9200-value_09 MODULE check_value_09_9200 ON REQUEST.
  FIELD gs_s9200-value_10 MODULE check_value_10_9200 ON REQUEST.
  FIELD gs_s9200-value_11 MODULE check_value_11_9200 ON REQUEST.
  FIELD gs_s9200-value_12 MODULE check_value_12_9200 ON REQUEST.

  MODULE user_command_9200.

PROCESS ON VALUE-REQUEST.
  FIELD gs_s9200-value_01 MODULE f4_value_01_9200.
  FIELD gs_s9200-value_02 MODULE f4_value_02_9200.
  FIELD gs_s9200-value_03 MODULE f4_value_03_9200.
  FIELD gs_s9200-value_04 MODULE f4_value_04_9200.
  FIELD gs_s9200-value_05 MODULE f4_value_05_9200.
  FIELD gs_s9200-value_06 MODULE f4_value_06_9200.
  FIELD gs_s9200-value_07 MODULE f4_value_07_9200.
  FIELD gs_s9200-value_08 MODULE f4_value_08_9200.
  FIELD gs_s9200-value_09 MODULE f4_value_09_9200.
  FIELD gs_s9200-value_10 MODULE f4_value_10_9200.
  FIELD gs_s9200-value_11 MODULE f4_value_11_9200.
  FIELD gs_s9200-value_12 MODULE f4_value_12_9200.
