PROCESS BEFORE OUTPUT.
  MODULE status_0200.
  MODULE init_0200.

  CALL SUBSCREEN subrc INCLUDING gv_repid gv_subscr.

PROCESS AFTER INPUT.
  MODULE exit_0200 AT EXIT-COMMAND.
  MODULE get_okcode.

  CALL SUBSCREEN subrc.

  MODULE user_command_0200.

  " 차후에 화면을 변경 할 일 이 있는 경우 다음을 고려
  " subscreen 을 상/하 로 배치.
  " title 은 20자리 고정
  " value 는 100 고정, 40,80 자리 scroll 기능 추가
  " scroll field def length : 255
  " 입력 table seq 위치가 상/하 지정 : 지정되지 않은 경우 하
