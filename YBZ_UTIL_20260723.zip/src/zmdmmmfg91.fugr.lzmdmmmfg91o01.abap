*----------------------------------------------------------------------*
***INCLUDE LZMDMMMFG91O01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

  PERFORM set_fcode_0100.

*    CODE="ADD_BT_01  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_01"
*    CODE="ADD_BT_02  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_02"
*    CODE="ADD_BT_03  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_03"
*    CODE="ADD_BT_04  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_04"
*    CODE="ADD_BT_05  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_05"
*    CODE="ADD_BT_06  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_06"
*    CODE="ADD_BT_07  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_07"
*    CODE="ADD_BT_08  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_08"
*    CODE="ADD_BT_09  "           TEXT_TYPE="D" TEXT_NAME="GV_ADD_BT_09"
*    CODE="BACK_EXIT  " TYPE="E"  TEXT_TYPE="S" TEXT_NAME="ICON_OKAY   "    FUN_TEXT="확인"
*    CODE="CANC_EXIT  " TYPE="E"  TEXT_TYPE="D" TEXT_NAME="GV_CANCEL_BT"
*    CODE="SAVE       "           TEXT_TYPE="D" TEXT_NAME="GV_SAVE_BT  "
*
*    STATUS="0200" FUNCTION="ADD_BT_01"/>
*    STATUS="0200" FUNCTION="ADD_BT_02"/>
*    STATUS="0200" FUNCTION="ADD_BT_03"/>
*    STATUS="0200" FUNCTION="ADD_BT_04"/>
*    STATUS="0200" FUNCTION="ADD_BT_05"/>
*    STATUS="0200" FUNCTION="ADD_BT_06"/>
*    STATUS="0200" FUNCTION="ADD_BT_07"/>
*    STATUS="0200" FUNCTION="ADD_BT_08"/>
*    STATUS="0200" FUNCTION="ADD_BT_09"/>
*
*    STATUS="0200" FUNCTION="BACK_EXIT"/>
*    STATUS="0200" FUNCTION="SAVE"/>
*    STATUS="0200" FUNCTION="CANC_EXIT"/>

  " Popup ALV
  SET PF-STATUS '0100' EXCLUDING gt_fcode.

  " &
  SET TITLEBAR '0100' WITH gv_title.

ENDMODULE.                 " STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_0100 OUTPUT.

*  Container 가 없는 경우 신규로 생성..
  IF go_ccon_0100 IS INITIAL.

    go_alv_info->create_on_con( EXPORTING iv_repid  = gv_repid
                                          iv_dynnr  = sy-dynnr
                                          iv_contnm = gc_contnm_0100
                                IMPORTING eo_ccon   = go_ccon_0100
                                          eo_grid   = go_grid_0100 ).

*   define screen properties
    PERFORM set_alv_layout_0100.       " SET LAYOUT
    PERFORM set_alv_toolbar_0100.      " SET EXCLUDE_TB
    PERFORM set_alv_varient_0100.      " SET VARIENT
    PERFORM set_alv_fieldcat_0100.     " SET FIELD CATAGORY
    PERFORM set_alv_sortcat_0100.      " SET SORT FIELD

*-- SET  EVENT
    go_alv_info->set_event( EXPORTING iv_object_text = gv_object_text
                                      io_grid        = go_grid_0100
                                      iv_org_repid   = gv_cb_repid
                            CHANGING  co_alv_event   = go_alv_event
                                      ct_fcat        = gt_fieldcat_0100
                                      ct_drop        = gt_dropdown_0100 ).

    go_alv_info->display_grid( '0100' ).

  ELSE.

    go_alv_info->refresh_grid( '0100' ).
  ENDIF.

  go_alv_info->set_display_mode( '0100' ).

ENDMODULE.                 " INIT_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0200 OUTPUT.

  PERFORM set_fcode_0200.

  " Editor Screen
  SET PF-STATUS '0200' EXCLUDING gt_fcode.

  " &
  SET TITLEBAR '0200' WITH gv_title.

ENDMODULE.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_0200 OUTPUT.

*  Container 가 없는 경우 신규로 생성..
  IF go_ccon_0200 IS INITIAL.

    go_edit_info->create_on_con( EXPORTING iv_repid         = gv_repid
                                           iv_dynnr         = sy-dynnr
                                           iv_contnm        = gc_contnm_0200
                                           iv_line_length   = gv_line_length
                                 IMPORTING eo_ccon          = go_ccon_0200
                                           eo_edit          = go_edit_0200 ).

    go_edit_info->set_event( EXPORTING iv_object_text = gc_object_id_0200
                                       io_edit        = go_edit_0200
                             CHANGING  co_edit_event  = go_edit_event ).

    go_edit_info->set_edit_box( io_edit = go_edit_0200 ).

  ENDIF.

*   set screen edit mode
  go_edit_info->set_display_mode( '0200' ).
  go_edit_info->set_r3table( io_edit  = go_edit_0200
                             it_table = gt_s0200[]    ).

ENDMODULE.                 " INIT_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_9200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_9200 OUTPUT.
ENDMODULE.                 " INIT_9200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  MODIFY_SCREEN_9200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE modify_screen_9200 OUTPUT.

  LOOP AT SCREEN.

    " 화면의 가변 field
    IF screen-group1 = 'FIL'.
      screen-active     = '0'.  " 기본으로 숨김
      screen-length     = '1'.
      screen-value_help = '0'.

      " 입력된 정보가 있는지 확인
      REPLACE ALL OCCURRENCES OF '-' IN screen-name WITH '_'.
      SPLIT screen-name AT '_' INTO TABLE DATA(lt_name_part).

      READ TABLE lt_name_part INTO DATA(ls_name_part) INDEX 4.
      IF sy-subrc = 0.
        READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = ls_name_part.
        IF sy-subrc = 0.

          screen-active = '1'.  " Field 보임

          READ TABLE lt_name_part INTO ls_name_part INDEX 3.
          CASE ls_name_part.
            WHEN 'TITLE'. gs_scrattr_in = CORRESPONDING #( gs_scrfield_in-title ).
            WHEN OTHERS.  gs_scrattr_in = gs_scrfield_in-value.
          ENDCASE.

          PERFORM set_screen_attr_obl_9200  USING gs_scrattr_in CHANGING screen.
          PERFORM set_screen_attr_attr_9200 USING gs_scrattr_in CHANGING screen.
          PERFORM set_screen_attr_leng_9200 USING gs_scrattr_in CHANGING screen.
          PERFORM set_screen_attr_help_9200 USING gs_scrattr_in CHANGING screen.

        ENDIF.
      ENDIF.

    ENDIF.

    MODIFY SCREEN.

  ENDLOOP.

ENDMODULE.                 " MODIFY_SCREEN_9200  OUTPUT
