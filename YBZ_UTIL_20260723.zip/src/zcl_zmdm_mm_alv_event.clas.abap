CLASS zcl_zmdm_mm_alv_event DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ts_app_field,
        " sp,A: 1번라인이 아닌 경우 신규행
        " I   : 동일 라인에 값 추가
        add_position TYPE char1,
        recordpos    TYPE recordpos,
        text_field   TYPE lvc_fname,
        text_value   TYPE lvc_value,
      END OF ts_app_field .
    TYPES:
      tt_app_fields        TYPE TABLE OF ts_app_field .
    TYPES:
      BEGIN OF ts_mod_fld,
        fieldname TYPE fieldname,
        value     TYPE lvc_value,
      END OF ts_mod_fld .
    TYPES:
      tt_mod_fld TYPE TABLE OF ts_mod_fld WITH KEY fieldname .
    TYPES:
      BEGIN OF ts_mod_tab,
        index     TYPE lvc_s_modi-row_id,
        upt_tab   TYPE char1,
        upt_color TYPE char1,
        upt_line  TYPE char1,
        upt_field TYPE char1,
        fieldtab  TYPE tt_mod_fld,
        linecolor TYPE char4,
        celltab   TYPE lvc_t_styl,      " CHANGE THE PROPERTIES OF A FIELD
        cellcolor TYPE lvc_t_scol,      " CTAB_FNAME [ LVC_T_SCOL ]
      END OF ts_mod_tab .
    TYPES:
      tt_mod_tab TYPE TABLE OF ts_mod_tab .
    TYPES:
      BEGIN OF ts_rowtype,
        type    TYPE char1, " S: subtotal, T: total
        fil1    TYPE char1,
        level   TYPE numc2,
        collect TYPE numc2,
        fil2    TYPE char1,
        index   TYPE lvc_index,
      END OF ts_rowtype .

    CONSTANTS gc_ch TYPE char2 VALUE 'CH' ##NO_TEXT.
    CONSTANTS gc_sc TYPE char2 VALUE 'SC' ##NO_TEXT.
    CONSTANTS gc_fm_bt TYPE char40 VALUE 'LCA_BT_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_cf1 TYPE char40 VALUE 'LCA_CF_&1' ##NO_TEXT.
    CONSTANTS gc_fm_ch1 TYPE char40 VALUE 'LCA_CH_&1' ##NO_TEXT.
    CONSTANTS gc_fm_ch2 TYPE char40 VALUE 'LCA_CH_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_dg TYPE char40 VALUE 'LCA_DG_&1' ##NO_TEXT.
    CONSTANTS gc_fm_dp TYPE char40 VALUE 'LCA_DP_&1' ##NO_TEXT.
    CONSTANTS gc_fm_hs1 TYPE char40 VALUE 'LCA_HS_&1' ##NO_TEXT.
    CONSTANTS gc_fm_hs2 TYPE char40 VALUE 'LCA_HS_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_hs3 TYPE char40 VALUE 'LCA_HSS_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_hs4 TYPE char40 VALUE 'LCA_HST_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_hs5 TYPE char40 VALUE 'LCA_HSS_&1' ##NO_TEXT.
    CONSTANTS gc_fm_hs6 TYPE char40 VALUE 'LCA_HST_&1' ##NO_TEXT.
    CONSTANTS gc_fm_dc1 TYPE char40 VALUE 'LCA_DC_&1' ##NO_TEXT.
    CONSTANTS gc_fm_dc2 TYPE char40 VALUE 'LCA_DC_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_f4 TYPE char40 VALUE 'LCA_F4_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_f41 TYPE char40 VALUE 'LCA_F4_&1' ##NO_TEXT.
    CONSTANTS gc_fm_tb TYPE char40 VALUE 'LCA_TOOLBAR_' ##NO_TEXT.
    CONSTANTS gc_fm_top TYPE char40 VALUE 'SET_ALV_TOPPAGE_' ##NO_TEXT.
    CONSTANTS gc_fm_ar TYPE char40 VALUE 'SET_ALV_AFTER_REFRESH_' ##NO_TEXT.
    CONSTANTS gc_fm_uc TYPE char40 VALUE 'LCA_UC_&1_&2' ##NO_TEXT.
    CONSTANTS gc_fm_uc_bef TYPE char40 VALUE 'LCA_UB_&1' ##NO_TEXT.
    CONSTANTS gc_fm_cm TYPE char40 VALUE 'LCA_CM_&1_&2' ##NO_TEXT.
    CONSTANTS gc_ok_refresh TYPE syucomm VALUE 'REFRESH' ##NO_TEXT.
    DATA gv_object_text TYPE char30 .
    DATA gv_data_scr TYPE sy-dynnr .
    DATA gv_prog_scr TYPE sy-dynnr .
    DATA gv_subc_scr TYPE sy-dynnr .
    DATA gv_obj_name TYPE char40 .
    DATA gv_form_name TYPE char40 .
    DATA gv_exit_flag TYPE char1 .
    DATA gv_repid TYPE syrepid .
    DATA gv_org_repid TYPE syrepid .
    DATA gv_set_no_refresh TYPE string .
    DATA gv_set_no_change TYPE string .
    DATA gv_set_error_data TYPE string .
    DATA gv_set_okcode TYPE string .
    DATA gv_set_table TYPE string .
    DATA gv_set_table_del TYPE string .
    DATA gv_set_saveflag TYPE string .
    DATA gv_set_new_okcode TYPE string .
    DATA gv_set_refresh TYPE string .
    DATA gv_set_layout TYPE string .
    DATA gv_set_alvgrid TYPE string .
    DATA gt_mod_tab TYPE tt_mod_tab .
    DATA go_line TYPE REF TO data .
    DATA go_line_in TYPE REF TO data .

    METHODS constructor
      IMPORTING
        !iv_object_text TYPE char30
        !iv_repid       TYPE sy-repid
        !iv_org_repid   TYPE sy-repid DEFAULT space .
    METHODS handle_after_refresh
        FOR EVENT after_refresh OF cl_gui_alv_grid .
    METHODS handle_button_click
      FOR EVENT button_click OF cl_gui_alv_grid
      IMPORTING
        !es_col_id
        !es_row_no .
    METHODS handle_context_menu
      FOR EVENT context_menu_request OF cl_gui_alv_grid
      IMPORTING
        !e_object .
    METHODS handle_data_changed
      FOR EVENT data_changed OF cl_gui_alv_grid
      IMPORTING
        !er_data_changed
        !e_onf4
        !e_onf4_before
        !e_onf4_after
        !e_ucomm .
    METHODS handle_data_changed_finished
      FOR EVENT data_changed_finished OF cl_gui_alv_grid
      IMPORTING
        !e_modified
        !et_good_cells .
    METHODS handle_double_click
      FOR EVENT double_click OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no .
    METHODS handle_hotspot_click
      FOR EVENT hotspot_click OF cl_gui_alv_grid
      IMPORTING
        !e_row_id
        !e_column_id
        !es_row_no .
    METHODS handle_ondrag
      FOR EVENT ondrag OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no
        !e_dragdropobj .
    METHODS handle_ondrop
      FOR EVENT ondrop OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no
        !e_dragdropobj .
    METHODS handle_ondropcomplete
      FOR EVENT ondropcomplete OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no
        !e_dragdropobj .
    METHODS handle_ondropgetflavor
      FOR EVENT ondropgetflavor OF cl_gui_alv_grid
      IMPORTING
        !e_row
        !e_column
        !es_row_no
        !e_dragdropobj
        !e_flavors .
    METHODS handle_onf4
      FOR EVENT onf4 OF cl_gui_alv_grid
      IMPORTING
        !e_fieldname
        !e_fieldvalue
        !es_row_no
        !er_event_data
        !et_bad_cells
        !e_display .
    METHODS handle_toolbar
      FOR EVENT toolbar OF cl_gui_alv_grid
      IMPORTING
        !e_object
        !e_interactive .
    METHODS handle_top_of_page
      FOR EVENT top_of_page OF cl_gui_alv_grid
      IMPORTING
        !e_dyndoc_id .
    METHODS handle_user_command
      FOR EVENT user_command OF cl_gui_alv_grid
      IMPORTING
        !e_ucomm .
    METHODS handle_subtotal_text
      FOR EVENT subtotal_text OF cl_gui_alv_grid
      IMPORTING
        !es_subtottxt_info
        !ep_subtot_line
        !e_event_data .
    METHODS set_runtime_references
      IMPORTING
        !io_grid      TYPE REF TO cl_gui_alv_grid
        !ir_table     TYPE REF TO data
        !ir_layout    TYPE REF TO data OPTIONAL
        !ir_save_flag TYPE REF TO data OPTIONAL.
  PROTECTED SECTION.
  PRIVATE SECTION.
    DATA gr_run_grid      TYPE REF TO cl_gui_alv_grid .
    DATA gr_run_table     TYPE REF TO data .
    DATA gr_run_layout    TYPE REF TO data .
    DATA gr_run_save_flag TYPE REF TO data .

    METHODS get_subtotals
      IMPORTING
        !is_row_id     TYPE lvc_s_row
      RETURNING
        VALUE(ro_data) TYPE REF TO data .
    METHODS check_changed_data
      RETURNING
        VALUE(rv_error_in_data) TYPE char01 .
    METHODS dispatch
      RETURNING
        VALUE(rv_exit_form) TYPE char01 .
    METHODS refresh_grid .
    METHODS set_display_mode
      IMPORTING
        !iv_display_mode TYPE any .
    METHODS set_ftd_layout .
    METHODS set_local_fields .
ENDCLASS.



CLASS ZCL_ZMDM_MM_ALV_EVENT IMPLEMENTATION.


  METHOD check_changed_data.

    DATA: lv_valid TYPE c.

    FIELD-SYMBOLS:
      <lo_alv_grid>       TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    CLEAR: rv_error_in_data.

    CALL METHOD <lo_alv_grid>->check_changed_data
      IMPORTING
        e_valid = lv_valid.

    IF lv_valid IS INITIAL.
      rv_error_in_data = 'X'.
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    " C1 프로그램에서 C2 프로그램을 호출할 경우
    "   C2에서 C1 프로그램 로직 사용함.
    "  C1 : repid = C1, org_repid = C1
    "  C2 : repid = C2, org repid = C1
    " gv_object_text Format : xx_1000_2000
    "   xx : 구분자
    "   1000 : data screen -> internal table 이 정의된
    "   2000 : prog screen -> Program 내 form 호출시 사용

    CALL METHOD super->constructor.
    gv_object_text = iv_object_text.

    CASE gv_object_text+0(2).
* popup screen 을 호출한 경우
      WHEN gc_ch.  " data 와 screen 이 틀림.
        gv_subc_scr = gv_object_text+8(4).
        gv_data_scr = gv_object_text+3(4).
        gv_prog_scr = gv_object_text+8(4).

* 여러개의 화면을 한개의 screen 에 정의해 사용할때
* real screen 100, virtual screen 101,102,103 인경우
*  form 과 itab 은 100 화면정보는 101 인 경우 sc_0101_0100 으로 설정
      WHEN gc_sc.  " data 와 screen 이 동일, Subscreen 이 틀림
        gv_subc_scr = gv_object_text+3(4).
        gv_data_scr = gv_object_text+8(4).
        gv_prog_scr = gv_object_text+8(4).

      WHEN OTHERS. " data 와 screen 이 동일
        gv_subc_scr = gv_object_text+8(4).
        gv_data_scr = gv_object_text+8(4).
        gv_prog_scr = gv_object_text+8(4).
    ENDCASE.

    gv_repid    = iv_repid.
    IF iv_org_repid IS NOT INITIAL.
      gv_org_repid = iv_org_repid.
    ELSE.
      gv_org_repid = iv_repid.
    ENDIF.

    " 기타 변수 지정
    me->set_local_fields( ).

  ENDMETHOD.


  METHOD dispatch.

    DATA: lv_return_code TYPE i.

    FIELD-SYMBOLS:
      <lv_no_refresh> TYPE any,
      <lv_ok_code>    TYPE any.

    ASSIGN (gv_set_no_refresh) TO <lv_no_refresh>.
    CHECK sy-subrc = 0 AND <lv_no_refresh> IS ASSIGNED.

    ASSIGN (gv_set_okcode) TO <lv_ok_code>.
    CHECK sy-subrc = 0 AND <lv_ok_code> IS ASSIGNED.

    CLEAR: rv_exit_form.
    CALL METHOD cl_gui_cfw=>dispatch
      IMPORTING
        return_code = lv_return_code.
    IF lv_return_code = cl_gui_cfw=>rc_noevent.
      EXIT.
    ENDIF.

    CASE <lv_ok_code>+9(1).
      WHEN '9'.       <lv_no_refresh> = 'X'.
      WHEN OTHERS.    <lv_no_refresh> = space.
    ENDCASE.

    CLEAR <lv_ok_code>.
    rv_exit_form = 'X'.

  ENDMETHOD.


  METHOD get_subtotals.

    DATA: lv_row_id  TYPE lvc_index,
          ls_rowtype TYPE ts_rowtype.

    FIELD-SYMBOLS:
      <ls_work>     TYPE any,
      <lt_table>    TYPE STANDARD TABLE,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    UNASSIGN <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    ls_rowtype = is_row_id-rowtype.

    DATA: lr_c00  TYPE REF TO data,
          lr_c01  TYPE REF TO data, lr_c02 TYPE REF TO data, lr_c03 TYPE REF TO data,
          lr_c04  TYPE REF TO data, lr_c05 TYPE REF TO data, lr_c06 TYPE REF TO data,
          lr_c07  TYPE REF TO data, lr_c08 TYPE REF TO data, lr_c09 TYPE REF TO data,
          lt_grpl TYPE lvc_t_grpl.

    <lo_alv_grid>->get_subtotals( IMPORTING ep_collect00   = lr_c00
                                            ep_collect01   = lr_c01
                                            ep_collect02   = lr_c02
                                            ep_collect03   = lr_c03
                                            ep_collect04   = lr_c04
                                            ep_collect05   = lr_c05
                                            ep_collect06   = lr_c06
                                            ep_collect07   = lr_c07
                                            ep_collect08   = lr_c08
                                            ep_collect09   = lr_c09
                                            et_grouplevels = lt_grpl ).

    " 3) 그랜드토탈이면 EP_COLLECT00에서 1행 가져오면 끝
    UNASSIGN: <lt_table>, <ls_work>.
    CASE ls_rowtype-type.
      WHEN 'T'.
        ASSIGN lr_c00->* TO <lt_table>.
        READ TABLE <lt_table> ASSIGNING <ls_work> INDEX ls_rowtype-index.

      WHEN 'S'.
        READ TABLE lt_grpl INTO DATA(ls_grpl) INDEX is_row_id-index.
        CASE ls_grpl-collect.
          WHEN '01'. ASSIGN lr_c01->* TO <lt_table>.
          WHEN '02'. ASSIGN lr_c02->* TO <lt_table>.
          WHEN '03'. ASSIGN lr_c03->* TO <lt_table>.
          WHEN '04'. ASSIGN lr_c04->* TO <lt_table>.
          WHEN '05'. ASSIGN lr_c05->* TO <lt_table>.
          WHEN '06'. ASSIGN lr_c06->* TO <lt_table>.
          WHEN '07'. ASSIGN lr_c07->* TO <lt_table>.
          WHEN '08'. ASSIGN lr_c08->* TO <lt_table>.
          WHEN '09'. ASSIGN lr_c09->* TO <lt_table>.

          WHEN OTHERS. EXIT.
        ENDCASE.

        lv_row_id = ls_grpl-cindx_from.
        READ TABLE <lt_table> ASSIGNING <ls_work> INDEX lv_row_id.
      WHEN OTHERS.
    ENDCASE.
*    IF ls_rowtype-type = 'T'.
*      FIELD-SYMBOLS <t_c00> TYPE STANDARD TABLE.
*      FIELD-SYMBOLS <l_c00> TYPE any.
*      ASSIGN lr_c00->* TO <t_c00>.
*      IF <t_c00> IS ASSIGNED AND lines( <t_c00> ) > 0.
*        READ TABLE <t_c00> ASSIGNING <l_c00> INDEX 1.
*        IF sy-subrc = 0.
*          MOVE-CORRESPONDING <l_c00> TO es_line.
*          rv_ok = abap_true.
*        ENDIF.
*      ENDIF.
*      RETURN.
*    ENDIF.
*
*    " 4) 클릭된 '화면 기준' N번째 서브토탈 → lt_grpl의 N번째 항목과 매핑
*    DATA lv_nth TYPE i.
*    lv_nth = get_nth_subtotal_upto( iv_front_row = lv_front ).
*    IF lv_nth <= 0 OR lv_nth > lines( lt_grpl ).
*      RETURN.
*    ENDIF.

    GET REFERENCE OF <ls_work> INTO ro_data.

  ENDMETHOD.


  METHOD handle_after_refresh.

    FIELD-SYMBOLS:
      <lo_alv_grid>  TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED.

    CONCATENATE gc_fm_ar gv_prog_scr INTO gv_form_name.
    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING <lo_alv_grid>.

  ENDMETHOD.


  METHOD handle_button_click.


    FIELD-SYMBOLS:
      <lv_save_flag>  TYPE any,
      <lv_new_okcode> TYPE any,
      <ls_work>       TYPE any,
      <lt_table>      TYPE STANDARD TABLE,
      <lt_table_del>  TYPE STANDARD TABLE.

    CHECK gv_set_table      IS NOT INITIAL.
    CHECK gv_set_new_okcode IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    " new ok Code
    ASSIGN (gv_set_new_okcode) TO <lv_new_okcode>.

    UNASSIGN <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    READ TABLE <lt_table> INTO <ls_work> INDEX es_row_no-row_id.
    CHECK sy-subrc = 0.

    gv_form_name = gc_fm_bt.
    REPLACE '&2' IN gv_form_name WITH es_col_id-fieldname.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING es_row_no-row_id
                                 gv_subc_scr
                                 <ls_work>.

    " Active OK code..
    IF <lv_new_okcode> IS NOT INITIAL.
      cl_gui_cfw=>set_new_ok_code( <lv_new_okcode> ).
    ELSE.
      me->refresh_grid( ).
    ENDIF.
    CLEAR: <lv_new_okcode>.

  ENDMETHOD.


  METHOD handle_context_menu.


    DATA: lt_own_fcodes TYPE ui_functions,
          ls_col_id     TYPE lvc_s_col,
          lv_show_flag.

    FIELD-SYMBOLS:
      <lv_save_flag> TYPE any,
      <ls_work>      TYPE any,
      <lt_table>     TYPE STANDARD TABLE,
      <lt_table_del> TYPE STANDARD TABLE,
      <lo_alv_grid>  TYPE REF TO cl_gui_alv_grid.

    CHECK gv_set_table      IS NOT INITIAL.
    CHECK gv_set_alvgrid    IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED.

    CALL METHOD <lo_alv_grid>->get_current_cell
      IMPORTING
        es_col_id = ls_col_id.

    CALL METHOD cl_gui_cfw=>flush.

    gv_form_name = gc_fm_cm. "'LCA_CM_&1_&2'.
    REPLACE '&2' IN gv_form_name WITH ls_col_id-fieldname.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    CALL METHOD e_object->add_separator.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES   lt_own_fcodes
                           CHANGING e_object
                                    lv_show_flag.
    IF lv_show_flag = 'X'.
      CALL METHOD e_object->show_functions
        EXPORTING
          fcodes = lt_own_fcodes.
      CALL METHOD cl_gui_cfw=>flush.
    ENDIF.

  ENDMETHOD.


  METHOD handle_data_changed.


    DATA: lv_error,
          ls_modi_cell TYPE lvc_s_modi,
          lt_modi_cell TYPE lvc_t_modi.

* SELECT SCREEN OBJECT
    FIELD-SYMBOLS:
      <lv_no_change>     TYPE any,
      <lv_save_flag>     TYPE any,
      <lv_new_okcode>    TYPE any,
      <lv_error_in_data> TYPE any,
      <lv_crud>          TYPE any,
      <ls_work>          TYPE any,
      <ls_work_in>       TYPE any,
      <lt_table>         TYPE STANDARD TABLE,
      <lt_table_del>     TYPE STANDARD TABLE,
      <lv_linecolor>     TYPE char4,
      <lt_celltab>       TYPE lvc_t_styl,
      <lt_cellcolor>     TYPE lvc_t_scol.

    " 외부에서 전달된 table 이 있는지 여부
    IF gr_run_table IS BOUND.
      ASSIGN gr_run_table->*     TO <lt_table>.
      ASSIGN gr_run_save_flag->* TO <lv_save_flag>.
    ELSE.
      CHECK gv_set_table IS NOT INITIAL.
      ASSIGN (gv_set_table)      TO <lt_table>.
      ASSIGN (gv_set_saveflag)   TO <lv_save_flag>.     " save flag
    ENDIF.

    CHECK <lt_table> IS ASSIGNED.

    ASSIGN (gv_set_no_change)  TO <lv_no_change>.     " no_change
    ASSIGN (gv_set_new_okcode) TO <lv_new_okcode>.    " new ok Code
    ASSIGN (gv_set_error_data) TO <lv_error_in_data>. " gv_error_in_data

    UNASSIGN: <ls_work_in>, <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    CREATE DATA go_line_in LIKE LINE OF <lt_table>.
    ASSIGN go_line_in->* TO <ls_work_in>.

* SET CHANGED
    MOVE er_data_changed->mt_mod_cells TO lt_modi_cell.

* ERROR FLAG SETTING
    CLEAR: <lv_new_okcode>, <lv_error_in_data>, lv_error, gt_mod_tab[].

* CEHCK CHANGED VALUE
    LOOP AT lt_modi_cell INTO ls_modi_cell.

      READ TABLE <lt_table> INTO <ls_work> INDEX ls_modi_cell-row_id.
      IF sy-subrc NE 0.
        APPEND INITIAL LINE TO <lt_table> ASSIGNING <ls_work>.
        gv_form_name = |INITIALZATION_LINE_{ gv_prog_scr }|.
        TRY.
            PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid)
                                     CHANGING   <ls_work>.
            sy-subrc = 0.

          CATCH cx_sy_dyn_call_illegal_form cx_sy_program_not_found.
            sy-subrc = 4.

          CATCH cx_sy_dyn_call_param_missing.
            PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid)
                                     USING      <ls_work_in>
                                     CHANGING   <ls_work>.
            sy-subrc = 0.

        ENDTRY.
        IF sy-subrc = 0. " 초기화 form 에서 cell 속성 변경이 있는 경우
          " ls_work 내 celltab, cellcolor 에 값이 있는 경우
          UNASSIGN: <lt_celltab>, <lt_cellcolor>, <lv_linecolor>.
          ASSIGN ('<LS_WORK>-CELLTAB')  TO <lt_celltab>.
          IF <lt_celltab> IS ASSIGNED AND <lt_celltab> IS NOT INITIAL.
            APPEND VALUE #( index   = ls_modi_cell-row_id
                            upt_tab = abap_true
                            celltab = <lt_celltab>
                          ) TO gt_mod_tab.
          ENDIF.

          ASSIGN ('<LS_WORK>-CELLCOLOR')  TO <lt_cellcolor>.
          IF <lt_cellcolor> IS ASSIGNED AND <lt_cellcolor> IS NOT INITIAL.
            APPEND VALUE #( index     = ls_modi_cell-row_id
                            upt_color = abap_true
                            cellcolor = <lt_cellcolor>
                          ) TO gt_mod_tab.
          ENDIF.

          ASSIGN ('<LS_WORK>-LINECOLOR')  TO <lv_linecolor>.
          IF <lv_linecolor> IS ASSIGNED AND <lv_linecolor> IS NOT INITIAL.
            APPEND VALUE #( index     = ls_modi_cell-row_id
                            upt_line  = abap_true
                            linecolor = <lv_linecolor>
                          ) TO gt_mod_tab.
          ENDIF.
        ENDIF.

      ENDIF.

      CLEAR: <lv_error_in_data>, <lv_no_change>.

      gv_form_name = gc_fm_ch1. " 'LCA_CH_&1'.
      REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

      PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid) IF FOUND
                               USING      er_data_changed
                                          ls_modi_cell
                                          gv_subc_scr
                               CHANGING   <ls_work>
                                          gt_mod_tab.

      " SUBROUTEN ARE DEFINED BY FIELD..
      gv_form_name = gc_fm_ch2. " 'LCA_CH_&1_&2'.
      REPLACE '&2' IN gv_form_name WITH ls_modi_cell-fieldname.
      REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

      PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid) IF FOUND
                               USING      er_data_changed
                                          ls_modi_cell
                                          gv_subc_scr
                               CHANGING   <ls_work>
                                          gt_mod_tab.

* CHANGE COMPLET
      IF <lv_error_in_data> = space AND <lv_no_change> IS INITIAL.

        UNASSIGN <lv_crud>.
        ASSIGN ('<LS_WORK>-CRUD')  TO <lv_crud>.
        IF <lv_crud> IS ASSIGNED.
          <lv_crud>       = 'U'.  " CHANGE..
          MODIFY <lt_table> FROM <ls_work>
                            INDEX ls_modi_cell-row_id
                 TRANSPORTING ('CRUD').
        ENDIF.

        " 화면의 save flag 가 정의되어 있으면..
        IF <lv_save_flag> IS ASSIGNED.
          <lv_save_flag>   = 'X'.  " DATA CHANGED .
        ENDIF.

      ELSEIF <lv_error_in_data> IS NOT INITIAL.
        lv_error = 'X'.
      ENDIF.

      " 추가로 변경된 정보가 있는 경우
      IF lines( er_data_changed->mt_mod_cells ) <> lines( lt_modi_cell ).
        LOOP AT er_data_changed->mt_mod_cells INTO ls_modi_cell.
          IF NOT line_exists( lt_modi_cell[ row_id    = ls_modi_cell-row_id
                                            fieldname = ls_modi_cell-fieldname ] ).
            CALL METHOD er_data_changed->get_cell_value
              EXPORTING
                i_row_id    = ls_modi_cell-row_id
                i_fieldname = ls_modi_cell-fieldname
              IMPORTING
                e_value     = ls_modi_cell-value.
            APPEND ls_modi_cell  TO lt_modi_cell.
          ENDIF.
        ENDLOOP.
      ENDIF.

    ENDLOOP.

    " Row type 변경 정보가 있는 경우 row-id 를 변경한다
**    IF gt_mod_tab IS NOT INITIAL.
**      FIELD-SYMBOLS:
**            <ls_mod_tab> TYPE ts_mod_tab.
**      DATA(lt_roid_front) = er_data_changed->mt_roid_front.
**      DELETE lt_roid_front WHERE row_id = 0.
**      LOOP AT gt_mod_tab ASSIGNING <ls_mod_tab>.
**
**        READ TABLE lt_roid_front
**                   WITH KEY row_id = <ls_mod_tab>-index
**                   TRANSPORTING NO FIELDS .
**        IF sy-subrc = 0 AND <ls_mod_tab>-index <> sy-tabix.
**          <ls_mod_tab>-index = sy-tabix.
**        ENDIF.
**
**      ENDLOOP.
**    ENDIF.

* IF ERROR  CHANGE FIELD VALUE
    IF lv_error = 'X'.
      CALL METHOD er_data_changed->display_protocol.

    ELSE.

* CHANGE SCREEN LAYOUT
      me->set_ftd_layout(  ).
    ENDIF.

  ENDMETHOD.


  METHOD handle_data_changed_finished.

    DATA: lv_refresh,
          lv_new_okcode TYPE syucomm,
          ls_mod_tab    TYPE ts_mod_tab,
          lv_up_field   TYPE string.

* SELECT SCREEN OBJECT
    FIELD-SYMBOLS:
      <lv_save_flag>  TYPE any,
      <lv_refresh>    TYPE any,
      <lv_new_okcode> TYPE any,
      <lv_linecolor>  TYPE char4,
      <ls_work>       TYPE any,
      <lt_table>      TYPE STANDARD TABLE,
      <lt_table_del>  TYPE STANDARD TABLE,
      <lt_celltab>    TYPE lvc_t_styl,
      <lt_cellcolor>  TYPE lvc_t_scol.

    CHECK gv_set_table IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    UNASSIGN <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    UNASSIGN <lv_new_okcode>.
    ASSIGN (gv_set_new_okcode) TO <lv_new_okcode>.

    UNASSIGN <lv_refresh>.
    ASSIGN (gv_set_refresh) TO <lv_refresh>.

    " 화면 Field 변경이 끝난 후 수행해야 하는 일이 있는 경우
    gv_form_name = gc_fm_cf1. " 'LCA_CF_&1'.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    IF et_good_cells[] IS NOT INITIAL.
      PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid) IF FOUND
                               USING et_good_cells.
      IF lv_refresh = abap_true.
        lv_new_okcode = gc_ok_refresh.
      ENDIF.
    ENDIF.

    " 화면 속성 변경 작업 수행
    LOOP AT gt_mod_tab INTO ls_mod_tab.

      UNASSIGN: <lt_celltab>, <lt_cellcolor>, <lv_linecolor>.
      ASSIGN ('<LS_WORK>-LINECOLOR')  TO <lv_linecolor>.
      ASSIGN ('<LS_WORK>-CELLTAB')    TO <lt_celltab>.
      ASSIGN ('<LS_WORK>-CELLCOLOR')  TO <lt_cellcolor>.

      " linecolor 변경사항이 있는 경우
      IF ls_mod_tab-upt_line = abap_true AND <lv_linecolor> IS ASSIGNED.
        <lv_linecolor>  = ls_mod_tab-linecolor.
        MODIFY <lt_table> FROM <ls_work>
                          INDEX ls_mod_tab-index
               TRANSPORTING ('LINECOLOR').
        lv_new_okcode = gc_ok_refresh.
      ENDIF.

      " Celltab 변경사항이 있는 경우
      IF ls_mod_tab-upt_tab = abap_true AND <lt_celltab> IS ASSIGNED.
        <lt_celltab>  = ls_mod_tab-celltab.
        MODIFY <lt_table> FROM <ls_work>
                          INDEX ls_mod_tab-index
               TRANSPORTING ('CELLTAB').
        lv_new_okcode = gc_ok_refresh.
      ENDIF.

      " CellColor 변경사항이 있는 경우
      IF ls_mod_tab-upt_color = abap_true AND <lt_cellcolor> IS ASSIGNED.
        <lt_cellcolor>  = ls_mod_tab-cellcolor.
        MODIFY <lt_table> FROM <ls_work>
                          INDEX ls_mod_tab-index
               TRANSPORTING ('CELLCOLOR').
        lv_new_okcode = gc_ok_refresh.
      ENDIF.

      " field value 변경
      IF ls_mod_tab-upt_field = abap_true.
        " 추가 라인인 경우
        IF lines( <lt_table> ) < ls_mod_tab-index.
          INSERT INITIAL LINE INTO <lt_table> INDEX ls_mod_tab-index ASSIGNING FIELD-SYMBOL(<ls_table>).
          lv_new_okcode = gc_ok_refresh.
        ELSE.
          READ TABLE <lt_table> ASSIGNING <ls_table> INDEX ls_mod_tab-index.
        ENDIF.
        CHECK sy-subrc = 0.

        CLEAR: lv_up_field.
        LOOP AT ls_mod_tab-fieldtab INTO DATA(ls_fieldtab).
          DATA(lv_fieldvalue) = |<LS_WORK>-{ ls_fieldtab-fieldname }|.
          ASSIGN (lv_fieldvalue) TO FIELD-SYMBOL(<lv_fieldvalue>).
          CHECK sy-subrc = 0.

          <lv_fieldvalue> = ls_fieldtab-value.
          CONCATENATE ` ` lv_up_field ` ` ls_fieldtab-fieldname INTO lv_up_field.
        ENDLOOP.
        IF lv_up_field IS NOT INITIAL.
          MODIFY <lt_table> FROM <ls_work>
                            INDEX ls_mod_tab-index
                 TRANSPORTING (lv_up_field).
          lv_new_okcode = gc_ok_refresh.
        ENDIF.
      ENDIF.

    ENDLOOP.


    " row 삭제
    SORT gt_mod_tab BY index DESCENDING.
    LOOP AT gt_mod_tab INTO ls_mod_tab.
      IF ls_mod_tab-upt_field = 'D'.
        DELETE <lt_table> INDEX ls_mod_tab-index.
        lv_new_okcode = gc_ok_refresh.
      ENDIF.
    ENDLOOP.

    " Active OK code..
    IF lv_new_okcode IS NOT INITIAL.
      CASE lv_new_okcode.
        WHEN gc_ok_refresh. " '!REFRESH'.
          me->refresh_grid( ).

        WHEN OTHERS.
          cl_gui_cfw=>set_new_ok_code( lv_new_okcode ).

      ENDCASE.
    ENDIF.

    IF <lv_new_okcode> IS ASSIGNED    AND
       <lv_new_okcode> IS NOT INITIAL AND
       <lv_new_okcode> <> gc_ok_refresh.
      cl_gui_cfw=>set_new_ok_code( <lv_new_okcode> ).
    ENDIF.

    CLEAR: gt_mod_tab, lv_new_okcode.
    IF <lv_new_okcode> IS ASSIGNED.
      CLEAR <lv_new_okcode>.
    ENDIF.

  ENDMETHOD.


  METHOD handle_double_click.

    DATA: lv_valid     TYPE c,
          lv_fieldname TYPE lvc_fname.

    FIELD-SYMBOLS:
      <lv_new_okcode> TYPE any,
      <ls_work>       TYPE any,
      <lt_table>      TYPE STANDARD TABLE.

    CHECK gv_set_table       IS NOT INITIAL.
    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    " 화면 data 동기화
    lv_valid = me->check_changed_data( ).

    " new ok Code
    ASSIGN (gv_set_new_okcode) TO <lv_new_okcode>.

    UNASSIGN <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    IF e_row-rowtype+0(1) = space.
      READ TABLE <lt_table> INTO <ls_work> INDEX e_row-index.
      CHECK sy-subrc = 0.
    ELSE.
      " total, subtotal line  선택
      CLEAR: <ls_work>.
    ENDIF.

    " Column 별..
    CASE e_column-fieldname.
      WHEN '&&MARK&&'. lv_fieldname = 'MARK'.
      WHEN OTHERS.     lv_fieldname = e_column-fieldname.
    ENDCASE.

    gv_form_name = gc_fm_dc2. " 'LCA_DC_&1_&2'.
    REPLACE '&2' IN gv_form_name WITH lv_fieldname.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING e_row-index
                                 gv_subc_scr
                                 <ls_work>.

    " 라인에 적용되는..
    gv_form_name = gc_fm_dc1. "'LCA_DC_&1'.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING e_row-index
                                 e_column-fieldname
                                 gv_subc_scr
                                 <ls_work>.

    IF <lv_new_okcode> IS ASSIGNED AND <lv_new_okcode> IS NOT INITIAL.
      cl_gui_cfw=>set_new_ok_code( <lv_new_okcode> ).
      CLEAR: <lv_new_okcode>.
    ENDIF.

  ENDMETHOD.


  METHOD handle_hotspot_click.

    DATA: lv_index   TYPE lvc_index,
          ls_rowtype TYPE ts_rowtype,
          lo_data    TYPE REF TO data.

    FIELD-SYMBOLS:
      <lv_new_okcode> TYPE any,
      <lv_save_flag>  TYPE any,
      <ls_work>       TYPE any,
      <lt_table>      TYPE STANDARD TABLE,
      <lt_table_del>  TYPE STANDARD TABLE.

    " 외부에서 전달된 table 이 있는지 여부
    IF gr_run_table IS BOUND.
      ASSIGN gr_run_table->*     TO <lt_table>.
      ASSIGN gr_run_save_flag->* TO <lv_save_flag>.
    ELSE.
      CHECK gv_set_table IS NOT INITIAL.
      ASSIGN (gv_set_table)      TO <lt_table>.
      ASSIGN (gv_set_saveflag)   TO <lv_save_flag>.     " save flag
    ENDIF.

    CHECK <lt_table> IS ASSIGNED.

    " new ok Code
    ASSIGN (gv_set_new_okcode) TO <lv_new_okcode>.

    UNASSIGN <ls_work>.
    CREATE DATA go_line LIKE LINE OF <lt_table>.
    ASSIGN go_line->* TO <ls_work>.

    " sum 라인 클릭인 경우 : subtotal, grand total 라인 확인
    ls_rowtype = e_row_id-rowtype.

    CASE ls_rowtype-type.
      WHEN space.
        READ TABLE <lt_table> INTO <ls_work> INDEX e_row_id-index.
        CHECK sy-subrc = 0.

        lv_index = e_row_id-index.

      WHEN 'S'.
        lv_index = e_row_id-index.
        lo_data  = me->get_subtotals( e_row_id ).
        ASSIGN lo_data->* TO <ls_work>.

      WHEN 'T'.
        lv_index = ls_rowtype-index.
        lo_data  = me->get_subtotals( e_row_id ).
        ASSIGN lo_data->* TO <ls_work>.

      WHEN OTHERS. EXIT.
    ENDCASE.

    CASE ls_rowtype-type.
      WHEN 'S'.        gv_form_name = gc_fm_hs3. "'LCA_HSS_&1_&2'.
      WHEN 'T'.        gv_form_name = gc_fm_hs4. "'LCA_HST_&1_&2'.
      WHEN OTHERS.     gv_form_name = gc_fm_hs2. "'LCA_HS_&1_&2'.
    ENDCASE.
    gv_obj_name  = gv_prog_scr.

    REPLACE '&2' IN gv_form_name WITH e_column_id-fieldname.
    REPLACE '&1' IN gv_form_name WITH gv_obj_name.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING lv_index
                                 gv_subc_scr
                                 <ls_work>.

    " Field 이름 예외처리..
    CASE ls_rowtype-type.
      WHEN 'S'.        gv_form_name = gc_fm_hs5. "'LCA_HS_&1'.
      WHEN 'T'.        gv_form_name = gc_fm_hs6. "'LCA_HS_&1'.
      WHEN OTHERS.     gv_form_name = gc_fm_hs1. "'LCA_HS_&1'.
    ENDCASE.
    gv_obj_name  = gv_prog_scr.

    REPLACE '&1' IN gv_form_name WITH gv_obj_name.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING lv_index
                                 e_column_id-fieldname
                                 gv_subc_scr
                                 <ls_work>.

    " screen 예외처리
    CASE ls_rowtype-type.
      WHEN 'S'.        gv_form_name = gc_fm_hs5. "'LCA_HS_&1'.
      WHEN 'T'.        gv_form_name = gc_fm_hs6. "'LCA_HS_&1'.
      WHEN OTHERS.     gv_form_name = gc_fm_hs1. "'LCA_HS_&1'.
    ENDCASE.

    REPLACE '&1' IN gv_form_name WITH e_column_id-fieldname.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING lv_index
                                 gv_subc_scr
                                 <ls_work>.

    IF <lv_new_okcode> IS ASSIGNED AND <lv_new_okcode> IS NOT INITIAL.
      cl_gui_cfw=>set_new_ok_code( <lv_new_okcode> ).
      CLEAR: <lv_new_okcode>.
    ENDIF.

  ENDMETHOD.


  METHOD handle_ondrag.


    FIELD-SYMBOLS:
      <lt_table>    TYPE STANDARD TABLE,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    CHECK gv_set_table       IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED.

    gv_form_name = gc_fm_dg. " 'LCA_DG_&1'.
    gv_obj_name  = gv_prog_scr.

    REPLACE '&1' IN gv_form_name WITH gv_obj_name.
    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES <lt_table>
                           USING  <lo_alv_grid>
                                  e_dragdropobj
                                  es_row_no
                                  e_column-fieldname.

  ENDMETHOD.


  METHOD handle_ondrop.

    FIELD-SYMBOLS:
      <lt_table>     TYPE STANDARD TABLE.

    CHECK gv_set_table       IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    gv_form_name = gc_fm_dp. "'LCA_DP_&1'.
    gv_obj_name  = gv_prog_scr.

    REPLACE '&1' IN gv_form_name WITH gv_obj_name.
    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES <lt_table>
                           USING  e_dragdropobj
                                  es_row_no
                                  e_column-fieldname.

    me->refresh_grid( ).

  ENDMETHOD.


  METHOD handle_ondropcomplete.

    " 동작순서
    " drag(S) -> drop(T) -> complete(S)

    DATA: lo_work      TYPE REF TO data.

    FIELD-SYMBOLS:
      <lv_no_refresh> TYPE any,
      <lv_fieldname>  TYPE any,
      <ls_work>       TYPE any,
      <lt_table>      TYPE STANDARD TABLE.

    CHECK gv_set_table       IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    CREATE DATA lo_work LIKE LINE OF <lt_table>.
    ASSIGN lo_work->* TO <ls_work>.

    ASSIGN (gv_set_no_refresh) TO <lv_no_refresh>.    " gv_no_refresh

    CATCH SYSTEM-EXCEPTIONS move_cast_error = 1.

      " 동작이 MOVE 인 경우
      IF e_dragdropobj->effect = cl_dragdrop=>move.

        " 옮겨진 Data 를 삭제한다.
        LOOP AT <lt_table> INTO <ls_work>.
          UNASSIGN <lv_fieldname>.
          ASSIGN ('<LS_WORK>-CRUD') TO <lv_fieldname>.
          IF <lv_fieldname> IS ASSIGNED AND <lv_fieldname> = '2'.
            DELETE <lt_table>.
          ENDIF.
        ENDLOOP.
*      DELETE <lt_table> WHERE (lt_wtab).
        <lv_no_refresh> = '2'.
        me->refresh_grid( ).
      ENDIF.

    ENDCATCH.
    IF sy-subrc <> 0.
      CALL METHOD e_dragdropobj->abort.
    ENDIF.

  ENDMETHOD.


  METHOD handle_ondropgetflavor.
  ENDMETHOD.


  METHOD handle_onf4.

    DATA: lv_value           TYPE lvc_value,
          lt_app_field       TYPE tt_app_fields,
          ls_app_field       TYPE ts_app_field,
          lv_selected        TYPE char01,
          lv_multiple_choice TYPE char01,
          ls_lvc_modi        TYPE lvc_s_modi.


    FIELD-SYMBOLS:
      <lv_save_flag> TYPE any,
      <ls_work>      TYPE any,
      <lt_table>     TYPE STANDARD TABLE,
      <lt_table_del> TYPE STANDARD TABLE,
      <lt_f4tab>     TYPE lvc_t_modi.

    CLEAR: lv_value, lt_app_field[], ls_app_field,
           lv_selected, lv_multiple_choice.

    CHECK gv_set_table       IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    " 화면단위.
    gv_form_name = gc_fm_f41. " 'LCA_F4_&1'.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name)   IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES    lt_app_field
                           USING     e_fieldname
                                     es_row_no-row_id
                                     e_display
                           CHANGING  lv_value
                                     lv_selected
                                     lv_multiple_choice.

    " 화면의 Field 단이
    gv_form_name = gc_fm_f4. "'LCA_F4_&1_&2'.
    REPLACE '&2' IN gv_form_name WITH e_fieldname.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES    lt_app_field
                           USING     e_fieldname
                                     es_row_no-row_id
                                     e_display
                           CHANGING  lv_value
                                     lv_selected
                                     lv_multiple_choice.
    CHECK lv_selected = 'X'.

    ASSIGN er_event_data->m_data->* TO <lt_f4tab>.

    " 선택된 항목..
    ls_lvc_modi-row_id    = es_row_no-row_id.
    ls_lvc_modi-fieldname = e_fieldname.
    ls_lvc_modi-value     = lv_value.
    APPEND ls_lvc_modi TO <lt_f4tab>.


    " 첫라인 정보를 화면으로 전송한다.
    LOOP AT lt_app_field INTO ls_app_field.
*                           WHERE recordpos   =  '0001'
*                            AND text_field  <>  e_fieldname.
*    ls_lvc_modi-row_id    = es_row_no-row_id.
      CASE ls_app_field-add_position.
        WHEN 'A' OR space.
          IF ls_app_field-recordpos <> '0001'.
            ls_lvc_modi-row_id    = lines( <lt_table> ) + ( ls_app_field-recordpos - 1 ).
          ELSE.
            ls_lvc_modi-row_id    = es_row_no-row_id.
          ENDIF.

        WHEN 'I'.
          ls_lvc_modi-row_id    = ls_app_field-recordpos.
        WHEN OTHERS.
      ENDCASE.

      ls_lvc_modi-fieldname = ls_app_field-text_field.
      ls_lvc_modi-value     = ls_app_field-text_value.
      APPEND ls_lvc_modi TO <lt_f4tab>.
    ENDLOOP.

*   TO AVOID STANDARD F4-HELP.
    er_event_data->m_event_handled = 'X'.

*     MULTI SELECTION
    IF lv_multiple_choice = 'X'.
      me->refresh_grid( ).

    ELSE.
* SET SCREEN LAYOUT
      me->set_ftd_layout(  ).
    ENDIF.

  ENDMETHOD.


  METHOD handle_subtotal_text.

* subtotal field 가 hide 되어 있어야 event 발생
*  - hide 된 field 만 event 생성 - 변경해야할 line 의 total 값을 hide 시켜야 함
*  - ES_SUBTOTTXT_INFO-CRITERIA : hide 된 field 명
* subtotal field 의 text 만 변경됨 다른 field 는 변경되지 않음
* 변경 data 는
*  text 변경 : e_event_data->M_DATA 를 변경함 field assign 해서
*  do_sum field 변경 : ep_subtot_line 내 해당 column

*    BREAK-POINT.

  ENDMETHOD.


  METHOD handle_toolbar.

    CONCATENATE gc_fm_tb gv_prog_scr INTO gv_form_name.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING    gv_data_scr
                           CHANGING e_object.

  ENDMETHOD.


  METHOD handle_top_of_page.

    " alv grid 화면 위에 selection screen 입력정보 출력 순서
    "
    " 1. AT SELECTION-SCREEN.
    "     1.go_alv_info->get_selscr_fields( ). -> 기본적인 selscr field 정보 수집
    "     2.go_alv_info->SET_SELSCR_RADIOBUTTONGROUP( ... ) -> radio group 정보 정의 (option)
    "     3.go_alv_info->SET_SELSCR_FIELDTYPE( ... ) -> selscr field 의 datatype 정의 (D,T,M(Year Month) 등)
    "     4.go_alv_info->SET_SELSCR_EXCEPT( .. ) -> selscr field 중 header line 에 나오면 안되 field 정의
    "
    " 2.Header line 이 있는 docking 생성
*    go_alv_info->create_on_doc_h( EXPORTING iv_repid     = gv_repid
*                                            iv_dynnr     = sy-dynnr
*                                            iv_extension = gv_extension
*                                  IMPORTING eo_dcon      = go_dcon_0100
*                                            eo_head      = go_head_0100
*                                            eo_docu      = go_docu_0100
*                                            eo_grid      = go_grid_0100 ).
    "
    " 3.display_grid 이후 event call
*    go_alv_info->call_event( io_grid  = go_grid_0100
*                             io_docu  = go_docu_0100
*                             iv_event = gc_event_top_of_page ).
    "
    " 4.top-of-page event form 생성
*FORM set_alv_toppage_0100 USING
*              e_dyndoc_id TYPE REF TO cl_dd_document.
*
*  go_alv_info->set_header_show( EXPORTING iv_dynnr = '0100'
*                                CHANGING  co_docu  = go_docu_0100
*                                          co_head  = go_head_0100
*                                          co_html  = go_html_0100 ).
*endform.
*
* refresh top-of-page
*   pai 에서 event 호출시 pbo refresh 수행후 form top-of-page 수행
*    go_alv_info->call_event( io_grid  = go_grid_0100
*                             io_docu  = go_docu_0100
*                             iv_event = gc_event_top_of_page ).

    CONCATENATE gc_fm_top gv_prog_scr INTO gv_form_name.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING gv_subc_scr e_dyndoc_id.


  ENDMETHOD.


  METHOD handle_user_command.

    FIELD-SYMBOLS:
      <lv_ok_code>   TYPE any,
      <lt_table>     TYPE STANDARD TABLE,
      <lt_table_del> TYPE STANDARD TABLE,
      <lo_alv_grid>  TYPE REF TO cl_gui_alv_grid.

    IF me->dispatch( ) = 'X' OR me->check_changed_data( ) = 'X'.
      ASSIGN (gv_set_okcode) TO <lv_ok_code>.
      CLEAR: <lv_ok_code>.
      EXIT.
    ENDIF.

    CHECK gv_set_table       IS NOT INITIAL.

    ASSIGN (gv_set_table) TO <lt_table>.
    CHECK <lt_table> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED.

    UNASSIGN <lv_ok_code>.
    ASSIGN (gv_set_new_okcode) TO <lv_ok_code>.

    gv_form_name = gc_fm_uc_bef. "'LCA_UB_&1'.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    " user command 수행전
    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           USING    e_ucomm.

    gv_form_name = gc_fm_uc. "'LCA_UC_&1_&2'.
    REPLACE '&2' IN gv_form_name WITH e_ucomm.
    REPLACE '&1' IN gv_form_name WITH gv_prog_scr.

    PERFORM (gv_form_name) IN PROGRAM (gv_org_repid) IF FOUND
                           TABLES   <lt_table>
                           USING    <lo_alv_grid> gv_data_scr.

* SET SCREEN LAYOUT
    me->set_ftd_layout(  ).

    " refresh screen..
    IF <lv_ok_code> IS NOT INITIAL.
      cl_gui_cfw=>set_new_ok_code( <lv_ok_code> ).
      CLEAR: <lv_ok_code>.
    ELSE.
      me->refresh_grid( ).
    ENDIF.

  ENDMETHOD.


  METHOD refresh_grid.

    DATA: lv_soft_refresh TYPE char01,
          ls_stbl         TYPE lvc_s_stbl.

    FIELD-SYMBOLS:
      <lv_no_refresh>    TYPE any,
      <lv_error_in_data> TYPE any,
      <ls_layout>        TYPE lvc_s_layo,
      <lo_alv_grid>      TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_layout)     TO <ls_layout>." Layout
    CHECK <ls_layout> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    ASSIGN (gv_set_no_refresh) TO <lv_no_refresh>.    " gv_no_refresh
    ASSIGN (gv_set_error_data) TO <lv_error_in_data>. " gv_error_in_data

    CHECK <lv_no_refresh> <> 'X' AND <lv_error_in_data> = space.

    lv_soft_refresh = space.

    CASE <lv_no_refresh>.
      WHEN space.
        ls_stbl-row = 'X'.
        ls_stbl-col = 'X'.
        me->set_ftd_layout( ).
      WHEN '2'.
        lv_soft_refresh = 'X'.
      WHEN OTHERS.
        me->set_ftd_layout( ).
    ENDCASE.

    CALL METHOD <lo_alv_grid>->refresh_table_display
      EXPORTING
        is_stable      = ls_stbl
        i_soft_refresh = lv_soft_refresh.

  ENDMETHOD.


  METHOD set_display_mode.

    FIELD-SYMBOLS:
      <lo_alv_grid>       TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    IF iv_display_mode = space. " READ MODE ENABLE SETTING
      CALL METHOD <lo_alv_grid>->set_ready_for_input
        EXPORTING
          i_ready_for_input = '1'.

    ELSE.                          " READ MODE ENABLE SETTING
      CALL METHOD <lo_alv_grid>->set_ready_for_input
        EXPORTING
          i_ready_for_input = '0'.
    ENDIF.

  ENDMETHOD.


  METHOD set_ftd_layout.

    FIELD-SYMBOLS:
      <ls_layout>   TYPE lvc_s_layo,
      <lo_alv_grid> TYPE REF TO cl_gui_alv_grid.

    ASSIGN (gv_set_layout)     TO <ls_layout>." Layout
    CHECK <ls_layout> IS ASSIGNED.

    ASSIGN (gv_set_alvgrid) TO <lo_alv_grid>.   " Alv Grid
    CHECK <lo_alv_grid> IS ASSIGNED AND <lo_alv_grid> IS BOUND.

    CALL METHOD <lo_alv_grid>->set_frontend_layout
      EXPORTING
        is_layout = <ls_layout>.

  ENDMETHOD.


  METHOD set_local_fields.


    DATA: lv_repid TYPE syrepid,
          lv_scrno TYPE char04.


    FIELD-SYMBOLS:
      <lv_field>     TYPE any,
      <lt_table>     TYPE STANDARD TABLE,
      <lt_table_del> TYPE STANDARD TABLE.

    lv_repid = gv_repid.
    lv_scrno = gv_data_scr.

    " 일반적인 Table.
    CONCATENATE `(` lv_repid `)GT_S` lv_scrno `[]` INTO gv_set_table.
    ASSIGN (gv_set_table) TO <lt_table>.
    IF <lt_table> IS NOT ASSIGNED.
      CONCATENATE `(` lv_repid `)GT_S` lv_scrno INTO gv_set_table.
      ASSIGN (gv_set_table) TO <lt_table>.
      IF <lt_table> IS NOT ASSIGNED.
        CONCATENATE `(` lv_repid `)<GT_S` lv_scrno `>` INTO gv_set_table.
        ASSIGN (gv_set_table) TO <lt_table>.
        IF <lt_table> IS NOT ASSIGNED.
          CLEAR: gv_set_table.
        ENDIF.
      ENDIF.
    ENDIF.

    " Del Table
    CONCATENATE `(` lv_repid `)GT_S` lv_scrno `_DEL[]` INTO gv_set_table_del.
    ASSIGN (gv_set_table_del) TO <lt_table_del>.
    IF <lt_table_del> IS NOT ASSIGNED.
      CONCATENATE `(` lv_repid `)GT_S` lv_scrno `_DEL` INTO gv_set_table_del.
      ASSIGN (gv_set_table_del) TO <lt_table_del>.
      IF <lt_table_del> IS NOT ASSIGNED.
        CONCATENATE `(` lv_repid `)<GT_S` lv_scrno `_DEL>` INTO gv_set_table_del.
        ASSIGN (gv_set_table_del) TO <lt_table_del>.
        IF <lt_table_del> IS NOT ASSIGNED.
          CLEAR: gv_set_table_del.
        ENDIF.
      ENDIF.
    ENDIF.

    " OK Code
    CONCATENATE `(` lv_repid `)GV_OK_CODE` INTO gv_set_okcode.

    " ALV Grid
    CONCATENATE `(` lv_repid `)GO_GRID_` lv_scrno INTO gv_set_alvgrid.

    " layout
    CONCATENATE `(` lv_repid `)GS_LAYOUT_` lv_scrno INTO gv_set_layout.

    " save flag
    CONCATENATE `(` lv_repid `)GV_SAVE_FLAG_` lv_scrno INTO gv_set_saveflag.

    " gv_new_ok_code : Call Program 인 경우 Call 한 프로그램의 정보
    CONCATENATE `(` gv_org_repid `)GV_NEW_OK_CODE` INTO gv_set_new_okcode.
    ASSIGN (gv_set_new_okcode) TO <lv_field>.
    IF <lv_field> IS NOT ASSIGNED.
      CONCATENATE `(` lv_repid `)GV_NEW_OK_CODE` INTO gv_set_new_okcode.
    ENDIF.

    " 화면 fresh
    CONCATENATE `(` gv_org_repid `)GV_REFRESH` INTO gv_set_refresh.
    ASSIGN (gv_set_refresh) TO <lv_field>.
    IF <lv_field> IS NOT ASSIGNED.
      CONCATENATE `(` lv_repid `)GV_REFRESH` INTO gv_set_refresh.
    ENDIF.

    " gv_no_refresh
    CONCATENATE `(` lv_repid `)GV_NO_REFRESH` INTO gv_set_no_refresh.

    " gv_no_change
    CONCATENATE `(` lv_repid `)gv_no_change` INTO gv_set_no_change.

    " gv_error_in_data
    CONCATENATE `(` lv_repid `)GV_ERROR_IN_DATA` INTO gv_set_error_data.

  ENDMETHOD.


  METHOD set_runtime_references.

    gr_run_grid      = io_grid.
    gr_run_table     = ir_table.
    gr_run_layout    = ir_layout.
    gr_run_save_flag = ir_save_flag.

  ENDMETHOD.
ENDCLASS.
