*--------------------------------------------------------------------*
*  Report : YBZ_DATACOPY
*--------------------------------------------------------------------*
* 프로그램 Desc: Data Copy in Table From Other System or Client      *
*                                                                    *
* Version                                                            *
*  2.0   2026.06.19 - RFC Dest 방식만 허용                         *
*                   - Trusted RFC + Current User 사용 전제           *
*                   - SysID 매핑/TMS Dest 자동선택 제거              *
*  1.9   2025.07.01 - add conv exit 필드 전체 기본값으로 no convexit *
*                         설정                                       *
*                   - add field data conv exit 기능 추가             *
*                   - add 종료시 변경된 Data 존재여부 확인 및 메시지 *
*  1.8   2023.12.13 - Remote Copy시 Client 전체 읽기 기능추가        *
*  1.7   2023.10.12 - Table 명이 다를경우 Client 전체 읽기 기능추가  *
*  1.6   2023.01.03 - Table Data Download 기능 추가                  *
*                   - Multi File Upload 기능 추가                    *
*                   - 화면에 보이지 않음 기능 추가                   *
*  1.5   2020.02.25 - ALV Label 선택 기능 추가                       *
*  1.4.3 2020.01.10 - Client 변경 기능 삭제(ABAP Version 으로 인함)  *
*                   - Column Mass Change 기능 추가                   *
*  1.4.2 2019.06.20 - Excel Upload 방식 변경 및 화면 comment 추가    *
*  1.0              - 언제인지 모름                                  *
*--------------------------------------------------------------------*
* GUI Texts
*--------------------------------------------------------------------*
* 0100 --> CBO Table of Data Loading - &
* 0200 --> Change of Field Catalog
* 5010 --> Upload Error List
*--------------------------------------------------------------------*
* 화면 0100 설정
*  TitleBar  : 0100 : CBO Table of Data Loading
*  PF-Status : 0100
*      기능키 : SAVE,BACK(E)
*      F5 : REFRESH - Refresh      - App1 - ICON_REFRESH
*      F6 : CLEAR   - 화면 Clear   - App2 - ICON_CREATE
*      F7 : FEDIT   - FCat Edit    - App3 - ICON_REPORT_CALL
*      F8 : MASS    - Mass Change  - App4 - ICON_MASS_CHANGE
*
*%_DESCRIPTION        : Result Screen
*%_FIELDS           : GV_OK_CODE
*%_FLOWLOGIC
*
*PROCESS BEFORE OUTPUT.
*  MODULE status_0100.
*  MODULE init_0100.
**
*PROCESS AFTER INPUT.
*  MODULE exit_0100           AT EXIT-COMMAND.
*  MODULE get_okcode.
*  MODULE user_command_0100.

* 화면 0200 설정
*  TitleBar  : 0200 : Field Catalog Edit
*  PF-Status : 0200
*      기능키 : SAVE,BACK(E)
*
*%_DESCRIPTION        : Edit of Field Catalog
*%_FIELDS           : GV_OK_CODE
*%_FLOWLOGIC
*
*PROCESS BEFORE OUTPUT.
*  MODULE status_0200.
*  MODULE init_0200.
**
*PROCESS AFTER INPUT.
*  MODULE exit_0200           AT EXIT-COMMAND.
*  MODULE get_okcode.
*  MODULE user_command_0200.

* 화면 5010 설정
*  TitleBar  : 5010 : Upload Error List
*  PF-Status : 5010
*      기능키 : BACK(E)
*
*%_DESCRIPTION      : Upload Error List
*%_FIELDS           : GV_OK_CODE
*%_FLOWLOGIC
*
*PROCESS BEFORE OUTPUT.
*  MODULE status_5010.
*  MODULE init_5010.
**
*PROCESS AFTER INPUT.
*  MODULE exit_5010           AT EXIT-COMMAND.
*  MODULE get_okcode.
*  MODULE user_command_5010.
*--------------------------------------------------------------------*
*FUNCTION ybz_datacopy.
**"----------------------------------------------------------------------
**"*"로컬 인터페이스:
**"  IMPORTING
**"     VALUE(IV_FR_TAB) TYPE  TABNAME
**"     VALUE(IV_TO_TAB) TYPE  TABNAME OPTIONAL
**"  TABLES
**"      IT_WTAB STRUCTURE  RSDSWHERE
**"      ET_DATA STRUCTURE  BAPIXMSPOW
**"----------------------------------------------------------------------
*
*  DATA: lv_mandt   TYPE mandt,
*        lv_tab_len TYPE i,
*        lv_where   TYPE string.
*
*  FIELD-SYMBOLS : <fs_table> TYPE STANDARD TABLE,
*                  <fs_work>  TYPE any.
*
*  DATA: lo_new_line  TYPE REF TO data,  " dereference <fs>
*        lo_new_table TYPE REF TO data.
*
*  DATA: lv_tabname      TYPE tabname.
*
*  IF iv_to_tab IS INITIAL.
*    lv_tabname = iv_fr_tab.
*  ELSE.
*    lv_tabname = iv_to_tab.
*  ENDIF.
*
*  " to Table 이 없는 경우 from table 을 가지고 온다...
*  SELECT COUNT( * )
*    FROM dd02l
*    INTO sy-dbcnt
*   WHERE tabname = lv_tabname.
*  IF sy-subrc NE 0 OR sy-dbcnt = 0.
*    lv_tabname = iv_fr_tab.
*  ENDIF.
*
*  CREATE DATA lo_new_table TYPE TABLE OF (lv_tabname).
*  CREATE DATA lo_new_line  TYPE (lv_tabname).
*  ASSIGN lo_new_table->* TO <fs_table>.
*  ASSIGN lo_new_line->*  TO <fs_work>.
*
*  CLEAR: et_data[], lv_where.
*
*  SELECT *
*  FROM (lv_tabname) CLIENT SPECIFIED
*  INTO CORRESPONDING FIELDS OF TABLE <fs_table>
* WHERE (it_wtab).
*  IF sy-subrc NE 0.
*    EXIT.
*  ENDIF.
*
** UNICode 때문에 Type Conversion 해야 한다
*
*  LOOP AT <fs_table> INTO <fs_work>.
*
*    CALL FUNCTION 'PI_BP_MOVE_UNICODE'
*      EXPORTING
*        iv_move_from = <fs_work>
*      CHANGING
*        cv_move_to   = et_data.
*    APPEND et_data.
*  ENDLOOP.
*
*ENDFUNCTION.
*&---------------------------------------------------------------------*

REPORT ybz_datacopy               MESSAGE-ID oo.

CONSTANTS:
  gc_object_id_0100 TYPE char30     VALUE 'GO_GRID_0100',
  gc_contnm_0100    TYPE scrfname   VALUE 'UC_0100',

  gc_dev            TYPE sy-sysid VALUE 'KED',
  gc_qa             TYPE sy-sysid VALUE 'KEQ',
  gc_prd            TYPE sy-sysid VALUE 'KEP',
  gc_rdest_d        TYPE rfcdes-rfcdest VALUE 'KEDCLNT100',
  gc_rdest_q        TYPE rfcdes-rfcdest VALUE 'KEQCLNT100',
  gc_rdest_p        TYPE rfcdes-rfcdest VALUE 'KEPCLNT100'.



TABLES:    sscrfields.   " Fields on selection screens
*----------------------------------------------------------------------*
* Type 선언부
*----------------------------------------------------------------------*
TYPES: BEGIN OF tys_s0200.
         INCLUDE TYPE lvc_s_fcat.
TYPES: END OF tys_s0200,
tyt_s0200 TYPE tys_s0200 OCCURS 0.

TYPES: BEGIN OF tys_s5010,
         line       TYPE sy-tabix,
         column     TYPE fieldname,
         column_txt TYPE as4text,
         message    TYPE bapi_msg,
       END OF tys_s5010,
       tyt_s5010 TYPE tys_s5010 OCCURS 0.

*----------------------------------------------------------------------*
* Excel OLE 관련
*----------------------------------------------------------------------*
TYPE-POOLS: soi,ole2, kcde.
DATA: go_application   TYPE ole2_object,
      go_workbook      TYPE ole2_object,
      go_workbooks     TYPE ole2_object,
      go_range         TYPE ole2_object,
      go_worksheet     TYPE ole2_object,
      go_worksheets    TYPE ole2_object,
      go_column        TYPE ole2_object,
      go_row           TYPE ole2_object,
      go_cell          TYPE ole2_object,
      go_font          TYPE ole2_object,
      go_cell_autofit  TYPE ole2_object,
      go_cell_interior TYPE ole2_object,
      go_cellstart     TYPE ole2_object,
      go_cellend       TYPE ole2_object,
      go_selection     TYPE ole2_object,
      go_borders       TYPE ole2_object,
      go_validation    TYPE ole2_object.
*----------------------------------------------------------------------*
* function Code Control.
*----------------------------------------------------------------------*
DATA: gv_ok_code TYPE sy-ucomm,
      gv_save_ok TYPE sy-ucomm,
      gs_fcode   TYPE sy-ucomm,
      gt_fcode   TYPE TABLE OF sy-ucomm.

DATA: go_docu_0100     TYPE REF TO cl_dd_document,          "DOCUMENT
      go_dcon_0100     TYPE REF TO cl_gui_docking_container,
      go_ccon_0100     TYPE REF TO cl_gui_custom_container,
      go_grid_0100     TYPE REF TO cl_gui_alv_grid,

      gt_dropdown      TYPE lvc_t_dral,

      gs_layout_0100   TYPE        lvc_s_layo,
      gs_vari_0100     TYPE        disvariant,
      gt_tool_0100     TYPE        ui_functions,
      gt_fieldcat_0100 TYPE        lvc_t_fcat,
      gt_sort_0100     TYPE        lvc_t_sort,

      go_dcon_0200     TYPE REF TO cl_gui_docking_container,
      go_grid_0200     TYPE REF TO cl_gui_alv_grid,
      gs_layout_0200   TYPE        lvc_s_layo,
      gs_vari_0200     TYPE        disvariant,
      gt_tool_0200     TYPE        ui_functions,
      gt_fieldcat_0200 TYPE        lvc_t_fcat,
      gt_sort_0200     TYPE        lvc_t_sort,

      go_dcon_5010     TYPE REF TO cl_gui_docking_container,
      go_grid_5010     TYPE REF TO cl_gui_alv_grid,
      gs_layout_5010   TYPE        lvc_s_layo,
      gs_vari_5010     TYPE        disvariant,
      gt_tool_5010     TYPE        ui_functions,
      gt_fieldcat_5010 TYPE        lvc_t_fcat,
      gt_sort_5010     TYPE        lvc_t_sort,

      gv_contnm_0100   TYPE        scrfname  VALUE 'UC_0100'.      " CONTAINER NAME

DATA: gv_display_mode_0100,
      gv_action_flag_0100,
      gv_first_flag_0100   VALUE 'X',
      gv_save_flag_0100.

DATA: gv_repid         TYPE sy-repid,
      gv_extension     TYPE i VALUE 32000,
      gv_col_pos       TYPE i,

      gv_error_flag,
      gv_no_change,   " save_flag 변경하지 않음
      gv_no_refresh,
      gv_exit_form,
      gv_valid,
      gv_new_ok_code   TYPE sy-ucomm,
      gv_error_in_data.

DATA: gs_where_tab             TYPE rsdswhere,
      gs_where_clause          TYPE rsds_where,
      gt_tables_tab            TYPE TABLE OF rsdstabs,
      gt_tabfields_not_display TYPE TABLE OF rsdsfields,
      gt_fields_tab	           TYPE TABLE OF rsdsfields,
      gt_where_clauses         TYPE rsds_twhere,
      gt_expressions           TYPE rsds_texpr,
      gt_field_ranges          TYPE rsds_trange.

DATA: gv_text100(100),
      gv_text100_01(100),
      gv_text100_02(100),
      gv_title(100),
      gv_message         TYPE bapi_msg,
      gv_answer.

DATA: gt_wtab   TYPE rsdswhere OCCURS 0 WITH HEADER LINE,
      gt_wtab_d TYPE rsdswhere OCCURS 0 WITH HEADER LINE.

DATA: gt_s0200 TYPE tyt_s0200,
      gt_s5010 TYPE tyt_s5010.

DATA: gv_codepage      TYPE abap_encoding.
DATA: go_comfunc   TYPE REF TO ZCL_ZMDM_MM_comfunc,
      go_alv_info  TYPE REF TO ZCL_ZMDM_MM_alv_info,
      go_alv_event TYPE REF TO ZCL_ZMDM_MM_alv_event.
DATA: gt_file_up_list  TYPE filetable.

*----------------------------------------------------------------------*
*   POPUP_GET_VALUES
*----------------------------------------------------------------------*
DATA: gv_returncode,
      gs_popup_fields TYPE sval,
      gt_popup_fields TYPE TABLE OF sval.
*----------------------------------------------------------------------*
DATA: go_tab      TYPE REF TO data,
      go_tab_down TYPE REF TO data.

FIELD-SYMBOLS:
  <gt_s0100>    TYPE STANDARD TABLE,
  <gt_tab_down> TYPE STANDARD TABLE.

*-----------------------------------------------------------------------
DEFINE %loc_xls_msg.

  CASE sy-subrc.

    WHEN 0.
    WHEN 1.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

    WHEN OTHERS. EXIT. " raise upload_ole.

  ENDCASE.

END-OF-DEFINITION.

*----------------------------------------------------------------------*
*  field_attr
*      ' ' 	Normal intensity, data entry possible
*      '01'	Field Text Highlighted, data entry possible
*      '02'	Normal intensity, data entry not possible
*      '03'	Field Text Highlighted, Field Disable, , data entry possible
*      '04'	Do not display
*
*  field_obl : 'X' -> Required field
*----------------------------------------------------------------------*
DEFINE %loc_set_popup_field.

  CLEAR: gs_popup_fields.
  gs_popup_fields-tabname    = &1.
  gs_popup_fields-fieldname  = &2.
  gs_popup_fields-field_obl  = &3.
  gs_popup_fields-field_attr = &4.
  APPEND gs_popup_fields TO gt_popup_fields.

END-OF-DEFINITION.
DEFINE %loc_set_popup_field_ex1.

  CLEAR: gs_popup_fields.
  gs_popup_fields-tabname    = &1.
  gs_popup_fields-fieldname  = &2.
  gs_popup_fields-field_obl  = &3.
  gs_popup_fields-field_attr = &4.

  gs_popup_fields-value      = &5.
  gs_popup_fields-fieldtext  = &6.

  " 'X' : Search Help 사용하지 않음
  " 'S' : Tabname-Fieldname 에 연결된 search Help 사용
  gs_popup_fields-novaluehlp = &7.

  APPEND gs_popup_fields TO gt_popup_fields.

END-OF-DEFINITION.
*-----------------------------------------------------------------------
SELECTION-SCREEN FUNCTION KEY 1.

SELECTION-SCREEN BEGIN OF BLOCK bl1 WITH FRAME TITLE text_100.

  " Table Name
  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(28) text_110 FOR FIELD p_tab.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS: p_tab            TYPE dd02l-tabname." OBLIGATORY.
    SELECTION-SCREEN COMMENT 67(40) p_tabnm FOR FIELD p_tab.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(28) text_111 FOR FIELD p_tab1  MODIF ID sou.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS: p_tab1            TYPE dd02l-tabname          MODIF ID sou.
    SELECTION-SCREEN COMMENT 67(40) p_tabnm1 FOR FIELD p_tab1 MODIF ID sou.
  SELECTION-SCREEN END OF LINE.

*SELECTION-SCREEN BEGIN OF LINE.
*SELECTION-SCREEN COMMENT 1(28) text_120 FOR FIELD p_mandtt.
*SELECTION-SCREEN POSITION 33.
*PARAMETERS : p_mandtt LIKE sy-mandt.
*SELECTION-SCREEN END OF LINE.


SELECTION-SCREEN END OF BLOCK bl1.

" Option
SELECTION-SCREEN BEGIN OF BLOCK bl2 WITH FRAME TITLE text_200.

*--------------------------------------------------------------------*
  "  From File
  SELECTION-SCREEN BEGIN OF LINE.
    PARAMETERS: rb201 RADIOBUTTON GROUP rg2 USER-COMMAND dummy.
    SELECTION-SCREEN COMMENT 4(28) text_210. " FOR FIELD rb201.

    SELECTION-SCREEN POSITION 33.
    PARAMETERS : p_file TYPE string DEFAULT 'C:\TEMP\' MODIF ID fil VISIBLE LENGTH 43.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 10(20) text_214  MODIF ID fil.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS: rb211 RADIOBUTTON GROUP rga  MODIF ID fil  DEFAULT 'X' USER-COMMAND dummy.
    SELECTION-SCREEN COMMENT 36(10) text_212 FOR FIELD rb211 MODIF ID fil.

    SELECTION-SCREEN POSITION 50.
    PARAMETERS: rb212 RADIOBUTTON GROUP rga  MODIF ID fil.
    SELECTION-SCREEN COMMENT 53(10) text_213 FOR FIELD rb212 MODIF ID fil.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 10(20) text_215  MODIF ID fil.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS : cb_out AS CHECKBOX MODIF ID fil.
    SELECTION-SCREEN COMMENT 35(30) text_211 FOR FIELD cb_out MODIF ID fil.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS : cb_hdx AS CHECKBOX MODIF ID fil.
    SELECTION-SCREEN COMMENT 35(30) text_216 FOR FIELD cb_hdx MODIF ID fil.
  SELECTION-SCREEN END OF LINE.

*--------------------------------------------------------------------*
  "  Table Data Download
  SELECTION-SCREEN BEGIN OF LINE.
    PARAMETERS: rb205 RADIOBUTTON GROUP rg2 .
    SELECTION-SCREEN COMMENT 4(28) text_250.

    SELECTION-SCREEN POSITION 33.
    PARAMETERS : p_filed TYPE string DEFAULT 'C:\TEMP\' MODIF ID fid VISIBLE LENGTH 43.

    SELECTION-SCREEN POSITION 79.
    SELECTION-SCREEN PUSHBUTTON (30) text_251 USER-COMMAND additional MODIF ID fid.
  SELECTION-SCREEN END OF LINE.

  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 10(20) text_252 FOR FIELD p_cnt MODIF ID fid.
    SELECTION-SCREEN POSITION 33.
    PARAMETERS : p_cnt TYPE i DEFAULT 30000 MODIF ID fid.
  SELECTION-SCREEN END OF LINE.

*--------------------------------------------------------------------*
  "  From Client
  SELECTION-SCREEN BEGIN OF LINE.
    PARAMETERS: rb202 RADIOBUTTON GROUP rg2.
    SELECTION-SCREEN COMMENT 4(28) text_220. " FOR FIELD rb202.

    SELECTION-SCREEN COMMENT 33(05) text_222 FOR FIELD p_mandt MODIF ID sou.
    SELECTION-SCREEN POSITION 39.
    PARAMETERS : p_mandt LIKE sy-mandt DEFAULT '100' MODIF ID sou.

    SELECTION-SCREEN POSITION 50.
    PARAMETERS: rb221 RADIOBUTTON GROUP rg21  MODIF ID sou.
    SELECTION-SCREEN COMMENT 53(08) text_221 FOR FIELD rb221 MODIF ID sou.

    SELECTION-SCREEN POSITION 61.
    PARAMETERS : p_sysid LIKE sy-sysid DEFAULT gc_dev MODIF ID sou.

    SELECTION-SCREEN POSITION 79.
    SELECTION-SCREEN PUSHBUTTON (30) text_223 USER-COMMAND additional MODIF ID sou.
  SELECTION-SCREEN END OF LINE.

  "  From Client - Remote Destration
  SELECTION-SCREEN BEGIN OF LINE.

    SELECTION-SCREEN POSITION 50.
    PARAMETERS: rb222 RADIOBUTTON GROUP rg21 DEFAULT 'X' MODIF ID sou.
    SELECTION-SCREEN COMMENT 53(08) text_224 FOR FIELD rb222 MODIF ID sou.

    SELECTION-SCREEN POSITION 61.
    PARAMETERS : p_dest LIKE rfcdes-rfcdest DEFAULT gc_rdest_q MODIF ID sou.

  SELECTION-SCREEN END OF LINE.

  " Direct reading
  SELECTION-SCREEN BEGIN OF LINE.
    PARAMETERS: rb203 RADIOBUTTON GROUP rg2.
    SELECTION-SCREEN COMMENT 4(28) text_230. " FOR FIELD rb203.

    SELECTION-SCREEN POSITION 79.
    SELECTION-SCREEN PUSHBUTTON (30) text_231 USER-COMMAND additional MODIF ID dir.
  SELECTION-SCREEN END OF LINE.

  " Empty Screen
  SELECTION-SCREEN BEGIN OF LINE.
    PARAMETERS: rb204 RADIOBUTTON GROUP rg2  DEFAULT 'X'.
    SELECTION-SCREEN COMMENT 4(28) text_240. " FOR FIELD rb204.
  SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN END OF BLOCK bl2.

" label 선택
SELECTION-SCREEN BEGIN OF BLOCK bl3 WITH FRAME TITLE text_300.
  SELECTION-SCREEN BEGIN OF LINE.
    SELECTION-SCREEN COMMENT 1(20) text_310.

    SELECTION-SCREEN POSITION 33.
    PARAMETERS: rb301            RADIOBUTTON GROUP rg3
                                 USER-COMMAND dummy.
    SELECTION-SCREEN COMMENT 35(20) text_311 FOR FIELD rb301.


    SELECTION-SCREEN POSITION 61.
    PARAMETERS: rb302           RADIOBUTTON GROUP rg3  DEFAULT 'X'.
    SELECTION-SCREEN COMMENT 63(15) text_312 FOR FIELD rb302.

  SELECTION-SCREEN END OF LINE.

SELECTION-SCREEN END OF BLOCK bl3.


" Comment
SELECTION-SCREEN BEGIN OF BLOCK bl9 WITH FRAME TITLE text_900.
  SELECTION-SCREEN COMMENT /4(60) text_911. " 1. Excel Upload 시 Title 은 2 라인 입니다.
  SELECTION-SCREEN COMMENT /4(60) text_912. " 2. Text Upload 시 Title 은 없습니다.
  SELECTION-SCREEN COMMENT /4(60) text_913.
SELECTION-SCREEN END OF BLOCK bl9.

INITIALIZATION.
  PERFORM set_title_text.
  PERFORM initialization_buffer.

AT SELECTION-SCREEN OUTPUT.
  PERFORM modify_screen_1000.

AT SELECTION-SCREEN.
  PERFORM get_tabname_1000 USING    p_tab
                           CHANGING p_tabnm.

  PERFORM get_tabname_1000 USING    p_tab1
                           CHANGING p_tabnm1.

  " User Command 처리...
  CASE sy-ucomm.
    WHEN 'ADDITIONAL'.
      PERFORM get_additional_options.
      CLEAR: sy-ucomm.

    WHEN 'FC01'.
      PERFORM xls_download_template    USING p_tab.
      CLEAR: sy-ucomm.

  ENDCASE.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  PERFORM get_upload_file  CHANGING  p_file
                                     gv_error_flag.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_filed.
  PERFORM get_download_file  CHANGING  p_filed
                                       gv_error_flag.

START-OF-SELECTION.
  PERFORM check_selection_1000.

  PERFORM create_buffer.
  PERFORM create_wtab.

  PERFORM get_data_main.
  CASE 'X'.
    WHEN rb205.
    WHEN OTHERS.
      IF gv_error_flag <> space.
        LEAVE TO LIST-PROCESSING.
      ENDIF.
  ENDCASE.


END-OF-SELECTION.
  CASE 'X'.
    WHEN rb201. " File Upload
      IF cb_out = space. " 결과출력
        CALL SCREEN '0100'.
      ENDIF.

    WHEN rb205.  " Download
    WHEN OTHERS.
      CALL SCREEN '0100'.
  ENDCASE.


*&---------------------------------------------------------------------*
*&      Form  SET_TITLE_TEXT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_title_text .

  text_100 = 'Target'.

  text_110 = 'Table Name'.
  text_111 = 'From Table Name(Option)'.
*  text_120 = 'Client(Option)'.

  text_200 = 'Source'.

  text_210 = 'File(Excel)'.
  text_211 = '결과조회안함'.
  text_212 = 'Single'.
  text_213 = 'Multi'.
  text_214 = 'Upload File 갯수'.
  text_215 = '추가 Option'.
  text_216 = 'Header Line 없음'.

  text_220 = 'Other System/Client'.
  text_221 = 'SysID'.
  text_222 = 'Clent'.
  text_223 = 'Additional'.
  text_224 = 'RFC Dest'. "'RFC Destination'.

  text_230 = 'Current System Data'.
  text_231 = 'Additional'.

  text_240 = 'Empty Screen'.

  text_250 = 'DownLoad FileName'.
  text_251 = 'Additional'.
  text_252 = 'Down Cnt(1회)'.

  text_300 = 'Additional Options'.
  text_310 = 'Label Text'.
  text_311 = 'Field Description'.
  text_312 = 'Field Name'.

  text_900 = 'Comment'.
  text_911 = '1. Excel Upload 시 Title 은 2 라인 입니다.'.
  text_912 = '2. Text Upload 시 Title 은 없습니다.'.
  text_913 = '3. File Upload 시 MANDT Field 및 값이 있어야 합니다.'.

  " Button
  sscrfields-functxt_01 = 'DownTemplate'.


ENDFORM.                    " SET_TITLE_TEXT
*&---------------------------------------------------------------------*
*&      Form  MODIFY_SCREEN_1000
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM modify_screen_1000 .

  PERFORM set_icon.

  LOOP AT SCREEN.

    " From File
    IF screen-group1 = 'FIL' AND rb201 = space.
      screen-active = 0.
    ENDIF.

    " Table Data Download
    IF screen-group1 = 'FID' AND rb205 = space.
      screen-active = 0.
    ENDIF.

    " From Client
    IF screen-group1 = 'SOU' AND rb202 = space.
      screen-active = 0.
    ENDIF.

    " Direct Reading
    IF screen-group1 = 'DIR' AND rb203 = space.
      screen-active = 0.
    ENDIF.

    MODIFY SCREEN.
  ENDLOOP.

ENDFORM.                    " MODIFY_SCREEN_1000
*&---------------------------------------------------------------------*
*&      Form  GET_UPLOAD_FILE
*&---------------------------------------------------------------------*
FORM get_upload_file  CHANGING pv_filename
                               pv_result.

  DATA: lv_multu TYPE c,
        lv_rc    TYPE i,
        lv_file  TYPE string,
        lt_file  TYPE filetable.

  CLEAR: pv_filename, pv_result, lt_file[].

  CASE 'X'.
    WHEN rb211. lv_multu = space.
    WHEN rb212. lv_multu = 'X'.
  ENDCASE.

  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      multiselection   = lv_multu
      default_filename = '*.XLS'
*     initial_directory = 'C:\TEMP\'
      file_filter      = '*.XLS||*.XLSX||*.*'
    CHANGING
      file_table       = lt_file
      rc               = lv_rc
    EXCEPTIONS
      OTHERS           = 1.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE 'S' NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               DISPLAY LIKE 'E'.
    pv_result = 'E'.
    EXIT.
  ENDIF.

  READ TABLE lt_file INDEX 1 INTO lv_file.
  IF lv_file IS INITIAL.
    MESSAGE s001(00) WITH '취소되었습니다.'.
    pv_result = 'E'.
    EXIT.
  ENDIF.

  MOVE lv_file TO pv_filename.

  CASE 'X'.
    WHEN rb211. CLEAR: gt_file_up_list.
    WHEN OTHERS.gt_file_up_list = lt_file.
  ENDCASE.

ENDFORM.                    " GET_UPLOAD_FILE
*&---------------------------------------------------------------------*
*&      Form  GET_DOWNLOAD_FILE
*&---------------------------------------------------------------------*
FORM get_download_file  CHANGING pv_filename
                                 pv_result.

  DATA: lv_rc       TYPE i,
        lv_file     TYPE string,
        lv_path     TYPE string,
        lv_fullpath TYPE string.

  CLEAR: pv_filename, pv_result.
  CALL METHOD cl_gui_frontend_services=>file_save_dialog
    EXPORTING
      window_title              = 'Table Data Download File Select'
      default_file_name         = '*.XLS'
      file_filter               = '*.XLS||*.XLSX||*.*'
      initial_directory         = 'C:\TEMP\'
    CHANGING
      filename                  = lv_file
      path                      = lv_path
      fullpath                  = lv_fullpath
      user_action               = lv_rc
    EXCEPTIONS
      cntl_error                = 1
      error_no_gui              = 2
      not_supported_by_gui      = 3
      invalid_default_file_name = 4
      OTHERS                    = 5.

  IF lv_rc IS NOT INITIAL.
    MESSAGE s001(00) WITH '취소되었습니다.'.
    pv_result = 'E'.
    EXIT.
  ENDIF.

  MOVE lv_fullpath TO pv_filename.

ENDFORM.                    " GET_DOWNLOAD_FILE
*&---------------------------------------------------------------------*
*&      Form  CHECK_SELECTION_1000
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM check_selection_1000 .

  gv_error_flag = 'X'.

  " Table name 가지고 오기
  SELECT SINGLE b~ddtext
    FROM dd02t AS b
         INNER JOIN dd02l AS a ON a~tabname = b~tabname
    INTO p_tabnm
   WHERE b~tabname    = p_tab
     AND b~ddlanguage = sy-langu
     AND a~tabclass   = 'TRANSP'.
  IF sy-subrc <> 0.
    MESSAGE s001(00) WITH 'Table Name 을 확인 하십시오.' DISPLAY LIKE 'E'.
    LEAVE LIST-PROCESSING.
  ENDIF.

  IF p_tab1 IS NOT INITIAL.
    SELECT SINGLE b~ddtext
      FROM dd02t AS b
           INNER JOIN dd02l AS a ON a~tabname = b~tabname
      INTO p_tabnm1
     WHERE b~tabname    = p_tab1
       AND b~ddlanguage = sy-langu
       AND a~tabclass   = 'TRANSP'.
    IF sy-subrc <> 0.
      MESSAGE s001(00) WITH 'Table Name 을 확인 하십시오.' DISPLAY LIKE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.
  ENDIF.

  "--------------------------------------------------------------------
  " Remote RFC read must use authenticated SM59 RFC destination.
  " QA SSO 환경에서 SAP GUI RFC logon popup 방지를 위해
  " SysID 매핑 방식은 허용하지 않고 RFC Dest 방식만 허용한다.
  "--------------------------------------------------------------------
  IF rb202 = abap_true.

    IF rb222 IS INITIAL.
      MESSAGE s001(00)
         WITH 'Remote 조회는 인증된 RFC Dest 방식만 허용됩니다.'
         DISPLAY LIKE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.

    IF p_dest IS INITIAL.
      MESSAGE s001(00)
         WITH 'RFC Destination을 입력하십시오.'
         DISPLAY LIKE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.

    SELECT SINGLE rfcdest
      FROM rfcdes
      WHERE rfcdest = @p_dest
      INTO @DATA(lv_rfcdest).
    IF sy-subrc <> 0.
      MESSAGE s001(00)
         WITH 'SM59 RFC Destination을 확인하십시오.' p_dest
         DISPLAY LIKE 'E'.
      LEAVE LIST-PROCESSING.
    ENDIF.

  ENDIF.

  CLEAR: gv_error_flag.

ENDFORM.                    " CHECK_SELECTION_1000
*&---------------------------------------------------------------------*
*&      Form  GET_ADDITIONAL_OPTIONS
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_additional_options .

  DATA: lv_tabname      TYPE tabname,
        lv_selection_id LIKE rsdynsel-selid,
        lv_title        LIKE sy-title,
        lt_field_ranges TYPE rsds_trange,
        lt_field_texts  TYPE TABLE OF rsdstexts.

  " 입력된 Table Name 확인
  SELECT SINGLE tabname
    FROM dd02l
    INTO lv_tabname
   WHERE tabname  = p_tab
  AND tabclass = 'TRANSP'.
  IF sy-subrc NE 0.
    MESSAGE i000 WITH
    '등록되어 있지 않은 Table 또는 Table 이 아닙니다.'.
    EXIT.
  ENDIF.

  PERFORM get_tabname_1000 USING    p_tab
                           CHANGING p_tabnm.

  " 검색 대상 Table
  DATA: ls_tables TYPE rsdstabs,
        ls_fields TYPE rsdsfields.

  READ TABLE gt_tables_tab INTO ls_tables INDEX 1.
  IF sy-subrc NE 0 OR ls_tables-prim_tab <> p_tab.
    CLEAR: gt_tables_tab[],
           gt_tabfields_not_display[], gt_tabfields_not_display,
           gt_fields_tab[],
           gt_where_clauses,           gt_expressions,
           gt_field_ranges.

    ls_tables-prim_tab = p_tab.
    APPEND ls_tables TO gt_tables_tab.
  ENDIF.

  " 예외 Field..
  IF gt_tabfields_not_display IS INITIAL.
    SELECT tabname    AS tablename
           fieldname
      FROM dd03l
      INTO CORRESPONDING FIELDS OF TABLE gt_tabfields_not_display
     WHERE tabname  = p_tab
    AND datatype = 'CLNT'.
  ENDIF.

  IF gt_fields_tab IS INITIAL.
    PERFORM get_field_text TABLES gt_fields_tab
                                  lt_field_texts
                           USING  p_tab.

  ENDIF.

  DATA:lv_kind TYPE char1.
  IF lines( gt_fields_tab[] ) > 30 OR gt_expressions IS INITIAL.
    CLEAR: gt_fields_tab[].
    lv_kind = 'T'.
  ELSE.
    lv_kind = 'F'.
  ENDIF.

  CALL FUNCTION 'FREE_SELECTIONS_INIT'
    EXPORTING
      kind                     = lv_kind
      expressions              = gt_expressions
*     field_ranges_int         = gt_field_ranges
*     field_groups_key         = ls_field_groups_key
*     RESTRICTION              =
*     alv                      = 'X'
*     CURR_QUAN_PROG           = SY-CPROG
*     CURR_QUAN_RELATION       =
    IMPORTING
      selection_id             = lv_selection_id
*     WHERE_CLAUSES            =
      expressions              = gt_expressions
*     field_ranges             = lt_field_ranges
*     NUMBER_OF_ACTIVE_FIELDS  =
    TABLES
      tables_tab               = gt_tables_tab
      tabfields_not_display    = gt_tabfields_not_display
      fields_tab               = gt_fields_tab
*     FIELD_DESC               =
      field_texts              = lt_field_texts
*     EVENTS                   =
*     EVENT_FIELDS             =
*     FIELDS_NOT_SELECTED      =
*     NO_INT_CHECK             =
*     ALV_QINFO                =
    EXCEPTIONS
      fields_incomplete        = 1
      fields_no_join           = 2
      field_not_found          = 3
      no_tables                = 4
      table_not_found          = 5
      expression_not_supported = 6
      incorrect_expression     = 7
      illegal_kind             = 8
      area_not_found           = 9
      inconsistent_area        = 10
      kind_f_no_fields_left    = 11
      kind_f_no_fields         = 12
      too_many_fields          = 13
      dup_field                = 14
      field_no_type            = 15
      field_ill_type           = 16
      dup_event_field          = 17
      node_not_in_ldb          = 18
      area_no_field            = 19
      OTHERS                   = 20.
  IF sy-subrc <> 0 .
    MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    EXIT.
  ENDIF.

  DATA: lv_no_act_fld TYPE sy-tfill.

  CONCATENATE '['  p_tab  '-' p_tabnm '] 검색조건' INTO lv_title.
  CALL FUNCTION 'FREE_SELECTIONS_DIALOG'
    EXPORTING
      selection_id            = lv_selection_id
      title                   = lv_title
*     FRAME_TEXT              = ' '
*     status                  = '1'
      as_window               = 'X'
      start_row               = 3
      start_col               = 20
*     NO_INTERVALS            = ' '
*     JUST_DISPLAY            = ' '
*     PFKEY                   =
*     ALV                     = ' '
      tree_visible            = space " 'X'
*     DIAG_text_1             =
*     DIAG_text_2             =
*     WARNING_TITLE           =
*     AS_SUBSCREEN            = ' '
*     no_frame                = ' '
    IMPORTING
      where_clauses           = gt_where_clauses
      expressions             = gt_expressions
      field_ranges            = gt_field_ranges
      number_of_active_fields = lv_no_act_fld
    TABLES
      fields_tab              = gt_fields_tab
*     FCODE_TAB               =
*     FIELDS_NOT_SELECTED     =
    EXCEPTIONS
      no_action               = 1
      OTHERS                  = 5.
  CASE sy-subrc.
    WHEN 0.
      sscrfields-ucomm = 'ONLI'.
    WHEN 1.
      CLEAR: sscrfields-ucomm .
    WHEN OTHERS.
      MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDCASE.

ENDFORM.                    " GET_ADDITIONAL_OPTIONS
*&---------------------------------------------------------------------*
*&      Form  INITIALIZATION_BUFFER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM initialization_buffer .

  gv_repid              = sy-repid.

  DATA: lv_unicode TYPE fc_flg.

  CALL FUNCTION 'UNICODE_REQUIRED'
    IMPORTING
      unicode_required = lv_unicode.
  IF lv_unicode IS INITIAL.
    gv_codepage = '1101'. "ASCII
  ELSE.
    gv_codepage = '8500'. " KOREA                        "UTF16-LE
  ENDIF.

  CREATE OBJECT go_alv_info
    EXPORTING
      iv_repid = gv_repid.

  CREATE OBJECT go_comfunc
    EXPORTING
      iv_repid = gv_repid.

  CLEAR: gt_file_up_list.

  CASE sy-sysid.
    WHEN gc_dev.
      p_sysid = gc_dev.
      p_dest  = gc_rdest_q.
    WHEN gc_qa.
      p_sysid = gc_qa.
      p_dest  = gc_rdest_d.
    WHEN gc_prd.
      p_sysid = gc_prd.
      p_dest  = gc_rdest_q.
  ENDCASE.

ENDFORM.                    " INITIALIZATION_BUFFER
*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data .

  DATA: lv_fieldname TYPE fieldname,
        lv_and       TYPE char5.

  SELECT SINGLE fieldname
    FROM dd03l
    INTO lv_fieldname
   WHERE tabname  = p_tab
  AND ( fieldname = 'MANDT' OR datatype = 'CLNT' ).
  IF sy-subrc NE 0.
    CLEAR: lv_fieldname.
  ENDIF.

  CLEAR: lv_and.

  " to client 삭제
*  IF p_mandtt IS INITIAL OR p_mandtt = sy-mandt OR lv_fieldname IS INITIAL.
  SELECT *
    FROM (p_tab)
    INTO CORRESPONDING FIELDS OF TABLE <gt_s0100>
  WHERE (gt_wtab).

*  ELSE.
*    IF gt_wtab[] IS NOT INITIAL.
*      lv_and = 'AND'.
*    ENDIF.
*
*    CONCATENATE lv_and lv_fieldname ` = P_MANDTT`
*           INTO gt_wtab-line SEPARATED BY space.
*    APPEND gt_wtab.
*
*    SELECT *
*      FROM (p_tab) CLIENT SPECIFIED
*      INTO CORRESPONDING FIELDS OF TABLE <gt_s0100>
*     WHERE (gt_wtab).
*
*  ENDIF.


ENDFORM.                    " GET_DATA
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

* Title : CBO Table of Data Loading
*      기능키 : SAVE,BACK(E)
*      F5 : REFRESH - Refresh      - App1 - ICON_REFRESH
*      F6 : CLEAR   - 화면 Clear   - App2 - ICON_CREATE
*      F7 : FEDIT   - FCat Edit    - App3 - ICON_REPORT_CALL
*      F8 : MASS    - Mass Change  - App4 - ICON_MASS_CHANGE
  SET PF-STATUS '0100'.

  " CBO Table of Data Loading - &
  SET TITLEBAR '0100' WITH p_tab.

ENDMODULE.                 " STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_0100 OUTPUT.

*  Container 가 없는 경우 신규로 생성..
  IF go_dcon_0100 IS INITIAL.

    PERFORM com_alv_create_grid_from_doc
            USING    gv_repid
                     sy-dynnr
            CHANGING go_dcon_0100
                     go_grid_0100.

*   define screen properties
    PERFORM set_alv_layout_0100.       " SET LAYOUT
    PERFORM set_alv_varient_0100.      " SET VARIENT
    PERFORM set_alv_fieldcat_0100.     " SET FIELD CATAGORY
    PERFORM set_alv_sortcat_0100.      " SET SORT FIELD

*-- SET  EVENT
    go_alv_info->set_event( EXPORTING iv_object_text = gc_object_id_0100
                                      io_grid        = go_grid_0100
*                                      iv_org_repid   = gv_org_repid
                            CHANGING  co_alv_event   = go_alv_event
                                      ct_fcat        = gt_fieldcat_0100
                                      ct_drop        = gt_dropdown ).

    CALL METHOD go_grid_0100->set_ready_for_input
      EXPORTING
        i_ready_for_input = '1'.

    PERFORM com_alv_display_grid     USING go_grid_0100
                                           gs_layout_0100
                                           gs_vari_0100
                                           gt_tool_0100
                                           gt_fieldcat_0100
                                           gt_sort_0100
                                           <gt_s0100>[].

  ELSE.

    PERFORM com_alv_refresh_grid     USING go_grid_0100.
  ENDIF.

ENDMODULE.                 " INIT_0100  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0100 INPUT.

  IF go_alv_info->exit_program( iv_save_flag = gv_save_flag_0100 ) = 'X'.
    LEAVE TO SCREEN 0.
  ELSE.
    CLEAR: gv_ok_code.
  ENDIF.

*  PERFORM com_exit_0100.
*  LEAVE TO SCREEN 0.

ENDMODULE.                 " EXIT_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  GET_OKCODE  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_okcode INPUT.

  gv_save_ok = gv_ok_code.
  CLEAR gv_ok_code.

ENDMODULE.                    "get_okcode INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.

  PERFORM com_alv_check_changed_data USING    go_grid_0100.
  PERFORM com_alv_dispatch           CHANGING gv_exit_form.
  CHECK gv_exit_form IS INITIAL.

  " process..
  CASE gv_save_ok.
    WHEN 'SAVE'.    " 저장..
      PERFORM luc_save_data_0100.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN 'REFRESH'.  " Refresh.
      PERFORM luc_refresh_data_0100.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN 'CLEAR'. " 화면 Clear
      IF <gt_s0100> IS ASSIGNED.
        CLEAR: <gt_s0100>.
        MESSAGE s000(oo) WITH '화면 Data가 Clear 되었습니다.'.
      ENDIF.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN 'FEDIT'.  " field catalog edit
      PERFORM luc_fieldcatalog_edit_0100.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN 'MASS'.  " Mass Change
      PERFORM luc_mass_change_0100.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN 'NOCONVEXIT'.  " No ConvExit
      PERFORM luc_no_convexit_0100.
      CLEAR: gv_save_ok. "  CLEAR ok code!

    WHEN OTHERS.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0200 OUTPUT.

* status : BACK(E), SAVE
  SET PF-STATUS '0200'.
  SET TITLEBAR '0200'. " Change of Field Catalog

ENDMODULE.                 " STATUS_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_0200  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_0200 OUTPUT.

*  Container 가 없는 경우 신규로 생성..
  IF go_dcon_0200 IS INITIAL.

    PERFORM com_alv_create_grid_from_doc
            USING    gv_repid
                     sy-dynnr
            CHANGING go_dcon_0200
                     go_grid_0200.

*   define screen properties
    PERFORM set_alv_layout_0200.       " SET LAYOUT
    PERFORM set_alv_varient_0200.      " SET VARIENT
    PERFORM set_alv_fieldcat_0200.     " SET FIELD CATAGORY
    PERFORM set_alv_sortcat_0200.      " SET SORT FIELD

**-- SET  EVENT
*    PERFORM com_alv_set_event        USING    go_grid_0200
*                                              'GO_GRID_0200'
*                                     CHANGING gt_fieldcat_0200.

    CALL METHOD go_grid_0200->set_ready_for_input
      EXPORTING
        i_ready_for_input = '1'.

    PERFORM com_alv_display_grid     USING go_grid_0200
                                           gs_layout_0200
                                           gs_vari_0200
                                           gt_tool_0200
                                           gt_fieldcat_0200
                                           gt_sort_0200
                                           gt_s0200[].

  ELSE.

    PERFORM com_alv_refresh_grid     USING go_grid_0200.
  ENDIF.

ENDMODULE.                 " INIT_0200  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0200 INPUT.

  PERFORM com_exit_0200.
  LEAVE TO SCREEN 0.

ENDMODULE.                 " EXIT_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0200 INPUT.

  PERFORM com_alv_check_changed_data USING    go_grid_0200.
  PERFORM com_alv_dispatch           CHANGING gv_exit_form.
  CHECK gv_exit_form IS INITIAL.

  " process..
  CASE gv_save_ok.
    WHEN 'SAVE'.    " 저장..
      PERFORM luc_save_data_0200.
      CLEAR: gv_save_ok. "  CLEAR ok code!


    WHEN OTHERS.
  ENDCASE.

ENDMODULE.                 " USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*&      Module  STATUS_5010  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_5010 OUTPUT.

* status : BACK(E)
  SET PF-STATUS '5010'.
  SET TITLEBAR '5010'. " Upload Error List

ENDMODULE.                 " STATUS_5010  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  INIT_5010  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init_5010 OUTPUT.

*  Container 가 없는 경우 신규로 생성..
  IF go_dcon_5010 IS INITIAL.

    PERFORM com_alv_create_grid_from_doc
            USING    gv_repid
                     sy-dynnr
            CHANGING go_dcon_5010
                     go_grid_5010.

*   define screen properties
    PERFORM set_alv_layout_5010.       " SET LAYOUT
    PERFORM set_alv_varient_5010.      " SET VARIENT
    PERFORM set_alv_fieldcat_5010.     " SET FIELD CATAGORY
    PERFORM set_alv_sortcat_5010.      " SET SORT FIELD

**-- SET  EVENT
*    PERFORM com_alv_set_event        USING    go_grid_5010
*                                              'GO_GRID_5010'
*                                     CHANGING gt_fieldcat_5010.

    CALL METHOD go_grid_5010->set_ready_for_input
      EXPORTING
        i_ready_for_input = '0'.

    PERFORM com_alv_display_grid     USING go_grid_5010
                                           gs_layout_5010
                                           gs_vari_5010
                                           gt_tool_5010
                                           gt_fieldcat_5010
                                           gt_sort_5010
                                           gt_s5010[].

  ELSE.

    PERFORM com_alv_refresh_grid     USING go_grid_5010.
  ENDIF.

ENDMODULE.                 " INIT_5010  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_5010  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_5010 INPUT.

  PERFORM com_exit_5010.
  LEAVE TO SCREEN 0.

ENDMODULE.                 " EXIT_5010  INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_5010  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_5010 INPUT.

  PERFORM com_alv_check_changed_data USING    go_grid_5010.
  PERFORM com_alv_dispatch           CHANGING gv_exit_form.
  CHECK gv_exit_form IS INITIAL.

  " process..
*  CASE gv_save_ok.
*    WHEN OTHERS.
*  ENDCASE.

ENDMODULE.                 " USER_COMMAND_5010  INPUT
*----------------------------------------------------------------------*
FORM com_alv_check_changed_data
     USING po_grid           TYPE REF TO cl_gui_alv_grid.

  IF po_grid IS BOUND.
    CLEAR gv_valid.
    CALL METHOD po_grid->check_changed_data
      IMPORTING
        e_valid = gv_valid.
  ENDIF.

ENDFORM.                    "com_alv_check_changed_data
*&---------------------------------------------------------------------*
*&      Form  com_alv_dispatch
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--PV_EXIT_FORM  text
*----------------------------------------------------------------------*
FORM com_alv_dispatch        CHANGING pv_exit_form.

  DATA: lv_return_code       TYPE i.

  CLEAR: pv_exit_form.
  CALL METHOD cl_gui_cfw=>dispatch
    IMPORTING
      return_code = lv_return_code.
  IF lv_return_code <> cl_gui_cfw=>rc_noevent.
    CASE gv_ok_code+9(1).
      WHEN '9'.
        gv_no_refresh = 'X'.
      WHEN OTHERS.
        gv_no_refresh = space.
    ENDCASE.

    CLEAR gv_ok_code.
    gv_exit_form = 'X'.
    EXIT.
  ENDIF.

ENDFORM.                    "com_alv_dispatch
*----------------------------------------------------------------------*
*&      Form  COM_EXIT_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM com_exit_0100.

  IF go_grid_0100 IS NOT INITIAL.
    CALL METHOD go_grid_0100->free.
    CLEAR: go_grid_0100.
  ENDIF.

  IF go_dcon_0100 IS NOT INITIAL.
    CALL METHOD go_dcon_0100->free.
    CLEAR: go_dcon_0100.
  ENDIF.

  IF go_ccon_0100 IS NOT INITIAL.
    CALL METHOD go_ccon_0100->free.
    CLEAR: go_ccon_0100.
  ENDIF.

ENDFORM.                    "COM_EXIT_0100
*&---------------------------------------------------------------------*
*&      Form  COM_EXIT_0200
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM com_exit_0200.

  IF go_grid_0200 IS NOT INITIAL.
    CALL METHOD go_grid_0200->free.
    CLEAR: go_grid_0200.
  ENDIF.

  IF go_dcon_0200 IS NOT INITIAL.
    CALL METHOD go_dcon_0200->free.
    CLEAR: go_dcon_0200.
  ENDIF.

ENDFORM.                    "COM_EXIT_0200
*&---------------------------------------------------------------------*
*&      Form  COM_EXIT_5010
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
FORM com_exit_5010.

  IF go_grid_5010 IS NOT INITIAL.
    CALL METHOD go_grid_5010->free.
    CLEAR: go_grid_5010.
  ENDIF.

  IF go_dcon_5010 IS NOT INITIAL.
    CALL METHOD go_dcon_5010->free.
    CLEAR: go_dcon_5010.
  ENDIF.

ENDFORM.                    "COM_EXIT_5010
*&---------------------------------------------------------------------*
*&      Form  com_alv_create_grid_from_doc
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PV_REPID      text
*      -->TYPE  SYREPID  text
*      -->PV_DYNNR      text
*      -->TYPE  SYDYNNR  text
*      <--PO_DCON       text
*      <--PO_GRID       text
*----------------------------------------------------------------------*
FORM com_alv_create_grid_from_doc
     USING    pv_repid       TYPE	syrepid
              pv_dynnr       TYPE	sydynnr
     CHANGING po_dcon        TYPE REF TO cl_gui_docking_container
              po_grid        TYPE REF TO cl_gui_alv_grid.

*  Docking container 생성..
  CREATE OBJECT po_dcon
    EXPORTING
      repid                       = pv_repid
      dynnr                       = pv_dynnr
      side                        = cl_gui_docking_container=>dock_at_top
      extension                   = gv_extension
    EXCEPTIONS
      cntl_error                  = 1
      cntl_system_error           = 2
      create_error                = 3
      lifetime_error              = 4
      lifetime_dynpro_dynpro_link = 5.

  " Grid 생성..
  CREATE OBJECT po_grid
    EXPORTING
      i_parent          = po_dcon
      i_appl_events     = space
    EXCEPTIONS
      error_cntl_create = 1
      error_cntl_init   = 2
      error_cntl_link   = 3
      error_dp_create   = 4.

ENDFORM.                    "com_alv_create_grid_from_doc
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_LAYOUT_0100
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_layout_0100.

  CLEAR gs_layout_0100.
  gs_layout_0100-zebra      = 'X'.
  gs_layout_0100-sel_mode   = 'A'.
  gs_layout_0100-cwidth_opt = 'X'.
  gs_layout_0100-edit_mode  = 'X'.

ENDFORM.                    "SET_ALV_LAYOUT_0100
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_VARIENT_0100
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_varient_0100.

  CLEAR: gs_vari_0100.
  gs_vari_0100-report   = gv_repid.
  gs_vari_0100-username = sy-uname.

ENDFORM.                    "SET_ALV_VARIENT_0100
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_FIELDCAT_0100
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_fieldcat_0100.

  DATA: ls_fieldcat  TYPE lvc_s_fcat.      " FIELD CATALOG

* FIELDCATALOG 정의
  CLEAR: gt_fieldcat_0100[].
  gt_fieldcat_0100[] = go_alv_info->get_fieldcatalog( it_tab = <gt_s0100>[] ).

*  보여지는 FIELD 정의, : 화면에 보여지는 순서데로.
  LOOP AT gt_fieldcat_0100 INTO ls_fieldcat.

    IF ls_fieldcat-datatype = 'CLNT'.
      IF rb202 = abap_true AND p_mandt <> sy-mandt.
      ELSE.
        ls_fieldcat-tech = 'X'.
      ENDIF.
    ENDIF.

    " Label Text 선택에 따라서
    IF ls_fieldcat-reptext IS INITIAL OR rb302 = 'X'.
      ls_fieldcat-reptext    = ls_fieldcat-fieldname.
      ls_fieldcat-scrtext_l  = ls_fieldcat-fieldname.
      ls_fieldcat-scrtext_m  = ls_fieldcat-fieldname.
      ls_fieldcat-scrtext_s  = ls_fieldcat-fieldname.
      ls_fieldcat-coltext    = ls_fieldcat-fieldname.

      MODIFY gt_fieldcat_0100 FROM ls_fieldcat
             TRANSPORTING reptext scrtext_l scrtext_m scrtext_s
                          coltext.
    ENDIF.

    ls_fieldcat-col_pos    = sy-tabix.
    ls_fieldcat-edit       = 'X'.

    IF ls_fieldcat-convexit IS NOT INITIAL.  " conv exit 제외
      ls_fieldcat-no_convext = abap_true .
    ENDIF.

    MODIFY gt_fieldcat_0100 FROM ls_fieldcat
           TRANSPORTING col_pos edit tech no_convext.

  ENDLOOP.

ENDFORM.                    "SET_ALV_FIELDCAT_0100
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_SORTCAT_0100
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_sortcat_0100.

  CLEAR: gt_sort_0100[].
*  PERFORM com_alv_set_sortcat     TABLES gt_sort_0100  USING  'U':
*          'ICON'       ,    " 상태
*          'QMNUM'      ,    " 통지 번호
*          'MAWERK'     ,    " 플랜트
*          'QMTXT'      ,    " 통지내역
*          'MATNR'      ,    " 자재코드
*          'MAKTX'      ,    " 자재명
*          'RKMNGC'     ,    " 부적합 수량
*          'MGEIN'      ,    " 단위
*          'CHARG'      ,    " 배치 번호
*          'PRODDAT'    ,    " 생산일자
*          'FERTAUFNR'  ,    " 오더번호 (생산오더)
*          'STRMN'      ,    " 요청시작일
*          'LTRMN'      ,    " 요청종료일
*          'QMDAB'      ,    " 완료일
*          'DEPCDNM'    ,    " 담당부서
*          'EMPNO_TXT'  ,    " 코디네이터
*          'PRUEFLOS'   .    " 검사로트

ENDFORM.                    "SET_ALV_SORTCAT_0100
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_LAYOUT_0200
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_layout_0200.

  CLEAR gs_layout_0200.
  gs_layout_0200-zebra      = 'X'.
  gs_layout_0200-sel_mode   = 'A'.
  gs_layout_0200-cwidth_opt = 'X'.
  gs_layout_0200-edit_mode  = 'X'.

ENDFORM.                    "SET_ALV_LAYOUT_0200
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_VARIENT_0200
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_varient_0200.

  CLEAR: gs_vari_0200.
  gs_vari_0200-report   = gv_repid.
  gs_vari_0200-username = sy-uname.

ENDFORM.                    "SET_ALV_VARIENT_0200
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_FIELDCAT_0200
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_fieldcat_0200.

  DATA: ls_fieldcat   TYPE lvc_s_fcat.      " FIELD CATALOG

* FIELDCATALOG 정의
  CLEAR: gt_fieldcat_0200[].
  gt_fieldcat_0200[] = go_alv_info->get_fieldcatalog( it_tab = gt_s0200[] ).

*  보여지는 FIELD 정의, : 화면에 보여지는 순서데로.
  LOOP AT gt_fieldcat_0200 INTO ls_fieldcat.

    IF ls_fieldcat-datatype = 'CLNT'.
      ls_fieldcat-tech = 'X'.
    ELSE.
      ls_fieldcat-edit    = 'X'.

      CASE ls_fieldcat-fieldname.
        WHEN 'ROW_POS'   OR 'COL_POS' OR 'FIELDNAME' OR
             'REF_FIELD' OR 'REF_TABLE'.
          ls_fieldcat-col_pos = sy-tabix.
        WHEN OTHERS.
          ls_fieldcat-col_pos = sy-tabix + 100.
      ENDCASE.
    ENDIF.

    ls_fieldcat-coltext = ls_fieldcat-fieldname.

    MODIFY gt_fieldcat_0200 FROM ls_fieldcat
           TRANSPORTING col_pos edit tech coltext.

  ENDLOOP.

ENDFORM.                    "SET_ALV_FIELDCAT_0200
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_SORTCAT_0200
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_sortcat_0200.

  CLEAR: gt_sort_0200[].

ENDFORM.                    "SET_ALV_SORTCAT_0200
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_LAYOUT_5010
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_layout_5010.

  CLEAR gs_layout_5010.
  gs_layout_5010-zebra      = 'X'.
  gs_layout_5010-sel_mode   = 'A'.
  gs_layout_5010-cwidth_opt = 'X'.
  gs_layout_5010-edit_mode  = 'X'.

ENDFORM.                    "SET_ALV_LAYOUT_5010
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_VARIENT_5010
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_varient_5010.

  CLEAR: gs_vari_5010.
  gs_vari_5010-report   = gv_repid.
  gs_vari_5010-username = sy-uname.

ENDFORM.                    "SET_ALV_VARIENT_5010
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_FIELDCAT_5010
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_fieldcat_5010.

  DATA: ls_fieldcat   TYPE lvc_s_fcat.      " FIELD CATALOG

* FIELDCATALOG 정의
  CLEAR: gt_fieldcat_5010[].
  gt_fieldcat_5010[] = go_alv_info->get_fieldcatalog( it_tab = gt_s5010[] ).

*  보여지는 FIELD 정의, : 화면에 보여지는 순서데로.
  CLEAR: gv_col_pos.  " column 위치 설정..
  PERFORM com_alv_col_pos      TABLES gt_fieldcat_5010 USING:
         'COLUMN'       ' ' '30' 'Column'       ' ' ' ' ' ',    " Column
         'COLUMN_TXT'   ' ' '30' 'Description'  ' ' ' ' ' ',    " Description
         'LINE'         ' ' '04' 'Line'         ' ' ' ' ' ',    " Line
         'MESSAGE'      ' ' '30' 'Message'      ' ' ' ' ' '.    " Message

* 보여지지 않는 FIELD 감추기
  PERFORM com_alv_col_delete TABLES gt_fieldcat_5010.

ENDFORM.                    "SET_ALV_FIELDCAT_5010
*&---------------------------------------------------------------------*
*&      FORM  SET_ALV_SORTCAT_5010
*&---------------------------------------------------------------------*
*       TEXT
*----------------------------------------------------------------------*
FORM set_alv_sortcat_5010.

  CLEAR: gt_sort_5010[].

ENDFORM.                    "SET_ALV_SORTCAT_5010
*&---------------------------------------------------------------------*
*&      Form  com_alv_display_grid
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PO_GRID      text
*      -->PS_LAYOUT    text
*      -->PS_VARI      text
*      -->PT_TOOL      text
*      -->PT_FIELDCAT  text
*      -->PT_SORT      text
*      -->PT_TABLE     text
*----------------------------------------------------------------------*
FORM com_alv_display_grid
     USING po_grid           TYPE REF TO cl_gui_alv_grid
           ps_layout         TYPE        lvc_s_layo
           ps_vari           TYPE        disvariant
           pt_tool           TYPE        ui_functions
           pt_fieldcat       TYPE        lvc_t_fcat
           pt_sort           TYPE        lvc_t_sort
           pt_table          TYPE STANDARD TABLE.

  CALL METHOD po_grid->set_table_for_first_display
    EXPORTING
      is_layout                     = ps_layout
      i_save                        = 'A'
      i_default                     = 'X'
      is_variant                    = ps_vari
      it_toolbar_excluding          = pt_tool
    CHANGING
      it_outtab                     = pt_table[]
      it_fieldcatalog               = pt_fieldcat[]
      it_sort                       = pt_sort[]
    EXCEPTIONS
      invalid_parameter_combination = 1
      program_error                 = 2
      too_many_lines                = 3
      OTHERS                        = 4.

  CALL METHOD cl_gui_control=>set_focus
    EXPORTING
      control = po_grid.

  CALL METHOD cl_gui_cfw=>flush.

ENDFORM.                    "com_alv_display_grid
*&---------------------------------------------------------------------*
*&      Form  com_alv_refresh_grid
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PO_GRID    text
*----------------------------------------------------------------------*
FORM com_alv_refresh_grid
     USING po_grid           TYPE REF TO cl_gui_alv_grid.
*
  DATA: ls_stbl             TYPE lvc_s_stbl.

  CLEAR: ls_stbl.

  IF gv_no_refresh    = space AND gv_error_in_data = space.

    ls_stbl-row = 'X'.
    ls_stbl-col = 'X'.

    IF po_grid IS BOUND.
      CALL METHOD po_grid->refresh_table_display
        EXPORTING
          is_stable = ls_stbl.
    ENDIF.
  ENDIF.
*  ENDIF.

ENDFORM.                    "com_alv_refresh_grid
*&---------------------------------------------------------------------*
*&      Form  LUC_SAVE_DATA_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM luc_save_data_0100 .

  DATA: lv_del_flag,
        lv_fieldname TYPE fieldname,
        lv_mandt     TYPE scrfname,
        lo_work      TYPE REF TO data.

  FIELD-SYMBOLS:
    <ls_work>  TYPE any,
    <lv_mandt> TYPE any.

  gv_title   = '자료 저장 확인'.
  gv_text100 = '화면의 자료를 저장 하시겠습니까?'.

  CLEAR: lv_del_flag.
  IF rb201 = 'X' OR rb204 = 'X'.
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = gv_title
        text_question         = gv_text100
*       text_button_1         = '저장'
*       text_button_2         = '보관'
        display_cancel_button = space
      IMPORTING
        answer                = gv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.

  ELSE.

    CONCATENATE gv_text100 ` ` '저장시 기존 동일 자료는 삭제됩니다.'
           INTO gv_text100.

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = gv_title
        text_question         = gv_text100
        text_button_1         = '삭제'
        text_button_2         = '보관'
        display_cancel_button = 'X'
      IMPORTING
        answer                = gv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
  ENDIF.

  CASE gv_answer.

    WHEN 'J' OR '1'. " 예
      IF rb201 = 'X' OR rb204 = 'X'.
      ELSE.
        IF p_mandt = '000'.
          DELETE FROM (p_tab) USING ALL CLIENTS
                 WHERE (gt_wtab_d).
        ELSE.
          DELETE FROM (p_tab) WHERE (gt_wtab_d).
        ENDIF.
        COMMIT WORK AND WAIT.

        lv_del_flag = abap_true.
      ENDIF.

    WHEN 'N' OR '2'. " 아니오.
      IF rb201 = 'X' OR rb204 = 'X'.
        MESSAGE i000(oo) WITH '작업이 취소되었습니다.'.
        EXIT.
      ENDIF.

    WHEN OTHERS.
      MESSAGE i000(oo) WITH '작업이 취소되었습니다.'.
      EXIT.

  ENDCASE.

  " 화면에 저장할 정보가 없는 경우(삭제 제외)
  IF <gt_s0100>[] IS INITIAL AND lv_del_flag = abap_false.
    MESSAGE s000(oo) WITH '저장 할 자료가 없습니다.'.
    EXIT.
  ENDIF.

  " to client 삭제
*  IF p_mandtt IS INITIAL OR p_mandtt = sy-mandt.
  IF <gt_s0100>[] IS NOT INITIAL.
    MODIFY (p_tab) FROM TABLE <gt_s0100>.
  ENDIF.

*  ELSE.
*    SELECT SINGLE fieldname
*      FROM dd03l
*      INTO lv_fieldname
*     WHERE tabname  = p_tab
*       AND datatype = 'CLNT'.
*    IF sy-subrc = 0.  " 클라이언트 정보가 있는 경우 해당 클라이언트 변경.
*      UNASSIGN <ls_work>.
*      CREATE DATA lo_work TYPE (p_tab).
*      ASSIGN lo_work->* TO <ls_work>.
*      IF sy-subrc NE 0 OR <ls_work> IS NOT ASSIGNED.
*        MESSAGE i000(oo) WITH 'Work Buffer 생성 에러'.
*        EXIT.
*      ENDIF.
*
*      CONCATENATE '<LS_WORK>-' lv_fieldname INTO lv_mandt.
**      ASSIGN (lv_mandt) TO <lv_mandt>.
*
**      CLEAR: <ls_work>.
**      <lv_mandt> = p_mandtt.
*
**      CLEAR: gt_wtab[], gt_wtab.
**      CONCATENATE lv_fieldname ` <> P_MANDTT` INTO gt_wtab-line.
**      APPEND gt_wtab.
*
*      LOOP AT <gt_s0100> ASSIGNING <ls_work>.
*
*        ASSIGN (lv_mandt) TO <lv_mandt>.
*        <lv_mandt> = p_mandtt.
**        MODIFY <gt_s0100>.
*
*      ENDLOOP.
*
**      MODIFY <gt_s0100> FROM <ls_work>
**             TRANSPORTING (lv_fieldname)
**             WHERE (gt_wtab).
*    ENDIF.
*
*    MODIFY (p_tab) CLIENT SPECIFIED FROM TABLE <gt_s0100>.
*  ENDIF.

  COMMIT WORK AND WAIT.

  MESSAGE s000(oo) WITH '저장 되었습니다'.

  gv_save_flag_0100 = abap_false.

ENDFORM.                    " LUC_SAVE_DATA_0100
*&---------------------------------------------------------------------*
*&      Form  CREATE_BUFFER
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_buffer .

  IF <gt_s0100> IS ASSIGNED.
    FREE <gt_s0100>.
    UNASSIGN <gt_s0100>.
  ENDIF.

  CREATE DATA go_tab TYPE TABLE OF (p_tab).
  ASSIGN go_tab->* TO <gt_s0100>.

  CLEAR: <gt_s0100>[].

ENDFORM.                    " CREATE_BUFFER
*&---------------------------------------------------------------------*
*&      Form  EMPTY_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM empty_data .

  IF <gt_s0100> IS ASSIGNED.
    CLEAR: <gt_s0100>[].
  ENDIF.
*  APPEND INITIAL LINE TO <gt_s0100>.

ENDFORM.                    " EMPTY_DATA
*&---------------------------------------------------------------------*
*&      Form  CREATE_WTAB
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM create_wtab .

  CLEAR: gt_wtab[], gt_wtab_d[].
  READ TABLE gt_where_clauses INTO gs_where_clause INDEX 1.
  CHECK sy-subrc = 0.

  LOOP AT gs_where_clause-where_tab INTO gs_where_tab.
    APPEND gs_where_tab TO gt_wtab.
  ENDLOOP.

  gt_wtab_d[] = gt_wtab[].

ENDFORM.                    " CREATE_WTAB
*&---------------------------------------------------------------------*
*&      Form  SET_ICON
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM set_icon .

  text_231 = text_223 = 'Additional'.

  IF gt_where_clauses IS NOT INITIAL.
    CASE 'X'.
      WHEN rb202.
        PERFORM create_icon USING icon_led_green
                            CHANGING text_223.
      WHEN rb203.
        PERFORM create_icon USING icon_led_green
                            CHANGING text_231.
    ENDCASE.
  ENDIF.

ENDFORM.                    " SET_ICON
*&---------------------------------------------------------------------*
*&      Form  CREATE_ICON
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_ICON_GREEN_LIGHT  text
*      <--P_text_231  text
*----------------------------------------------------------------------*
FORM create_icon             USING    pv_icon
                             CHANGING pv_text.

  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = pv_icon
      text   = pv_text
      info   = pv_text
    IMPORTING
      result = pv_text
    EXCEPTIONS
      OTHERS = 0.

ENDFORM.                    " CREATE_ICON
*&---------------------------------------------------------------------*
*&      Form  GET_DATA_CLIENT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data_client .

  DATA: lv_fieldname TYPE fieldname,
        lv_message   TYPE bapi_msg,
        lv_subrc     TYPE sy-subrc,
        lt_tab       TYPE STANDARD TABLE OF bapixmspow,
        lt_wtab      TYPE STANDARD TABLE OF rsdswhere,
        lo_line      TYPE REF TO data.

  FIELD-SYMBOLS:
    <ls_work> TYPE any.

  CLEAR: lv_fieldname,
         lv_message,
         lv_subrc,
         lt_tab[],
         lt_wtab[].

  CREATE DATA lo_line TYPE (p_tab).
  ASSIGN lo_line->* TO <ls_work>.
  IF sy-subrc <> 0 OR <ls_work> IS NOT ASSIGNED.
    MESSAGE i000(oo) WITH 'Work Buffer 생성 에러'.
    EXIT.
  ENDIF.

  lt_wtab[] = gt_wtab[].

  " Client field check
  SELECT SINGLE fieldname
    FROM dd03l
    WHERE tabname = @p_tab
      AND ( fieldname = 'MANDT' OR datatype = 'CLNT' )
    INTO @lv_fieldname.
  IF sy-subrc <> 0.
    CLEAR lv_fieldname.
  ENDIF.

  " p_mandt = '000' 인 경우 Remote 전체 Client 조회
  " => CLIENT 조건을 추가하지 않는다.
  IF lv_fieldname IS NOT INITIAL
     AND p_mandt IS NOT INITIAL
     AND p_mandt <> '000'.

    DATA(lv_client_where) =
      COND string(
        WHEN lt_wtab[] IS INITIAL
        THEN |{ lv_fieldname } = '{ p_mandt }'|
        ELSE |AND { lv_fieldname } = '{ p_mandt }'| ).

    APPEND VALUE rsdswhere( line = lv_client_where ) TO lt_wtab.

  ENDIF.

  " RFC Dest 방식만 허용한다.
  " SM59 Logon Procedure: Trusted RFC + Current User 전제.
  IF rb202 = abap_true AND rb222 = abap_true.

    CALL FUNCTION 'YBZ_DATACOPY'
      DESTINATION p_dest
      EXPORTING
        iv_fr_tab             = p_tab
        iv_to_tab             = p_tab1
      TABLES
        it_wtab               = lt_wtab
        et_data               = lt_tab
      EXCEPTIONS
        communication_failure = 1 MESSAGE lv_message
        system_failure        = 2 MESSAGE lv_message
        OTHERS                = 3.

    lv_subrc = sy-subrc.

    IF lv_subrc <> 0.
      IF lv_message IS INITIAL.
        lv_message = |RFC 호출 오류. DEST={ p_dest }, SUBRC={ lv_subrc }|.
      ENDIF.

      MESSAGE i000(oo) WITH lv_message.
      EXIT.
    ENDIF.

  ELSE.
    MESSAGE i000(oo)
       WITH 'Remote 조회는 인증된 RFC Dest 방식만 허용됩니다.'.
    EXIT.
  ENDIF.

  CLEAR <gt_s0100>[].

* UNICode 때문에 Type Conversion 해야 한다
  LOOP AT lt_tab ASSIGNING FIELD-SYMBOL(<ls_tab>).

    CLEAR <ls_work>.

    CALL FUNCTION 'PI_BP_MOVE_UNICODE'
      EXPORTING
        iv_move_from = <ls_tab>
      CHANGING
        cv_move_to   = <ls_work>.

    APPEND <ls_work> TO <gt_s0100>.

  ENDLOOP.

  gt_wtab[]   = lt_wtab[].
  gt_wtab_d[] = lt_wtab[].

ENDFORM.                    " GET_DATA_CLIENT
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload_file .

  DATA: lv_tabname   TYPE ddobjname,
        lv_position  TYPE tabfdpos,
        lv_start_col TYPE i VALUE '1',
        lv_start_row TYPE i VALUE '3',
        lv_end_col   TYPE i VALUE '256',
        lv_end_row   TYPE i VALUE '65536',

        ls_stab      TYPE dfies,
        lt_stab      TYPE TABLE OF dfies,
        lt_execl_tmp TYPE kcde_sender,
        ls_execl_tmp TYPE kcde_sender_struc.

  DATA: BEGIN OF lt_excel_col  OCCURS 0,
          field(1000),
        END OF lt_excel_col.

  DATA: lo_stru_ref TYPE REF TO cl_abap_structdescr,
        lo_tab_ref  TYPE REF TO cl_abap_tabledescr.

  DATA: lv_separator TYPE c           VALUE cl_abap_char_utilities=>horizontal_tab,
        lv_linex     TYPE sy-tabix,
        lv_tabix     TYPE sy-tabix.

  DATA: lo_new_line TYPE REF TO data.  " DEREFERENCE <FS>
  FIELD-SYMBOLS: <ls_work>,
                 <lo_field>.

  CREATE DATA lo_new_line  TYPE (p_tab).
  ASSIGN lo_new_line->*      TO <ls_work>.

  DATA: lv_extension(05).

  lv_tabname = p_tab.
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname        = lv_tabname
    TABLES
      dfies_tab      = lt_stab
    EXCEPTIONS
      not_found      = 1
      internal_error = 2
      OTHERS         = 3.
  IF sy-subrc NE 0.
    EXIT.
  ENDIF.

  SORT lt_stab BY position.

  DATA: lv_type,
        lv_error_flag,
        ls_s5010       TYPE tys_s5010.

  lo_tab_ref  ?= cl_abap_typedescr=>describe_by_data( <gt_s0100> ).
  lo_stru_ref ?= lo_tab_ref->get_table_line_type( ).

  " Column 수 정의..
  lv_end_col   = lines( lo_stru_ref->components ).

  DATA: ls_file_up_list TYPE file_table,
        lv_dbcnt        TYPE sy-dbcnt,
        lv_dbcnt_c      TYPE char20,
        lv_msg          TYPE bapi_msg,
        lv_filename     TYPE string,
        lv_filename_out TYPE draw-filep.

  IF rb211 = 'X'.  " single
    CLEAR: gt_file_up_list.
  ENDIF.

  IF gt_file_up_list IS INITIAL.
    ls_file_up_list-filename = p_file.
    APPEND ls_file_up_list TO gt_file_up_list.
  ENDIF.

  CLEAR: <gt_s0100>[], gt_s5010[], lv_dbcnt.
  LOOP AT gt_file_up_list INTO ls_file_up_list.

    lv_filename = ls_file_up_list-filename.

    " File 이 있는지 여부 확인
    PERFORM com_check_file_name  USING    lv_filename space
                                 CHANGING gv_error_flag.
    CHECK gv_error_flag IS INITIAL.

    " Extension 분리
    PERFORM com_check_file_extension USING    lv_filename
                                     CHANGING lv_filename_out
                                              lv_extension.
*--------------------------------------------------------------------*
    CONCATENATE lv_filename_out ` .. Reading Start` INTO go_comfunc->gv_sp_msg.
    go_comfunc->show_message_p( 0 ).
*--------------------------------------------------------------------*

    CASE lv_extension.
      WHEN 'XLS' OR 'XLSX'.
        PERFORM upload_xls_file2 TABLES lt_execl_tmp
                                 USING  lv_filename.

      WHEN 'TXT' OR 'CVS'.
        PERFORM upload_text_file TABLES lt_execl_tmp
                                 USING  lv_filename.

      WHEN OTHERS.
*        MESSAGE i000(oo) WITH 'EXTENSION Error'.
        CONTINUE.
    ENDCASE.

    IF lt_execl_tmp[] IS INITIAL.
      CONTINUE.
    ENDIF.

    IF cb_out = 'X'. " 결과출력 안하면 단위로 update 함
      CLEAR: <gt_s0100>[].
    ENDIF.

    LOOP AT lt_execl_tmp INTO ls_execl_tmp.

      lv_linex = sy-tabix.

      CHECK NOT ls_execl_tmp IS INITIAL.
      SPLIT ls_execl_tmp-line AT lv_separator
            INTO TABLE lt_excel_col.

      CLEAR: <ls_work>.

      LOOP AT lt_excel_col.

        lv_tabix = sy-tabix.

        READ TABLE lt_stab INTO ls_stab INDEX lv_tabix.
        CHECK sy-subrc = 0.

        UNASSIGN <lo_field>.
        ASSIGN COMPONENT lv_tabix OF STRUCTURE <ls_work> TO <lo_field>.
        CHECK sy-subrc EQ 0.

        IF ls_stab-datatype = 'CLNT'.
          <lo_field> = sy-mandt.
          CONTINUE.
        ENDIF.

        DESCRIBE FIELD <lo_field> TYPE lv_type.
        CASE lv_type.

          WHEN 'D'. " DATE.
            PERFORM conversion_date_input USING    lt_excel_col-field
                                          CHANGING lt_excel_col-field.
            <lo_field> = lt_excel_col-field.

          WHEN 'T'. " TIME
            PERFORM conversion_time_input USING    lt_excel_col-field
                                          CHANGING lt_excel_col-field.
            <lo_field> = lt_excel_col-field.

          WHEN 'P' OR 'b' OR 'I' OR 's'. " 숫자인 경우..
            PERFORM conversion_curr_input USING    lt_excel_col-field
                                          CHANGING lt_excel_col-field
                                                   lv_error_flag.
            IF lv_error_flag = space.
              <lo_field> = lt_excel_col-field.
            ELSE.
              CLEAR: ls_s5010.
              ls_s5010-line        = lv_linex.
              ls_s5010-column      = ls_stab-fieldname.
              ls_s5010-column_txt  = ls_stab-fieldtext.
              CONCATENATE `Invalid Value ` `[` lt_excel_col-field `]`
                     INTO ls_s5010-message.
              APPEND ls_s5010 TO gt_s5010.
            ENDIF.

          WHEN 'X' OR 'x'.
            <lo_field> = lt_excel_col-field.

          WHEN OTHERS.
            IF lt_excel_col-field IS INITIAL.
              CLEAR: <lo_field>.

            ELSE.

              PERFORM loc_convert_data_in_excel  USING    ls_stab lv_tabix
                                                          lt_excel_col-field
                                                 CHANGING <lo_field>.
              IF <lo_field> IS INITIAL.
              ENDIF.
            ENDIF.
        ENDCASE.

      ENDLOOP.

      APPEND <ls_work> TO <gt_s0100>.

    ENDLOOP.

    IF cb_out = 'X'. " 결과출력 안하면 단위로 update 함
      MODIFY (p_tab) FROM TABLE <gt_s0100>.
      IF sy-subrc = 0.
        lv_dbcnt = lv_dbcnt + sy-dbcnt.
        COMMIT WORK AND WAIT.
      ENDIF.
    ENDIF.
  ENDLOOP.

  IF gt_s5010[] IS NOT INITIAL.
    SORT gt_s5010 BY column line.
    CALL SCREEN '5010'
         STARTING AT  5 5
         ENDING AT  100 15.
  ELSE.
    IF cb_out = space. " 결과출력인경우
      lv_dbcnt = lines( <gt_s0100> ).
    ENDIF.
    WRITE lv_dbcnt TO lv_dbcnt_c LEFT-JUSTIFIED.
    CONCATENATE lv_dbcnt_c ' 건이 Upload 되었습니다' INTO lv_msg.
    MESSAGE s000 WITH lv_msg.
  ENDIF.


ENDFORM.                    " UPLOAD_FILE
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_XLS_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_FILE  text
*----------------------------------------------------------------------*
FORM upload_xls_file         TABLES   pt_excel_tab TYPE kcde_sender
                             USING    pv_file
                                      pv_begin_col
                                      pv_begin_row.
*                                      pv_end_col
*                                      pv_end_row  .


  FIELD-SYMBOLS: <lv_field>.

  DATA: lo_application TYPE ole2_object,
        lo_workbook    TYPE ole2_object,
        lo_range       TYPE ole2_object,
        lo_activesheet TYPE ole2_object.
  DATA: lo_start_cell TYPE ole2_object.
  DATA: lo_end_cell   TYPE ole2_object.
  DATA: lo_end       TYPE ole2_object.

*-----------------------------------------------------------------------
*  IF iv_begin_row > iv_end_row. RAISE inconsistent_parameters. ENDIF.
*  IF iv_begin_col > iv_end_col. RAISE inconsistent_parameters. ENDIF.

  IF lo_application-header = space OR lo_application-handle = -1.
    CREATE OBJECT lo_application 'EXCEL.APPLICATION'.
    %loc_xls_msg.
  ENDIF.

  SET PROPERTY OF lo_application 'Visible' = 0.

  CALL METHOD OF
    lo_application
      'WORKBOOKS' = lo_workbook.
  %loc_xls_msg.

  CALL METHOD OF
    lo_workbook
    'OPEN'
    EXPORTING
      #1 = pv_file.
  %loc_xls_msg.

  GET PROPERTY OF  lo_application 'ACTIVESHEET' = lo_activesheet.
  %loc_xls_msg.

  " start cell
  CALL METHOD OF
    lo_application
    'CELLS' = lo_start_cell
    EXPORTING
    #1 = pv_begin_row
    #2 = pv_begin_col.
*  CALL METHOD OF
*      lo_activesheet
*      'CELLS'        = lo_start_cell
*    EXPORTING
*      #1             = pv_begin_row
*      #2             = pv_begin_col.
  %loc_xls_msg.

  GET PROPERTY OF lo_application 'ActiveCell' = lo_end_cell.

  CALL METHOD OF
    lo_end_cell
    'SpecialCells' = lo_end
    EXPORTING
    #1 = '11'."'xlLastCell'.


*  CALL METHOD OF
*      lo_worksheet
*      'CELLS'      = lo_h_cell1
*    EXPORTING
*      #1           = pv_end_row
*      #2           = pv_end_col.
*  %loc_xls_msg.

  CALL METHOD OF
    lo_application
    'RANGE' = lo_range
    EXPORTING
    #1 = lo_start_cell
    #2 = lo_end.
*  CALL METHOD OF
*      lo_activesheet
*      'RANGE'        = lo_range
*    EXPORTING
*      #1             = lo_start_cell
*      #2             = lo_end.
  %loc_xls_msg.

  CALL METHOD OF
    lo_range
    'SELECT'.
  %loc_xls_msg.

  CALL METHOD OF
    lo_range
    'COPY'.
  %loc_xls_msg.

* Read clipboard into ABAP
  CALL METHOD cl_gui_frontend_services=>clipboard_import
    IMPORTING
      data                 = pt_excel_tab[]
    EXCEPTIONS
      cntl_error           = 1
      error_no_gui         = 2
      not_supported_by_gui = 3
      OTHERS               = 4.

* WITHOUT FLUSH, CLPB_IMPORT DOES NOT FIND THE DATA    "SEVERING 5/99
*  CALL FUNCTION 'CONTROL_FLUSH'                        "SEVERING 5/99
*    EXCEPTIONS
*      OTHERS = 3.                       "SEVERING 5/99
*
*  CALL FUNCTION 'CLPB_IMPORT'
*    TABLES
*      data_tab   = pt_excel_tab
*    EXCEPTIONS
*      clpb_error = 1
*      OTHERS     = 2.

  IF sy-subrc <> 0. MESSAGE x001(kx). ENDIF.
*  ASSIGN Ev_SEPARATOR TO <LV_FIELD> TYPE 'X'.
*  <LV_FIELD> = C_HEX_TAB.

*  ev_separator = cl_abap_char_utilities=>horizontal_tab.

  SET PROPERTY OF lo_application 'CUTCOPYMODE' = 0.
  %loc_xls_msg.

  CALL METHOD OF
    lo_application
    'QUIT'.
  %loc_xls_msg.

  FREE OBJECT lo_activesheet.
  FREE OBJECT lo_application.
  %loc_xls_msg.

ENDFORM.                    " UPLOAD_XLS_FILE
*&---------------------------------------------------------------------*
*&      Form  com_check_file_name
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      <--PV_FILE        text
*      <--PV_ERROR_FLAG  text
*----------------------------------------------------------------------*
FORM com_check_file_name    USING    pv_file
                                     pv_show_msg
                            CHANGING pv_error_flag.

  DATA: lv_result   TYPE abap_bool,
        lv_filename TYPE string.

  pv_error_flag = 'X'.
  lv_filename = pv_file.

  CALL METHOD cl_gui_frontend_services=>file_exist
    EXPORTING
      file                 = lv_filename
    RECEIVING
      result               = lv_result
    EXCEPTIONS
      cntl_error           = 1
      error_no_gui         = 2
      wrong_parameter      = 3
      not_supported_by_gui = 4
      OTHERS               = 5.
  IF sy-subrc <> 0 OR lv_result = space.
    IF pv_show_msg = 'X'.
      MESSAGE i000(oo) WITH '선택한 파일이 존재하지 않습니다.('
                        lv_filename ')'.
    ENDIF.
    EXIT.
  ENDIF.

  pv_error_flag = space.

ENDFORM.                    " COM_GET_FILE_NAME
*&---------------------------------------------------------------------*
*&      Form  CONVERSION_DATE_INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EXCEL_COL_FIELD  text
*      <--P_LT_EXCEL_COL_FIELD  text
*----------------------------------------------------------------------*
FORM conversion_date_input  USING    pv_input
                            CHANGING pv_output.

  DATA: lv_spl,
        lv_datum_input(50) TYPE c,
        lv_datum_output    LIKE sy-datum.

  IF pv_input = space.
    pv_output = pv_input.
    EXIT.
  ENDIF.

  lv_datum_input = pv_input.

  CLEAR: lv_spl.
  FIND '.'  IN lv_datum_input.
  IF sy-subrc = 0.
    lv_spl = '.'.
  ENDIF.

  FIND ',' IN lv_datum_input.
  IF sy-subrc = 0.
    lv_spl = ','.
  ENDIF.

  FIND '-' IN lv_datum_input.
  IF sy-subrc = 0.
    lv_spl = '-'.
  ENDIF.

  FIND '/' IN lv_datum_input.
  IF sy-subrc = 0.
    lv_spl = '/'.
  ENDIF.


  DATA: lv_len       TYPE i,
        lv_data1(10),
        lv_data2(10),
        lv_data3(10).
  SPLIT lv_datum_input AT lv_spl INTO lv_data1 lv_data2 lv_data3.

  IF lv_data1 BETWEEN '2000' AND '2099'.
    lv_len = strlen( lv_data2 ).   " 월
    IF lv_len = 1.
      CONCATENATE '0' lv_data2 INTO lv_data2.
    ENDIF.

    lv_len = strlen( lv_data3 ).  " 일
    IF lv_len = 1.
      CONCATENATE '0' lv_data3 INTO lv_data3.
    ENDIF.

    CONCATENATE lv_data1 lv_data2 lv_data3 INTO pv_output.
    EXIT.
  ENDIF.

  IF lv_data3 BETWEEN '2000' AND '2099'.
    lv_len = strlen( lv_data1 ).   " 월
    IF lv_len = 1.
      CONCATENATE '0' lv_data1 INTO lv_data1.
    ENDIF.

    lv_len = strlen( lv_data2 ).  " 일
    IF lv_len = 1.
      CONCATENATE '0' lv_data2 INTO lv_data2.
    ENDIF.

    IF lv_data1 BETWEEN '13' AND '31'.
      CONCATENATE lv_data3 lv_data2 lv_data1 INTO pv_output.
    ELSE.
      CONCATENATE lv_data3 lv_data1 lv_data2 INTO pv_output.
    ENDIF.

    EXIT.
  ENDIF.

*  REPLACE ALL OCCURRENCES OF '.' IN lv_datum_input WITH ''.
*  REPLACE ALL OCCURRENCES OF ',' IN lv_datum_input WITH ''.
*  REPLACE ALL OCCURRENCES OF '-' IN lv_datum_input WITH ''.
*  REPLACE ALL OCCURRENCES OF '/' IN lv_datum_input WITH ''.
*
*
*  CALL FUNCTION 'CONVERT_DATE_INPUT'
*    EXPORTING
*      input                     = lv_datum_input
*      plausibility_check        = 'X'
*    IMPORTING
*      output                    = lv_datum_output
*    EXCEPTIONS
**     PLAUSIBILITY_CHECK_FAILED = 02
*      wrong_format_in_input     = 01.
*
*  IF sy-subrc <> 0.
*    pv_output = space.
*    MESSAGE s885(fk) DISPLAY LIKE 'E'.
*  ELSE.

*  pv_output = lv_datum_output.

*ENDIF.

ENDFORM.                    " CONVERSION_DATE_INPUT
*&---------------------------------------------------------------------*
*&      Form  CONVERSION_TIME_INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EXCEL_COL_FIELD  text
*      <--P_LT_EXCEL_COL_FIELD  text
*----------------------------------------------------------------------*
FORM conversion_time_input   USING    pv_input
                             CHANGING pv_output.

  DATA: lv_len            TYPE i,
        lv_time_input(50) TYPE c,
        lv_time_output    LIKE sy-uzeit.

  IF pv_input = space.
    pv_output = pv_input.
    EXIT.
  ENDIF.

  lv_time_input = pv_input.

  REPLACE ALL OCCURRENCES OF ':'     IN lv_time_input WITH ''.
  REPLACE ALL OCCURRENCES OF '.'     IN lv_time_input WITH ''.
  REPLACE ALL OCCURRENCES OF '/'     IN lv_time_input WITH ''.
  REPLACE ALL OCCURRENCES OF ','     IN lv_time_input WITH ''.
  REPLACE ALL OCCURRENCES OF '-'     IN lv_time_input WITH ''.

  DATA: lv_time1 TYPE char20,
        lv_time2 TYPE char20,
        lv_time3 TYPE char20,  " 구분자
        lv_time4 TYPE char20,  " 시간
        lv_timen TYPE numc06.

  SPLIT lv_time_input AT space INTO lv_time1 lv_time2.
  TRANSLATE lv_time1 TO UPPER CASE.
  TRANSLATE lv_time2 TO UPPER CASE.
  CASE lv_time1.
      " ex: HH:MM:SS AM
    WHEN '오전' OR '오후' OR 'AM' OR 'PM'.
      lv_time3 = lv_time1.
      lv_time4 = lv_time2.

    WHEN OTHERS.
      CASE lv_time2.
          " ex: AM HH:MM:SS
        WHEN '오전' OR '오후' OR 'AM' OR 'PM'.
          lv_time3 = lv_time2.
          lv_time4 = lv_time1.

        WHEN OTHERS.
          " ex: HH:MM:SS
          lv_time4 = lv_time1.
      ENDCASE.
  ENDCASE.

  lv_len = strlen( lv_time4 ).
  IF lv_len = 5.
    lv_timen+1 = lv_time4.
  ELSE.
    lv_timen   = lv_time4.
  ENDIF.

  IF lv_time3 = '오후' OR lv_time3 = 'PM'.
    lv_timen+0(2) = lv_timen+0(2) + 12.
    IF lv_timen+0(2) = '24'.
      lv_timen+0(2) = '00'.
    ENDIF.
  ENDIF.

  lv_time_input = lv_timen.






*  REPLACE ALL OCCURRENCES OF '오전'  IN lv_time_input WITH ''.
*  REPLACE ALL OCCURRENCES OF '오후'  IN lv_time_input WITH ''.
*
*  CONDENSE lv_time_input NO-GAPS.
*  lv_len = strlen( lv_time_input ).
*  IF lv_len = 5.
*    lv_time_input = '0' && lv_time_input.
*  ENDIF.
*  FIND pv_input IN '오후'.
*  IF sy-subrc = 0.
*    lv_time_input+0(2) = lv_time_input+0(2) + 12.
*  ENDIF.

  CALL FUNCTION 'CONVERT_TIME_INPUT'
    EXPORTING
      input                 = lv_time_input
      plausibility_check    = 'X'
    IMPORTING
      output                = lv_time_output
    EXCEPTIONS
*     PLAUSIBILITY_CHECK_FAILED = 02
      wrong_format_in_input = 01.

  IF sy-subrc <> 0.
    pv_output = space.
    MESSAGE s885(fk).
  ELSE.

    pv_output = lv_time_output.

  ENDIF.
ENDFORM.                    " CONVERSION_TIME_INPUT
*&---------------------------------------------------------------------*
*&      Form  CONVERSION_CURR_INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EXCEL_COL_FIELD  text
*      <--P_LT_EXCEL_COL_FIELD  text
*----------------------------------------------------------------------*
FORM conversion_curr_input   USING    pv_input
                             CHANGING pv_output
                                      pv_error_flag.

  DATA: lv_curr_input      TYPE string,
        lv_curr_output(30).

  IF pv_input IS INITIAL OR pv_input = space.
    pv_output = pv_input.
    EXIT.
  ENDIF.

  lv_curr_input = pv_input.
  pv_error_flag = 'X'.

  REPLACE ALL OCCURRENCES OF ','     IN lv_curr_input WITH ''.
  CONDENSE lv_curr_input NO-GAPS.

*  CALL FUNCTION 'CATS_NUMERIC_INPUT_CHECK'
*    EXPORTING
*      input      = lv_curr_input
*    EXCEPTIONS
*      no_numeric = 1
*      OTHERS     = 2.
*  IF sy-subrc NE 0.
  IF NOT lv_curr_input CO '0123456789-. '.
*    RAISE not_numeric.
    CLEAR lv_curr_input.
  ENDIF.

  WRITE lv_curr_input TO lv_curr_output  LEFT-JUSTIFIED.
  CONDENSE lv_curr_output NO-GAPS.

  IF lv_curr_output = '-'.
    lv_curr_output = '0'.
  ENDIF.

  pv_output     = lv_curr_output.
  pv_error_flag = space.

ENDFORM.                    " CONVERSION_CURR_INPUT
*&---------------------------------------------------------------------*
*&      Form  LOC_CONVERT_DATA_IN_EXCEL
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LV_TABIX  text
*      -->P_LT_EXCEL_COL_FIELD  text
*      <--P_<LO_FIELD>  text
*----------------------------------------------------------------------*
FORM loc_convert_data_in_excel  USING    ps_stab  TYPE dfies
                                         pv_tabix
                                         pv_input
                                CHANGING pv_output.

  CONSTANTS: lc_type_xc2a0(2) TYPE x VALUE 'C2A0',
             lc_type_x00a0(2) TYPE x VALUE '00A0',
             lc_type_x0000(2) TYPE x VALUE '0000'.          "#EC NOTEXT


  DATA: lv_field_value TYPE txt1024,
        lv_char_value  TYPE string,
        lv_char_valuex TYPE xstring,
        lo_convin      TYPE REF TO cl_abap_conv_in_ce.

  DATA: lv_len TYPE i,
        lv_pos TYPE i.

  CLEAR: pv_output.

  WRITE pv_input TO pv_output  LEFT-JUSTIFIED.

  CHECK pv_input IS NOT INITIAL.

  lv_field_value = pv_input.

  " 처음 문자가 '"' 인 경우 마지막 문자도 '"' 인지 확인 한다
  " 동일한 경우 두 문자를 제거한다
  IF lv_field_value+0(1) = `"`.
    lv_pos = strlen( lv_field_value ) - 1.
    IF lv_field_value+lv_pos(1) = `"`.
      lv_field_value+lv_pos(1) = ``.
      lv_field_value+0(1) = ``.
    ENDIF.

    " "" 인 정보가 있는 경우 " 으로 변경
    REPLACE ALL OCCURRENCES OF `""` IN lv_field_value WITH `"`.
  ENDIF.


  " 공백제거
  SHIFT lv_field_value LEFT  DELETING LEADING  ` `.

  lv_char_value = lv_field_value.

  CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
    EXPORTING
      text     = lv_char_value
      encoding = gv_codepage
    IMPORTING
      buffer   = lv_char_valuex.

  SHIFT lv_char_valuex RIGHT DELETING TRAILING lc_type_xc2a0 IN BYTE MODE.
  SHIFT lv_char_valuex RIGHT DELETING TRAILING lc_type_x00a0 IN BYTE MODE.
  SHIFT lv_char_valuex LEFT  DELETING LEADING  lc_type_x0000 IN BYTE MODE.

  " xstring to string
  CALL METHOD cl_abap_conv_in_ce=>create
    EXPORTING
      encoding = gv_codepage
      input    = lv_char_valuex
    RECEIVING
      conv     = lo_convin.

  CALL METHOD lo_convin->read
    IMPORTING
      data = lv_char_value.

  lv_field_value = lv_char_value.

  " 개행문자가 있는지 확인
  FIND cl_abap_char_utilities=>newline IN lv_field_value.
  IF sy-subrc = 0.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline
            IN lv_field_value WITH ' '.
*    REPLACE ALL OCCURRENCES OF `"` IN lv_field_value WITH ''.
  ENDIF.

  DESCRIBE FIELD pv_output LENGTH lv_len IN CHARACTER MODE.
  IF lv_len = 1.
    CASE lv_field_value.
      WHEN 'false'.
        pv_output = space.
      WHEN 'ture'.
        pv_output = 'X'.
      WHEN OTHERS.
        pv_output = lv_field_value.
    ENDCASE.

  ELSE.
    pv_output = lv_field_value.
  ENDIF.

  IF ps_stab-convexit IS NOT INITIAL.
    PERFORM conversion_exit USING    ps_stab-convexit
                            CHANGING pv_output.
  ENDIF.

  CASE p_tab.
    WHEN OTHERS.
  ENDCASE.

ENDFORM.                    " LOC_CONVERT_DATA_IN_EXCEL
*&---------------------------------------------------------------------*
*&      Form  XLS_DOWNLOAD_TEMPLATE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_TAB  text
*      -->P_0444   text
*      -->P_SPACE  text
*----------------------------------------------------------------------*
FORM xls_download_template  USING    pv_tab.

  DATA: lv_do_cnt TYPE i,
        ls_stab   TYPE dfies,
        lt_stab   TYPE TABLE OF dfies.

  " Table 의 layout 정보를 가지고 온다.
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname        = pv_tab
    TABLES
      dfies_tab      = lt_stab
    EXCEPTIONS
      not_found      = 1
      internal_error = 2
      OTHERS         = 3.
  IF sy-subrc NE 0.
    MESSAGE i000 WITH 'Table Layout Loading Error!'.
    EXIT.
  ENDIF.

*  DELETE lt_stab WHERE rollname = 'CLNT'.
*  DELETE lt_stab WHERE fieldname = 'MANDT' OR fieldname = 'CLIENT'.

  IF lt_stab[] IS INITIAL.
    MESSAGE i000 WITH 'Table Layout Loading Error!'.
    EXIT.
  ENDIF.

  lv_do_cnt = lines( lt_stab ).
  SORT lt_stab BY position.

  " Excel Download format 으로 전송한다.

  CREATE OBJECT go_application 'EXCEL.APPLICATION'.
  CALL METHOD OF
    go_application
      'WORKBOOKS' = go_workbooks.
  CALL METHOD OF
    go_workbooks
      'ADD' = go_workbook.
  GET PROPERTY OF go_application 'ACTIVESHEET' = go_worksheet.

  SET PROPERTY OF go_application 'VISIBLE' = 0.

  DO lv_do_cnt TIMES.

    READ TABLE lt_stab INTO ls_stab INDEX sy-index.
    CHECK sy-subrc = 0.

    PERFORM set_value_cell USING 1 sy-index ls_stab-fieldtext 'X'. " Field Text
    PERFORM set_value_cell USING 2 sy-index ls_stab-fieldname 'X'. " Field name

  ENDDO.

  " box
  PERFORM fill_template_box_1000 USING 3 lv_do_cnt.

  " autofit
*  CALL METHOD OF GO_APPLICATION 'COLUMNS' = GO_CELL_AUTOFIT.
*  CALL METHOD OF GO_CELL_AUTOFIT 'AUTOFIT'.

  SET PROPERTY OF go_application 'VISIBLE' = 1.

*  CALL METHOD OF go_application 'QUIT'.
  FREE OBJECT go_cell.
  FREE OBJECT go_worksheet.
  FREE OBJECT go_workbooks.
  FREE OBJECT go_application.

ENDFORM.                    " XLS_DOWNLOAD_TEMPLATE
*&---------------------------------------------------------------------*
*&      Form  CONVERSION_EXIT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_STAB_CONVEXIT  text
*      <--P_<LO_FIELD>  text
*----------------------------------------------------------------------*
FORM conversion_exit         USING    pv_convexit
                             CHANGING pv_value.

  DATA: lv_func      TYPE rs38l_fnam,
        ls_ptab      TYPE abap_func_parmbind,
        lt_ptab      TYPE abap_func_parmbind_tab,
        ls_etab      TYPE abap_func_excpbind,
        lt_etab      TYPE abap_func_excpbind_tab,
        ls_fupararef TYPE fupararef,
        lt_fupararef TYPE TABLE OF fupararef.

  lv_func = 'CONVERSION_EXIT_&_INPUT'.
  REPLACE ALL OCCURRENCES OF '&' IN lv_func WITH pv_convexit.

  " parameters table 을 check 한다.
  SELECT *
    FROM fupararef
    INTO TABLE lt_fupararef
   WHERE funcname = lv_func
     AND r3state  = 'A'
  ORDER BY paramtype pposition.
  CHECK sy-subrc = 0.

  CLEAR: lt_ptab, lt_etab.
  LOOP AT lt_fupararef INTO ls_fupararef WHERE defaultval = space.

    CASE ls_fupararef-paramtype.
      WHEN 'I'.
        ls_ptab-name = ls_fupararef-parameter.
        ls_ptab-kind = abap_func_exporting.
        GET REFERENCE OF pv_value INTO ls_ptab-value.
        INSERT ls_ptab INTO TABLE lt_ptab.

      WHEN 'E'.
        ls_ptab-name = ls_fupararef-parameter.
        ls_ptab-kind = abap_func_importing.
        GET REFERENCE OF pv_value INTO ls_ptab-value.
        INSERT ls_ptab INTO TABLE lt_ptab.

      WHEN 'X'.
        ls_etab-name  = ls_fupararef-parameter.
        ls_etab-value = sy-tabix.
        INSERT ls_etab INTO TABLE lt_etab.

      WHEN OTHERS.
    ENDCASE.

  ENDLOOP.
  CHECK lt_ptab[] IS NOT INITIAL.

  CALL FUNCTION lv_func
    PARAMETER-TABLE
    lt_ptab
    EXCEPTION-TABLE
    lt_etab.

*  SELECT COUNT( * )
*    FROM tfdir
*    INTO sy-dbcnt
*   WHERE funcname = lv_func.
*  IF sy-subrc = 0 AND sy-dbcnt > 0.
*
*    " 예외 Case 로 처리.
*    CASE pv_convexit.
*      WHEN OTHERS.
*        CALL FUNCTION lv_func
*          EXPORTING
*            input  = pv_value
*          IMPORTING
*            output = pv_value.
*
*    ENDCASE.
*  ENDIF.

ENDFORM.                    " CONVERSION_EXIT
*&---------------------------------------------------------------------*
*&      Form  GET_DATA_MAIN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM get_data_main .

  DATA: lv_lines TYPE i.

  CASE 'X'.
    WHEN rb201.      PERFORM upload_file.
    WHEN rb205.      PERFORM download_file.

    WHEN rb202.
      PERFORM get_data_client.
      IF gv_error_flag = space.
        lv_lines = lines( <gt_s0100> ).
        MESSAGE s000(oo) WITH lv_lines ' 건 검색되었습니다'.
      ENDIF.

    WHEN rb203.
      PERFORM get_data.
      IF gv_error_flag = space.
        lv_lines = lines( <gt_s0100> ).
        MESSAGE s000(oo) WITH lv_lines ' 건 검색되었습니다'.
      ENDIF.

    WHEN rb204.
      PERFORM empty_data.
      IF gv_error_flag = space.
        lv_lines = lines( <gt_s0100> ).
        MESSAGE s000(oo) WITH lv_lines ' 건 검색되었습니다'.
      ENDIF.

  ENDCASE.

ENDFORM.                    " GET_DATA_MAIN
*&---------------------------------------------------------------------*
*&      Form  LUC_REFRESH_DATA_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM luc_refresh_data_0100 .

  PERFORM get_data_main.

ENDFORM.                    " LUC_REFRESH_DATA_0100
*&---------------------------------------------------------------------*
*&      Form  GET_FIELD_TEXT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_FIELD_TEXTS  text
*      -->P_P_TAB  text
*----------------------------------------------------------------------*
FORM get_field_text  TABLES   pt_field       STRUCTURE rsdsfields
                              pt_field_texts STRUCTURE rsdstexts
                     USING    pv_tab.

  DATA: ls_stab TYPE dfies,
        lt_stab TYPE TABLE OF dfies.

  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname        = pv_tab
    TABLES
      dfies_tab      = lt_stab
    EXCEPTIONS
      not_found      = 1
      internal_error = 2
      OTHERS         = 3.
  IF sy-subrc NE 0.
    SELECT tabname
           fieldname
*           fldstat    as DD03L-AS4LOCAL
           rollname
*           rollstat   as dd04l-AS4LOCAL
           domname
*           domstat     as dd01l-AS4LOCAL
*           textstat
*           ddlanguage
           position
           keyflag
*           mandatory
           checktable
*           adminfield
           inttype
           intlen
           reftable
           precfield
           reffield
*           conrout
*           routputlen
           memoryid
           logflag
           headlen
           scrlen1
           scrlen2
           scrlen3
*           dtelglobal
*           dtelmaster
*           reservedte
           datatype
           leng
           outputlen
           decimals
           lowercase
*           signflag
*           langflag
           valexi
*           entitytab
           convexit
           mask
           masklen
*           actflag
*           dommaster
*           reservedom
*           domglobal
           ddtext AS fieldtext
           reptext
           scrtext_s
           scrtext_m
           scrtext_l
      FROM dd03m
      INTO CORRESPONDING FIELDS OF TABLE lt_stab
     WHERE tabname    = pv_tab
    AND ddlanguage = sy-langu.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.
  ENDIF.

  DELETE lt_stab WHERE datatype = 'CLNT'.
  DELETE lt_stab WHERE datatype = 'STRG'.  " string.

*  pt_field[]       = CORRESPONDING #( lt_stab MAPPING tablename = tabname ).
*  pt_field_texts[] = CORRESPONDING #( lt_stab MAPPING tablename = tabname
*                                                      text      = fieldname  ).

  CLEAR: pt_field[],pt_field_texts[].
  LOOP AT lt_stab INTO ls_stab.

    MOVE-CORRESPONDING: ls_stab  TO pt_field,
                        ls_stab  TO pt_field_texts.
    MOVE: ls_stab-tabname        TO pt_field-tablename,
          ls_stab-tabname        TO pt_field_texts-tablename.

    CASE 'X'.
      WHEN rb301.
        CONCATENATE ls_stab-fieldtext '(' ls_stab-fieldname ')' INTO pt_field_texts-text.
      WHEN rb302.
        CONCATENATE ls_stab-fieldname '(' ls_stab-fieldtext ')' INTO pt_field_texts-text.
    ENDCASE.

    APPEND: pt_field, pt_field_texts.

  ENDLOOP.

ENDFORM.                    "get_field_text
*&---------------------------------------------------------------------*
*& Form SET_VALUE_CELL
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*      -->P_LV_ROW  text
*      -->P_LV_COL  text
*      -->P_LV_VALUE  text
*&---------------------------------------------------------------------*
FORM set_value_cell  USING    pv_row
                              pv_col
                              pv_value
                              pv_color.

  CALL METHOD OF
      go_worksheet
      'CELLS'      = go_cell
    EXPORTING
      #1           = pv_row  " ROW
      #2           = pv_col.  "COLUMN
  SET PROPERTY OF go_cell 'VALUE' = pv_value.

  IF pv_color = 'X'.
    GET PROPERTY OF go_cell 'Interior' = go_cell_interior.
    SET PROPERTY OF go_cell_interior 'ColorIndex' = 6.
  ENDIF.

ENDFORM.                    "set_value_cell
*&---------------------------------------------------------------------*
*& Form LUC_FIELDCATALOG_EDIT_0100
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM luc_fieldcatalog_edit_0100 .

  DATA: ls_fieldcat TYPE lvc_s_fcat,
        ls_s0200    TYPE tys_s0200.

  CLEAR: gt_s0200[].
  LOOP AT gt_fieldcat_0100 INTO ls_fieldcat.

    CLEAR: ls_s0200.
    MOVE-CORRESPONDING ls_fieldcat TO ls_s0200.
    APPEND ls_s0200                TO gt_s0200.

  ENDLOOP.
*  gt_s0200 = corresponding tyt_s0200( gt_fieldcat_0100 ).

  CALL SCREEN '0200'.

ENDFORM.                    "luc_fieldcatalog_edit_0100
*&---------------------------------------------------------------------*
*& Form LUC_SAVE_DATA_0200
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM luc_save_data_0200 .

  gv_title   = '자료 저장 확인'.
  gv_text100 = 'Main 화면의 Field Catalog를 변경 하시겠습니까?'.

  CALL FUNCTION 'POPUP_TO_CONFIRM'
    EXPORTING
      titlebar              = gv_title
      text_question         = gv_text100
      display_cancel_button = space
    IMPORTING
      answer                = gv_answer
    EXCEPTIONS
      text_not_found        = 1
      OTHERS                = 2.
  IF gv_answer = 'N' OR gv_answer = '2'. " 아니오.
    MESSAGE i000(oo) WITH '작업이 취소되었습니다.'.
    EXIT.
  ENDIF.

  DATA: ls_fieldcat TYPE lvc_s_fcat,
        ls_s0200    TYPE tys_s0200.

  CLEAR: gt_fieldcat_0100[].
  LOOP AT gt_s0200 INTO ls_s0200.

    CLEAR: ls_fieldcat.
    MOVE-CORRESPONDING ls_s0200 TO ls_fieldcat.
    APPEND ls_fieldcat          TO gt_fieldcat_0100.

  ENDLOOP.

*  gt_fieldcat_0100 = corresponding #( gt_s0200 ).

  CALL METHOD go_grid_0100->set_frontend_fieldcatalog
    EXPORTING
      it_fieldcatalog = gt_fieldcat_0100.

  MESSAGE s000(oo) WITH '반영되었습니다'.

ENDFORM.                    "luc_save_data_0200
*&---------------------------------------------------------------------*
*&      Form  GET_TABNAME_1000
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_TAB  text
*      <--P_P_TABNM  text
*----------------------------------------------------------------------*
FORM get_tabname_1000          USING    pv_tab
                               CHANGING pv_tabnm.

  CLEAR: pv_tabnm.
  CHECK pv_tab <> space.

  SELECT SINGLE ddtext
    FROM dd02t
    INTO pv_tabnm
   WHERE tabname    = pv_tab
  AND ddlanguage = sy-langu.
  IF sy-subrc NE 0 AND sy-langu <> '3'.
    SELECT SINGLE ddtext
      FROM dd02t
      INTO pv_tabnm
     WHERE tabname    = pv_tab
    AND ddlanguage = '3'.
  ENDIF.

ENDFORM.                    " GET_TABNAME_1000
*&---------------------------------------------------------------------*
*&      Form  FILL_TEMPLATE_BOX_1000
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_3      text
*----------------------------------------------------------------------*
FORM fill_template_box_1000  USING    pv_rowend pv_colend.

  CALL METHOD OF
      go_application
      'Cells'        = go_cellend
    EXPORTING
      #1             = pv_rowend   " row
      #2             = pv_colend. " col

  CALL METHOD OF
    go_application
    'Range' = go_selection
    EXPORTING
    #1 = 'A1'
    #2 = go_cellend.

  PERFORM fill_template_borders_1000 USING '1'.  " Left
  PERFORM fill_template_borders_1000 USING '2'.  " right
  PERFORM fill_template_borders_1000 USING '3'.  " top
  PERFORM fill_template_borders_1000 USING '4'.  " bottom

ENDFORM.                    " FILL_TEMPLATE_BOX_1000
*&---------------------------------------------------------------------*
*&      Form  FILL_TEMPLATE_BORDERS_1000
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_4412   text
*----------------------------------------------------------------------*
FORM fill_template_borders_1000  USING    pv_location.

  " LineStyle : xlContinuous = 1
  " Weight : xlHairline = 1, xlMedium = 2, xlThick = 3, xlThin = 4

  CALL METHOD OF
    go_selection
    'BORDERS' = go_borders
    EXPORTING
    #1 = pv_location.
  SET PROPERTY OF go_borders 'LineStyle' = '1'.             " 선종류  1:실선
  SET PROPERTY OF go_borders 'Weight' = '2'.  " 2:일반 3: 약간굵음 4:굵음


ENDFORM.                    " FILL_TEMPLATE_BORDERS_1000
*&---------------------------------------------------------------------*
*&      FORM  COM_ALV_COL_POS
*&---------------------------------------------------------------------*
FORM com_alv_col_pos         TABLES pt_fieldcat TYPE lvc_t_fcat
                             USING  pv_fieldname
                                    pv_key
                                    pv_len
                                    pv_text
                                    pv_hotspot
                                    pv_editor
                                    pv_graph. " I(ICON),C(CHECKBOX)

  DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

  READ TABLE pt_fieldcat INTO ls_fieldcat WITH KEY fieldname = pv_fieldname.
  CHECK sy-subrc = 0.
  gv_col_pos             = gv_col_pos + 1.
  ls_fieldcat-col_pos    = gv_col_pos.

  IF pv_len = '-' OR pv_len = space.    " IF CHANGE FIELD LENGTH.
    ls_fieldcat-col_opt     = 'X'.
  ELSE.
    ls_fieldcat-outputlen   = pv_len.
*    ls_fieldcat-col_opt     = space.
  ENDIF.

  CASE pv_text .
    WHEN space.

*    WHEN `'`.
*      ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
*      ls_fieldcat-scrtext_m =
*      ls_fieldcat-scrtext_s = ls_fieldcat-coltext = space.

    WHEN OTHERS.
      ls_fieldcat-reptext   = ls_fieldcat-scrtext_l =
      ls_fieldcat-scrtext_m =
      ls_fieldcat-scrtext_s = ls_fieldcat-coltext = pv_text.
  ENDCASE.

  ls_fieldcat-key         = pv_key.
  ls_fieldcat-fix_column  = pv_key.  " FIXED COLUMN.

  IF ls_fieldcat-inttype = 'D' OR " JUST CENTER DATE/TIME TYPE.
     ls_fieldcat-inttype = 'T'.
    ls_fieldcat-just     = 'C'.
  ENDIF.

  CASE pv_graph.
    WHEN 'I'.  " icon
      ls_fieldcat-icon    = 'X'.
      ls_fieldcat-just    = 'C'.

    WHEN 'C'.  " checkbox
      ls_fieldcat-checkbox  = 'X'.
      ls_fieldcat-just      = 'C'.
  ENDCASE.

  ls_fieldcat-hotspot    = pv_hotspot.
  ls_fieldcat-edit       = pv_editor.

  MODIFY pt_fieldcat FROM ls_fieldcat
            TRANSPORTING col_pos outputlen key coltext scrtext_l scrtext_m
                         reptext scrtext_s fix_column just col_opt
                         icon checkbox
                         hotspot
                         edit
            WHERE fieldname = pv_fieldname.


ENDFORM.                    "COM_ALV_COL_POS
*&---------------------------------------------------------------------*
*&      Form  COM_ALV_COL_DELETE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_GT_FIELDCAT_5010  text
*----------------------------------------------------------------------*
FORM com_alv_col_delete  TABLES   pt_fieldcat TYPE lvc_t_fcat.

  DATA: ls_fieldcat    TYPE        lvc_s_fcat.      " FIELD CATALOG

  CLEAR: ls_fieldcat.
  MODIFY pt_fieldcat FROM ls_fieldcat
             TRANSPORTING domname f4availabl checktable ref_field
                          ref_table
             WHERE fieldname <> space
               AND edit      =  space
               AND ( f4availabl <> 'Y' AND
                     f4availabl <> 'A' ).

  ls_fieldcat-f4availabl = 'X'.
  MODIFY pt_fieldcat FROM ls_fieldcat
             TRANSPORTING f4availabl
             WHERE f4availabl = 'A'.

  "  화면에는 보이지 않고 Layout 에서는 사용불가함..
  ls_fieldcat-tech = 'X'.
  MODIFY pt_fieldcat FROM ls_fieldcat TRANSPORTING tech
        WHERE col_pos = 999
          AND no_out  = space.

ENDFORM.                    " COM_ALV_COL_DELETE
*&---------------------------------------------------------------------*
*&      Form  COM_CHECK_FILE_EXTENSION
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_P_FILE  text
*      <--P_LV_EXTENSION  text
*----------------------------------------------------------------------*
FORM com_check_file_extension  USING    pv_file
                               CHANGING pv_file_out
                                        pv_extension.

  DATA: lv_path(1024),
        lv_directory     LIKE draw-filep,
        lv_filename      LIKE draw-filep,
        lv_filenames     TYPE string,
        lv_extension(05).

* File 명과 Directiroy 분리
  lv_path = pv_file.
  CALL FUNCTION 'CV120_SPLIT_PATH'
    EXPORTING
      pf_path  = lv_path
    IMPORTING
      pfx_path = lv_directory
      pfx_file = lv_filename.

  pv_file_out = lv_filename.

*  확장자.
  CALL FUNCTION 'CV120_SPLIT_FILE'
    EXPORTING
      pf_file       = lv_filename
    IMPORTING
      pfx_extension = lv_extension.

  TRANSLATE lv_extension TO UPPER CASE.

  pv_extension = lv_extension.

  REPLACE ALL OCCURRENCES OF '.' IN pv_extension WITH ''.

ENDFORM.                    " COM_CHECK_FILE_EXTENSION
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_text_FILE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EXECL_TMP  text
*      -->P_P_FILE  text
*----------------------------------------------------------------------*
FORM upload_text_file  TABLES   pt_excel_tab TYPE kcde_sender
                      USING    pv_file.


  DATA: lv_filename	TYPE string,
        lv_filetype	TYPE char10  VALUE 'ASC'.

  lv_filename = pv_file.
  CALL METHOD cl_gui_frontend_services=>gui_upload
    EXPORTING
      filename                = lv_filename
      filetype                = lv_filetype
*     has_field_separator     = SPACE
*     header_length           = 0
*     read_by_line            = 'X'
*     dat_mode                = SPACE
      codepage                = gv_codepage
*     ignore_cerr             = ABAP_TRUE
*     replacement             = '#'
*     virus_scan_profile      =
*    IMPORTING
*     filelength              =
*     header                  =
    CHANGING
      data_tab                = pt_excel_tab[]
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      not_supported_by_gui    = 17
      error_no_gui            = 18
      OTHERS                  = 19.
  IF sy-subrc <> 0.
*   Implement suitable error handling here
  ENDIF.


ENDFORM.                    " UPLOAD_text_FILE
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_XLS_FILE2
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_LT_EXECL_TMP  text
*      -->P_P_FILE  text
*----------------------------------------------------------------------*
FORM upload_xls_file2  TABLES   pt_excel_tab TYPE kcde_sender
                       USING    pv_file.

  DATA: lv_path(1024),
        lv_directory   TYPE draw-filep,
        lv_filename_in TYPE draw-filep.

  DATA: lo_application    TYPE ole2_object,
        lo_workbook       TYPE ole2_object,
        lo_range          TYPE ole2_object,
        lo_activeworkbook TYPE ole2_object,
        lo_activesheet    TYPE ole2_object,
        lo_sheet_new      TYPE ole2_object,
        lo_start_cell     TYPE ole2_object,
        lo_end_cell       TYPE ole2_object,
        lo_end            TYPE ole2_object.

  lv_path = pv_file.
  CALL FUNCTION 'CV120_SPLIT_PATH'
    EXPORTING
      pf_path  = lv_path
    IMPORTING
      pfx_path = lv_directory
      pfx_file = lv_filename_in.

  DATA: lv_sap_workdir TYPE string.

  CALL METHOD cl_gui_frontend_services=>get_sapgui_workdir
    CHANGING
      sapworkdir           = lv_sap_workdir
    EXCEPTIONS
      cntl_error           = 1
      error_no_gui         = 2
      not_supported_by_gui = 3
      OTHERS               = 4.

  DATA: lv_filename TYPE string.
  CONCATENATE lv_sap_workdir '\~' lv_filename_in '_'
              sy-datum '_' sy-uzeit '.txt'
         INTO lv_filename.

  IF lo_application-header = space OR lo_application-handle = -1.
    CREATE OBJECT lo_application 'EXCEL.APPLICATION'.
    %loc_xls_msg.
  ENDIF.

  SET PROPERTY OF lo_application 'DisplayAlerts' = 0.
  SET PROPERTY OF lo_application 'Visible' = 0.

  CALL METHOD OF
    lo_application
      'WORKBOOKS' = lo_workbook.
  %loc_xls_msg.

  CALL METHOD OF
    lo_workbook
    'OPEN'
    EXPORTING
      #1 = pv_file.
  %loc_xls_msg.

  GET PROPERTY OF lo_application 'ActiveWorkbook' = lo_activeworkbook.
  GET PROPERTY OF lo_application 'ACTIVESHEET' = lo_activesheet.
  %loc_xls_msg.

  " start cell
  DATA lv_line_st TYPE i.
  IF cb_hdx = 'X'.  " Header line 없음
    lv_line_st = 1.
  ELSE.
    lv_line_st = 3.
  ENDIF.

  CALL METHOD OF lo_application 'CELLS' = lo_start_cell
    EXPORTING
    #1 = lv_line_st
    #2 = 1.
  %loc_xls_msg.

  GET PROPERTY OF lo_application 'ActiveCell' = lo_end_cell.

  CALL METHOD OF
    lo_end_cell
    'SpecialCells' = lo_end
    EXPORTING
    #1 = '11'."'xlLastCell'.
  %loc_xls_msg.

  CALL METHOD OF
    lo_application
    'RANGE' = lo_range
    EXPORTING
    #1 = lo_start_cell
    #2 = lo_end.
  %loc_xls_msg.

  CALL METHOD OF
    lo_range
    'SELECT'.
  %loc_xls_msg.

  CALL METHOD OF
    lo_range
    'COPY'.
  %loc_xls_msg.


  GET PROPERTY OF lo_activeworkbook 'Sheets' = lo_sheet_new .
  CALL METHOD OF
    lo_sheet_new
      'Add' = lo_sheet_new.

  CALL METHOD OF
    lo_sheet_new
    'Paste'.

  CALL METHOD OF
    lo_activeworkbook
    'SaveAs'
    EXPORTING
      #1 = lv_filename
      #2 = -4158. "42.

  CALL METHOD OF
    lo_activeworkbook
    'CLOSE'
    EXPORTING
      #1 = 0
      #2 = 0
      #3 = 0.
*  %com_xls_msg_o2.

  CALL METHOD OF
    lo_application
    'QUIT'.

  FREE OBJECT lo_sheet_new.
  FREE OBJECT lo_activeworkbook.
  FREE OBJECT lo_application.

  PERFORM upload_text_file TABLES pt_excel_tab
                          USING  lv_filename.

  DATA: lv_filenames TYPE string,
        lv_rc        TYPE i.

  lv_filenames = lv_filename.

  CALL METHOD cl_gui_frontend_services=>file_delete
    EXPORTING
      filename             = lv_filenames
    CHANGING
      rc                   = lv_rc
    EXCEPTIONS
      file_delete_failed   = 1
      cntl_error           = 2
      error_no_gui         = 3
      file_not_found       = 4
      access_denied        = 5
      unknown_error        = 6
      not_supported_by_gui = 7
      wrong_parameter      = 8
      OTHERS               = 9.


ENDFORM.                    " UPLOAD_XLS_FILE2
*&---------------------------------------------------------------------*
*&      Form  LUC_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM luc_mass_change_0100 .

  DATA: ls_fieldcat      TYPE lvc_s_fcat,
        ls_index_column  TYPE lvc_s_col,
        lt_index_columns TYPE lvc_t_col.

  CHECK <gt_s0100> IS ASSIGNED.

  " column 이 선택되었는지 확인 한다.
  CLEAR: lt_index_columns[].
  CALL METHOD go_grid_0100->get_selected_columns
    IMPORTING
      et_index_columns = lt_index_columns.

  " popup value 호출
  CLEAR: gt_popup_fields[].
  LOOP AT lt_index_columns INTO ls_index_column.

    READ TABLE gt_fieldcat_0100 INTO ls_fieldcat WITH KEY fieldname = ls_index_column-fieldname.
    CHECK sy-subrc = 0.

    " search help 가 있는지 여부에 따라서 기능 추가 예정
    %loc_set_popup_field_ex1 p_tab:
         ls_fieldcat-fieldname 'X' ' ' ' ' ls_fieldcat-scrtext_m 'X'.

  ENDLOOP.

  " comment line 추가
  %loc_set_popup_field_ex1 'SVAL':
      'VALUE'      ' ' '03'
      `초기값으로 설정시 '~' 를 입력 하십시오` `Comment` 'X'.

  " Call popup screen..
  CALL FUNCTION 'POPUP_GET_VALUES_USER_HELP'
    EXPORTING
      f4_formname     = 'COM_PC_F4_MASS_CHANGE_0100'
      f4_programname  = gv_repid
      formname        = 'COM_PC_CH_MASS_CHANGE_0100'
      popup_title     = 'Column Mass Change'
      programname     = gv_repid
    IMPORTING
      returncode      = gv_returncode
    TABLES
      fields          = gt_popup_fields
    EXCEPTIONS
      error_in_fields = 1
      OTHERS          = 2.

  IF sy-subrc <> 0 OR gv_returncode = 'A'.
    " The operation has been canceled.
    MESSAGE s000 DISPLAY LIKE 'E' WITH 'The operation has been canceled.'.
    EXIT.
  ENDIF.

  " 입력된 값으로 변경
  gv_title   = '자료 변경 확인'.
  gv_text100 = '선택된 컬럼의 자료를 변경 하시겠습니까?'.

  CALL FUNCTION 'POPUP_TO_CONFIRM'
    EXPORTING
      titlebar              = gv_title
      text_question         = gv_text100
*     text_button_1         = '저장'
*     text_button_2         = '보관'
      display_cancel_button = space
    IMPORTING
      answer                = gv_answer
    EXCEPTIONS
      text_not_found        = 1
      OTHERS                = 2.

  CASE gv_answer.
    WHEN 'J' OR '1'. " 예

    WHEN OTHERS.
      MESSAGE i000(oo) WITH '작업이 취소되었습니다.'.
      EXIT.
  ENDCASE.

  DATA: lv_first_flag,
        lv_index      TYPE sy-tabix,
        lv_fieldname  TYPE scrfname,
        lv_fieldtab   TYPE string,
        lo_work       TYPE REF TO data.
  FIELD-SYMBOLS:
    <ls_work>       TYPE any,
    <lv_fieldvalue> TYPE any.

*      UNASSIGN <ls_work>.
  CREATE DATA lo_work TYPE (p_tab).
  ASSIGN lo_work->* TO <ls_work>.

  CLEAR: lv_fieldtab.
  lv_first_flag = 'X'.

  LOOP AT <gt_s0100> INTO <ls_work>.

    lv_index = sy-tabix.

    LOOP AT gt_popup_fields INTO gs_popup_fields WHERE tabname = p_tab.

      IF lv_first_flag = 'X'.
        CONCATENATE lv_fieldtab ` ` gs_popup_fields-fieldname INTO lv_fieldtab.
      ENDIF.

      UNASSIGN <lv_fieldvalue>.
      CONCATENATE '<LS_WORK>-' gs_popup_fields-fieldname INTO lv_fieldname.
      ASSIGN (lv_fieldname) TO <lv_fieldvalue>.
      CHECK <lv_fieldvalue> IS ASSIGNED.

      IF gs_popup_fields-value = '~'.
        CLEAR <lv_fieldvalue>.
      ELSE.
        <lv_fieldvalue> = gs_popup_fields-value.
      ENDIF.

    ENDLOOP.

    lv_first_flag = space.

    MODIFY <gt_s0100> FROM <ls_work> INDEX lv_index.
*           TRANSPORTING (lv_fieldtab).

  ENDLOOP.

  MESSAGE s000(oo) WITH '작업이 완료 되었습니다.'.

ENDFORM.                    " LUC_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*&      Form  LUC_NO_CONVEXIT_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM luc_no_convexit_0100 .  " No ConvExit

  DATA: lv_exist_flag,
        lv_convexit      TYPE convexit,
        ls_fieldcat      TYPE lvc_s_fcat,
        ls_index_column  TYPE lvc_s_col,
        lt_index_columns TYPE lvc_t_col.

  CHECK <gt_s0100> IS ASSIGNED.

  " column 이 선택되었는지 확인 한다.
  CLEAR: lt_index_columns[].
  CALL METHOD go_grid_0100->get_selected_columns
    IMPORTING
      et_index_columns = lt_index_columns.

  " 변경가능 Field 인지 확인
  lv_exist_flag = abap_true.
  LOOP AT lt_index_columns INTO ls_index_column.
    ls_fieldcat = VALUE #( gt_fieldcat_0100[ fieldname = ls_index_column-fieldname ] OPTIONAL ).
    IF ls_fieldcat-convexit = space.
      lv_exist_flag    = abap_false.
      EXIT.
    ENDIF.
  ENDLOOP.

  " 선택된 컬럼이 1개 이면서 정의된 convexit 이 없는 경우 convexit 입력화면 popup
  CLEAR: lv_convexit.
  IF lines( lt_index_columns ) = 1 AND lv_exist_flag    = abap_false.
    CLEAR: gt_popup_fields[].

    %loc_set_popup_field_ex1 'LVC_S_FCAT':
         'CONVEXIT' 'X' ' ' ' ' '변환 루틴' 'X'.

    " Call popup screen..
    CALL FUNCTION 'POPUP_GET_VALUES_USER_HELP'
      EXPORTING
*       f4_formname     = 'COM_PC_F4_MASS_CHANGE_0100'
        f4_programname  = gv_repid
*       formname        = 'COM_PC_CH_MASS_CHANGE_0100'
        popup_title     = 'Select Conv Exit'
        programname     = gv_repid
      IMPORTING
        returncode      = gv_returncode
      TABLES
        fields          = gt_popup_fields
      EXCEPTIONS
        error_in_fields = 1
        OTHERS          = 2.

    IF sy-subrc <> 0 OR gv_returncode = 'A'.
      " The operation has been canceled.
      MESSAGE s000 DISPLAY LIKE 'E' WITH 'The operation has been canceled.'.
      EXIT.
    ELSE.
      lv_convexit   = gt_popup_fields[ 1 ]-value.
      lv_exist_flag = abap_true.
    ENDIF.
  ENDIF.

  IF lt_index_columns IS INITIAL OR
     lv_exist_flag    = abap_false.
    MESSAGE i000(oo) WITH '선택된 컬럼이 없거나 Conv Exit Field 가 아닙니다' DISPLAY LIKE 'E'.
    EXIT.
  ENDIF.

  " 입력된 값으로 변경
  gv_title   = 'Column Conv Exit 확인'.
  gv_text100 = '선택된 컬럼의 Data를 ConvExit 적용 하시겠습니까?'.

  CALL FUNCTION 'POPUP_TO_CONFIRM'
    EXPORTING
      titlebar              = gv_title
      text_question         = gv_text100
*     text_button_1         = '저장'
*     text_button_2         = '보관'
      display_cancel_button = space
    IMPORTING
      answer                = gv_answer
    EXCEPTIONS
      text_not_found        = 1
      OTHERS                = 2.

  CASE gv_answer.
    WHEN 'J' OR '1'. " 예

    WHEN OTHERS.
      MESSAGE i000(oo) WITH '작업이 취소되었습니다.'.
      EXIT.
  ENDCASE.

  DATA: lv_first_flag,
        lv_index      TYPE sy-tabix,
        lv_fieldname  TYPE scrfname,
        lv_funcname   TYPE rs38l_fnam,
        lo_work       TYPE REF TO data.
  FIELD-SYMBOLS:
    <ls_work>       TYPE any,
    <lv_fieldvalue> TYPE any.

*      UNASSIGN <ls_work>.
  CREATE DATA lo_work TYPE (p_tab).
  ASSIGN lo_work->* TO <ls_work>.

*  CLEAR: lv_fieldtab.
*  lv_first_flag = 'X'.

  LOOP AT <gt_s0100> ASSIGNING <ls_work>.

*    lv_index = sy-tabix.

    LOOP AT lt_index_columns INTO ls_index_column.

      ls_fieldcat = VALUE #( gt_fieldcat_0100[ fieldname = ls_index_column-fieldname ] OPTIONAL ).
      CHECK ls_fieldcat-convexit IS NOT INITIAL.

      IF lv_convexit IS INITIAL.
        CONCATENATE 'CONVERSION_EXIT_' ls_fieldcat-convexit '_INPUT' INTO lv_funcname.
      ELSE.
        CONCATENATE 'CONVERSION_EXIT_' lv_convexit '_INPUT' INTO lv_funcname.
      ENDIF.

*      CONCATENATE lv_fieldtab ` ` ls_index_column-fieldname INTO lv_fieldtab.

      UNASSIGN <lv_fieldvalue>.
      CONCATENATE '<LS_WORK>-' ls_index_column-fieldname INTO lv_fieldname.
      ASSIGN (lv_fieldname) TO <lv_fieldvalue>.
      CHECK <lv_fieldvalue> IS ASSIGNED.

      CALL FUNCTION lv_funcname
        EXPORTING
          input  = <lv_fieldvalue>
        IMPORTING
          output = <lv_fieldvalue>.
    ENDLOOP.

*    MODIFY <gt_s0100> FROM <ls_work> INDEX lv_index.
**           TRANSPORTING (lv_fieldtab).

  ENDLOOP.

  MESSAGE s000(oo) WITH '작업이 완료 되었습니다.'.

ENDFORM.                    " LUC_NO_CONVEXIT_0100
*&---------------------------------------------------------------------*
*&      Form  COM_PC_F4_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PV_TABNAME     text
*      -->PV_FIELDNAME   text
*      -->PV_FLAG        text
*      -->PV_RETURNCODE  text
*      -->PV_VALUE       text
*----------------------------------------------------------------------*
FORM com_pc_f4_mass_change_0100  USING  pv_tabname
                                        pv_fieldname
                                        pv_flag
                                        pv_returncode
                                        pv_value.

*  " 값이 선택이 되면 pv_returncode 에 'F'
*
*  DATA: ls_idx_key  TYPE tys_idxtab_key,
*        ls_idx_list TYPE tys_idxtab_list,
*        lt_idx_list TYPE tyt_idxtab_list,
*        ls_dynpread TYPE dynpread,
*        lt_dynpread TYPE TABLE OF dynpread.
*
*  " 화면의 Tabname 정보를 읽는다
*  CLEAR: lt_dynpread, ls_dynpread.
*  ls_dynpread-fieldname = 'SVALD-VALUE'.
*
*  READ TABLE gt_popup_fields WITH KEY fieldname = 'TABNAME'
*       TRANSPORTING NO FIELDS.
*  IF sy-subrc = 0.
*    ls_dynpread-stepl = sy-tabix.
*  ENDIF.
*
*  APPEND ls_dynpread TO lt_dynpread.
*
*  CALL FUNCTION 'DYNP_VALUES_READ'
*    EXPORTING
*      dyname     = 'SAPLSPO4'
*      dynumb     = '0300'
*    TABLES
*      dynpfields = lt_dynpread
*    EXCEPTIONS
*      OTHERS     = 1.
*  CHECK sy-subrc = 0.
*
*  READ TABLE lt_dynpread INTO ls_dynpread WITH KEY fieldname = 'SVALD-VALUE'.
*  CHECK sy-subrc = 0.
*
*  " popup value 조회
*  DATA: ls_return TYPE ddshretval,
*        lt_return TYPE TABLE OF ddshretval.
*
*  CALL FUNCTION 'F4IF_FIELD_VALUE_REQUEST'
*    EXPORTING
*      tabname           = space
*      fieldname         = space
*      searchhelp        = 'DD_TABL'
*      shlpparam         = 'TABNAME'
*      multiple_choice   = space
*      display           = space
**    IMPORTING
**      user_reset        = gv_user_reset
*    TABLES
*      return_tab        = lt_return
*    EXCEPTIONS
*      field_not_found   = 1
*      no_help_for_field = 2
*      inconsistent_help = 3
*      no_values_found   = 4
*      OTHERS            = 5.
*
*  CHECK sy-subrc = 0.
*
*  READ TABLE lt_return INTO ls_return INDEX 1.
*  IF sy-subrc = 0.
*    pv_returncode = 'F'.
*    pv_value      = ls_return-fieldval.
*
*  ELSE.
*    MESSAGE i000 WITH '취소 되었습니다.'.
*  ENDIF.


ENDFORM.                    "COM_PC_F4_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*&      Form  COM_PC_CH_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->PT_IFIELDS text
*      -->PS_ERROR   text
*----------------------------------------------------------------------*
FORM com_pc_ch_mass_change_0100  TABLES pt_ifields  STRUCTURE sval
                                 USING  ps_error    LIKE      svale.

*  DATA: ls_ifield TYPE sval.
*
*  " Table 추가시에 동작을 한다
*  READ TABLE pt_ifields INTO ls_ifield WITH KEY fieldname = 'TABNAME'.
*  CHECK sy-subrc = 0.
*
*  " 입력된 Table 명이 유효한지 확인 한다.
*  PERFORM check_table_0110 USING    pt_ifields-value
*                           CHANGING gv_error_flag.
*  IF gv_error_flag = 'X'.
*    ps_error-msgid = 'OO'.
*    ps_error-msgty = 'E'.
*    ps_error-msgno = '003'.    " &1 &2 does not exist
*    ps_error-msgv1 = 'Table'.   " Input Table.
*    ps_error-msgv2 = pt_ifields-value. " Input Table.
*    EXIT.
*  ENDIF.
*
*  " 기존에 등록된 Table 인지 확인 한다.
*  " 중복된 Table 인지 확인 한다.
*  READ TABLE gt_node_key WITH KEY tabname = pt_ifields-value
*       TRANSPORTING NO FIELDS.
*  IF sy-subrc = 0.
*
*    " check popup message..
*    gv_title    = 'Add Table Confirm'.
*    gv_text100  = '이미 정의된 Table 입니다. 추가 정의 하시겠습니까?'.
*    PERFORM com_popup_to_confirm    USING    gv_title gv_text100
*                                             space
*                                             space
*                                             'X'
*                                    CHANGING gv_answer_flag.
*    IF gv_answer_flag <> 'X'.
*      ps_error-msgid = 'OO'.
*      ps_error-msgty = 'E'.
*      ps_error-msgno = '002'.    " &1 &2 already exists
*      ps_error-msgv1 = text-e01. " Input Table.
*      EXIT.
*    ENDIF.
*  ENDIF.
ENDFORM.                    "COM_PC_CH_MASS_CHANGE_0100
*&---------------------------------------------------------------------*
*& Form download_file
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM download_file .

  DATA: lv_max_cnt  TYPE sy-dbcnt,
        lv_from_cnt TYPE sy-dbcnt,
        lv_to_cnt   TYPE sy-dbcnt,
        lv_p_cnt    TYPE sy-dbcnt,
        lv_no(5)    TYPE n.

  IF <gt_tab_down> IS ASSIGNED.
    FREE: <gt_tab_down>.
    UNASSIGN: <gt_tab_down>.
  ENDIF.

  CREATE DATA go_tab_down TYPE TABLE OF (p_tab).
  ASSIGN go_tab_down->* TO <gt_tab_down>.

  CLEAR: <gt_tab_down>[].

  PERFORM get_data.
  IF <gt_s0100>[] IS INITIAL.
    EXIT.
  ENDIF.

  lv_max_cnt = lines( <gt_s0100> ).
  lv_p_cnt   = p_cnt.
  IF lv_p_cnt = 0.
    lv_p_cnt  = lv_max_cnt.
  ENDIF.

  lv_from_cnt = 1.
  lv_to_cnt   = lv_p_cnt.

  IF lv_to_cnt > lv_max_cnt.
    lv_to_cnt   = lv_max_cnt.
  ENDIF.

  DATA: lv_div TYPE i.
  DATA: lv_max_cnt_c TYPE char20,
        lv_to_cnt_c  TYPE char20,
        lv_no_c      TYPE char20,
        lv_msg       TYPE bapi_msg.

  IF lv_p_cnt < lv_max_cnt.  " split 해야 하는 경우
    lv_no = '00001'.

    lv_div = lv_max_cnt / p_cnt.
    IF lv_div > 99990.
      MESSAGE i000 WITH 'Download Split 건수를 늘려야 합니다'.
      EXIT.
    ENDIF.
  ELSE.
    lv_no = '00000'.
  ENDIF.

  WRITE lv_max_cnt TO lv_max_cnt_c LEFT-JUSTIFIED.

  WHILE lv_max_cnt > 0.

    WRITE lv_to_cnt  TO lv_to_cnt_c  LEFT-JUSTIFIED.

    CONCATENATE lv_max_cnt_c ` 건중 ` lv_to_cnt_c ` 건 Download 진행중..`
           INTO go_comfunc->gv_sp_msg.
    go_comfunc->show_message_p( 0 ).

    CLEAR: <gt_tab_down>.
    APPEND LINES OF <gt_s0100> FROM lv_from_cnt TO lv_to_cnt TO <gt_tab_down>.
    PERFORM download_data USING lv_no.

    IF lv_to_cnt   = lv_max_cnt.
      lv_max_cnt = 0.
      EXIT.
    ENDIF.

    lv_no = lv_no + 1.
    lv_from_cnt = lv_from_cnt + lv_p_cnt.
    lv_to_cnt   = lv_to_cnt   + lv_p_cnt.
    IF lv_to_cnt > lv_max_cnt.
      lv_to_cnt   = lv_max_cnt.
    ENDIF.

  ENDWHILE.

  lv_max_cnt = lines( <gt_s0100> ).
  IF lv_no = '00000' .
    lv_no = '00001'.
  ENDIF.

  WRITE lv_max_cnt TO lv_max_cnt_c LEFT-JUSTIFIED.
  WRITE lv_no      TO lv_no_c      LEFT-JUSTIFIED.

  CONCATENATE lv_max_cnt_c ` 건 이 ` lv_no_c ` 개의 File 로 Download 되었습니다`
         INTO lv_msg.
  MESSAGE s000 WITH lv_msg.

ENDFORM.                    "download_file
*&---------------------------------------------------------------------*
*& Form DOWNLOAD_DATA
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LV_NO
*&---------------------------------------------------------------------*
FORM download_data  USING    pv_no.

  DATA: lv_filename         TYPE string,
        lv_pf_file          TYPE draw-filep,
        lv_pfx_file         TYPE draw-filep,
        lv_pfx_dotextension TYPE char5.

  IF pv_no IS INITIAL.
    lv_filename = p_filed.

  ELSE.
    lv_pf_file = p_filed.
    CALL FUNCTION 'CV120_SPLIT_FILE'
      EXPORTING
        pf_file          = lv_pf_file
      IMPORTING
        pfx_file         = lv_pfx_file
        pfx_dotextension = lv_pfx_dotextension.

    CONCATENATE lv_pfx_file `_` pv_no lv_pfx_dotextension INTO lv_filename.
  ENDIF.

  CALL METHOD cl_gui_frontend_services=>gui_download
    EXPORTING
      filename                = lv_filename
*     filetype                = 'ASC'
*     append                  = SPACE
      write_field_separator   = 'X'
*     header                  = '00'
*     trunc_trailing_blanks   = SPACE
*     write_lf                = 'X'
*     col_select              = SPACE
*     col_select_mask         = SPACE
*     dat_mode                = SPACE
*     confirm_overwrite       = SPACE
*     no_auth_check           = SPACE
      codepage                = '8500'
*     ignore_cerr             = ABAP_TRUE
*     replacement             = '#'
*     write_bom               = SPACE
*     trunc_trailing_blanks_eol = 'X'
*     wk1_n_format            = SPACE
*     wk1_n_size              = SPACE
*     wk1_t_format            = SPACE
*     wk1_t_size              = SPACE
      show_transfer_status    = space  " Function 내 Status 안보임
*     fieldnames              =
*     write_lf_after_last_line  = 'X'
*     virus_scan_profile      = '/SCET/GUI_DOWNLOAD'
*    IMPORTING
*     filelength              =
    CHANGING
      data_tab                = <gt_tab_down>
    EXCEPTIONS
      file_write_error        = 1
      no_batch                = 2
      gui_refuse_filetransfer = 3
      invalid_type            = 4
      no_authority            = 5
      unknown_error           = 6
      header_not_allowed      = 7
      separator_not_allowed   = 8
      filesize_not_allowed    = 9
      header_too_long         = 10
      dp_error_create         = 11
      dp_error_send           = 12
      dp_error_write          = 13
      unknown_dp_error        = 14
      access_denied           = 15
      dp_out_of_memory        = 16
      disk_full               = 17
      dp_timeout              = 18
      file_not_found          = 19
      dataprovider_exception  = 20
      control_flush_error     = 21
      not_supported_by_gui    = 22
      error_no_gui            = 23
      OTHERS                  = 24.
  IF sy-subrc = 0.
*    MESSAGE S000 WITH 'Download 완료되었습니다'.
*  ELSE.
    MESSAGE ID sy-msgid TYPE 'S' NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
               DISPLAY LIKE 'E'.
  ENDIF.

ENDFORM.                    "download_data
