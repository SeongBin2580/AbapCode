*----------------------------------------------------------------------*
***INCLUDE LZMDMMMFG91I01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  GET_OKCODE  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_okcode INPUT.

  gv_save_ok = gv_ok_code.
  CLEAR gv_ok_code.

ENDMODULE.                    "get_okcode INPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0100 INPUT.

  IF gv_exit_mode_0100 = space.
    gv_save_flag_0100 = space.
  ENDIF.

  IF go_alv_info->exit_program( iv_save_flag = gv_save_flag_0100 ) = 'X'.
    gv_selected_0100 = space.
    LEAVE TO SCREEN 0.
  ELSE.
    CLEAR: gv_ok_code.  " 화면으로 돌아 간다
  ENDIF.

ENDMODULE.                    "exit_0100 INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.

  gv_error_in_data = go_alv_info->check_changed_data( go_grid_0100 ).
  gv_exit_form     = go_alv_info->dispatch( ).
  IF gv_exit_form = 'X' OR gv_error_in_data = 'X'.
    CLEAR: gv_save_ok.
    EXIT.
  ENDIF.

  " process..\
  gv_action_flag = gv_exit_flag = space.
  CASE gv_save_ok.
    WHEN 'SAVE' OR 'OK' OR 'ENTR'.
      gv_error_flag  = space.
      gv_action_flag = 'C'.
      PERFORM (gv_check_form) IN PROGRAM (gv_repid) IF FOUND
                              TABLES   <gt_s0100>
                              CHANGING gv_error_flag
                                       gv_message.
      IF gv_error_flag = 'E'.
        MESSAGE i000(oo) WITH gv_message.
        EXIT.
      ENDIF.

      " 저장 form 이 있는 경우 수행
      PERFORM (gv_save_form) IN PROGRAM (gv_repid) IF FOUND
                              TABLES   <gt_s0100>
                              USING    go_grid_0100
                              CHANGING gv_exit_flag
                                       gv_error_flag
                                       gv_message.
      CLEAR: gv_save_ok."  CLEAR ok code!

    WHEN 'ADD_BT_01' OR 'ADD_BT_02' OR 'ADD_BT_03' OR 'ADD_BT_04' OR
         'ADD_BT_05' OR 'ADD_BT_06' OR 'ADD_BT_07' OR 'ADD_BT_08' OR
         'ADD_BT_09'.

      gv_action_flag = 'C'.

      gv_add_bt_form = |LUC_{ gv_dynnr }_{ gv_save_ok }|.
      PERFORM (gv_add_bt_form) IN PROGRAM (gv_repid) IF FOUND
                              TABLES   <gt_s0100>
                              USING    go_grid_0100
                              CHANGING gv_exit_flag
                                       gv_error_flag
                                       gv_message.
      CLEAR: gv_save_ok."  CLEAR ok code!

    WHEN gc_ok_exit      OR gc_ok_canc_exit OR
         gc_ok_back_exit OR gc_ok_disp_exit.
      gv_exit_flag   = 'X'.
      gv_action_flag = 'C'.

    WHEN OTHERS.
      CLEAR: gv_save_ok."  CLEAR ok code!

  ENDCASE.

  " 메시지
  IF ( gv_error_flag = 'E' OR gv_error_flag = 'X' ) AND
       gv_action_flag = 'C'.
    CASE gv_message.
      WHEN space.  MESSAGE i000(oo) WITH TEXT-e00.       " 정의되지 않은 에러가 있습니다.
      WHEN '!'.
      WHEN OTHERS. MESSAGE i000(oo) WITH gv_message.
    ENDCASE.

  ELSEIF gv_action_flag = 'C'.
*          MESSAGE i000(oo) WITH 'Data has been saved.'.     "#EC NOTEXT
    CASE gv_message.
      WHEN space.  MESSAGE i000(oo) WITH TEXT-s01.       " 자료가 저정 되었습니다.
      WHEN '!!'.   MESSAGE s000(oo) WITH TEXT-s01.       " 자료가 저정 되었습니다.
      WHEN '!'.
      WHEN OTHERS. MESSAGE i000(oo) WITH gv_message.
    ENDCASE.

    gv_selected_0100 = 'S'.
  ENDIF.

  " 작업종료
  IF gv_exit_flag = 'X' AND gv_action_flag = 'C'.  " 화면 종료인 경우.
    gv_ok_code = gc_ok_back_exit.
    IF go_alv_info->exit_program( iv_save_flag = space ) = 'X'.
      LEAVE TO SCREEN 0.
    ENDIF.
  ENDIF.

ENDMODULE.                    "USER_COMMAND_0100 INPUT
*&---------------------------------------------------------------------*
*&      Module  EXIT_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit_0200 INPUT.

  gv_save_flag_0200 = go_edit_info->check_text_modify( go_edit_0200 ).
  IF go_edit_info->exit_program( iv_save_flag = gv_save_flag_0200 ) = 'X'.
    LEAVE TO SCREEN 0.
  ELSE.
    CLEAR: gv_ok_code.  " 화면으로 돌아 간다
  ENDIF.

ENDMODULE.                    "EXIT_0200 INPUT
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0200 INPUT.

  IF go_edit_info->dispatch( '0200' ) = 'X'.
    EXIT.
  ENDIF.

  " process..
  CASE gv_save_ok.
    WHEN 'SAVE' OR 'OK' OR 'ENTR'.
      gv_exit_flag = gv_error_flag = space.

      " 화면의 Text 를 메모리로 전송
      go_edit_info->get_r3table( EXPORTING io_edit  = go_edit_0200
                                 IMPORTING et_table = gt_s0200[] ).

      IF gv_save_msg = 'X'.
        MESSAGE i000(oo) WITH 'Data has been saved.'.       "#EC NOTEXT
      ENDIF.

      gv_action_flag_0200 = 'S'.
      gv_ok_code = gc_ok_back_exit.
      IF go_edit_info->exit_program( iv_save_flag = space ) = 'X'.
        LEAVE TO SCREEN 0.
      ENDIF.

      CLEAR: gv_save_ok."  CLEAR ok code!

    WHEN OTHERS.
      CLEAR: gv_save_ok."  CLEAR ok code!

  ENDCASE.

ENDMODULE.                    "user_command_0200 INPUT
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_01_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_01_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '01'.
  CHECK sy-subrc = 0.

  PERFORM check_value_9200 CHANGING gs_s9200-value_01.

ENDMODULE.         " CHECK_VALUE_01_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_01_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_01_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '01'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_01.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_02_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_02_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '02'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_02_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_02_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_02_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '02'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_02.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_03_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_03_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '03'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_03_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_03_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_03_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '03'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_03.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_04_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_04_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '04'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_04_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_04_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_04_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '04'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_04.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_05_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_05_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '05'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_05_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_05_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_05_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '05'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_05.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_06_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_06_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '06'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_06_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_06_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_06_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '06'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_06.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_07_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_07_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '07'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_07_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_07_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_07_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '07'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_07.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_08_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_08_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '08'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_08_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_08_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_08_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '08'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_08.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_09_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_09_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '09'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_09_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_09_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_09_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '09'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_09.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_10_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_10_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '10'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_10_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_10_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_10_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '10'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_10.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_11_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_11_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '11'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_11_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_11_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_11_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '11'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_11.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  CHECK_VALUE_12_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE check_value_12_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '12'.
  CHECK sy-subrc = 0.

ENDMODULE.         " CHECK_VALUE_12_9200
*&---------------------------------------------------------------------*
*&      Module  F4_VALUE_12_9200  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE f4_value_12_9200 INPUT.

  READ TABLE gt_scrfield_in INTO gs_scrfield_in WITH KEY seqno = '12'.
  CHECK sy-subrc = 0.

  PERFORM execute_f4_9200 CHANGING gs_s9200-value_12.

ENDMODULE.
