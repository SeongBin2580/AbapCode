class ZCL_ZMDM_MM_COMFUNC definition
  public
  create public .

public section.

  interfaces IF_F4CALLBACK_VALUE_REQUEST .

  types:
    BEGIN OF tys_user_info,
        date_format   TYPE xudatfm, " Date format
        number_format TYPE xudcpfm, " Number format
        tzone         TYPE tznzone, " Time Zone
        nation        TYPE char2,   " 국가
        name          TYPE bapiaddr3-fullname, " 사용자명
        email         TYPE bapiadsmtp-e_mail,  " e-mail
        empno         TYPE zcmtp010-empno,
        hrcode        TYPE zcmtp010-hrcode,
        comcode       TYPE zcmtp010-comcode,
      END OF tys_user_info .
  types:
    BEGIN OF tys_xls_error,
        line      TYPE i,
        fieldname TYPE fieldname,
        message   TYPE bapi_msg,
      END OF tys_xls_error .
  types:
    tyt_xls_error TYPE TABLE OF tys_xls_error .
  types TYV_AMT type DMBTR .
  types:
    tyv_cnt TYPE p LENGTH 8 DECIMALS 0 .
  types:
    BEGIN OF tys_dd07v,  ""고정값 및 도메인텍스트 뷰
        domname  TYPE dd07v-domname,     " 코드구분
        domvalue TYPE dd07v-domvalue_l,     " 관리코드
        ddtext   TYPE dd07v-ddtext,     " 코드명
      END OF tys_dd07v .
  types:
    tyt_dd07v TYPE TABLE OF tys_dd07v .
  types:
    BEGIN OF tys_bdc_msg,
        msgid	TYPE bdc_mid,
        msgno	TYPE bdc_mnr,
      END OF tys_bdc_msg .
  types:
    tyt_bdc_msg TYPE TABLE OF tys_bdc_msg .
  types:
    BEGIN OF tys_sapid,
        userid   TYPE bapibname-bapibname,
        username TYPE bapiaddr3-firstname,
      END OF tys_sapid .
  types:
    tyt_sapid TYPE TABLE OF tys_sapid WITH EMPTY KEY .
  types:
    BEGIN OF tys_runtime,
        runtime_start TYPE i,
        runtime_stop  TYPE i,
        runtime       TYPE i,
        time_start    TYPE sy-uzeit,
        time_stop     TYPE sy-uzeit,
      END OF tys_runtime .
  types:
    BEGIN OF tys_hlp_return,
        selected TYPE char1,
        value    TYPE shvalue_d,
      END OF tys_hlp_return .
  types:
    tyt_t006  TYPE TABLE OF t006 .

  constants GC_MSGID type SYMSGID value 'ZMDM01' ##NO_TEXT.
  constants:
    gc_type_x0000(2)    TYPE x value '0000' ##NO_TEXT.
  constants:
    gc_type_x00a0(2)    TYPE x value '00A0' ##NO_TEXT.
  constants:
    gc_type_x0900(2) TYPE x value '0900' ##NO_TEXT.
  constants:
    gc_type_xc2a0(2)    TYPE x value 'C2A0' ##NO_TEXT.
  constants GC_XLS_ENDCOL type FIELDNAME value 'ZZENDCOLZZ' ##NO_TEXT.
  constants GC_FILE_MAX_LEN type I value 128 ##NO_TEXT.
  constants GC_XLS_EXTENSION type WWWPARAMS-NAME value 'fileextension' ##NO_TEXT.
  data GO_ALV_INFO type ref to ZCL_ZMDM_MM_ALV_INFO .
  data GS_F4_INFO type ZMDMMMS9000 .
  data GS_PARAMS type CTU_PARAMS .
  data GS_USER_INFO type TYS_USER_INFO .
  data:
    gt_bdcdata TYPE TABLE OF bdcdata .
  data:
    gt_bdcmsg  TYPE TABLE OF bdcmsgcoll .
  data GT_BDC_MSG_I type TYT_BDC_MSG .
  data GT_DOMAIN type TYT_DD07V .
  data GT_SAPID type TYT_SAPID .
  data GT_T006 type TYT_T006 .
  data GV_CODEPAGE type ABAP_ENCODING .
  data GV_COL_POS type I .
  data GV_HIDE_OUT type CHAR1 .
  data GV_MSGID type SYMSGID .
  data GV_REPID type SY-REPID .
  data GV_SP_CNT type TYV_CNT .
  data GV_SP_MSG type BAPI_MSG .
  data GV_SP_PERSENT type I .
  data GV_SP_TOTAL type SY-DBCNT .
  data GS_RUNTIME type TYS_RUNTIME .
  data GV_XLS_MAX_LINE type I value 7000 ##NO_TEXT.
  data GV_XLS_UPLOAD_MODULE type C .

  class-methods CLASS_CONSTRUCTOR .
  methods ADD_ICON
    importing
      !IV_ICON type ANY optional
      !IV_TEXT type ANY optional
      !IV_QUICK type ANY optional
      !IV_TYPE type CHAR1 default SPACE
    returning
      value(RV_RESULT) type RSFUNC_TXT .
  methods ADD_LISTBOX_DOMAIN
    importing
      !IV_FIELDNAME type ANY
      !IV_DOMAIN type ANY
      !IV_WITH_KEY type FLAG default 'X' .
  methods ADD_RANGE
    importing
      !IT_INPUT type STANDARD TABLE optional
      !IV_INPUT_FIELD type FIELDNAME optional
      !IV_INPUT_VALUE type ANY optional
      !IV_INPUT_FR type ANY optional
      !IV_INPUT_TO type ANY optional
    exporting
      !ET_OUTPUT type STANDARD TABLE .
  methods BDC_EXECUTE
    importing
      !IV_TCODE type BDC_TCODE
      !IV_MSGID type BDC_MID
      !IV_MSGNO type BDC_MNR
    returning
      value(RS_BDCMSG) type BAPIRET2 .
  methods BDC_INITIALIZATION
    importing
      !IV_MODE type CTU_MODE default 'N'
      !IV_RACOMMIT type CTU_RAFC default SPACE
      !IV_NOBINPT type CTU_NOBIM default SPACE .
  methods BDC_SET_DATA
    importing
      !IV_DYNBEGIN type CHAR1
      !IV_FNAME type ANY
      !IV_FVALUE type ANY .
  methods CALL_CL03
    importing
      !IV_CLASS type KLASSE_D
      !IV_KLART type KLASSENART .
  methods CALL_CT04
    importing
      !IV_ATNAM type ATNAM .
  methods CALL_MM03
    importing
      !IV_MATNR type MATNR
      !IV_WERKS type WERKS_D optional .
  methods CE_ALPHA_I
    importing
      !IV_INPUT type ANY
      !IV_TYPE type ANY default SPACE
    returning
      value(RV_OUTPUT) type STRING .
  methods CE_ALPHA_O
    importing
      !IV_INPUT type ANY
      !IV_TYPE type ANY default SPACE
    returning
      value(RV_OUTPUT) type STRING .
  methods CE_CURR_I
    importing
      !IV_AMT type ANY
      !IV_CURRENCY type ANY default 'KRW'
    returning
      value(RV_AMT) type TYV_AMT
    exceptions
      NOT_NUMERIC .
  methods CE_CURR_O
    importing
      !IV_AMT type ANY
      !IV_CURRENCY type ANY default 'KRW'
    returning
      value(RV_AMT) type CHAR30
    exceptions
      NOT_NUMERIC .
  methods CE_DATE_I
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type SY-DATUM .
  methods CE_DATE_O
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type CHAR10 .
  methods CE_DATE_TIME
    importing
      !IV_DATE type ANY
      !IV_TIME type ANY optional
      !IV_TYPE type CHAR1 default SPACE
    returning
      value(RV_OUTPUT) type STRING .
  methods CE_FLTP_O
    importing
      !IV_FLTP_VALUE type QSOLLWERTE
      !IV_NUM_DIG type I default 1
    returning
      value(RV_OUTPUT) type STRING .
  methods CE_MATNR_UNIT_QTY
    importing
      !IV_MATNR type ANY
      !IV_IN_QTY type ANY
      !IV_IN_UNIT type ANY
      !IV_OUT_UNIT type ANY
    returning
      value(RV_OUT_QTY) type LABST .
  methods CE_NUMC_I
    importing
      !IV_INPUT type ANY
    exporting
      !EV_OUTPUT type ANY
    exceptions
      NOT_NUMERIC .
  methods CE_NUMC_O
    importing
      !IV_INPUT type ANY
      !IV_COMMA type FLAG default SPACE
      !IV_DECIMAL_LEN type I default 0
    exporting
      !EV_OUTPUT type ANY
      !EV_DECIMAL_LEN type I
    exceptions
      NOT_NUMERIC .
  methods CE_SPRAS_I
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type CHAR1 .
  methods CE_SPRAS_O
    importing
      !IV_INPUT type CHAR1
      !IV_TYPE type CHAR1 default '1'
    returning
      value(RV_OUTPUT) type SPTXT .
  methods CE_STRING_TO_TABLE
    importing
      !IV_TEXT type ANY
      !IV_TEXT_LEN type INT1 default 72
    returning
      value(RT_TEXTLINE) type RE_T_TEXTLINE .
  methods CE_TIME_I
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type SY-UZEIT .
  methods CE_TIME_O
    importing
      !IV_INPUT type ANY
      !IV_TYPE type CHAR1 default SPACE
    returning
      value(RV_OUTPUT) type CHAR8 .
  methods CE_TNUM_I
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type I .
  methods CE_TNUM_O
    importing
      !IV_INPUT type I
    returning
      value(RV_OUTPUT) type UZEIT .
  methods CE_TNUM_T
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type CHAR30 .
  methods CE_UNIT_I
    importing
      !IV_UNIT type ANY
      !IV_LANGU type SYST_LANGU default SY-LANGU
    returning
      value(RV_UNIT) type CHAR3 .
  methods CE_UNIT_ISO
    importing
      !IV_UNIT type ANY
      !IV_LANGU type SYST_LANGU default SY-LANGU
    returning
      value(RV_UNIT) type ISOCD_UNIT .
  methods CE_UNIT_O
    importing
      !IV_UNIT type ANY
      !IV_LANGU type SYST_LANGU default SY-LANGU
    returning
      value(RV_UNIT) type CHAR3 .
  methods CHECK_FILE_NAME
    importing
      !IV_FILENAME type ANY
      !IV_MSG_TYPE type C default 'I'
    returning
      value(RV_ERROR_FLAG) type CHAR1 .
  methods CHECK_MESSAGE
    importing
      !IV_MSG type ANY
      !IV_TITLE type ANY optional
      !IV_TEXT1 type ANY optional
      !IV_TEXT2 type ANY optional
      !IV_CANCEL type ANY default SPACE
      !IV_TEXT_BUTTON_1 type ANY default SPACE
      !IV_TEXT_BUTTON_2 type ANY default SPACE
    returning
      value(RV_CHECK) type CHAR1 .
  methods CHECK_MIMETYPE
    importing
      !IV_OBJID type ANY
    returning
      value(RV_RC) type I .
  methods CONSTRUCTOR
    importing
      !IV_MSGID type SYMSGID optional
      !IV_REPID type SY-REPID optional .
  methods CREATE_DATA
    importing
      !IV_TYPE type C
      !IV_LEN type I
      !IV_DEC type I default 0
    returning
      value(RO_DATA) type ref to DATA
    raising
      CX_SY_CREATE_DATA_ERROR .
  methods F4_FIELD_VALUE_REQUEST
    changing
      !CS_F4_INFO type ZMDMMMS9000 .
  methods F4_SEARCH_HELP
    importing
      !IV_SEARCH_HELP type ANY
      !IV_FN_RET_FIELD type ANY
      !IS_F4_INFO type ZMDMMMS9000 optional
    returning
      value(RS_RETURN) type TYS_HLP_RETURN .
  methods FILE_DELETE
    importing
      !IV_DIRECTORY type ANY optional
      !IV_FILENAME type ANY .
  methods GET_CHARACTVALUE
    importing
      !IV_CHARACT type ATNAM
      !IV_VALUE_FROM type ATFLV
      !IV_VALUE_TO type ATFLB
    returning
      value(RV_VALUE_NEUTRAL) type ATWRT30 .
  methods GET_DOMAIN
    importing
      !IV_DOMNAME type DOMNAME
      !IV_DOMTEXT type ANY
    returning
      value(RV_DOMVALUE) type DOMVALUE_L .
  methods GET_DOMAIN_TXT
    importing
      !IV_DOMNAME type DOMNAME
      !IV_DOMVALUE type ANY
    returning
      value(RV_TEXT) type VAL_TEXT .
  methods GET_FIELD_VALUE
    importing
      !IV_FIELDNAME type ANY
      !IV_REPID type D020S-PROG default SY-CPROG
      !IV_DYNNR type D020S-DNUM default SY-DYNNR
    returning
      value(RV_VALUE) type DYNFIELDVALUE .
  methods GET_FILE_NAME
    importing
      !IV_MSG_TYPE type C default 'I'
    exporting
      !EV_FILENAME type LOCALFILE
      !EV_ERROR_FLAG type C .
  methods GET_LAST_MESSAGE
    importing
      !IV_MSG_TYPE type ANY default SPACE
      !IV_GUBUN type CHAR1 default 'L'
      !IT_TAB type STANDARD TABLE
    returning
      value(RV_MSG) type BAPI_MSG .
  methods GET_LISTBOX
    importing
      !IV_FIELDNAME type ANY
      !IV_VALUE type ANY
    returning
      value(RS_VRM_VALUE) type VRM_VALUE .
  methods GET_MESSAGE
    importing
      !IV_MSGID type ANY optional
      !IV_MSGNO type NUMC3
      !IV_PARM1 type ANY optional
      !IV_PARM2 type ANY optional
      !IV_PARM3 type ANY optional
      !IV_PARM4 type ANY optional
      !IV_PARM_CLEAR type FLAG default ABAP_TRUE
    returning
      value(RV_MESSAGE) type BAPI_MSG .
  methods GET_RUNTIME
    returning
      value(RS_RUNTIME) type TYS_RUNTIME .
  methods GET_SAPID
    importing
      !IV_SAPID type ANY
    returning
      value(RS_SAPID_TXT) type TYS_SAPID .
  methods GET_UC_TEXT
    importing
      !IV_INPUT type SIMPLE
    returning
      value(RV_OUTPUT) type SYCHAR02 .
  methods INITIALIZATION_MESSAGE .
  methods INITIALIZATION_RUNTIME .
  methods MAKE_MESSAGE_TEXT
    importing
      !IV_MSG_TXT type ANY
      !IV_PARM1 type ANY optional
      !IV_PARM2 type ANY optional
      !IV_PARM3 type ANY optional
      !IV_PARM4 type ANY optional
      !IV_MSG_OLD type ANY optional
    returning
      value(RV_MESSAGE) type BAPI_MSG .
  methods POPUP_TO_CONFIRM
    importing
      !IV_TITLE type ANY
      !IV_TEXT1 type ANY
      !IV_TEXT2 type ANY optional
      !IV_CANCEL type CHAR1 default SPACE
      !IV_NO_MSG type CHAR1 default SPACE
      !IV_TEXT_BUTTON_1 type ANY default SPACE
      !IV_TEXT_BUTTON_2 type ANY default SPACE
    returning
      value(RV_ANSWER) type CHAR1 .
  methods POPUP_TO_INFORMATION
    importing
      !IV_TITLE type ANY
      !IV_TEXT1 type ANY
      !IV_TEXT2 type ANY optional
      !IV_TEXT_BUTTON_1 type ANY default SPACE
    returning
      value(RV_ANSWER) type CHAR1 .
  methods READ_TEXT
    importing
      !IV_ID type ANY
      !IV_NAME type ANY
      !IV_OBJECT type ANY
    returning
      value(RT_TEXTLINE) type RE_T_TEXTLINE .
  methods READ_TEXT_SINGLE
    importing
      !IV_ID type ANY
      !IV_NAME type ANY
      !IV_OBJECT type ANY
    returning
      value(RV_OUTPUT) type STRING .
  methods SAVE_FILE_NAME
    changing
      !CV_FILENAME type C
    returning
      value(RV_ERROR_FLAG) type FLAG .
  methods SAVE_TEXT
    importing
      !IV_ID type ANY
      !IV_NAME type ANY
      !IV_OBJECT type ANY
      !IV_SAVEMODE type CHAR1 default 'X'
      !IT_TEXTLINE type RE_T_TEXTLINE .
  methods SEND_MAIL
    importing
      !IV_TITLE type ANY
      !IV_SENDER type ANY
      !IT_RECEIVERS type ZMDMMMY9060
      !IT_TEXT type ZMDMMMY9030
    exporting
      !EV_TYPE type BAPI_MTYPE
      !EV_MESSAGE type BAPI_MSG .
  methods SET_MESSAGE
    importing
      !IV_MSGID type ANY optional
      !IV_MSGTY type ANY default 'S'
      !IV_MSGNO type NUMC3
      !IV_PARM1 type ANY optional
      !IV_PARM2 type ANY optional
      !IV_PARM3 type ANY optional
      !IV_PARM4 type ANY optional
      !IV_INDEX type ANY default 0 .
  methods SET_TIMESTAMP
    changing
      !CS_TIMESTAMP type ANY .
  methods SHOW_MESSAGE
    importing
      !IV_TITLE type ANY default SPACE .
  methods SHOW_MESSAGE_P
    importing
      !IV_READ_CNT type SYDBCNT
      !IV_BATCH_MODE type FLAG default SPACE .
  methods SPLIT_PATHS
    importing
      !IV_PATHS type ANY
    exporting
      !EV_DIRECTORY type FILEP
      !EV_FILENAME type FILEP
      !EV_EXTENSION type ANY
      !EV_APPR_TYPE type DRAW-DAPPL
      !EV_SIZE type I .
  methods STRLENX
    importing
      !IV_INPUT type ANY
    returning
      value(RV_OUTPUT) type I .
  methods XLS_DOWNLOAD
    importing
      !IV_NO_CLEAR type ANY default 'X'
      !IV_XLS_EXECUTE type ANY default 'X'
      !IV_CONV_ROUTINE type ANY default 'DEFAULT'
      !IS_XLS_LAYOUT type ANY optional
      !IT_FIELDCAT type LVC_T_FCAT optional
      !IT_XLS_DATA type STANDARD TABLE .
  methods XLS_DOWNLOAD_TEMPLATE
    importing
      !IV_OBJID type ANY
      !IV_IS_DISPLAY type ANY default 'X'
      !IV_FILENAME type ANY optional
      !IV_FILENAME_POPUP type ANY default SPACE
    exporting
      !EV_FILENAME type LOCALFILE .
  methods XLS_UPLOAD
    importing
      !IV_FILENAME type LOCALFILE default SPACE
      !IV_START_ROW type I default 2
      !IV_END_ROW type I default 65536
      !IV_END_COL type I default 0
      !IV_SHEETNAME type ANY default SPACE
      !IV_CHECK_ROUTINE type ANY default 'DEFAULT'
    exporting
      !ET_XLS_DATA type STANDARD TABLE
      !EV_CNT type I
    returning
      value(RV_TYPE) type FLAG .
  methods XLS_UPLOAD_CONV_DEFAULT
    importing
      !IV_VALUE type ANY
    exporting
      !EV_VALUE type ANY .
  PROTECTED SECTION.
private section.

  types:
    BEGIN OF tys_alv_message,
        msgno   TYPE numc3,
        index   TYPE sy-tabix,
        message TYPE bapi_msg,
      END OF tys_alv_message .
  types:
    tyt_alv_message TYPE TABLE OF tys_alv_message .
  types:
    tyt_hidden_rows TYPE STANDARD TABLE OF i WITH EMPTY KEY .
  types:
    tyt_hidden_cols TYPE STANDARD TABLE OF i WITH EMPTY KEY .
  types:
    BEGIN OF tys_filter,
        col_id TYPE i,
        values TYPE stringtab,
      END OF tys_filter .
  types:
    tyt_filters TYPE HASHED TABLE OF tys_filter WITH UNIQUE KEY col_id .

  data GT_ALV_MESSAGE type TYT_ALV_MESSAGE .
  data GV_ALV_MESSAGE type CHAR1 .

  methods BUILD_COMPONENT_TAB
    importing
      !IT_COMPS type ABAP_COMPDESCR_TAB
    returning
      value(RT_COMPX) type ABAP_COMPONENT_TAB .
  methods CE_DATE_C
    importing
      !IV_DATE type ANY
    returning
      value(RV_DATE) type STRING .
  methods CHECK_MAIL_ADDRESS
    importing
      !IV_EMAIL type ANY optional
      !IT_EMAIL type ZMDMMMY9060 optional
    returning
      value(RV_TYPE) type BAPI_MTYPE .
  methods CONV_F4_VALUE
    importing
      !IS_RETURN type DDSHRETVAL
    returning
      value(RV_VALUE) type SHVALUE_D .
  methods FILL_COMPONENTS
    importing
      !IS_INPUT type ANY
    returning
      value(RT_COMPONENTS) type ABAP_COMPONENT_TAB .
  methods SAVE_FILE_TEMP
    importing
      !IV_FILENAME type LOCALFILE .
  methods SHVALUE_EXT_TO_INT .
  methods XLS_COL_LETTERS_TO_IDX
    importing
      !IV_COL type STRING
    returning
      value(RV) type I .
  methods XLS_COPY_OUT
    importing
      !IV_NO_CLEAR type ANY default 'X'
      !IV_CONV_ROUTINE type ANY default 'DEFAULT'
      !IS_XLS_LAYOUT type ANY optional
      !IT_FIELDCAT type LVC_T_FCAT optional
      !IT_XLS_DATA type STANDARD TABLE
    changing
      !CT_XLS_DATA type ZMDMMMY9030
      !CT_XLS_COMP type ABAP_COMPONENT_TAB optional .
  methods XLS_COPY_TITLE
    importing
      !IS_XLS_LAYOUT type ANY optional
    exporting
      !ET_XLS_DATA type ZMDMMMY9030
    changing
      !CT_FIELDCAT type LVC_T_FCAT optional .
  methods XLS_DOWNLOAD_CONV_DEFAULT
    importing
      !IV_VALUE type ANY
    exporting
      !EV_VALUE type ANY .
  methods XLS_IS_SCIENTIFIC
    importing
      !IV_TEXT type STRING
    returning
      value(RV_YES) type ABAP_BOOL .
  methods XLS_PARSE_META_HIDDEN
    importing
      !IV_SHEET_XML type STRING
    exporting
      !EV_MAX_ROW type I
      !EV_MAX_COL type I
      !ET_HIDDEN_ROWS type TYT_HIDDEN_ROWS
      !ET_HIDDEN_COLS type TYT_HIDDEN_COLS
      !EV_HAS_FILTER type ABAP_BOOL
      !EV_FILTER_REF type STRING .
  methods XLS_PARSE_SIMPLE_FILTERS
    importing
      !IV_SHEET_XML type STRING
    returning
      value(RT_FILTERS) type TYT_FILTERS .
  methods XLS_SHEET_NAME_TO_PATH
    importing
      !IV_ZIP type XSTRING
      !IV_SHEET_NAME type STRING
    returning
      value(RV_PATH) type STRING .
  methods XLS_TO_CHAR
    importing
      !IV_TEXT type STRING
    returning
      value(RV) type STRING .
  methods XLS_UNZIP_GET_XML
    importing
      !IV_ZIP type XSTRING
      !IV_PATH type STRING
    returning
      value(RV_XML) type STRING .
  methods XLS_UPLOAD_DISPLAY_ERROR
    importing
      !IT_XLS_ERROR type TYT_XLS_ERROR .
  methods XLS_UPLOAD_FDT
    importing
      !IV_FILENAME type LOCALFILE
      !IV_SHEET_NAME type ANY
    returning
      value(RO_XLS_DATA) type ref to DATA .
  methods XLS_UPLOAD_OLE
    importing
      !IV_FILENAME type LOCALFILE
      !IV_START_ROW type I default 2
      !IV_START_COL type I default 1
      !IV_END_COL type I default 0
      !IV_SHEET_NAME type ANY default SPACE
      !IS_XLS_LAYOUT type ANY
    returning
      value(RO_EXCEL_DATA) type ref to DATA .
  methods XLS_UPLOAD_OLE_X
    importing
      !IV_FILENAME type LOCALFILE
      !IV_START_ROW type I
      !IV_START_COL type I
      !IV_SHEET_NAME type ANY
      !IV_DEL_TITLE type FLAG default SPACE
    returning
      value(RO_XLS_DATA) type ref to DATA .
ENDCLASS.



CLASS ZCL_ZMDM_MM_COMFUNC IMPLEMENTATION.


  METHOD add_icon.

    " check
    "  R : Report Selection Screen
    DATA: lv_icon    TYPE icon_d,
          lv_quick   TYPE ddtext,
          ls_functxt TYPE smp_dyntxt.

    IF iv_quick IS INITIAL.
      lv_quick = iv_text.
    ELSE.
      lv_quick = iv_quick.
    ENDIF.

    CASE iv_type.
      WHEN 'R'.
        IF iv_icon IS INITIAL.
          ls_functxt-text      = iv_text.
        ELSE.
          ls_functxt-icon_id   = iv_icon.
          ls_functxt-icon_text = iv_text.
        ENDIF.

        ls_functxt-quickinfo = lv_quick.
        rv_result            = ls_functxt.

      WHEN 'I'.
        rv_result = lv_icon.

      WHEN OTHERS.
        lv_quick = iv_quick.

        CALL FUNCTION 'ICON_CREATE'
          EXPORTING
            name                  = iv_icon
            text                  = iv_text
            info                  = lv_quick
          IMPORTING
            result                = rv_result
          EXCEPTIONS
            icon_not_found        = 1
            outputfield_too_short = 2
            OTHERS                = 3.

    ENDCASE.

  ENDMETHOD.


  METHOD add_listbox_domain.

    DATA: lv_domname    TYPE domname,
          lv_vrm_id     TYPE vrm_id,
          ls_vrm_value  TYPE vrm_value,
          lt_vrm_values TYPE vrm_values.

    lv_domname = iv_domain.
    lv_vrm_id  = iv_fieldname.

    SELECT domname,
           domvalue_l AS domvalue,
           ddtext
      FROM dd07v
     WHERE domname    = @lv_domname
       AND ddlanguage = @sy-langu
      INTO TABLE @DATA(lt_domain).
    CHECK sy-subrc = 0.

    LOOP AT lt_domain INTO DATA(ls_domain).
      ls_vrm_value-key     = ls_domain-domvalue.
      ls_vrm_value-text    = ls_domain-ddtext.
      APPEND ls_vrm_value TO lt_vrm_values.
    ENDLOOP.

    CALL FUNCTION 'VRM_SET_VALUES'
      EXPORTING
        id              = lv_vrm_id
        values          = lt_vrm_values
      EXCEPTIONS
        id_illegal_name = 1
        OTHERS          = 2.
    IF sy-subrc <> 0.
      EXIT.
    ENDIF.

    " screen control 이 활성화 되기전 listbox를 설정하면
    " ID 값이 다르게 들어감 ->
    ASSIGN ('(SAPLSVSM)VALUESETS') TO FIELD-SYMBOL(<lt_valuesets>).
    LOOP AT <lt_valuesets> ASSIGNING FIELD-SYMBOL(<ls_valuesets>) .
      ASSIGN ('<LS_VALUESETS>-ID') TO FIELD-SYMBOL(<lv_fld_id>).
      REPLACE ALL OCCURRENCES OF 'SAPMSSY0' IN <lv_fld_id> WITH gv_repid.
    ENDLOOP.

  ENDMETHOD.


  METHOD add_range.

    DATA: lo_range_table TYPE REF TO data.

    FIELD-SYMBOLS:
      <lv_sign>        TYPE any,
      <lv_option>      TYPE any,
      <lv_low>         TYPE any,
      <lv_high>        TYPE any,
      <lv_value>       TYPE any,
      <ls_range_work>  TYPE any,
      <lt_range_table> TYPE STANDARD TABLE.

*    CLEAR: <lt_range_table>[].
    DATA: lv_dtype,
          lv_dtype_r,
          lv_check_input,  " 입력값이 있는 경우
          lv_data_fr     TYPE string,
          lv_data_to     TYPE string.

    GET REFERENCE OF et_output INTO lo_range_table.
    ASSIGN lo_range_table->* TO <lt_range_table>.

    " 0. et_output -low field 의 type
    APPEND INITIAL LINE TO <lt_range_table> ASSIGNING <ls_range_work>.
    ASSIGN ('<LS_RANGE_WORK>-LOW')    TO <lv_low>.
    CHECK <lv_low> IS ASSIGNED.

    " low field type 확인
    DESCRIBE FIELD <lv_low>   TYPE lv_dtype_r.

*--------------------------------------------------------------------*
    "1. it_input으로 들어올 시
    IF it_input IS NOT INITIAL.
      LOOP AT it_input ASSIGNING FIELD-SYMBOL(<ls_work>).

        UNASSIGN: <lv_sign>, <lv_option>, <lv_low>, <lv_high>,
                  <ls_range_work>.

        APPEND INITIAL LINE TO <lt_range_table> ASSIGNING <ls_range_work>.
        ASSIGN ('<LS_RANGE_WORK>-SIGN')   TO <lv_sign>.
        ASSIGN ('<LS_RANGE_WORK>-OPTION') TO <lv_option>.
        ASSIGN ('<LS_RANGE_WORK>-LOW')    TO <lv_low>.
        ASSIGN ('<LS_RANGE_WORK>-HIGH')   TO <lv_high>.

        " value 값 설정
        IF iv_input_field IS NOT INITIAL.
          DATA(lv_value) = '<LS_WORK>-' && iv_input_field.
          ASSIGN (lv_value) TO <lv_value>.
          IF <lv_value> IS NOT ASSIGNED.
            CLEAR: <lt_range_table>.
            EXIT.
          ENDIF.

          DESCRIBE FIELD <lv_value> TYPE lv_dtype.
          IF lv_dtype = 'D' OR lv_dtype_r = 'D'.  " date type
            <lv_low> = me->ce_date_c( <lv_value> ).
          ELSE.
            <lv_low>  = <lv_value>.
          ENDIF.

        ELSE.
          DESCRIBE FIELD <lv_value> TYPE lv_dtype.
          IF lv_dtype = 'D' OR lv_dtype_r = 'D'.  " date type
            <lv_low> = me->ce_date_c( <ls_work> ).
          ELSE.
            <lv_low>  = <ls_work>.
          ENDIF.

        ENDIF.

        <lv_sign> = 'I'.

        FIND '*' IN <lv_low>.
        IF sy-subrc = 0.
          <lv_option> = 'CP'.
        ELSE.
          <lv_option> = 'EQ'.
        ENDIF.

      ENDLOOP.
    ENDIF.

*--------------------------------------------------------------------*
    "2. date 로 from~to 형태로 입력된 경우

    CLEAR: lv_dtype, lv_check_input.

    " input field 가 입력된 경우 date type 인지 여부
    IF iv_input_fr IS SUPPLIED.
      lv_check_input = abap_true.
      DESCRIBE FIELD iv_input_fr TYPE lv_dtype.
      IF lv_dtype = 'D' OR lv_dtype_r = 'D'.  " 입력이 D 이거나 range date type 이 D 인 경우
        lv_data_fr = me->ce_date_c( iv_input_fr ).
      ELSE.
        lv_data_fr = iv_input_fr.
      ENDIF.
    ENDIF.


    IF iv_input_to IS SUPPLIED.
      lv_check_input = abap_true.
      DESCRIBE FIELD iv_input_to TYPE lv_dtype.
      IF lv_dtype = 'D' OR lv_dtype_r = 'D'.  " date type
        lv_data_to = me->ce_date_c( iv_input_to ).
      ELSE.
        lv_data_to = iv_input_to.
      ENDIF.
    ENDIF.

    " input field 가 입력된경우
    IF lv_check_input = abap_true AND
       ( lv_data_fr IS NOT INITIAL OR lv_data_to IS NOT INITIAL ).
      APPEND INITIAL LINE TO <lt_range_table> ASSIGNING <ls_range_work>.
      ASSIGN ('<LS_RANGE_WORK>-SIGN')   TO <lv_sign>.
      ASSIGN ('<LS_RANGE_WORK>-OPTION') TO <lv_option>.
      ASSIGN ('<LS_RANGE_WORK>-LOW')    TO <lv_low>.
      ASSIGN ('<LS_RANGE_WORK>-HIGH')   TO <lv_high>.

      <lv_sign> = 'I'.
      " to 가 있는 경우는 BT로 처리
      IF lv_data_to IS NOT INITIAL .
        <lv_option> = 'BT'.
        <lv_low>  = lv_data_fr.
        <lv_high> = lv_data_to.

      ELSE.

        <lv_low>  = lv_data_fr.
        FIND '*' IN lv_data_fr.  " '*' 입력된 경우 CP
        IF sy-subrc = 0.
          <lv_option> = 'CP'.
        ELSE.
          <lv_option> = 'EQ'.
        ENDIF.

      ENDIF.

    ENDIF.
*--------------------------------------------------------------------*
    "3. input value 단일값인 경우
    IF iv_input_value IS NOT INITIAL.
      DESCRIBE FIELD iv_input_value TYPE lv_dtype.

      APPEND INITIAL LINE TO <lt_range_table> ASSIGNING <ls_range_work>.
      ASSIGN ('<LS_RANGE_WORK>-SIGN')   TO <lv_sign>.
      ASSIGN ('<LS_RANGE_WORK>-OPTION') TO <lv_option>.
      ASSIGN ('<LS_RANGE_WORK>-LOW')    TO <lv_low>.

      <lv_sign>   = 'I'.
      <lv_option> = 'EQ'.
      " 값설정 : 공백, 초기값 설정
      IF ( lv_dtype = 'C' AND iv_input_value = '!'        ) OR
         ( lv_dtype = 'D' AND iv_input_value < '19000101' ).
        CLEAR <lv_low>.
      ELSE.
        <lv_low> = iv_input_value.
      ENDIF.
    ENDIF.

*--------------------------------------------------------------------*

    DELETE <lt_range_table> WHERE ('SIGN = SPACE').
    SORT <lt_range_table> BY ('SIGN') ('OPTION') ('LOW') ('HIGH').
    DELETE ADJACENT DUPLICATES FROM <lt_range_table>
           COMPARING ALL FIELDS.

  ENDMETHOD.


  METHOD bdc_execute.

    CLEAR: rs_bdcmsg.
    CHECK gt_bdcdata IS NOT INITIAL.

    CALL TRANSACTION iv_tcode  USING         gt_bdcdata
                               OPTIONS FROM  gs_params
                               MESSAGES INTO gt_bdcmsg.

    " 성공 메시지가 있는 경우
    READ TABLE gt_bdcmsg INTO DATA(ls_bdcmsg) WITH KEY msgid  = iv_msgid
                                                       msgnr  = iv_msgno.
    IF sy-subrc = 0.
      rs_bdcmsg-type       = ls_bdcmsg-msgtyp.
      rs_bdcmsg-id         = ls_bdcmsg-msgid.
      rs_bdcmsg-number     = ls_bdcmsg-msgnr.
      rs_bdcmsg-message = me->get_message( iv_msgid = ls_bdcmsg-msgid
                                           iv_msgno = CONV symsgno( ls_bdcmsg-msgnr )
                                           iv_parm1 = ls_bdcmsg-msgv1
                                           iv_parm2 = ls_bdcmsg-msgv2
                                           iv_parm3 = ls_bdcmsg-msgv3
                                           iv_parm4 = ls_bdcmsg-msgv4 ).
      rs_bdcmsg-message_v1 = ls_bdcmsg-msgv1.
      rs_bdcmsg-message_v2 = ls_bdcmsg-msgv2.
      rs_bdcmsg-message_v3 = ls_bdcmsg-msgv3.
      rs_bdcmsg-message_v4 = ls_bdcmsg-msgv4.
      EXIT.
    ENDIF.

    " 메시지 tab 이 없는 경우
    IF gt_bdcmsg[] IS INITIAL.
      rs_bdcmsg-type = 'S'.
      " message check 하지 않음
      IF iv_msgid = 'XX' AND iv_msgno = '999'.
      ELSE.
        rs_bdcmsg-message = '결과 메시지가 없습니다.'.
      ENDIF.
      EXIT.
    ENDIF.

    "  경고 메시지가 있는 경우:ex) 삭제시 기 삭제된 경우 발생 메시지 등
    DATA(lv_exis_flag) = abap_false.
    LOOP AT gt_bdc_msg_i INTO DATA(ls_bed_msg).

      READ TABLE gt_bdcmsg INTO ls_bdcmsg WITH KEY msgid  = ls_bed_msg-msgid
                                                   msgnr  = ls_bed_msg-msgno.
      IF sy-subrc = 0.
        rs_bdcmsg-type       = 'I'.
        rs_bdcmsg-id         = ls_bdcmsg-msgid.
        rs_bdcmsg-number     = ls_bdcmsg-msgnr.
        rs_bdcmsg-message = me->get_message( iv_msgid = ls_bdcmsg-msgid
                                             iv_msgno = CONV symsgno( ls_bdcmsg-msgnr )
                                             iv_parm1 = ls_bdcmsg-msgv1
                                             iv_parm2 = ls_bdcmsg-msgv2
                                             iv_parm3 = ls_bdcmsg-msgv3
                                             iv_parm4 = ls_bdcmsg-msgv4 ).
        rs_bdcmsg-message_v1 = ls_bdcmsg-msgv1.
        rs_bdcmsg-message_v2 = ls_bdcmsg-msgv2.
        rs_bdcmsg-message_v3 = ls_bdcmsg-msgv3.
        rs_bdcmsg-message_v4 = ls_bdcmsg-msgv4.

        lv_exis_flag = abap_true.
        EXIT.
      ENDIF.

    ENDLOOP.
    CHECK lv_exis_flag = abap_false.

    " 마지막 에러 메시지 출력
    DATA(lv_rows) = lines( gt_bdcmsg ).
    DO lv_rows TIMES.

      DATA(lv_index) = ( lv_rows - sy-index ) + 1.
      READ TABLE gt_bdcmsg INTO ls_bdcmsg INDEX lv_index.
      IF sy-subrc NE 0.
        EXIT.
      ENDIF.

      CHECK ls_bdcmsg-msgtyp = 'E' OR ls_bdcmsg-msgtyp = 'A'.

      rs_bdcmsg-type       = 'E'.
      rs_bdcmsg-id         = ls_bdcmsg-msgid.
      rs_bdcmsg-number     = ls_bdcmsg-msgnr.
      rs_bdcmsg-message = me->get_message( iv_msgid = ls_bdcmsg-msgid
                                           iv_msgno = CONV symsgno( ls_bdcmsg-msgnr )
                                           iv_parm1 = ls_bdcmsg-msgv1
                                           iv_parm2 = ls_bdcmsg-msgv2
                                           iv_parm3 = ls_bdcmsg-msgv3
                                           iv_parm4 = ls_bdcmsg-msgv4 ).
      rs_bdcmsg-message_v1 = ls_bdcmsg-msgv1.
      rs_bdcmsg-message_v2 = ls_bdcmsg-msgv2.
      rs_bdcmsg-message_v3 = ls_bdcmsg-msgv3.
      rs_bdcmsg-message_v4 = ls_bdcmsg-msgv4.
      EXIT.
    ENDDO.
    CHECK rs_bdcmsg IS INITIAL.

    " 에러 메시지가 없는 경우 맨 마지막 메시지를 에러로 return 한다
    READ TABLE gt_bdcmsg INTO ls_bdcmsg INDEX lv_rows.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.

    rs_bdcmsg-type       = 'E'.
    rs_bdcmsg-id         = ls_bdcmsg-msgid.
    rs_bdcmsg-number     = ls_bdcmsg-msgnr.
    rs_bdcmsg-message = me->get_message( iv_msgid = ls_bdcmsg-msgid
                                         iv_msgno = CONV symsgno( ls_bdcmsg-msgnr )
                                         iv_parm1 = ls_bdcmsg-msgv1
                                         iv_parm2 = ls_bdcmsg-msgv2
                                         iv_parm3 = ls_bdcmsg-msgv3
                                         iv_parm4 = ls_bdcmsg-msgv4 ).
    rs_bdcmsg-message_v1 = ls_bdcmsg-msgv1.
    rs_bdcmsg-message_v2 = ls_bdcmsg-msgv2.
    rs_bdcmsg-message_v3 = ls_bdcmsg-msgv3.
    rs_bdcmsg-message_v4 = ls_bdcmsg-msgv4.


  ENDMETHOD.


  METHOD bdc_initialization.

    CLEAR: gt_bdcdata, gt_bdcmsg, gs_params.

    gs_params-dismode  = iv_mode.
    gs_params-updmode  = 'S'.
    gs_params-cattmode = ' '.
    gs_params-defsize  = ' '.
    gs_params-racommit = iv_racommit.
    gs_params-nobinpt  = iv_nobinpt. "space.
    gs_params-nobiend  = ' '. "SWITCH #( iv_mode when 'A' then space else 'X' ).

    CLEAR: gt_bdc_msg_i.

  ENDMETHOD.


  METHOD bdc_set_data.

    IF iv_dynbegin = abap_true.
      APPEND VALUE #( program   = iv_fname
                      dynpro    = iv_fvalue
                      dynbegin  = abap_true ) TO gt_bdcdata.
    ELSE.
      APPEND VALUE #( fnam   = iv_fname
                      fval   = iv_fvalue ) TO gt_bdcdata.
    ENDIF.

  ENDMETHOD.


  METHOD build_component_tab.


    FIELD-SYMBOLS: <c>       TYPE any,
                   <fs_name> TYPE any,
                   <fs_type> TYPE any,
                   <fs_tk>   TYPE any,
                   <fs_len>  TYPE any,
                   <fs_dec>  TYPE any,
                   <fs_inc>  TYPE any,
                   <fs_inct> TYPE REF TO cl_abap_structdescr,
                   <fs_suf>  TYPE abap_compname.

    CLEAR rt_compx.

    LOOP AT it_comps ASSIGNING <c>.
      DATA ls_x TYPE abap_componentdescr.

      " 이름
      ASSIGN COMPONENT 'NAME' OF STRUCTURE <c> TO <fs_name>.
      IF sy-subrc <> 0 OR <fs_name> IS INITIAL.
        CONTINUE.
      ENDIF.
      ls_x-name = CONV abap_compname( <fs_name> ).
      ls_x-type = cl_abap_elemdescr=>get_string( ).

      " 타입(가장 중요) : 원본 RTTI 레퍼런스를 그대로 사용
*****      ASSIGN COMPONENT 'TYPE' OF STRUCTURE <c> TO <fs_type>.
*****      IF sy-subrc = 0 AND <fs_type> IS NOT INITIAL.
*****        TRY.
*****            ls_x-type ?= <fs_type>.   " ← 상수 불필요
*****          CATCH cx_sy_move_cast_error.
*****            CONTINUE.                 " 타입 없으면 이 컴포넌트 스킵(또는 STRING으로 대체)
*****        ENDTRY.
*****      ELSE.
*****        CONTINUE.                     " TYPE이 없다면 정확 복제가 불가 → 스킵(또는 임의 대체)
*****      ENDIF.

      " AS_INCLUDE / INCLUDE_TYPE / SUFFIX (있으면 복사)
      ASSIGN COMPONENT 'AS_INCLUDE'   OF STRUCTURE <c> TO <fs_inc>.
      IF sy-subrc = 0. ls_x-as_include = <fs_inc>. ENDIF.

*****      ASSIGN COMPONENT 'INCLUDE_TYPE' OF STRUCTURE <c> TO <fs_inct> CASTING.
*****      IF sy-subrc = 0 AND <fs_inct> IS BOUND.
*****        ls_x-AS_INCLUDE = <fs_inct>. " ✅ 동일 타입 간 대입
*****      ENDIF.
*****
*****      ASSIGN COMPONENT 'SUFFIX'       OF STRUCTURE <c> TO <fs_suf>.
*****      IF sy-subrc = 0. ls_x-suffix = <fs_suf>. ENDIF.

      APPEND ls_x TO rt_compx.
    ENDLOOP.

  ENDMETHOD.


  METHOD call_cl03.

    CHECK iv_class IS NOT INITIAL AND
          iv_klart IS NOT INITIAL.

    SET PARAMETER ID 'KLA' FIELD iv_class.
    SET PARAMETER ID 'KAR' FIELD iv_klart.

    CALL TRANSACTION 'CL03' AND SKIP FIRST SCREEN.

  ENDMETHOD.


  METHOD call_ct04.

    CHECK iv_atnam IS NOT INITIAL.

    SET PARAMETER ID 'FEA' FIELD iv_atnam.

    CALL TRANSACTION 'CT06' AND SKIP FIRST SCREEN.

  ENDMETHOD.


  METHOD ce_alpha_i.

    DATA: lv_type     TYPE char1,
          lv_type_i   TYPE char1,
          lv_length   TYPE i,
          lv_length_i TYPE i,
          lo_data     TYPE REF TO data.

    FIELD-SYMBOLS:
      <lv_output> TYPE any.

*    CLEAR: rv_output.
    CHECK iv_input IS NOT INITIAL.

    IF iv_type IS INITIAL.
      DESCRIBE FIELD iv_input TYPE lv_type
                              LENGTH lv_length IN CHARACTER MODE.
    ELSE.
      lv_type   = iv_type+0(1).
      lv_length = iv_type+1.
    ENDIF.

*    DATA: lv_len TYPE i.
*    lv_len = strlen( rv_output ).
*    IF lv_len < lv_length.
*      rv_output = iv_input.
*      EXIT.
*    ENDIF.

    TRY.
        lo_data = me->create_data( EXPORTING iv_type = lv_type
                                             iv_len  = lv_length   ).
      CATCH cx_sy_create_data_error.
    ENDTRY.

    ASSIGN lo_data->* TO <lv_output>.

    DATA(lv_input) = CONV text132( iv_input ).
    SHIFT lv_input LEFT DELETING LEADING space.
    lv_length_i = strlen( lv_input ).
    IF lv_length_i = 0.
      CLEAR rv_output.
      EXIT.
    ENDIF.

    IF lv_length_i > lv_length.
      lv_length_i = lv_length.
    ENDIF.
    lv_input = lv_input+0(lv_length_i).

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = lv_input
      IMPORTING
        output = <lv_output>.

    rv_output = <lv_output>.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_alpha_o.

    DATA: lv_type   TYPE char1,
          lv_length TYPE i,
          lo_data   TYPE REF TO data,
          lo_type   TYPE REF TO cl_abap_typedescr.

    FIELD-SYMBOLS:
      <lv_output> TYPE any.

*    CLEAR: rv_output.
    CHECK iv_input IS NOT INITIAL.

    IF iv_type IS INITIAL.
*      DESCRIBE FIELD iv_input TYPE lv_type
*                              LENGTH lv_length IN CHARACTER MODE.
      lo_type   = cl_abap_typedescr=>describe_by_data( iv_input ).
      lv_type   = lo_type->type_kind.   "E/S/T/R/D/X 등
      lv_length = lo_type->length.
    ELSE.
      lv_type   = iv_type+0(1).
      lv_length = iv_type+1.
    ENDIF.

    CASE lv_type.
      WHEN 'I' OR 'P'.
        rv_output = iv_input.
        EXIT.
      WHEN OTHERS.
    ENDCASE.

    DATA: lv_len TYPE i.
    lv_len = strlen( iv_input ).
    IF lv_len > lv_length.
      rv_output = iv_input.
      EXIT.
    ENDIF.

    TRY.
        lo_data = me->create_data( EXPORTING iv_type = lv_type
                                             iv_len  = lv_length   ).
      CATCH cx_sy_create_data_error.
    ENDTRY.

    ASSIGN lo_data->* TO <lv_output>.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
      EXPORTING
        input  = iv_input
      IMPORTING
        output = <lv_output>.

    rv_output = <lv_output>.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_curr_i.

    DATA: lv_currency TYPE tcurc-waers,
          lv_amt_inc  TYPE char40,
          lv_amt_in   TYPE bapicurr-bapicurr,
          lv_amt_out  TYPE tyv_amt.

    CLEAR: rv_amt.

    CHECK iv_amt      IS NOT INITIAL AND
          iv_currency IS NOT INITIAL.

*  lv_amt_in   = iv_amt.
    lv_currency = iv_currency.
    me->ce_numc_i( EXPORTING  iv_input  = iv_amt
                   IMPORTING  ev_output = lv_amt_inc
                   EXCEPTIONS OTHERS    = 1 ).
    IF sy-subrc NE 0.
      RAISE not_numeric.
    ENDIF.

    " - 가 있는지 여부
    FIND '-' IN lv_amt_inc.
    IF sy-subrc = 0.
      DATA(lv_minus) = 'X'.
      REPLACE ALL OCCURRENCES OF '-' IN lv_amt_inc WITH ''.
    ELSE.
      lv_minus = space.
    ENDIF.

    lv_amt_in = lv_amt_inc.
    CALL FUNCTION 'BAPI_CURRENCY_CONV_TO_INTERNAL'
      EXPORTING
        currency             = lv_currency
        amount_external      = lv_amt_in
        max_number_of_digits = 23
      IMPORTING
        amount_internal      = lv_amt_out
      EXCEPTIONS
        OTHERS               = 1.
    IF sy-subrc NE 0.
      RAISE not_numeric.
    ENDIF.

    IF lv_minus = 'X'.
      rv_amt = lv_amt_out * '-1'.
    ELSE.
      rv_amt = lv_amt_out.
    ENDIF.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_curr_o.

    DATA: lv_amt_out  TYPE char30,
          lv_amt_in   TYPE dmbtr,
          lv_currency TYPE waers.

    CLEAR: rv_amt.

    CHECK iv_amt      IS NOT INITIAL AND
          iv_currency IS NOT INITIAL.

    lv_currency = iv_currency.
    lv_amt_in   = iv_amt.
    WRITE lv_amt_in      TO lv_amt_out CURRENCY lv_currency LEFT-JUSTIFIED.

    me->ce_numc_o( EXPORTING iv_input  = lv_amt_out
                   IMPORTING ev_output = rv_amt ).

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_date_c.

    IF iv_date IS INITIAL OR iv_date <= '19000101'.
      CLEAR: rv_date.
    ELSE.
      rv_date = me->ce_date_i( iv_date ).
    ENDIF.

  ENDMETHOD.


  METHOD ce_date_i.

    DATA: lv_date TYPE char20.
    lv_date = iv_input.

    " 구분자 제거
    REPLACE ALL OCCURRENCES OF '-' IN lv_date WITH ''.
    REPLACE ALL OCCURRENCES OF '/' IN lv_date WITH ''.
    REPLACE ALL OCCURRENCES OF '.' IN lv_date WITH ''.

    CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
      EXPORTING
        date_external            = lv_date
        accept_initial_date      = space
      IMPORTING
        date_internal            = rv_output
      EXCEPTIONS
        date_external_is_invalid = 1
        OTHERS                   = 2.
    IF sy-subrc NE 0.
      rv_output = iv_input.
    ENDIF.

**    DATA: lv_len TYPE i.
**
**    CLEAR: rv_date.
**    lv_len = me->strlenx( iv_date ).
**    CHECK lv_len = 8 OR lv_len = 9 OR lv_len = 10.
**
**    " 입력된 date format 점검
***    IF ( iv_date+0(4) BETWEEN '2000' AND '2299' ) OR iv_date_default = abap_true.
***      IF lv_len = 8.
***        rv_date = iv_date+0(4) && iv_date+4(2) && iv_date+6(2).
***      ELSE.
***        rv_date = iv_date+0(4) && iv_date+5(2) && iv_date+8(2).
***      ENDIF.
***
***    ELSEIF lv_len = 8  AND ( iv_date+4(4) BETWEEN '2000' AND '2299' ).
***      rv_date = iv_date+4(4) && iv_date+0(2) && iv_date+2(2).
***
***    ELSEIF lv_len = 9 AND ( iv_date+5(4) BETWEEN '2000' AND '2299' ).
***      rv_date = iv_date+5(4) && iv_date+0(2) && '0' && iv_date+3(1).
***
***    ELSEIF lv_len = 10 AND ( iv_date+6(4) BETWEEN '2000' AND '2299' ).
***      rv_date = iv_date+6(4) && iv_date+0(2) && iv_date+3(2).
***
***    ELSE.
**    CASE gs_user_info-date_format.
**      WHEN '2' OR '3'. " MM/DD/YYYY -> YYYYMMDD
**        IF lv_len = 8.
**          rv_date = iv_date+4(4) && iv_date+0(2) && iv_date+2(2).
**        ELSE.
**          rv_date = iv_date+6(4) && iv_date+0(2) && iv_date+3(2).
**        ENDIF.
**      WHEN '4' OR '5' OR '6'. " YYYY.MM.DD -> YYYYMMDD
**        IF lv_len = 8.
**          rv_date = iv_date+0(4) && iv_date+4(2) && iv_date+6(2).
**        ELSE.
**          rv_date = iv_date+0(4) && iv_date+5(2) && iv_date+8(2).
**        ENDIF.
**      WHEN OTHERS. " DD.MM.YYYY, DDMMYYYY -> YYYYMMDD
**        IF lv_len = 8.
**          rv_date = iv_date+4(4) && iv_date+2(2) && iv_date+0(2).
**        ELSE.
**          rv_date = iv_date+6(4) && iv_date+3(2) && iv_date+0(2).
**        ENDIF.
**    ENDCASE.
***    ENDIF.

  ENDMETHOD.


  METHOD ce_date_o.

    CLEAR: rv_output.
    CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
      EXPORTING
        date_internal            = me->ce_date_i( iv_input )
      IMPORTING
        date_external            = rv_output
      EXCEPTIONS
        date_internal_is_invalid = 1
        OTHERS                   = 2.

  ENDMETHOD.


  METHOD ce_date_time.

    DATA: lv_date_c TYPE string,
          lv_time_c TYPE string.

    CLEAR: rv_output.
    CHECK iv_date IS NOT INITIAL.

    IF NOT iv_type CO sy-abcde.
      CHECK iv_time IS NOT INITIAL.
    ENDIF.

    lv_date_c = me->ce_date_o( iv_date ).
    lv_time_c = me->ce_time_o( iv_time ).

    " iv_type
    "  1: yyyy 년 mm 월 dd 일 hh 시 mm 분
    "  9: yyyy-mm-dd hh:mm

    CASE iv_type.
      WHEN '1'.
        rv_output = |{ lv_date_c+0(4) }년 { lv_date_c+5(2) }월 { lv_date_c+8(2) }일 {
                       lv_time_c+0(2) }시 { lv_time_c+3(2) }분 |.
      WHEN '9'.
        rv_output = |{ lv_date_c+0(4) }-{ lv_date_c+5(2) }-{ lv_date_c+8(2) } {
                       lv_time_c+0(2) }:{ lv_time_c+3(2) }|.

      WHEN 'A'.
        rv_output = |{ lv_date_c+0(4) }년 { lv_date_c+5(2) }월 { lv_date_c+8(2) }일|.
      WHEN OTHERS.
    ENDCASE.


  ENDMETHOD.


  METHOD ce_matnr_unit_qty.

    DATA: lv_matnr    TYPE mara-matnr,
          lv_in_qty   TYPE ekpo-menge,
          lv_in_unit  TYPE mara-meins,
          lv_out_unit TYPE mara-meins.

    CLEAR: rv_out_qty.
    CHECK iv_matnr IS NOT INITIAL AND
          iv_in_qty > 0.

    IF iv_in_unit = iv_out_unit.
      rv_out_qty = iv_in_qty.
      EXIT.
    ENDIF.

    lv_matnr    = iv_matnr.
    lv_in_qty   = iv_in_qty.
    lv_in_unit  = iv_in_unit.
    lv_out_unit = iv_out_unit.

    CALL FUNCTION 'MD_CONVERT_MATERIAL_UNIT'
      EXPORTING
        i_matnr              = lv_matnr " 자재코드
        i_in_me              = lv_in_unit
        i_out_me             = lv_out_unit
        i_menge              = lv_in_qty    " 입력수량
      IMPORTING
        e_menge              = rv_out_qty " 자재단위 변경수량
      EXCEPTIONS
        error_in_application = 1
        error                = 2
        OTHERS               = 3.

    IF sy-subrc NE 0.
      CLEAR: rv_out_qty.
    ENDIF.

  ENDMETHOD.


  METHOD ce_numc_i.

    DATA: lv_mcnt            TYPE i,
          lv_numc_input      TYPE string,
          lv_numc_f          TYPE string,
          lv_numc_b          TYPE string,
          lv_numc_output(30),
          lv_minus           TYPE flag,
          lv_dec_point       TYPE c,
          lv_comma           TYPE c.

*    CLEAR: ev_output.
    CHECK iv_input IS NOT INITIAL.

    lv_numc_input = iv_input.

    " number format : gs_user_info-number_format
    CASE gs_user_info-number_format.
      WHEN space."   : 1.234.567,89
        lv_dec_point = ','.
        lv_comma     = '.'.
      WHEN 'X'." X :  1,234,567.89
        lv_dec_point = '.'.
        lv_comma     = ','.
      WHEN OTHERS. " Y :  1 234 567,89
        lv_dec_point = ','.
        lv_comma     = ' '.
    ENDCASE.

    " 입력값이 지수인 경우
*****    DATA(lv_txt1) = |2.3E-2|.
*****    DATA(lv_txt2) = |3.3000000000000002E-2|.
*****
*****    DATA lv_dec34 TYPE decfloat34.
*****    DATA lv_p10   TYPE p LENGTH 16 DECIMALS 10.
*****
*****    TRY.
*****        " 1) 문자열 → decfloat34 (지수 인식)
*****        lv_dec34 = CONV decfloat34( lv_txt1 ).  " 0.023
*****
*****        " 2) decfloat34 → PACKED 로 변환
*****        lv_p10 = lv_dec34.       " ex) 0.0230000000
*****
*****      CATCH cx_sy_conversion_no_number INTO DATA(lx_conv).
*****        " 잘못된 형식일 때 처리
*****        " MESSAGE lx_conv->get_text( ) TYPE 'E'.
*****    ENDTRY.

    SPLIT lv_numc_input AT lv_dec_point INTO lv_numc_f lv_numc_b.
    REPLACE ALL OCCURRENCES OF `"`      IN lv_numc_f WITH ''.
    REPLACE ALL OCCURRENCES OF lv_comma IN lv_numc_f WITH ''.
    CONDENSE lv_numc_f NO-GAPS.

    IF lv_numc_b IS INITIAL.
      lv_numc_b     = '0'.
      lv_numc_input = lv_numc_f.
    ELSE.
      CONCATENATE lv_numc_f '.' lv_numc_b INTO lv_numc_input.
    ENDIF.

    CONDENSE lv_numc_input NO-GAPS.

*  CALL FUNCTION 'CATS_NUMERIC_INPUT_CHECK'
*    EXPORTING
*      input      = lv_numc_input
*    EXCEPTIONS
*      no_numeric = 1
*      OTHERS     = 2.
*  IF sy-subrc NE 0.
    IF NOT lv_numc_input CO ' 0123456789-.'.
      RAISE not_numeric.
    ENDIF.

    " '.', '-' 가 1개 이상인 경우
    FIND ALL OCCURRENCES OF lv_dec_point IN lv_numc_input MATCH COUNT lv_mcnt.
    IF lv_mcnt > 1.
      RAISE not_numeric.
    ENDIF.

    FIND ALL OCCURRENCES OF '-' IN lv_numc_input MATCH COUNT lv_mcnt.
    IF lv_mcnt > 1.
      RAISE not_numeric.
    ENDIF.

    FIND '-' IN lv_numc_input.
    IF sy-subrc = 0.
      lv_minus = 'X'.
      REPLACE ALL OCCURRENCES OF '-' IN lv_numc_input WITH ''.
    ELSE.
      lv_minus = space.
    ENDIF.

    WRITE lv_numc_input TO lv_numc_output  LEFT-JUSTIFIED.
    CONDENSE lv_numc_output NO-GAPS.

    IF lv_minus = 'X'.
      CONCATENATE lv_numc_output '-' INTO lv_numc_output.
    ENDIF.

    DATA: lv_type TYPE char1.
    DESCRIBE FIELD ev_output TYPE lv_type.
    CASE lv_type.
      WHEN 'N' OR 'n'.
        me->ce_numc_o( EXPORTING iv_input  = lv_numc_output
                       IMPORTING ev_output = ev_output ).
      WHEN OTHERS.  ev_output = lv_numc_output.
    ENDCASE.


  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_numc_o.

    DATA: lv_mcnt            TYPE i,
          lv_numc_input      TYPE string,
          lv_numc_f          TYPE string,
          lv_numc_b          TYPE string,
          lv_numc_output(30),
          lv_minus           TYPE flag,
          lv_dec_point       TYPE c,
          lv_comma           TYPE c.

*    CLEAR: ev_output.

    IF iv_input IS INITIAL.
      ev_output = 0.
      EXIT.
    ENDIF.

    lv_numc_input = iv_input.

    " number format : gs_user_info-number_format
    CASE gs_user_info-number_format.
      WHEN space."   : 1.234.567,89
        lv_dec_point = ','.
        lv_comma     = '.'.
      WHEN 'X'." X :  1,234,567.89
        lv_dec_point = '.'.
        lv_comma     = ','.
      WHEN OTHERS. " Y :  1 234 567,89
        lv_dec_point = ','.
        lv_comma     = ' '.
    ENDCASE.

    SPLIT lv_numc_input AT lv_dec_point INTO lv_numc_f lv_numc_b.
    REPLACE ALL OCCURRENCES OF `"`      IN lv_numc_f WITH ''.
    REPLACE ALL OCCURRENCES OF lv_comma IN lv_numc_f WITH ''.
    CONDENSE lv_numc_f NO-GAPS.

    CONCATENATE lv_numc_f '.' lv_numc_b INTO lv_numc_input.
    CONDENSE lv_numc_input NO-GAPS.

    IF NOT lv_numc_input CO '0123456789-. '.
      RAISE not_numeric.
      EXIT.
    ENDIF.

    " '.' 가 1개 이상인 경우
    FIND ALL OCCURRENCES OF lv_dec_point IN lv_numc_input MATCH COUNT lv_mcnt.
    IF lv_mcnt > 1.
      EXIT.
    ENDIF.

    DATA: lv_spl01     TYPE char30,
          lv_spl02     TYPE char30,
          lv_spl01p(7) TYPE p,
          lv_pos       TYPE i,
          lv_len       TYPE i.

    " '-' 가 1개 이상인 경우
    FIND ALL OCCURRENCES OF '-' IN lv_numc_input MATCH COUNT lv_mcnt.
    IF lv_mcnt > 1.
      EXIT.
    ELSEIF lv_mcnt = 1.
      lv_pos = strlen( lv_numc_input ) - 1.
      IF lv_numc_input+0(1) = '-' OR lv_numc_input+lv_pos(1) = '-'.
      ELSE.
        EXIT.
      ENDIF.

      lv_minus = 'X'.
      REPLACE ALL OCCURRENCES OF '-' IN lv_numc_input WITH ''.
    ELSE.
      lv_minus = space.
    ENDIF.

    SHIFT lv_numc_input LEFT DELETING LEADING `0`.
    WRITE lv_numc_input TO lv_numc_output  LEFT-JUSTIFIED.
    CONDENSE lv_numc_output NO-GAPS.

    SPLIT lv_numc_output AT '.' INTO lv_spl01 lv_spl02.

    lv_len = strlen( lv_spl02 ).
    DO lv_len TIMES.
      lv_pos = lv_len - sy-index.
      IF lv_spl02+lv_pos(1) = '0'.
        CLEAR: lv_spl02+lv_pos(1).
      ELSE.
        EXIT.
      ENDIF.
    ENDDO.

    " 입력된 소숫점 길이가 있는 경우 : 생성된 소숫점이 작은경우
    IF iv_decimal_len > 0 AND
       iv_decimal_len > strlen( lv_spl02 ) .
      lv_len = iv_decimal_len - strlen( lv_spl02 ).
      DO lv_len TIMES.
        lv_spl02 = |{ lv_spl02 }0|.
      ENDDO.

    ENDIF.

    DATA: lv_len_n TYPE i.
    lv_len = strlen( lv_spl01 ).
    DO lv_len TIMES.
      lv_pos = sy-index - 1.
      IF lv_spl01+lv_pos(1) = '0'.
        lv_len_n = strlen( lv_spl01 ).
        IF lv_len_n = 1.
          EXIT.
        ELSE.
          CLEAR: lv_spl01+lv_pos(1).
        ENDIF.
      ELSE.
        EXIT.
      ENDIF.
    ENDDO.

    IF lv_spl01 IS INITIAL.
      lv_spl01 = '0'.
    ENDIF.

    IF iv_comma = abap_true.
      lv_spl01p = lv_spl01.
      WRITE lv_spl01p TO lv_spl01 LEFT-JUSTIFIED.
    ENDIF.

    " 소숫점
    IF lv_spl02 IS INITIAL.
      ev_output      = lv_spl01.
      ev_decimal_len = 0.
    ELSE.
      CONCATENATE lv_spl01 lv_dec_point lv_spl02 INTO ev_output.
      ev_decimal_len = strlen( lv_spl02 ).
    ENDIF.
    CONDENSE ev_output NO-GAPS.

    IF lv_minus = 'X'.
      CONCATENATE '-' ev_output INTO ev_output.
    ENDIF.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_spras_i.

    DATA: lv_laiso TYPE t002-laiso.

    CHECK iv_input IS NOT INITIAL.

    CLEAR: rv_output.

    lv_laiso = iv_input.

    IF lv_laiso+1(1) NE space.  " 입력값이 2자리인 경우
      TRANSLATE lv_laiso TO UPPER CASE.                   "#EC SYNTCHAR
      SELECT SINGLE spras FROM t002 WHERE laiso = @lv_laiso
        INTO @rv_output.
    ELSE. " 입력값이 1자리인 경우
      SELECT SINGLE spras FROM t002 WHERE spras = @lv_laiso
        INTO @rv_output.
    ENDIF.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_spras_o.

    DATA: lv_laiso TYPE t002-laiso,
          ls_t002t TYPE t002t.

    CHECK iv_input IS NOT INITIAL.

    CLEAR: rv_output.

    lv_laiso = iv_input.

    IF lv_laiso+1(1) NE space.  " 입력값이 2자리인 경우
      TRANSLATE lv_laiso TO UPPER CASE.                   "#EC SYNTCHAR
      rv_output = lv_laiso.

    ELSE. " 입력값이 1자리인 경우
      SELECT SINGLE laiso FROM t002 WHERE spras = @lv_laiso
        INTO @rv_output.
    ENDIF.

    " 언어 text 로 변경
    CASE iv_type.
      WHEN '2'.
        SELECT SINGLE t~sptxt
          FROM t002 AS a
               INNER JOIN t002t AS t ON  t~spras = @sy-langu
                                     AND t~sprsl = a~spras
        WHERE a~laiso = @rv_output
         INTO @rv_output.
      WHEN OTHERS.
    ENDCASE.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_string_to_table.

    DATA: lt_string TYPE string_table,
          ls_tline  TYPE tline,
          lt_tline  TYPE TABLE OF tline.


    CLEAR rt_textline.
    CHECK iv_text IS NOT INITIAL.

    APPEND iv_text TO lt_string.

    CALL FUNCTION 'CONVERT_STREAM_TO_ITF_TEXT'
      EXPORTING
        stream_lines = lt_string
*       LANGUAGE     = SY-LANGU
        lf           = abap_true
        iv_fw        = iv_text_len
*       IV_LW        = 132
      TABLES
*       TEXT_STREAM  =
        itf_text     = lt_tline.

    LOOP AT lt_tline INTO ls_tline.
      APPEND ls_tline-tdline TO rt_textline.
    ENDLOOP.

  ENDMETHOD.


  METHOD ce_time_i.

    DATA: lv_time_input(50) TYPE c,
          lv_time_output    LIKE sy-timlo.

    DATA: lv_time1 TYPE char20,
          lv_time2 TYPE char20,
          lv_time3 TYPE char20,  " 구분자
          lv_time4 TYPE char20,  " 시간
          lv_timen TYPE numc06.

    IF iv_input = space.
      rv_output = iv_input.
      EXIT.
    ENDIF.

    lv_time_input = me->ce_time_o( iv_input = iv_input ).
    IF lv_time_input IS INITIAL.
      rv_output = iv_input.
      EXIT.
    ENDIF.

    REPLACE ALL OCCURRENCES OF ':' IN lv_time_input WITH ''.

    rv_output = lv_time_input.

  ENDMETHOD.


  METHOD ce_time_o.

    DATA: lv_time_input(50) TYPE c,
          lv_time_output    LIKE sy-timlo.

    DATA: lv_len   TYPE i,
          lv_time1 TYPE char20,
          lv_time2 TYPE char20,
          lv_time3 TYPE char20,  " 구분자
          lv_time4 TYPE char20,  " 시간
          lv_timen TYPE numc06.

    CLEAR: rv_output.
    lv_time_input = iv_input.

    IF iv_input = space.
      CASE iv_type.
        WHEN '1'. rv_output = '00'.
        WHEN '2'. rv_output = '00:00'.
        WHEN OTHERS.
      ENDCASE.
      EXIT.
    ENDIF.

    IF NOT lv_time_input CO '0123456789:/-.,AMPM오전오후 '.
      EXIT.
    ENDIF.

    " 오전,오후, AM, PM 분리
    SPLIT lv_time_input AT space INTO lv_time1 lv_time2.
    TRANSLATE lv_time1 TO UPPER CASE.
    TRANSLATE lv_time2 TO UPPER CASE.

    IF lv_time1 = 'AM' OR lv_time1 = 'PM' OR lv_time1 = '오전' OR lv_time1 = '오후'.
      lv_time4      = lv_time1.
      lv_time_input = lv_time2.

    ELSEIF lv_time2 = 'AM' OR lv_time2 = 'PM' OR lv_time2 = '오전' OR lv_time2 = '오후'.
      lv_time4      = lv_time2.
      lv_time_input = lv_time1.

    ELSE.
      lv_time4      = space.

    ENDIF.

    REPLACE ALL OCCURRENCES OF ':'      IN lv_time_input WITH ` `.
    REPLACE ALL OCCURRENCES OF '.'      IN lv_time_input WITH ` `.
    REPLACE ALL OCCURRENCES OF '/'      IN lv_time_input WITH ` `.
    REPLACE ALL OCCURRENCES OF ','      IN lv_time_input WITH ` `.
    REPLACE ALL OCCURRENCES OF '-'      IN lv_time_input WITH ` `.

    " 시, 분, 초 분리
    SPLIT lv_time_input AT space INTO lv_time1 lv_time2 lv_time3.

    " 시간변경
    lv_len = me->strlenx( lv_time1 ).
    CASE lv_len.
      WHEN 1. " 시간 1자리
        lv_time1 = '0' && lv_time1+0(1).

        IF lv_time2 IS INITIAL.
          lv_time2 = '00'.
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = '00'.
        ENDIF.

      WHEN 2. " 시간 2자리
        IF lv_time2 IS INITIAL.
          lv_time2 = '00'.
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = '00'.
        ENDIF.

      WHEN 3. " 시간 1 + 분 2
        IF lv_time2 IS INITIAL.
          lv_time2 = lv_time1+1(2).
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = '00'.
        ENDIF.

        lv_time1 = '0' && lv_time1+0(1).

      WHEN 4. " 시간 2 + 분 2
        IF lv_time2 IS INITIAL.
          lv_time2 = lv_time1+2(2).
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = '00'.
        ENDIF.

        lv_time1 = lv_time1+0(2).

      WHEN 5. " 시간 2 + 분 2 + 초 1
        IF lv_time2 IS INITIAL.
          lv_time2 = lv_time1+2(2).
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = lv_time1+4(1) && '0'.
        ENDIF.

        lv_time1 = lv_time1+0(2).

      WHEN OTHERS. " 시간 2 + 분 2 + 초 2
        IF lv_time2 IS INITIAL.
          lv_time2 = lv_time1+2(2).
        ENDIF.
        IF lv_time3 IS INITIAL.
          lv_time3 = lv_time1+4(2).
        ENDIF.

        lv_time1 = lv_time1+0(2).
    ENDCASE.

    " 분을 2단위로
    lv_len = me->strlenx( lv_time2 ).
    CASE lv_len.
      WHEN 0.     lv_time2 = '00'.
      WHEN 1.     lv_time2 = lv_time2 && '0'.
      WHEN OTHERS.lv_time2 = lv_time2+0(2).
    ENDCASE.

    " 초를 2단위로
    lv_len = me->strlenx( lv_time3 ).
    CASE lv_len.
      WHEN 0.     lv_time3 = '00'.
      WHEN 1.     lv_time3 = lv_time3 && '0'.
      WHEN OTHERS.lv_time3 = lv_time3+0(2).
    ENDCASE.

    IF lv_time4 = '오후' OR lv_time4 = 'PM'.
      IF lv_len = 1.
      ENDIF.

      lv_time1+0(2) = lv_time1+0(2) + 12.
      IF lv_time1+0(2) = '24'.
        lv_time1+0(2) = '00'.
      ENDIF.
    ENDIF.

    CASE iv_type.
      WHEN '1'.    rv_output = |{ lv_time1 }|.
      WHEN '2'.    rv_output = |{ lv_time1 }:{ lv_time2 }|.
      WHEN OTHERS. rv_output = |{ lv_time1 }:{ lv_time2 }:{ lv_time3 }|.
    ENDCASE.


  ENDMETHOD.


  METHOD ce_tnum_i.

    DATA: lv_time TYPE numc06,
          lv_hh   TYPE numc2,
          lv_mm   TYPE numc2,
          lv_ss   TYPE numc2.

    CLEAR: rv_output.

    DATA(lv_time_out) = me->ce_time_o( iv_input = iv_input ).
    CHECK lv_time_out IS NOT INITIAL.

    REPLACE ALL OCCURRENCES OF ':' IN lv_time_out WITH ''.
    lv_time = lv_time_out.

    lv_hh = lv_time+0(2).
    lv_mm = lv_time+2(2).
    lv_ss = lv_time+4(2).

    rv_output = ( lv_hh * 3600 ) + ( lv_mm * 60 ) + lv_ss.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_tnum_o.

    DATA: lv_time TYPE i,
          lv_mod  TYPE i,
          lv_hh   TYPE numc2,
          lv_mm   TYPE numc2,
          lv_ss   TYPE numc2.

    lv_time =  iv_input.

    IF lv_time > 86399 OR lv_time = 0.
      rv_output = '000000'.
      EXIT.
    ENDIF.

    lv_hh = round( val  = lv_time / 3600
                   dec  = 0
                   mode = cl_abap_math=>round_down ).
    lv_mod = lv_time MOD 3600.

    lv_mm = round( val  = lv_mod / 60
                   dec  = 0
                   mode = cl_abap_math=>round_down ).

    lv_ss = lv_mod MOD 60.

    rv_output = lv_hh && lv_mm && lv_ss.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_tnum_t.

    DATA: lv_timec TYPE char30,
          lv_hour  TYPE char30,
          lv_min   TYPE char30,
          lv_mini  TYPE i.

    CLEAR: rv_output.
    CHECK iv_input IS NOT INITIAL.

    me->ce_numc_o( EXPORTING  iv_input  = iv_input
                   IMPORTING  ev_output = lv_timec
                   EXCEPTIONS not_numeric = 1
                              OTHERS   = 2 ).
    IF sy-subrc <> 0.
      EXIT.
    ENDIF.

    SPLIT lv_timec AT '.' INTO lv_hour lv_min.

    IF lv_hour <> '0'.
      rv_output = |{ lv_hour }{ TEXT-mhr }|. " 시간
    ENDIF.

    IF lv_min <> '0' AND lv_min IS NOT INITIAL.
      lv_min = '0.' && lv_min.
      lv_mini = round( val = lv_min * 60
                       dec = 0
                       mode = cl_abap_math=>round_up ).
      IF rv_output IS INITIAL.
        rv_output = |{ lv_mini }{ TEXT-mmi }|. " 분
      ELSE.
        rv_output = |{ rv_output } { lv_mini }{ TEXT-mmi }|. " 분
      ENDIF.
    ENDIF.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_unit_i.

    DATA: lv_unit  TYPE char10,
          lv_langu TYPE sy-langu.

    IF iv_langu IS INITIAL.
      lv_langu = sy-langu.
    ELSE.
      lv_langu = iv_langu.
    ENDIF.

    CHECK iv_unit IS NOT INITIAL.

    lv_unit = iv_unit.
    CALL FUNCTION 'CONVERSION_EXIT_CUNIT_INPUT'
      EXPORTING
        input          = lv_unit
        language       = lv_langu
      IMPORTING
        output         = rv_unit
      EXCEPTIONS
        unit_not_found = 1
        OTHERS         = 2.
    IF sy-subrc <> 0.
      rv_unit = lv_unit.
    ENDIF.

  ENDMETHOD.                    "CE_DATE_I


  METHOD ce_unit_o.

    DATA: lv_unit  TYPE char10,
          lv_langu TYPE sy-langu.

    IF iv_langu IS INITIAL.
      lv_langu = sy-langu.
    ELSE.
      lv_langu = iv_langu.
    ENDIF.

    CHECK iv_unit IS NOT INITIAL.

    lv_unit = iv_unit.
    CALL FUNCTION 'CONVERSION_EXIT_CUNIT_OUTPUT'
      EXPORTING
        input          = lv_unit
        language       = lv_langu
      IMPORTING
        output         = rv_unit
      EXCEPTIONS
        unit_not_found = 1
        OTHERS         = 2.
    IF sy-subrc <> 0.
      rv_unit = iv_unit.
    ENDIF.

  ENDMETHOD.                    "CE_UNIT_O


  METHOD check_file_name.

    DATA: lv_result   TYPE abap_bool,
          lv_filename TYPE string.

    rv_error_flag = space.
    lv_filename   = iv_filename.

    CALL METHOD cl_gui_frontend_services=>file_exist
      EXPORTING
        file                 = lv_filename
      RECEIVING
        result               = lv_result
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        wrong_parameter      = 3
        not_supported_by_gui = 4
        OTHERS               = 5.
    IF sy-subrc <> 0 OR lv_result = space.
      " Selected file does not exist.
      CASE iv_msg_type.
        WHEN 'I'.
          MESSAGE i000(oo) WITH '선택한 파일이 존재하지 않습니다.('
                            iv_filename ')'.
        WHEN 'X'.
        WHEN OTHERS.
          MESSAGE s000(oo) WITH '선택한 파일이 존재하지 않습니다.('
                            iv_filename ')'
                           DISPLAY LIKE 'E'.
      ENDCASE.
      rv_error_flag = 'X'.
    ENDIF.

  ENDMETHOD.                    "CHECK_FILE_NAME


  METHOD check_mail_address.

    DATA: ls_addr TYPE sx_address.

    CLEAR: rv_type.

    CHECK iv_email IS NOT INITIAL OR  " 입력값이 있는 경우
          it_email IS NOT INITIAL.

    IF iv_email IS NOT INITIAL.
      ls_addr-type    = 'INT'.
      ls_addr-address = iv_email.

      CALL FUNCTION 'SX_INTERNET_ADDRESS_TO_NORMAL'
        EXPORTING
          address_unstruct    = ls_addr
*         COMPLETE_ADDRESS    = 'X'
*     IMPORTING
*         ADDRESS_NORMAL      =
*         LOCAL               =
*         DOMAIN              =
*         COMMENT             =
*         ADDR_NORMAL_NO_UPPER                 =
*         ADDR_NORMAL_NO_UP_WITH_COMMENT       =
        EXCEPTIONS
          error_address_type  = 1
          error_address       = 2
          error_group_address = 3
          OTHERS              = 4.
      IF sy-subrc <> 0.
        rv_type = 'E'.
        EXIT.
      ENDIF.
    ENDIF.

    " table 내에 있는 e-mail check
    LOOP AT it_email INTO DATA(ls_input).

      CHECK ls_input-zemail IS NOT INITIAL.

      ls_addr-type    = 'INT'.
      ls_addr-address = ls_input-zemail.
      CALL FUNCTION 'SX_INTERNET_ADDRESS_TO_NORMAL'
        EXPORTING
          address_unstruct    = ls_addr
*         COMPLETE_ADDRESS    = 'X'
*     IMPORTING
*         ADDRESS_NORMAL      =
*         LOCAL               =
*         DOMAIN              =
*         COMMENT             =
*         ADDR_NORMAL_NO_UPPER                 =
*         ADDR_NORMAL_NO_UP_WITH_COMMENT       =
        EXCEPTIONS
          error_address_type  = 1
          error_address       = 2
          error_group_address = 3
          OTHERS              = 4.
      IF sy-subrc <> 0.
        rv_type = 'E'.
        EXIT.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD check_message.

    DATA: lv_title   TYPE bapi_msg,
          lv_text1   TYPE bapi_msg,
          lv_text2   TYPE bapi_msg,
          lv_parm1   TYPE bapi_msg,
          lv_message TYPE bapi_msg.

    IF sy-batch = abap_true.
      rv_check = abap_true.
      EXIT.
    ENDIF.

    CASE iv_msg.
      WHEN 'E' OR 'EX'.
        " 작업종료 확인
        " 작업을 종료 하시겠습니까? 변경된 자료는 저장되지 않습니다.
*        lv_title = 'Confirm task completion'.
*        lv_text1 = 'Do you want to end the task? Changed data will not be saved?'.
        lv_title = TEXT-exc.
        lv_text1 = TEXT-exm.
        lv_text2 = TEXT-exn.

      WHEN 'R' OR 'R0'.
        "'화면갱신 확인'.
        " '화면을 갱신 하시겠습니까? 변경된 자료는 저장되지 않습니다'.
*        lv_title = 'Refresh Confirm'.
*        lv_text1 = 'Would you like to refresh the screen? Changed data will not be saved?'.
        lv_title = TEXT-r0c.
        lv_text1 = TEXT-r0m.
        lv_text2 = TEXT-r0n.

      WHEN 'R1'.
        "'화면전환 확인'.
        " '화면을 전환 하시겠습니까? 변경된 자료는 저장되지 않습니다'.
        lv_title = TEXT-r1c.
        lv_text1 = TEXT-r1m.
        lv_text2 = TEXT-r1n.

      WHEN 'C' OR 'C0'.
        " 작업을 취소 하시겠습니까? 변경된 자료는 저장되지 않습니다?
*        lv_title = '작업취소 확인'.
*        lv_text1 = '작업을 취소 하시겠습니까? 변경된 자료는 저장되지 않습니다?'.
        lv_title = TEXT-c0c.
        lv_text1 = TEXT-c0m.

      WHEN 'C1'.
        " '작업취소 확인'.
        " '변경된 자료가 있습니다 작업을 진행 하시겠습니까?'.
        " '작업을 진행하면 변경된 자료는 저장되지 않습니다.'.
*        lv_title = 'Confirm Job Cancellation'.
*        lv_text1 = 'There has been changed Data. Do you want to proceed?'.
*        lv_text2 = 'If you proceed with the operation, any changed data will not be saved.'.
        lv_title = TEXT-c1c.
        lv_text1 = TEXT-c1m.
        lv_text2 = TEXT-c1n.

      WHEN 'C2'.
        " 기존에 등록된 자료가 있습니다.기존 자료를 삭제 후 신규 작업을 수행 하시겠습니까?'
        lv_title = '생성작업 확인'.
        lv_text1 = '기존에 등록된 자료가 있습니다.'.
        lv_text2 = '기존 자료를 삭제 후 신규 작업을 수행 하시겠습니까?'.

      WHEN 'AA'.
*        lv_title = '승인여부 확인'.
*        lv_text1 = '선택된 라인의 자료를 승인 하시겠습니까?'.
        lv_title = TEXT-aac.
        lv_text1 = TEXT-aam.

      WHEN 'AR'.
*        lv_title = '반려여부 확인'.
*        lv_text1 = '선택된 라인의 자료를 반려 하시겠습니까?'.
        lv_title = TEXT-arc.
        lv_text1 = TEXT-arm.

      WHEN 'AS'.
*        lv_title = '반려여부 확인'.
*        lv_text1 = '화면의 자료를 반려 하시겠습니까?'.
        lv_title = TEXT-asc.
        lv_text1 = TEXT-asm.

      WHEN 'AP'.
*        lv_title = '승인여부 확인'.
*        lv_text1 = '화면의 자료를 승인 하시겠습니까?'.
        lv_title = TEXT-apc.
        lv_text1 = TEXT-apm.

      WHEN 'DS'.
*        lv_title = '라인삭제 확인'.
*        lv_text1 = '선택된 라인의 &1를(을) 삭제 하시겠습니까?'.
        lv_parm1 = SWITCH #( iv_text1 WHEN space THEN TEXT-dat ELSE iv_text1 ). " 자료
        lv_title = TEXT-d1c.
        lv_text1 = me->make_message_text( iv_msg_txt = TEXT-d1m
                                          iv_parm1   = lv_parm1 ).

      WHEN 'PR'.
*        lv_title = '자료출력 확인'.
*        lv_text1 = '화면의 자료를 출력 하시겠습니까?
        lv_title = TEXT-prc.
        lv_text1 = TEXT-prm.

      WHEN 'S'.
*        lv_title = '저장작업확인'.
*        lv_text1 = '화면에 입력된 자료를 저장 하시겠습니까?
*        lv_title = 'Confirm saving'.
*        lv_text1 = 'Do you want to save the data?'.
        lv_title = TEXT-s0c.
        lv_text1 = TEXT-s0m.

      WHEN 'SA'.
        " 라인생성 확인'.
        " 추가된 라인의 자료를 생성 하시겠습니까?'.
        lv_title = TEXT-sac.
        lv_text1 = TEXT-sam.

      WHEN 'SC'.
        " 라인생성 확인'.
        " 선택된 라인의 자료를 생성 하시겠습니까?'.
        lv_title = 'Confirm line creation'.
        lv_text1 = 'Do you want to creation data from the selected line?'.

      WHEN 'SU'.
*        lv_title = '라인변경 확인'.
*        lv_text1 = '선택된 라인의 자료를 변경 하시겠습니까?'.
        lv_title = 'Confirm line changed'.
        lv_text1 = 'Do you want to change data from the selected line?'.

      WHEN 'SD'.
*        lv_title = '라인삭제 확인'.
*        lv_text1 = '선택된 라인의 자료를 삭제 하시겠습니까?'.
        lv_title = 'Confirm line deletion'.
        lv_text1 = 'Do you want to delete data from the selected line?'.

      WHEN 'SS'.
*        lv_title = '라인저장 확인'.
*        lv_text1 = '선택된 라인의 &1를(을) 저장 하시겠습니까?'.
        lv_parm1 = SWITCH #( iv_text1 WHEN space THEN TEXT-dat ELSE iv_text1 ). " 자료
        lv_title = TEXT-ssc.
        lv_text1 = me->make_message_text( iv_msg_txt = TEXT-ssm
                                          iv_parm1   = lv_parm1 ).

      WHEN 'SV'.
        " 선택 라인 조회 확인
        " 변경된 자료가 있습니다. 선택 라인의 자료를 조회 하시겠습니까?
*        lv_title = 'Confirm Display selected line'.
*        lv_text1 = 'There is changed Data. Would you like to view data from a selected line?'.

      WHEN 'SR'.
        " '저장작업 확인'.
        " 변경된 자료를 저장 하시겠습니까?
*        lv_title = 'Confirm saved operation'.
*        lv_text1 = 'Would you like to save the data on the screen?'.
        lv_title = TEXT-src.
        lv_text1 = TEXT-srm.

      WHEN 'S1'.
        lv_title = TEXT-rsc.
        lv_text1 = iv_text1.

      WHEN 'MA'.
        " 자료변경 확인'.
        " 변경된 라인의 자료를 저장 하시겠습니까?'.
        lv_title = TEXT-mac.
        lv_text1 = TEXT-mam.

      WHEN 'M1'.
        " 생산실적을 생성 하시겠습니까?
        lv_title = TEXT-m1c. " 자료생성 확인
        lv_text1 = me->make_message_text( iv_msg_txt = TEXT-m1m
                                          iv_parm1   = iv_text1 ).


      WHEN 'M2'.
        " 생산실적을 취소 하시겠습니까?
        lv_title = TEXT-m2c." 자료취소 확인
        lv_text1 = me->make_message_text( iv_msg_txt = TEXT-m2m
                                          iv_parm1   = iv_text1 ).

      WHEN 'US'.
        " Upload Data 저장확인
        " Upload 된 자료를 저장 하시겠습니까?
*        lv_title = 'Upload Data completion'.
*        lv_text1 = 'Would you like to save the uploaded data?'.
        lv_title = TEXT-usc.
        lv_text1 = TEXT-usm.


      WHEN 'UD'. " xls upload
        " 이전에 저장한 데이터를 삭제하고 업로드한 데이터를 저장하시겠습니까?
        lv_title = 'Upload Data completion'.
        lv_text1 = 'Do you want to delete previously saved data and save uploaded data?'.

      WHEN 'U2'. " xls upload
        " 화면에 조회된 자료를 Clear 하고 XLS 자료를 Upload 하시겠습니까?
        lv_title = 'XLS Upload 확인'.
        lv_text1 = '화면에 조회된 자료를 Clear 하고 XLS 자료를 Upload 하시겠습니까?'.

      WHEN 'N1'. " xls download
        " XLS Download 확인'.
        " 화면에 조회된 데이터를 Download 합니다. 작업을 진행하시겠습니까?'.
*        lv_title = 'Confirm Excel Download'.
*        lv_text1 = 'Download the data viewed on the screen. Would you like to proceed with the task?'.
        lv_title = TEXT-n1c.
        lv_text1 = TEXT-n1m.

      WHEN 'E1'.
        lv_title = iv_title.
        lv_text1 = iv_text1.

      WHEN 'E2'.
        lv_title = iv_title.
        lv_text1 = iv_text1.
        lv_text2 = iv_text2.

      WHEN 'IS'.
        "'자료 저장확인'.
        " '변경된 자료가 있습니다. 저장 후 작업을 진행 하십시오.'.
*        lv_title = 'Save Confirm'.
        lv_title = TEXT-rsc.
        lv_text1 = TEXT-rsm.

      WHEN 'I1'.
        lv_title = iv_title.
        lv_text1 = iv_text1.

      WHEN 'I2'.
        lv_title = iv_title.
        lv_text1 = iv_text1.
        lv_text2 = iv_text2.
    ENDCASE.

    IF lv_title IS INITIAL.
      lv_title = TEXT-dfc. " 작업확인
    ENDIF.

    IF iv_msg+0(1) = 'I'.
      rv_check = me->popup_to_information( iv_title = lv_title
                                           iv_text1 = lv_text1
                                           iv_text2 = lv_text2 ).

    ELSE.
* 종료확인 메세지
      rv_check = me->popup_to_confirm( iv_title         = lv_title
                                       iv_text1         = lv_text1
                                       iv_text2         = lv_text2
                                       iv_cancel        = iv_cancel
                                       iv_text_button_1 = iv_text_button_1
                                       iv_text_button_2 = iv_text_button_2
                                     ).
    ENDIF.

  ENDMETHOD.


  METHOD check_mimetype.

    DATA: lv_relid    TYPE wwwparams-relid,
          lv_objid    TYPE wwwdataid, "wwwparams-objid,
          lv_mimetype TYPE w3_name,
          lv_mimeappl TYPE wwwdata-objid,
          lt_mimeapps TYPE TABLE OF w3mimeappl WITH EMPTY KEY.

    lv_relid     = 'MI'.
    lv_objid     = iv_objid.
    lv_mimetype  = 'mimetype'.
    lv_mimeappl  = 'mimeappl'.

    CALL FUNCTION 'WWWPARAMS_READ'
      EXPORTING
        relid = lv_relid
        objid = lv_objid
        name  = lv_mimetype
      IMPORTING
        value = lv_mimetype.

    CONCATENATE lv_mimeappl sy-uname INTO lv_objid.
    IMPORT mimeapps = lt_mimeapps FROM DATABASE wwwdata(st) ID lv_objid.

    rv_rc = 0.
    READ TABLE lt_mimeapps INTO DATA(ls_mineapps) WITH KEY mtype = lv_mimetype.
    IF sy-subrc EQ 0 AND ls_mineapps-appli IS NOT INITIAL.
    ELSE.
      IF sy-subrc = 0.
        DATA(lv_idx) = sy-tabix.
      ELSE.
        lv_idx = 0.
      ENDIF.

      CASE lv_mimetype.
        WHEN 'xls/xlsx' OR
             'application/vnd.ms-excel'.
          ls_mineapps-mtype = lv_mimetype.
          ls_mineapps-appli = 'EXCEL.EXE'.
          IF lv_idx = 0.
            APPEND ls_mineapps TO lt_mimeapps.
          ELSE.
            MODIFY lt_mimeapps FROM ls_mineapps INDEX lv_idx.
          ENDIF.

          EXPORT mimeapps = lt_mimeapps TO DATABASE wwwdata(st) ID lv_objid.

        WHEN OTHERS.       rv_rc = 1.
      ENDCASE.

    ENDIF.

  ENDMETHOD.


  METHOD class_constructor.
  ENDMETHOD.


  METHOD constructor.

    " 메시지 id
    IF iv_msgid IS INITIAL.
      gv_msgid = gc_msgid.
    ELSE.
      gv_msgid = iv_msgid.
    ENDIF.

    " 수행 프로그램 정보
    IF iv_repid IS INITIAL.
      gv_repid = sy-repid.
    ELSE.
      gv_repid = iv_repid.
    ENDIF.

    " 사용자 정보 가지고 온다
    DATA: ls_default   TYPE bapidefaul,
          ls_logondata TYPE bapilogond,
          ls_address   TYPE bapiaddr3,
          lt_addsmtp   TYPE TABLE OF bapiadsmtp,
          lt_return    TYPE TABLE OF bapiret2.

    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING
        username  = sy-uname
      IMPORTING
        logondata = ls_logondata
        defaults  = ls_default
        address   = ls_address
      TABLES
        addsmtp   = lt_addsmtp
        return    = lt_return.

    gs_user_info-date_format   = ls_default-datfm. " 날짜 형식
    gs_user_info-number_format = ls_default-dcpfm. " 숫자 형식
    gs_user_info-name          = ls_address-fullname.  " 이름
    gs_user_info-email         = VALUE #( lt_addsmtp[ 1 ]-e_mail OPTIONAL ).
    IF ls_logondata-tzone IS INITIAL.
      gs_user_info-tzone       = sy-tzone.
    ELSE.
      gs_user_info-tzone       = ls_logondata-tzone.
    ENDIF.

    gs_user_info-nation = 'KR'.

    SELECT SINGLE empno, hrcode, comcode
      FROM zcmtp010
     WHERE hr_id = @sy-uname
      INTO CORRESPONDING FIELDS OF @gs_user_info.


    " 코드page
    gv_codepage = '8500'. " Korea

    " upload xls 사용 기능
    gv_xls_upload_module = '3'. " 1:OLE, 2:FDT, 3:FUNCTION.


  ENDMETHOD.


  METHOD conv_f4_value.

    DATA: lv_datatype TYPE dd32s-datatype,
          lv_datum    TYPE sy-datlo,
          lv_uzeit    TYPE sy-timlo.

    " search help field type 을 가지고 온다.
    CLEAR: lv_datatype.
    SELECT SINGLE datatype
      FROM dd32s
      INTO lv_datatype
     WHERE shlpname  = is_return-shlpname
       AND fieldname = is_return-fieldname
       AND as4local  = 'A'.

    CASE lv_datatype.
      WHEN 'DATS'.
        lv_datum = me->ce_date_i( is_return-fieldval ).
        rv_value = lv_datum.
      WHEN 'TIMS'.
        lv_uzeit = me->ce_time_i( is_return-fieldval ).
        rv_value = lv_uzeit.
      WHEN OTHERS. rv_value = is_return-fieldval.
    ENDCASE.

  ENDMETHOD.


  METHOD create_data.

    DATA:lv_type TYPE char10.
    lv_type = iv_type.

    TRANSLATE lv_type TO LOWER CASE.
    CASE lv_type.
      WHEN 'd' OR 'decfloat16' OR 'decfloat34' OR 'f' OR 'i'
               OR 'string' OR 't' OR 'xstring'.
        CREATE DATA ro_data TYPE (lv_type).

      WHEN 'c' OR 'n' OR 'x'.
        CREATE DATA ro_data TYPE (lv_type) LENGTH iv_len.

      WHEN 'p'.
        CREATE DATA ro_data TYPE p LENGTH iv_len DECIMALS iv_dec.

      WHEN OTHERS.
        RAISE EXCEPTION TYPE cx_sy_create_data_error.
    ENDCASE.

  ENDMETHOD.


  METHOD f4_field_value_request.


    DATA: lv_num1       TYPE numc4 VALUE '0001',
          lv_idx        TYPE sy-tabix,
          lv_user_reset TYPE c,
          ls_dynpfield  TYPE dynpread,
          lt_dynpfields TYPE TABLE OF dynpread,
          ls_f4_field   TYPE zmdmmms9010,
          ls_f4_value   TYPE zmdmmms9020,
          ls_return_tab TYPE ddshretval,
          lt_return_tab TYPE TABLE OF ddshretval.

    gs_f4_info = cs_f4_info.

* 호출 프로그램..
    IF gs_f4_info-repid IS INITIAL.
      gs_f4_info-repid = gv_repid.
    ENDIF.

    CLEAR: gs_f4_info-selected, gs_f4_info-selected_value.

* Search Help 에서 값을 가지고 오기..
    CLEAR: lt_return_tab[].
    CALL FUNCTION 'F4IF_FIELD_VALUE_REQUEST'
      EXPORTING
        tabname           = gs_f4_info-tabname
        fieldname         = gs_f4_info-fieldname
        searchhelp        = gs_f4_info-shlpname
        shlpparam         = gs_f4_info-shlpfield
        multiple_choice   = gs_f4_info-multiple_choice
        display           = gs_f4_info-display
*       suppress_recordlist = 'X'
*       callback_program  = gs_f4_info-repid
*       callback_form     = 'COM_F4_SET_SELOPT'
        callback_method   = me  " interface 가 있는 Class
      IMPORTING
        user_reset        = lv_user_reset
      TABLES
        return_tab        = lt_return_tab
      EXCEPTIONS
        field_not_found   = 1
        no_help_for_field = 2
        inconsistent_help = 3
        no_values_found   = 4
        OTHERS            = 5.

* 선택된 값 처리..
    CHECK lt_return_tab[] IS NOT INITIAL.

*  1. Search help 호출 Field 의 값 return
    READ TABLE lt_return_tab INTO ls_return_tab
               WITH KEY recordpos = lv_num1
                        fieldname =  gs_f4_info-shlpfield.
    IF sy-subrc = 0.
      lv_idx                    = sy-tabix.
      gs_f4_info-selected_value = me->conv_f4_value( ls_return_tab ).
      gs_f4_info-selected       = 'X'.
      DELETE lt_return_tab INDEX lv_idx.
    ENDIF.


* 2. 화면의 선택 Row 에 해당하는 다른 Field 정보 Update
    CLEAR: lt_dynpfields[].
    LOOP AT lt_return_tab INTO ls_return_tab
            WHERE recordpos =  lv_num1.
*            AND fieldname <> gs_f4_info-shlpfield.

      " 화면에 값 저장..
      READ TABLE gs_f4_info-fields INTO ls_f4_field
                 WITH KEY shlp_field = ls_return_tab-fieldname
                          action  = 'U'.
      IF sy-subrc = 0.
        CLEAR: ls_dynpfield.
        ls_dynpfield-fieldname  = ls_f4_field-scr_field .
        ls_dynpfield-stepl      = gs_f4_info-line.
        ls_dynpfield-fieldvalue = ls_return_tab-fieldval.
        APPEND ls_dynpfield    TO lt_dynpfields.
      ENDIF.
    ENDLOOP.

* 3. Multichoise 인 경우 나머지 정보 저장..
    CLEAR: gs_f4_info-values[].
*    IF gs_f4_info-multiple_choice = 'X'.
    LOOP AT lt_return_tab INTO ls_return_tab.

*    검색 결과 전체..
      CLEAR ls_f4_value.
      ls_f4_value-recordpos = ls_return_tab-recordpos.
      ls_f4_value-fieldname = ls_return_tab-fieldname.
      ls_f4_value-value     = ls_return_tab-fieldval.
      INSERT ls_f4_value INTO TABLE gs_f4_info-values.
    ENDLOOP.
*    ENDIF.

*  화면에 Update 해야 할 정보가 있는 경우..
    IF lt_dynpfields[] IS NOT INITIAL.
      CALL FUNCTION 'DYNP_VALUES_UPDATE'
        EXPORTING
          dyname               = gs_f4_info-repid
          dynumb               = gs_f4_info-dynnr
        TABLES
          dynpfields           = lt_dynpfields
        EXCEPTIONS
          invalid_abapworkarea = 1
          invalid_dynprofield  = 2
          invalid_dynproname   = 3
          invalid_dynpronummer = 4
          invalid_request      = 5
          no_fielddescription  = 6
          undefind_error       = 7
          OTHERS               = 8.
    ENDIF.

    cs_f4_info = gs_f4_info.


  ENDMETHOD.


  METHOD f4_search_help.

    DATA: lv_dynnr    TYPE sy-dynnr,
          ls_f4_field TYPE zmdmmms9010.

    CLEAR: rs_return.

    " search help 설정
    IF is_f4_info-dynnr IS INITIAL.
      lv_dynnr = sy-dynnr.
    ELSE.
      lv_dynnr = is_f4_info-dynnr.
    ENDIF.

    _com_set_f4        lv_dynnr  iv_search_help iv_fn_ret_field space space.
    gs_f4_info-title            = is_f4_info-title.
    gs_f4_info-display          = is_f4_info-display.
    gs_f4_info-multiple_choice  = is_f4_info-multiple_choice.


    " reference field
*_com_set_f4_fld_r.  scr_field  = &1.  shlp_field = &2.  action     = 'R'. " 화면 Field 읽어서
*_com_set_f4_fld_f.  fix_value  = &1.  shlp_field = &2.  action     = 'F'. " 고정값 지정
*_com_set_f4_fld_u.  scr_field  = &1.  shlp_field = &2.  action     = 'U'. " 화면 Field 에 Update
* action = 'E'. : 선택값 export 추가
* action = 'N'. : Fixed Value NE

    LOOP AT is_f4_info-fields INTO DATA(ls_ref_field).
      INSERT ls_ref_field INTO TABLE gs_f4_info-fields.
    ENDLOOP.

    " search help 호출
    me->f4_field_value_request( CHANGING cs_f4_info = gs_f4_info ).
    CHECK gs_f4_info-selected IS NOT INITIAL.

    " date format 반영
    me->shvalue_ext_to_int( ).

    rs_return-value    = gs_f4_info-selected_value.
    rs_return-selected = gs_f4_info-selected.

  ENDMETHOD.


  METHOD file_delete.

    DATA: lt_filelist    TYPE STANDARD TABLE OF file_table WITH EMPTY KEY,
          ls_filelist    TYPE file_table,
          lv_filter      TYPE string,
          lv_filename    TYPE string,
          lv_directory_s TYPE filep,
          lv_filename_s	 TYPE filep,
          lv_dir         TYPE string,
          lv_dirc        TYPE zmdmmmetxt2000,
          lv_count       TYPE i,
          lv_rc          TYPE i.

    " 입력된 directory 와 file 이 없는 경우 에러
    CHECK iv_filename  IS NOT INITIAL.

    " 입력된 directory 가 없는 경우
    IF iv_directory IS INITIAL.
      me->split_paths( EXPORTING iv_paths     = iv_filename
                       IMPORTING ev_directory = lv_directory_s
                                 ev_filename  = lv_filename_s ).

      lv_dirc   = lv_directory_s.
      lv_filter = lv_filename_s.

    ELSE.
      " 해당 디렉토리 내 전체 파일 읽기
      lv_dirc   = iv_directory.
      lv_filter = iv_filename.
    ENDIF.

    lv_rc = strlen( lv_dirc ) - 1.
    IF lv_dirc+lv_rc(1) = '\'.
      CLEAR: lv_dirc+lv_rc(1).
    ENDIF.
    lv_dir = lv_dirc.

    CALL METHOD cl_gui_frontend_services=>directory_list_files
      EXPORTING
        directory                   = lv_dir
        filter                      = lv_filter
      CHANGING
        file_table                  = lt_filelist
        count                       = lv_count
      EXCEPTIONS
        cntl_error                  = 1
        directory_list_files_failed = 2
        wrong_parameter             = 3
        not_supported_by_gui        = 4
        OTHERS                      = 5.
    CHECK sy-subrc = 0.


    LOOP AT lt_filelist INTO ls_filelist.

      lv_filename = |{ lv_dir }\\{ ls_filelist-filename }|.

      TRY.
          CALL METHOD cl_gui_frontend_services=>file_delete
            EXPORTING
              filename             = lv_filename
            CHANGING
              rc                   = lv_rc
            EXCEPTIONS
              file_delete_failed   = 1
              cntl_error           = 2
              error_no_gui         = 3
              file_not_found       = 4
              access_denied        = 5
              not_supported_by_gui = 6
              OTHERS               = 7.

        CATCH cx_root  INTO DATA(lx).
*          MESSAGE lx->get_text( ) TYPE 'E'.
      ENDTRY.

    ENDLOOP.

  ENDMETHOD.


  METHOD fill_components.

    DATA: lv_xls_idx      TYPE sy-tabix,
          ls_xls_comp     TYPE abap_componentdescr,
          lt_xls_comp_sub TYPE abap_component_tab,
          ls_xls_comp_sub TYPE abap_componentdescr,
          lo_xls_str      TYPE REF TO cl_abap_structdescr,
          lo_xls_str_sub  TYPE REF TO cl_abap_structdescr.

    CLEAR: rt_components.

    ASSIGN COMPONENT 1 OF STRUCTURE is_input TO FIELD-SYMBOL(<lv_check_field>).
    CHECK <lv_check_field> IS ASSIGNED.

    lo_xls_str ?= cl_abap_typedescr=>describe_by_data( is_input ).
    rt_components = lo_xls_str->get_components( ).

    LOOP AT rt_components INTO ls_xls_comp WHERE as_include = 'X'.

      lv_xls_idx = sy-tabix.
      DELETE rt_components.

      lo_xls_str_sub ?= ls_xls_comp-type.
      lt_xls_comp_sub = lo_xls_str_sub->get_components( ).

      LOOP AT lt_xls_comp_sub INTO ls_xls_comp_sub.

        IF ls_xls_comp-suffix IS NOT INITIAL.
          IF ls_xls_comp_sub-as_include = space.
            CONCATENATE ls_xls_comp_sub-name ls_xls_comp-suffix INTO ls_xls_comp_sub-name.
          ELSE.
            ls_xls_comp_sub-suffix = ls_xls_comp-suffix.
          ENDIF.
          MODIFY lt_xls_comp_sub FROM ls_xls_comp_sub.
        ENDIF.

        INSERT ls_xls_comp_sub INTO rt_components INDEX lv_xls_idx.
        lv_xls_idx = lv_xls_idx + 1.

      ENDLOOP.

    ENDLOOP.


  ENDMETHOD.


  METHOD get_charactvalue.

    DATA: lv_value_from TYPE cha_class_view-sollwert,
          lv_value_to   TYPE cha_class_view-sollwert,
          lv_digit      TYPE cha_class_data-stellen,
          lv_fltp       TYPE cha_class_data-sollwert,
          ls_cabn       TYPE cabn.

    CLEAR: rv_value_neutral, lv_value_from, lv_value_to.

    CHECK iv_value_from IS NOT INITIAL OR
          iv_value_to   IS NOT INITIAL.

    SELECT SINGLE anzdz
      FROM cabn
      INTO CORRESPONDING FIELDS OF ls_cabn
     WHERE atnam = iv_charact.
    CHECK sy-subrc = 0.

    lv_digit = ls_cabn-anzdz.  " 소숫점 자리수

    " From 값이 있는 경우
    IF iv_value_from IS NOT INITIAL.
      lv_fltp = iv_value_from.
      CALL FUNCTION 'QSS0_FLTP_TO_CHAR_CONVERSION'
        EXPORTING
          i_number_of_digits       = lv_digit " 소수점자리수
          i_fltp_value             = lv_fltp  "변환대상값
          i_value_not_initial_flag = 'X'
          i_screen_fieldlength     = 16
        IMPORTING
          e_char_field             = lv_value_from. " 변환된결과값
      CONDENSE lv_value_from NO-GAPS.
    ENDIF.

    " To 값이 있는 경우
    IF iv_value_to IS NOT INITIAL.
      lv_fltp = iv_value_from.
      CALL FUNCTION 'QSS0_FLTP_TO_CHAR_CONVERSION'
        EXPORTING
          i_number_of_digits       = lv_digit " 소수점자리수
          i_fltp_value             = lv_fltp  "변환대상값
          i_value_not_initial_flag = 'X'
          i_screen_fieldlength     = 16
        IMPORTING
          e_char_field             = lv_value_to. " 변환된결과값
      CONDENSE lv_value_to NO-GAPS.
    ENDIF.

    IF lv_value_from IS NOT INITIAL AND
       lv_value_to   IS NOT INITIAL.     " From ~ To
      rv_value_neutral = lv_value_from && ` ~ ` && lv_value_to.

    ELSEIF lv_value_from IS NOT INITIAL.
      rv_value_neutral = lv_value_from.

    ELSE.
      rv_value_neutral = lv_value_to.
    ENDIF.

  ENDMETHOD.


  METHOD get_domain.

    DATA: lv_domname TYPE domname,
          lv_domtext TYPE val_text,
          ls_domain  TYPE tys_dd07v.

    CLEAR rv_domvalue.

    CHECK iv_domname IS NOT INITIAL.

    lv_domname  = iv_domname.
    lv_domtext  = iv_domtext.

    " domain 정보가 있는지 확인 하여 없는
    "   경우 domain value 정보를 가지고 온다
    IF NOT line_exists( gt_domain[ domname  = lv_domname ] ).
      SELECT domname
             domvalue_l AS domvalue
             ddtext
        FROM dd07v
        APPENDING CORRESPONDING FIELDS OF TABLE gt_domain
       WHERE domname    = lv_domname
         AND ddlanguage = sy-langu.
      IF sy-subrc NE 0.
        CLEAR: ls_domain.
        ls_domain-domname  = lv_domname.
        ls_domain-domvalue = '<!Empty>'.
        APPEND ls_domain TO gt_domain.
      ENDIF.
    ENDIF.

    " Domain Value 정보를 가지고 온다
    rv_domvalue = VALUE #( gt_domain[ domname  = lv_domname
                                      ddtext   = lv_domtext ]-domvalue OPTIONAL ).

  ENDMETHOD.


  METHOD get_domain_txt.

    DATA: lv_domname  TYPE domname,
          lv_domvalue TYPE domvalue_l,
          ls_domain   TYPE tys_dd07v.

    CLEAR rv_text.

    CHECK iv_domname IS NOT INITIAL.

    lv_domname  = iv_domname.
    lv_domvalue = iv_domvalue.

    " domain 정보가 있는지 확인 하여 없는
    "   경우 domain value 정보를 가지고 온다
    IF NOT line_exists( gt_domain[ domname  = lv_domname ] ).
      SELECT domname
             domvalue_l AS domvalue
             ddtext
        FROM dd07v
        APPENDING CORRESPONDING FIELDS OF TABLE gt_domain
       WHERE domname    = lv_domname
         AND ddlanguage = sy-langu.
      IF sy-subrc NE 0.
        CLEAR: ls_domain.
        ls_domain-domname  = lv_domname.
        ls_domain-domvalue = '<!Empty>'.
        APPEND ls_domain TO gt_domain.
      ENDIF.
    ENDIF.

    " Domain Value 정보를 가지고 온다
    rv_text = VALUE #( gt_domain[ domname  = lv_domname
                                  domvalue = lv_domvalue ]-ddtext OPTIONAL ).


  ENDMETHOD.


  METHOD get_field_value.

    DATA: ls_dynpfield  TYPE dynpread,
          lt_dynpfields TYPE TABLE OF dynpread.
    CLEAR: rv_value.
    CHECK iv_fieldname IS NOT INITIAL.

    lt_dynpfields = VALUE #( ( fieldname = iv_fieldname ) ).

    CALL FUNCTION 'DYNP_VALUES_READ'
      EXPORTING
        dyname               = iv_repid
        dynumb               = iv_dynnr
        translate_to_upper   = 'X'
*       request              = c_x
      TABLES
        dynpfields           = lt_dynpfields
      EXCEPTIONS
        invalid_abapworkarea = 1
        invalid_dynprofield  = 2
        invalid_dynproname   = 3
        invalid_dynpronummer = 4
        invalid_request      = 5
        no_fielddescription  = 6
        invalid_parameter    = 7
        undefind_error       = 8
        double_conversion    = 8
        stepl_not_found      = 10
        OTHERS               = 99.

    rv_value = VALUE #( lt_dynpfields[ fieldname = iv_fieldname ]-fieldvalue OPTIONAL ).

  ENDMETHOD.


  METHOD get_file_name.


    DATA: lv_desktop  TYPE string,
          lv_rc       TYPE i,

          ls_file_tab TYPE file_table,
          lt_file_tab TYPE filetable.

    DATA: lv_error_text_01 TYPE txt40 VALUE 'Desktop not found'.

    CLEAR: ev_error_flag, ev_filename.

    CALL METHOD cl_gui_cfw=>flush.

    DATA: lv_filter TYPE string.
    lv_filter = cl_gui_frontend_services=>filetype_excel &&
                cl_gui_frontend_services=>filetype_all.

* Open Fiile dialog.
    CALL METHOD cl_gui_frontend_services=>file_open_dialog
      EXPORTING
        window_title            = 'Select Open File'
        default_extension       = cl_gui_frontend_services=>filetype_excel
        file_filter             = lv_filter
*       initial_directory       = lv_desktop
      CHANGING
        file_table              = lt_file_tab
        rc                      = lv_rc
      EXCEPTIONS
        file_open_dialog_failed = 1
        cntl_error              = 2
        error_no_gui            = 3
        not_supported_by_gui    = 4
        OTHERS                  = 5.
    IF sy-subrc NE  0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ev_error_flag = 'X'.
      EXIT.
    ENDIF.

    CALL METHOD cl_gui_cfw=>flush.

    IF lv_rc = 0.
      CASE iv_msg_type.
        WHEN 'I'.
          " Operation cancelled.
          MESSAGE i001(00) WITH '작업이 취소되었습니다.'. " '작업이 취소되었습니다.;
        WHEN OTHERS.
          MESSAGE s001(00) WITH '작업이 취소되었습니다.' " '작업이 취소되었습니다.;
                           DISPLAY LIKE 'E'.
      ENDCASE.
      ev_error_flag = 'X'.
      EXIT.
    ENDIF.

    " 선택된 파일중 첫라인의 파일명을 return 한다
    READ TABLE lt_file_tab INTO ls_file_tab INDEX 1.
    IF sy-subrc = 0.
      ev_filename = ls_file_tab-filename.
    ENDIF.


  ENDMETHOD.


  METHOD get_last_message.

    TYPES: BEGIN OF tys_field,
             fieldname TYPE fieldname,
           END OF tys_field.

    DATA: lv_fieldname  TYPE scrfname,
          ls_field      TYPE tys_field,
          lt_field_type TYPE TABLE OF tys_field,
          lt_field_msg  TYPE TABLE OF tys_field.

    APPEND VALUE #( fieldname = 'TYPE' )        TO lt_field_type.
    APPEND VALUE #( fieldname = 'MSG_TYPE' )    TO lt_field_type.
    APPEND VALUE #( fieldname = 'MSGTY'    )    TO lt_field_type.

    APPEND VALUE #( fieldname = 'MESSAGE' )     TO lt_field_msg.
    APPEND VALUE #( fieldname = 'MSG_TXT' )     TO lt_field_msg.

    CLEAR: rv_msg.
    CHECK it_tab IS NOT INITIAL.

    READ TABLE it_tab ASSIGNING FIELD-SYMBOL(<ls_msg>) INDEX 1.
    CHECK sy-subrc = 0.

    DATA(lv_msx_line) = lines( it_tab ).

    DO lv_msx_line TIMES.

      IF iv_gubun = 'L'.
        DATA(lv_index) = lv_msx_line - sy-index + 1.
      ELSE.
        lv_index = sy-index.
      ENDIF.

      READ TABLE it_tab ASSIGNING <ls_msg> INDEX lv_index.
      IF sy-subrc NE 0.
        EXIT.
      ENDIF.

      " Type Field 가 있는지 확인 한다.
      LOOP AT lt_field_type INTO ls_field.

        lv_fieldname = '<LS_MSG>-' && ls_field-fieldname.
        ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<lv_type>).
        IF sy-subrc = 0 AND <lv_type> IS ASSIGNED.
          EXIT.
        ENDIF.

      ENDLOOP.
      CHECK <lv_type> IS ASSIGNED.

      IF iv_msg_type IS INITIAL.
        CHECK <lv_type> = 'E' OR <lv_type> = 'A'.
      ELSE.
        CHECK <lv_type> = iv_msg_type.
      ENDIF.

      " Message Field 가 있는지 확인 한다.
      LOOP AT lt_field_msg INTO ls_field.

        lv_fieldname = '<LS_MSG>-' && ls_field-fieldname.
        ASSIGN (lv_fieldname) TO FIELD-SYMBOL(<lv_message>).
        IF sy-subrc = 0 AND <lv_message> IS ASSIGNED.
          EXIT.
        ENDIF.

      ENDLOOP.
      IF <lv_message> IS ASSIGNED.
        CHECK <lv_message> IS NOT INITIAL.
        rv_msg = <lv_message>.
      ELSE.

        ASSIGN ('<LS_MSG>-MSGID') TO FIELD-SYMBOL(<lv_msgid>).
        ASSIGN ('<LS_MSG>-MSGNO') TO FIELD-SYMBOL(<lv_msgno>).
        ASSIGN ('<LS_MSG>-MSGV1') TO FIELD-SYMBOL(<lv_msgv1>).
        ASSIGN ('<LS_MSG>-MSGV2') TO FIELD-SYMBOL(<lv_msgv2>).
        ASSIGN ('<LS_MSG>-MSGV3') TO FIELD-SYMBOL(<lv_msgv3>).
        ASSIGN ('<LS_MSG>-MSGV4') TO FIELD-SYMBOL(<lv_msgv4>).

        CHECK <lv_msgid> IS ASSIGNED AND <lv_msgno> IS ASSIGNED AND
              <lv_msgv1> IS ASSIGNED AND <lv_msgv2> IS ASSIGNED AND
              <lv_msgv3> IS ASSIGNED AND <lv_msgv4> IS ASSIGNED.
        MESSAGE ID <lv_msgid> TYPE 'S' NUMBER <lv_msgno>
                INTO rv_msg
                WITH <lv_msgv1> <lv_msgv2> <lv_msgv3> <lv_msgv4>.
      ENDIF.

      EXIT.

    ENDDO.

  ENDMETHOD.


  METHOD get_listbox.

    DATA: lv_vrm_id     TYPE vrm_id,
          lt_vrm_values TYPE vrm_values.

    lv_vrm_id  = iv_fieldname.

    CALL FUNCTION 'VRM_GET_VALUES'
      EXPORTING
        id           = lv_vrm_id
      IMPORTING
        values       = lt_vrm_values
      EXCEPTIONS
        id_not_found = 1
        OTHERS       = 2.

    CLEAR: rs_vrm_value.
    rs_vrm_value = VALUE #( lt_vrm_values[ text = iv_value ] OPTIONAL ).

  ENDMETHOD.


  METHOD get_message.

    DATA: lv_msgid TYPE symsgid,
          lv_parm1 TYPE symsgv,
          lv_parm2 TYPE symsgv,
          lv_parm3 TYPE symsgv,
          lv_parm4 TYPE symsgv.

    IF gv_msgid IS INITIAL.
      gv_msgid = gc_msgid.
    ENDIF.

    lv_msgid = iv_msgid.
    IF lv_msgid IS INITIAL.
      lv_msgid = gv_msgid.
    ENDIF.

    SELECT SINGLE * FROM t100
           WHERE sprsl = @sy-langu
           AND   arbgb = @lv_msgid
           AND   msgnr = @iv_msgno
      INTO @DATA(ls_t100).
    IF sy-subrc = 0.
      rv_message = ls_t100-text.
    ELSE.
      " *** No message found in T100 ***
      rv_message = TEXT-e01.
      EXIT.

    ENDIF.

    CHECK rv_message IS NOT INITIAL.

    DATA: lv_no(1) TYPE n,
          lv_field TYPE scrfname,
          lv_parm  TYPE scrfname.

    FIELD-SYMBOLS:
          <lv_field> TYPE any.

    DO 4 TIMES.
      lv_no = sy-index.

      UNASSIGN: <lv_field>.
      CONCATENATE 'IV_PARM' lv_no INTO lv_field.
      ASSIGN (lv_field) TO <lv_field>.
      CHECK <lv_field> IS ASSIGNED.

      CONCATENATE '&' lv_no INTO lv_parm.
      REPLACE lv_parm IN rv_message WITH <lv_field>.
      IF sy-subrc NE 0.
        lv_parm = '&'.
        REPLACE lv_parm IN rv_message WITH <lv_field>.
      ENDIF.

    ENDDO.

    " 변환되지 않은 변수 위치 clear
    IF iv_parm_clear = abap_true.
      REPLACE ALL OCCURRENCES OF '&1' IN rv_message WITH ''.
      REPLACE ALL OCCURRENCES OF '&2' IN rv_message WITH ''.
      REPLACE ALL OCCURRENCES OF '&3' IN rv_message WITH ''.
      REPLACE ALL OCCURRENCES OF '&4' IN rv_message WITH ''.
      REPLACE ALL OCCURRENCES OF '&'  IN rv_message WITH ''.
    ENDIF.

  ENDMETHOD.


  METHOD get_runtime.

    GET RUN TIME FIELD gs_runtime-time_stop .
    GET TIME FIELD gs_runtime-runtime_stop.

    gs_runtime-runtime = gs_runtime-time_stop - gs_runtime-time_start.

    rs_runtime = gs_runtime.

  ENDMETHOD.


  METHOD get_sapid.

    DATA: lv_sapid     TYPE bapibname-bapibname,
          ls_default   TYPE bapidefaul,
          ls_logondata TYPE bapilogond,
          ls_address   TYPE bapiaddr3,
          lt_return    TYPE TABLE OF bapiret2.

    rs_sapid_txt = VALUE #( gt_sapid[ userid = iv_sapid ] OPTIONAL ).
    CHECK rs_sapid_txt IS INITIAL.

    lv_sapid = iv_sapid.
    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING
        username  = lv_sapid
      IMPORTING
        logondata = ls_logondata
        defaults  = ls_default
        address   = ls_address
      TABLES
        return    = lt_return.

    IF lt_return[] IS INITIAL.
      rs_sapid_txt-userid   = lv_sapid.
      rs_sapid_txt-username = |{ ls_address-lastname }{ ls_address-firstname }|.

    ELSE.
      rs_sapid_txt-userid   = lv_sapid.
      rs_sapid_txt-username = lv_sapid.

    ENDIF.
    APPEND rs_sapid_txt  TO gt_sapid.

  ENDMETHOD.


  METHOD get_uc_text.

    TRY.
        CALL METHOD cl_abap_conv_in_ce=>uccp
          EXPORTING
            uccp = iv_input
          RECEIVING
            char = rv_output.
      CATCH cx_sy_conversion_codepage.
      CATCH cx_parameter_invalid_type.
      CATCH cx_sy_codepage_converter_init.
    ENDTRY.

  ENDMETHOD.


  METHOD if_f4callback_value_request~f4_call_callback.

    DATA: ls_selopt     TYPE ddshselopt,
          ls_fieldprop  TYPE ddshfprop,
          ls_interface  TYPE ddshiface,
          ls_f4_field   TYPE zmdmmms9010,
          ls_dynpfield  TYPE dynpread,
          lt_dynpfields TYPE TABLE OF dynpread.

* 호출 프로그램 & 화면번호..
    IF gs_f4_info-repid IS INITIAL.
      gs_f4_info-repid = gv_repid.
    ENDIF.
    IF gs_f4_info-dynnr IS INITIAL.
      gs_f4_info-dynnr = sy-dynnr.
    ENDIF.

*  참조값이 있는지 확인 한다.
    IF gs_f4_info-fields[] IS NOT INITIAL.
      cs_shlp-intdescr-dialogtype = 'D'.
    ENDIF.

    " title 이 있는지 여부 확인
    IF gs_f4_info-title IS NOT INITIAL.
      cs_shlp-intdescr-title = gs_f4_info-title.
    ENDIF.

    " 추가 output field 가 있는지 여부
    LOOP AT gs_f4_info-fields INTO ls_f4_field   WHERE action = 'E'.
      ls_interface-f4field = abap_true.
      MODIFY cs_shlp-interface FROM ls_interface
             TRANSPORTING f4field
             WHERE shlpfield = ls_f4_field-shlp_field.
    ENDLOOP.

    " Update Field 가 Output 으로 정의 되어 있는지 확인 한다.
    LOOP AT gs_f4_info-fields INTO ls_f4_field   WHERE action = 'U'.
      READ TABLE cs_shlp-interface INTO ls_interface
           WITH KEY shlpfield = ls_f4_field-shlp_field.
      IF sy-subrc = 0 AND ls_interface-f4field = space.
        READ TABLE cs_shlp-fieldprop INTO ls_fieldprop
             WITH KEY fieldname = ls_f4_field-shlp_field.
        IF sy-subrc = 0.
          ls_interface-f4field = ls_fieldprop-shlpoutput.
          MODIFY cs_shlp-interface FROM ls_interface
                 TRANSPORTING f4field
                 WHERE shlpfield = ls_f4_field-shlp_field.
        ENDIF.
      ENDIF.
    ENDLOOP.

*  Read Field 로 정의된 것만..
    CLEAR: lt_dynpfields[].
    LOOP AT gs_f4_info-fields INTO ls_f4_field   WHERE action = 'R'.

      CLEAR: ls_dynpfield.
      ls_dynpfield-fieldname = ls_f4_field-scr_field.
      ls_dynpfield-stepl     = gs_f4_info-line.
      APPEND ls_dynpfield TO lt_dynpfields.

    ENDLOOP.

*  화면에서 읽어올 값이 있는 경우..
    IF lt_dynpfields[] IS NOT INITIAL.
      CALL FUNCTION 'DYNP_VALUES_READ'
        EXPORTING
          dyname               = gs_f4_info-repid
          dynumb               = gs_f4_info-dynnr
          translate_to_upper   = 'X'
*         request              = c_x
        TABLES
          dynpfields           = lt_dynpfields
        EXCEPTIONS
          invalid_abapworkarea = 1
          invalid_dynprofield  = 2
          invalid_dynproname   = 3
          invalid_dynpronummer = 4
          invalid_request      = 5
          no_fielddescription  = 6
          invalid_parameter    = 7
          undefind_error       = 8
          double_conversion    = 8
          stepl_not_found      = 10
          OTHERS               = 99.

      " 화면 검색 Field 의 값 설정..
      LOOP AT lt_dynpfields INTO ls_dynpfield WHERE fieldvalue <> space.

        READ TABLE gs_f4_info-fields INTO ls_f4_field
             WITH KEY scr_field = ls_dynpfield-fieldname.
        CHECK sy-subrc = 0.

        CLEAR: ls_selopt.
        ls_selopt-shlpname  = cs_shlp-shlpname.
        ls_selopt-shlpfield = ls_f4_field-shlp_field.
        ls_selopt-sign      = 'I'.
        ls_selopt-low       = ls_dynpfield-fieldvalue.

        " Patten 검색인지 확인..
        FIND FIRST OCCURRENCE OF '*' IN ls_dynpfield-fieldvalue.
        IF sy-subrc = 0.
          ls_selopt-option    = 'CP'.
        ELSE.
          ls_selopt-option    = 'EQ'.
        ENDIF.

        INSERT ls_selopt  INTO TABLE cs_shlp-selopt.

      ENDLOOP.
    ENDIF.

    " 고정값 설정..
    LOOP AT gs_f4_info-fields INTO ls_f4_field
                              WHERE action = 'F' OR action = 'N' .

      CLEAR: ls_selopt.
      ls_selopt-shlpname  = cs_shlp-shlpname.
      ls_selopt-shlpfield = ls_f4_field-shlp_field.
      ls_selopt-sign      = 'I'.
      ls_selopt-low       = ls_f4_field-fix_value.

      " Patten 검색인지 확인..
      FIND FIRST OCCURRENCE OF '*' IN ls_f4_field-fix_value.
      IF sy-subrc = 0.
        ls_selopt-option    = 'CP'.
      ELSE.
        CASE ls_f4_field-action.
          WHEN 'N'.        ls_selopt-option    = 'NE'.
          WHEN OTHERS.     ls_selopt-option    = 'EQ'.
        ENDCASE.
      ENDIF.

      INSERT ls_selopt  INTO TABLE cs_shlp-selopt.

    ENDLOOP.

  ENDMETHOD.


  METHOD initialization_message.

    CLEAR: gv_alv_message.

  ENDMETHOD.


  METHOD initialization_runtime.

    CLEAR: gs_runtime.
    SET RUN TIME CLOCK RESOLUTION LOW.
    GET RUN TIME FIELD gs_runtime-runtime_start.
    GET TIME FIELD gs_runtime-time_start.

  ENDMETHOD.


  METHOD make_message_text.

    DATA: lv_no          TYPE n,
          lv_message     TYPE bapi_msg,
          lv_message_old TYPE bapi_msg,
          lv_field       TYPE scrfname,
          lv_parm        TYPE scrfname,
          lv_parmc       TYPE scrfname.

    FIELD-SYMBOLS:
      <lv_field>   TYPE any,
      <lv_field_p> TYPE any.

    lv_message     = iv_msg_txt.
    lv_message_old = iv_msg_old.
    CLEAR: rv_message.

    CHECK iv_msg_txt IS NOT INITIAL.

    DO 4 TIMES.
      lv_no = sy-index.

      UNASSIGN: <lv_field>.
      CONCATENATE 'IV_PARM' lv_no INTO lv_field.
      ASSIGN (lv_field) TO <lv_field>.
      CHECK <lv_field> IS ASSIGNED AND <lv_field> IS NOT INITIAL.
*      WRITE <lv_field> TO lv_parmc LEFT-JUSTIFIED.

      lv_parmc = me->ce_alpha_o( iv_input = <lv_field> ).

      CONCATENATE '&' lv_no INTO lv_parm.
      REPLACE lv_parm IN lv_message WITH lv_parmc.
      IF sy-subrc NE 0.
        lv_parm = '&'.
        REPLACE lv_parm IN lv_message WITH lv_parmc.
      ENDIF.

    ENDDO.

    " 생성된 메시지 return
    IF lv_message_old IS INITIAL.
      rv_message = lv_message.
    ELSE.
      rv_message = lv_message_old && ',' && lv_message.
    ENDIF.

    " 변환되지 않은 변수 위치 clear
    REPLACE ALL OCCURRENCES OF '&1' IN rv_message WITH ''.
    REPLACE ALL OCCURRENCES OF '&2' IN rv_message WITH ''.
    REPLACE ALL OCCURRENCES OF '&3' IN rv_message WITH ''.
    REPLACE ALL OCCURRENCES OF '&4' IN rv_message WITH ''.
    REPLACE ALL OCCURRENCES OF '&'  IN rv_message WITH ''.


  ENDMETHOD.


  METHOD popup_to_confirm.

    DATA: lv_flag,
          lv_message(400),"       TYPE bapi_msg,
          lv_text_button_1 TYPE bapi_msg,
          lv_text_button_2 TYPE bapi_msg.

    CONCATENATE iv_text1 ` ` iv_text2 INTO lv_message.

*    IF iv_text_button_1 IS INITIAL AND iv_text_button_2 IS INITIAL.
*      CLEAR: lv_flag.
*
*      lv_text_button_1 = space.
*      lv_text_button_2 = space.
*    ELSE.
*      lv_flag    = 'X'.
    IF iv_text_button_1 IS INITIAL.
      lv_text_button_1 = TEXT-yes.
    ELSE.
      lv_text_button_1 = iv_text_button_1.
    ENDIF.

    IF iv_text_button_2 IS INITIAL.
      lv_text_button_2 = TEXT-no1.
    ELSE.
      lv_text_button_2 = iv_text_button_2.
    ENDIF.

*    ENDIF.

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = iv_title
        text_question         = lv_message
        text_button_1         = lv_text_button_1
        text_button_2         = lv_text_button_2
        display_cancel_button = iv_cancel
      IMPORTING
        answer                = rv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.


    CASE rv_answer.

      WHEN 'J' OR '1'. " OK or text_button_1
        rv_answer = 'X'.

      WHEN 'N' OR '2'. " text_button_2
        rv_answer = space.

*        IF iv_no_msg = space AND lv_flag = space.
*          MESSAGE i000(oo) WITH 'The operation has been canceled.'.
**          MESSAGE i000(oo) WITH '작업이 취소 되었습니다.'.
*        ENDIF.
*
*        IF iv_no_msg = 'O' AND lv_flag = space.
*          MESSAGE i000(oo) WITH 'The operation has been canceled.'
**          MESSAGE s000(oo) WITH '작업이 취소 되었습니다.'
*                           DISPLAY LIKE 'E'.
*        ENDIF.
*
*      WHEN 'A'. " Cancel..
*        rv_answer = 'C'.
*        IF iv_no_msg = space.
*          MESSAGE i000(oo) WITH 'The operation has been canceled.'.
**          MESSAGE i000(oo) WITH '작업이 취소 되었습니다.'.
*        ENDIF.
*
*        IF iv_no_msg = 'O'.
*          MESSAGE i000(oo) WITH 'The operation has been canceled.'
**          MESSAGE s000(oo) WITH '작업이 취소 되었습니다.'
*                           DISPLAY LIKE 'E'.
*        ENDIF.
**          MESSAGE i000(oo) WITH '작업이 취소 되었습니다.'.

      WHEN OTHERS.
        rv_answer  = 'C'.
*        lv_message = 'The operation has been canceled.'.
        MESSAGE s100 INTO lv_message. " = '작업이 취소 되었습니다.'.
        CASE iv_no_msg.
          WHEN 'X'.  " Message 없음
          WHEN space. MESSAGE i000(oo) WITH lv_message.
          WHEN 'E'.   MESSAGE s000(oo) WITH lv_message DISPLAY LIKE 'E'.
          WHEN OTHERS.
        ENDCASE.
    ENDCASE.

  ENDMETHOD.


  METHOD popup_to_information.



  ENDMETHOD.


  METHOD read_text.

    " SE75 에서 Object 생성

    DATA: lv_id     TYPE thead-tdid,
          lv_name   TYPE thead-tdname,
          lv_object TYPE thead-tdobject,
          ls_thead  TYPE thead,
          ls_tline  TYPE tline,
          lt_tline  TYPE TABLE OF tline.

    CLEAR: rt_textline[].
    CHECK iv_id     IS NOT INITIAL AND
          iv_name   IS NOT INITIAL AND
          iv_object IS NOT INITIAL.

    lv_id      = iv_id.
    lv_name    = iv_name.
    lv_object  = iv_object.

    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        id                      = lv_id
        language                = sy-langu
        name                    = lv_name
        object                  = lv_object
      IMPORTING
        header                  = ls_thead
      TABLES
        lines                   = lt_tline
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.

    LOOP AT lt_tline INTO ls_tline.
      APPEND ls_tline-tdline TO rt_textline.
    ENDLOOP.

  ENDMETHOD.


  METHOD read_text_single.

    " SE75 에서 Object 생성

    DATA: lv_id     TYPE thead-tdid,
          lv_name   TYPE thead-tdname,
          lv_object TYPE thead-tdobject,
          ls_thead  TYPE thead,
          ls_tline  TYPE tline,
          lt_tline  TYPE TABLE OF tline,
          lt_stream TYPE STANDARD TABLE OF char255.

    CLEAR: rv_output.
    CHECK iv_id     IS NOT INITIAL AND
          iv_name   IS NOT INITIAL AND
          iv_object IS NOT INITIAL.

    lv_id      = iv_id.
    lv_name    = iv_name.
    lv_object  = iv_object.

    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        id                      = lv_id
        language                = sy-langu
        name                    = lv_name
        object                  = lv_object
      IMPORTING
        header                  = ls_thead
      TABLES
        lines                   = lt_tline
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.

    CALL FUNCTION 'CONVERT_ITF_TO_STREAM_TEXT'
      TABLES
        itf_text    = lt_tline
        text_stream = lt_stream.

    CONCATENATE LINES OF lt_stream
           INTO rv_output
      SEPARATED BY cl_abap_char_utilities=>newline.

*    LOOP AT lt_tline INTO ls_tline.
*      IF rv_output IS INITIAL.
*        rv_output = ls_tline-tdline.
*      ELSE.
*        CONCATENATE rv_output ls_tline-tdline
*               INTO rv_output. " SEPARATED BY space.
*      ENDIF.
*    ENDLOOP.

  ENDMETHOD.


  METHOD save_file_name.


    CONSTANTS:
       lc_period TYPE char1 VALUE '.'.

    DATA: lv_path_c            TYPE draw-filep,
          lv_file_c            TYPE draw-filep,
          lv_filename          TYPE string,
          lv_path              TYPE string,
          lv_fullpath          TYPE string,
          lv_extension         TYPE string,
          lv_initial_directory TYPE string,
          lv_rc                TYPE i.

    IF cv_filename IS NOT INITIAL.
      lv_path_c = cv_filename.
      CALL FUNCTION 'CV120_SPLIT_PATH'
        EXPORTING
          pf_path  = lv_path_c
        IMPORTING
          pfx_path = lv_path_c
          pfx_file = lv_file_c.

      DATA: lv_fil(256).
      SPLIT lv_file_c AT lc_period INTO lv_fil lv_extension.
      lv_initial_directory = lv_path_c.
      lv_filename          = lv_file_c.
    ENDIF.

    DATA: lv_filter TYPE string.
    lv_filter = cl_gui_frontend_services=>filetype_excel &&
                cl_gui_frontend_services=>filetype_all.

    CLEAR: rv_error_flag.
    lv_filename = cv_filename.
    CALL METHOD cl_gui_frontend_services=>file_save_dialog
      EXPORTING
        window_title         = 'Save Template File Name'
        default_file_name    = lv_filename
        default_extension    = cl_gui_frontend_services=>filetype_excel
        file_filter          = lv_filter
      CHANGING
        filename             = lv_filename
        path                 = lv_path
        fullpath             = lv_fullpath
        user_action          = lv_rc
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        not_supported_by_gui = 3
        OTHERS               = 4.
    IF sy-subrc NE  0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      rv_error_flag = 'X'.
    ENDIF.

    IF lv_rc NE 0.
      " Excel Template Download 작업이 취소되었습니다.
      MESSAGE i000(oo) WITH TEXT-e02.
      rv_error_flag = 'X'.
      EXIT.
    ENDIF.

    DATA lv_len TYPE i.
    lv_len = strlen( lv_fullpath ).
    IF lv_len > gc_file_max_len.
      " 파일명(Paths 포함)이 너무 깁니다.
      MESSAGE i000(oo) WITH TEXT-e03.
      rv_error_flag = 'X'.
      EXIT.
    ENDIF.

    cv_filename = lv_fullpath.

  ENDMETHOD.


  METHOD save_file_temp.


    DATA: lv_path_c TYPE draw-filep,
          lv_file_c TYPE draw-filep.

    CHECK iv_filename IS NOT INITIAL.

    " paths 분리, 분리된  paths 가 있는 경우 skip
    CALL FUNCTION 'CV120_SPLIT_PATH'
      EXPORTING
        pf_path  = iv_filename
      IMPORTING
        pfx_path = lv_path_c
        pfx_file = lv_file_c.

    CHECK lv_path_c IS NOT INITIAL.

    " directory 가 존재하는지 확인 \
    " directory check
    DATA: lv_directory TYPE string,
          lv_result    TYPE abap_bool,
          lv_rc        TYPE i.
    lv_directory = lv_path_c.
    CALL METHOD cl_gui_frontend_services=>directory_exist
      EXPORTING
        directory            = lv_directory
      RECEIVING
        result               = lv_result
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        wrong_parameter      = 3
        not_supported_by_gui = 4
        OTHERS               = 5.
    IF lv_result IS INITIAL.
      CALL METHOD cl_gui_frontend_services=>directory_create
        EXPORTING
          directory                = lv_directory
        CHANGING
          rc                       = lv_rc
        EXCEPTIONS
          directory_create_failed  = 1
          cntl_error               = 2
          error_no_gui             = 3
          directory_access_denied  = 4
          directory_already_exists = 5
          path_not_found           = 6
          unknown_error            = 7
          not_supported_by_gui     = 8
          wrong_parameter          = 9
          OTHERS                   = 10.
    ENDIF.

  ENDMETHOD.


  METHOD save_text.

    DATA: lv_tdline TYPE tdline,
          ls_thead  TYPE thead,
          ls_tline  TYPE tline,
          lt_tline  TYPE TABLE OF tline.

    CHECK iv_id     IS NOT INITIAL AND
          iv_name   IS NOT INITIAL AND
          iv_object IS NOT INITIAL.

    ls_thead-tdid      = iv_id.
    ls_thead-tdname    = iv_name.
    ls_thead-tdobject  = iv_object.
    ls_thead-tdspras   = sy-langu.

    CLEAR: lt_tline[].
    LOOP AT it_textline INTO lv_tdline.

      CLEAR: ls_tline.
      MOVE lv_tdline TO ls_tline-tdline.
      APPEND ls_tline TO lt_tline.

    ENDLOOP.

    CALL FUNCTION 'SAVE_TEXT'
      EXPORTING
        header          = ls_thead
        insert          = ' '
        savemode_direct = iv_savemode
      TABLES
        lines           = lt_tline
      EXCEPTIONS
        id              = 1
        language        = 2
        name            = 3
        object          = 4
        OTHERS          = 5.

  ENDMETHOD.


  METHOD send_mail.

* 메일 전송 확인 : T-Code : SOST

    DATA: lv_error_flag,
          lv_sender_address      TYPE soextreci1-receiver,
          lv_sender_address_type TYPE soextreci1-adr_typ,
          lv_sent_all(1),
          ls_doc_data            TYPE sodocchgi1,
          lt_packing_list	       TYPE TABLE OF sopcklsti1,
          lt_receivers           TYPE somlreci1_t. "TABLE OF somlreci1.

    CLEAR: ev_message.
    ev_type = 'E'.
    ev_message = TEXT-es1. " 입력값에 누락이 있습니다.

    CHECK iv_title       IS NOT INITIAL AND  " 메일제목
          iv_sender      IS NOT INITIAL AND " 발신자 주소
          it_text[]      IS NOT INITIAL AND " 메일내용
          it_receivers[] IS NOT INITIAL. " 수신자 주소

    IF NOT line_exists( it_receivers[ ztype = 'R' ] ).
      ev_message = TEXT-es2. " 수신자가 지정되어 있지 않습니다.
      EXIT.
    ENDIF.

* 발신자 email 주소 check
    IF me->check_mail_address( iv_email = iv_sender ) = 'E'.
      ev_message = TEXT-es3. " 발신자 e_mail 주소가 유효하지 않습니다.
      EXIT.
    ENDIF.

* 수신자 email 주소 check.
    IF me->check_mail_address( it_email = it_receivers ) = 'E'.
      ev_message = TEXT-es4. " 수신자 e_mail 주소중 유효하지 않은것이 있습니다.
      EXIT.
    ENDIF.
*--------------------------------------------------------------------*

    CLEAR: ls_doc_data.
    ls_doc_data-obj_langu  = sy-langu.
    ls_doc_data-obj_name   = 'SAPRPT'.
    ls_doc_data-obj_descr  = iv_title.  " 제목
*  ls_doc_data-sensitivty = 'F'.

    CLEAR: lt_packing_list.
    APPEND VALUE #( head_start = 0
                    head_num   = 0
                    body_start = 1
                    body_num   = lines( it_text )
                    doc_type   = 'HTM'
                    obj_descr  = iv_title  " 내역
                  ) TO lt_packing_list.

* 발신자 정보..
    lv_sender_address      = iv_sender.
    lv_sender_address_type = 'INT'.

* 수신 대상자를 가지고 온다.
    CLEAR: lt_receivers.
    LOOP AT it_receivers INTO DATA(ls_receive).

      APPEND VALUE #( receiver      = SWITCH #( ls_receive-zname WHEN space THEN ls_receive-zemail
                                                                ELSE |{ ls_receive-zname } <{ ls_receive-zemail }>| )
                      rec_type      = 'U'
                      com_type      = 'INT'
                      notif_del     = 'X'
                      notif_ndel    = 'X'
                      copy          = SWITCH #( ls_receive-ztype WHEN 'R' THEN space     ELSE abap_true ) " 수신/참조
                      blind_copy    = SWITCH #( ls_receive-ztype WHEN 'H' THEN abap_true ELSE space )     " 숨은참조
                    ) TO lt_receivers.

    ENDLOOP.

    " 중복 발신자 제외 : 이메일 + 수신,참조 구분
    SORT lt_receivers BY receiver copy.
    DELETE ADJACENT DUPLICATES FROM lt_receivers
           COMPARING receiver copy.

    " 메일발송
    CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
      EXPORTING
        document_data              = ls_doc_data
        put_in_outbox              = 'X'
        sender_address             = lv_sender_address
        sender_address_type        = lv_sender_address_type
        commit_work                = 'X'
      IMPORTING
        sent_to_all                = lv_sent_all
      TABLES
        packing_list               = lt_packing_list
*       contents_bin               = t_attachment
        contents_txt               = it_text
        receivers                  = lt_receivers
      EXCEPTIONS
        too_many_receivers         = 1
        document_not_sent          = 2
        document_type_not_exist    = 3
        operation_no_authorization = 4
        parameter_error            = 5
        x_error                    = 6
        enqueue_error              = 7
        OTHERS                     = 8.
    IF sy-subrc NE 0.
      ev_type = 'E'.
      MESSAGE ID sy-msgid TYPE 'S'
              NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4
              INTO ev_message.
      EXIT.
    ENDIF.

    WAIT UP TO 2 SECONDS.
    SUBMIT rsconn01 WITH mode   = 'INT'
                    WITH output = space " 'X'
           AND RETURN.
    CALL FUNCTION 'SO_DEQUEUE_UPDATE_LOCKS'.

    ev_type    = 'S'.
    ev_message = TEXT-sm0.  " 메일이 발송 되었습니다.

  ENDMETHOD.


  METHOD set_message.

    DATA: ls_alv_message TYPE tys_alv_message.

    IF gv_alv_message IS INITIAL.
      CALL FUNCTION 'MESSAGES_INITIALIZE'.
      CLEAR: gt_alv_message[].
    ENDIF.

    DATA: lv_msgid TYPE symsgid,
          lv_parm1 TYPE bapi_msg,
          lv_parm2 TYPE symsgv,
          lv_parm3 TYPE symsgv,
          lv_parm4 TYPE symsgv.

    IF gv_msgid IS INITIAL.
      gv_msgid = gc_msgid.
    ENDIF.

    lv_msgid = iv_msgid.
    IF lv_msgid IS INITIAL.
      lv_msgid = gv_msgid.
    ENDIF.

    lv_parm1 = iv_parm1.
    lv_parm2 = iv_parm2.
    lv_parm3 = iv_parm3.
    lv_parm4 = iv_parm4.


    " 중복 메시지 제거
    ls_alv_message-msgno = iv_msgno.
    ls_alv_message-index = iv_index.
    ls_alv_message-message = me->get_message( iv_msgid = iv_msgid
                                              iv_msgno = iv_msgno
                                              iv_parm1 = iv_parm1
                                              iv_parm2 = iv_parm2
                                              iv_parm3 = iv_parm3
                                              iv_parm4 = iv_parm4 ).

    READ TABLE gt_alv_message WITH KEY msgno   = ls_alv_message-msgno
                                       index   = ls_alv_message-index
                                       message = ls_alv_message-message
         TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      IF gv_alv_message IS INITIAL.
        gv_alv_message = 'X'.
      ENDIF.
      IF gv_alv_message = 'X' AND ls_alv_message-index > 0.
        gv_alv_message = 'Y'.  " line no 조회
      ENDIF.

      APPEND ls_alv_message TO gt_alv_message.

      ASSIGN ('(SAPLSMSG)MESSAGES_COLLECT') TO FIELD-SYMBOL(<lv_msg_col>).
      IF sy-subrc = 0.
        <lv_msg_col> = 'X'.
      ENDIF.

      CALL FUNCTION 'MESSAGE_STORE'
        EXPORTING
          arbgb                  = lv_msgid
          msgty                  = iv_msgty
          msgv1                  = lv_parm1
          msgv2                  = lv_parm2
          msgv3                  = lv_parm3
          msgv4                  = lv_parm4
          txtnr                  = iv_msgno
          zeile                  = iv_index
        EXCEPTIONS
          message_type_not_valid = 1
          not_active             = 2
          OTHERS                 = 99.


    ENDIF.

  ENDMETHOD.


  METHOD set_timestamp.

* 등록/변경일자
    DATA(ls_timestamp) = CORRESPONDING zmdmcms_time_stamp( cs_timestamp ).

    IF ls_timestamp-ernam IS INITIAL OR ls_timestamp-erdat IS INITIAL.
      ls_timestamp-ernam = sy-uname.
      ls_timestamp-erdat = sy-datlo.
      ls_timestamp-erzet = sy-timlo.
*      ls_timestamp-aenam = sy-uname.
*      ls_timestamp-aedat = SY-DATLO.
*      ls_timestamp-aezet = SY-TIMLO.

    ELSE.
      ls_timestamp-aenam = sy-uname.
      ls_timestamp-aedat = sy-datlo.
      ls_timestamp-aezet = sy-timlo.

    ENDIF.

    cs_timestamp = CORRESPONDING #( BASE ( cs_timestamp ) ls_timestamp ).

  ENDMETHOD.


  METHOD show_message.

    DATA: lv_linno TYPE char1,
          lv_title TYPE cua_tit_tx.

    CHECK sy-batch IS INITIAL.

    IF iv_title IS NOT INITIAL.
      lv_title = iv_title.
    ENDIF.

    IF gv_alv_message IS NOT INITIAL.
      IF gv_alv_message = 'Y'.
        lv_linno = 'X'.
      ELSE.
        lv_linno = space.
      ENDIF.

      CALL FUNCTION 'MESSAGES_SHOW'
        EXPORTING
          object     = lv_title
          show_linno = lv_linno.
    ENDIF.

    CLEAR: gv_alv_message.

  ENDMETHOD.


  METHOD show_message_p.

    DATA: lv_text   TYPE bapi_msg,
          lv_per    TYPE i,
          lv_per_sc TYPE i,
          lv_per_s0 TYPE i,
          lv_per_c  TYPE char10,
          lv_tot_c  TYPE char10,
          lv_line_c TYPE char10.

    CHECK sy-batch = space.

    IF gv_sp_msg IS INITIAL.
      gv_sp_msg = 'Processing..'.
    ENDIF.

    " 단순 메시지 출력
    IF iv_read_cnt = 0 OR gv_sp_total = 0 OR
       iv_read_cnt > gv_sp_total.
      CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
        EXPORTING
          percentage = 0
          text       = gv_sp_msg.
      EXIT.
    ENDIF.

    " 보여줄 persent 단위 없는 경우 5%씩
    IF gv_sp_persent IS INITIAL.
      gv_sp_persent = 5.
    ENDIF.

    " 초기값 설정
    IF iv_read_cnt = 1.
      gv_sp_cnt = 0.
    ENDIF.

    " 현재 persent 를 조회 persent 로 나누고 난 나머지
    lv_per_sc   = ( iv_read_cnt * 100 ) / gv_sp_total .
    lv_per_s0   = lv_per_sc MOD gv_sp_persent.

    " 보여줄 대상 persent 가 넘거나 처음인 경우
    IF ( gv_sp_cnt < lv_per_sc AND lv_per_s0 = 0 ) OR iv_read_cnt = 1.
      gv_sp_cnt = lv_per_sc.
      WRITE lv_per_sc   TO lv_per_c   LEFT-JUSTIFIED.
      WRITE iv_read_cnt TO lv_line_c  LEFT-JUSTIFIED.
      WRITE gv_sp_total TO lv_tot_c   LEFT-JUSTIFIED.

      CONCATENATE gv_sp_msg `..( ` lv_line_c `/` lv_tot_c `= ` lv_per_c `% )..Processing`
             INTO lv_text.

      IF iv_batch_mode = space AND sy-batch = space.
        CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
          EXPORTING
            percentage = lv_per
            text       = lv_text.
      ELSE.
        GET TIME.
        WRITE:/ lv_text+0(60), ':', sy-datlo, ' ', sy-timlo.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD shvalue_ext_to_int.

    DATA: lv_selected_value	 TYPE shvalue_d.

    lv_selected_value = gs_f4_info-selected_value.

    " 해당 search help 만
    CASE gs_f4_info-shlpname.
      WHEN OTHERS.
    ENDCASE.

  ENDMETHOD.


  METHOD split_paths.

    DATA: lv_path(1024),
          lv_directory     TYPE draw-filep,
          lv_filename      TYPE draw-filep,
          lv_filenames     TYPE string,
          lv_extension(05).

* File 명과 Directiroy 분리
    lv_path = iv_paths.
    CALL FUNCTION 'CV120_SPLIT_PATH'
      EXPORTING
        pf_path  = lv_path
      IMPORTING
        pfx_path = lv_directory
        pfx_file = lv_filename.

    ev_directory = lv_directory.
    ev_filename  = lv_filename.

*  확장자.
    CALL FUNCTION 'CV120_SPLIT_FILE'
      EXPORTING
        pf_file       = lv_filename
      IMPORTING
        pfx_extension = lv_extension.

    TRANSLATE lv_extension TO UPPER CASE.
    ev_extension = lv_extension.

* Appli
    CALL FUNCTION 'CV120_DOC_GET_APPL'
      EXPORTING
        pf_file   = lv_filename
      IMPORTING
        pfx_dappl = ev_appr_type.

* File Size .
    IF ev_size IS REQUESTED.
      lv_filenames = iv_paths.
      CALL METHOD cl_gui_frontend_services=>file_get_size
        EXPORTING
          file_name            = lv_filenames
        IMPORTING
          file_size            = ev_size
        EXCEPTIONS
          file_get_size_failed = 1
          cntl_error           = 2
          error_no_gui         = 3
          not_supported_by_gui = 4
          OTHERS               = 5.

      CALL METHOD cl_gui_cfw=>flush.
    ENDIF.

  ENDMETHOD.


  METHOD strlenx.

    CLEAR: rv_output.
    CHECK iv_input IS NOT INITIAL.

    CALL METHOD cl_abap_list_utilities=>dynamic_output_length
      EXPORTING
        field = CONV string( iv_input )
      RECEIVING
        len   = rv_output.

  ENDMETHOD.


  METHOD xls_col_letters_to_idx.

    DATA(lv_txt_u) = to_upper( iv_col ).
    DATA lv_sum TYPE i VALUE 0.
    DATA lv_pos TYPE i.

    DO strlen( lv_txt_u ) TIMES.
      DATA(lv_len) = sy-index - 1.
      DATA(ch) = lv_txt_u+lv_len(1).
      FIND ch IN sy-abcde MATCH OFFSET lv_pos.  " 0..25
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE cx_sy_conversion_no_number.
      ENDIF.
      lv_sum = lv_sum * 26 + ( lv_pos + 1 ).
    ENDDO.

    rv = lv_sum.

  ENDMETHOD.


  METHOD xls_copy_out.

    DATA: lv_field_type,
          lv_xls_field    TYPE scrfname,
          lv_xls_idx      TYPE sy-tabix,
          lv_xls_data     TYPE zmdmmmetxt2000,
          ls_xls_data_out TYPE zmdmmms9030,
          ls_fieldcat     TYPE lvc_s_fcat,
          lt_fieldcat     TYPE lvc_t_fcat,
          lo_xls_str      TYPE REF TO cl_abap_structdescr,
          lo_xls_str_sub  TYPE REF TO cl_abap_structdescr,
          lt_xls_comp     TYPE abap_component_tab,
          lt_xls_comp_sub TYPE abap_component_tab,
          ls_xls_comp     TYPE abap_componentdescr,
          ls_xls_comp_sub TYPE abap_componentdescr.

    FIELD-SYMBOLS :
      <lv_xls_field>   TYPE any,
      <lv_xls_field01> TYPE any,
      <ls_xls_data>    TYPE any.

    " Excel 출력 구조 가지고 오기..
    IF ct_xls_comp[] IS INITIAL.

      CLEAR: lt_xls_comp[].

      " fieldcatalog 가 입력된 경우
      IF it_fieldcat[] IS NOT INITIAL. " AND is_xls_layout IS NOT SUPPLIED.
        lt_fieldcat[] = it_fieldcat[].
        DELETE lt_fieldcat WHERE tech = 'X' OR no_out = 'X'.  " 숨김 필드명 삭제.
        SORT lt_fieldcat BY col_pos.

        LOOP AT lt_fieldcat INTO ls_fieldcat.

          CLEAR: ls_xls_comp.
          ls_xls_comp-name = ls_fieldcat-fieldname.

          APPEND ls_xls_comp TO lt_xls_comp.

        ENDLOOP.

      ELSEIF is_xls_layout IS SUPPLIED.

        " structure 가 입력된 경우
        lt_xls_comp = me->fill_components( is_xls_layout ).
      ENDIF.

      ct_xls_comp[] = lt_xls_comp[].

    ELSE.

      lt_xls_comp[] = ct_xls_comp[].

    ENDIF.

    gv_sp_total = lines( it_xls_data[] ).
    gv_sp_msg   = 'Converting to Excel Export Layout'.

    LOOP AT it_xls_data ASSIGNING <ls_xls_data>.

      me->show_message_p( sy-tabix ).

*   Value Assign.
      CLEAR: ls_xls_data_out.
      LOOP AT lt_xls_comp INTO ls_xls_comp.

        " field category 에 없으면 skip
        IF it_fieldcat[] IS NOT INITIAL.
          READ TABLE it_fieldcat WITH KEY fieldname = ls_xls_comp-name
               TRANSPORTING NO FIELDS.
          CHECK sy-subrc = 0.
        ENDIF.

        UNASSIGN: <lv_xls_field>.
        CONCATENATE `<LS_XLS_DATA>` `-` ls_xls_comp-name INTO lv_xls_field.
        ASSIGN (lv_xls_field) TO <lv_xls_field>.

        CHECK <lv_xls_field> IS ASSIGNED.

        IF <lv_xls_field> IS INITIAL AND iv_no_clear IS INITIAL.
          CLEAR lv_xls_data.
        ELSE.

          CASE iv_conv_routine.
            WHEN space.
              WRITE <lv_xls_field> TO lv_xls_data LEFT-JUSTIFIED.

            WHEN 'DEFAULT'.
              me->xls_download_conv_default( EXPORTING iv_value = <lv_xls_field>
                                             IMPORTING ev_value = lv_xls_data ).

            WHEN OTHERS.
              WRITE <lv_xls_field> TO lv_xls_data LEFT-JUSTIFIED .
              PERFORM (iv_conv_routine)  IN PROGRAM (gv_repid) IF FOUND
                                         USING    ls_xls_comp-name
                                                  <ls_xls_data>
                                         CHANGING lv_xls_data.
          ENDCASE.

        ENDIF.

        CONCATENATE ls_xls_data_out-line  lv_xls_data
                    cl_abap_char_utilities=>horizontal_tab
               INTO ls_xls_data_out-line.

      ENDLOOP.

      APPEND ls_xls_data_out TO ct_xls_data.

    ENDLOOP.

  ENDMETHOD.


  METHOD xls_copy_title.

    " xls layout 의 title 정보를 가지고 온다
    DATA: lv_index    TYPE sy-tabix,
          lo_table    TYPE REF TO data,
          lv_title    TYPE bapi_msg,
          ls_xls_data TYPE zmdmmms9030,
          ls_xls_comp TYPE abap_componentdescr,
          lt_xls_comp TYPE abap_component_tab,
          ls_fieldcat TYPE lvc_s_fcat,
          lt_fieldcat TYPE lvc_t_fcat.

    FIELD-SYMBOLS:
       <lt_table> TYPE STANDARD TABLE.

    CHECK is_xls_layout IS NOT SUPPLIED OR ct_fieldcat[] IS NOT INITIAL.

    IF go_alv_info IS INITIAL.
      CREATE OBJECT go_alv_info
        EXPORTING
          iv_repid   = gv_repid
          io_comfunc = me.
    ENDIF.

    IF ct_fieldcat[] IS INITIAL.
      CREATE DATA lo_table LIKE TABLE OF is_xls_layout.
      ASSIGN lo_table->* TO <lt_table>.
      CHECK <lt_table> IS ASSIGNED.

      lt_fieldcat[] = go_alv_info->get_fieldcatalog( it_tab = <lt_table>[] ).
    ELSE.
      lt_fieldcat[] = ct_fieldcat[].
*      DELETE lt_fieldcat WHERE tech = 'X' OR no_out = 'X'.  " 숨김 필드명 삭제.
*      SORT lt_fieldcat BY col_pos.
    ENDIF.

    " 출력구조가 입력된 경우
    ASSIGN COMPONENT 1 OF STRUCTURE is_xls_layout TO FIELD-SYMBOL(<lv_check_field>).
    IF <lv_check_field> IS ASSIGNED.
      lt_xls_comp = me->fill_components( is_xls_layout ).
      SORT lt_xls_comp BY name.
      LOOP AT lt_fieldcat INTO ls_fieldcat.
        lv_index = sy-tabix.
        READ TABLE lt_xls_comp WITH KEY name = ls_fieldcat-fieldname
             TRANSPORTING NO FIELDS BINARY SEARCH.
        IF sy-subrc NE 0.
          DELETE lt_fieldcat.
        ELSE.
          IF gv_hide_out = abap_true.
            ls_fieldcat-tech   = space.
            ls_fieldcat-no_out = space.
            MODIFY lt_fieldcat FROM ls_fieldcat INDEX lv_index
                   TRANSPORTING tech no_out.
          ENDIF.
        ENDIF.
      ENDLOOP.

    ENDIF.

    DELETE lt_fieldcat WHERE tech = 'X' OR no_out = 'X'.  " 숨김 필드명 삭제.
    SORT lt_fieldcat BY col_pos.

    CLEAR: ls_xls_data.
    LOOP AT lt_fieldcat INTO ls_fieldcat.

      CLEAR: lv_title.
      IF ls_fieldcat-coltext IS NOT INITIAL.
        lv_title = ls_fieldcat-coltext.

      ELSEIF ls_fieldcat-reptext IS NOT INITIAL.
        lv_title = ls_fieldcat-reptext.
      ELSE.
        lv_title = ls_fieldcat-scrtext_m.
      ENDIF.

      CONCATENATE ls_xls_data-line
                  lv_title
                  cl_abap_char_utilities=>horizontal_tab
             INTO ls_xls_data-line.

    ENDLOOP.
    APPEND ls_xls_data TO et_xls_data.

    " title 에 사용된 fieldcategory
    ct_fieldcat[] = lt_fieldcat[].

  ENDMETHOD.


  METHOD xls_download.

    DATA: lo_table        TYPE REF TO data,
          ls_xls_layout   TYPE string,
          lt_xls_fieldcat TYPE lvc_t_fcat,
          lt_xls_data     TYPE zmdmmmy9030,
          lt_comp         TYPE abap_component_tab.

    FIELD-SYMBOLS:
           <lt_table> TYPE STANDARD TABLE.

    " excel 로 download 대상이 있는지 여부 확인
    CHECK it_xls_data[] IS NOT INITIAL.

    IF is_xls_layout IS NOT INITIAL AND it_fieldcat[] IS INITIAL.
      CREATE DATA lo_table LIKE TABLE OF is_xls_layout.
      ASSIGN lo_table->* TO <lt_table>.
      CHECK <lt_table> IS ASSIGNED.

      lt_xls_fieldcat[] = go_alv_info->get_fieldcatalog( it_tab = <lt_table>[] ).
    ELSE.
      lt_xls_fieldcat[] = it_fieldcat[].
    ENDIF.

    " title 정보\
    CLEAR: lt_xls_data.
    me->xls_copy_title( EXPORTING is_xls_layout = is_xls_layout
                        IMPORTING et_xls_data   = lt_xls_data
                        CHANGING  ct_fieldcat   = lt_xls_fieldcat ).



    " 입력된 data 를 download 형태로 변경
    me->xls_copy_out( EXPORTING iv_no_clear     = iv_no_clear
                                iv_conv_routine = iv_conv_routine
                                is_xls_layout   = is_xls_layout
                                it_fieldcat     = lt_xls_fieldcat
                                it_xls_data     = it_xls_data
                      CHANGING  ct_xls_data     = lt_xls_data
                                ct_xls_comp     = lt_comp ).

    " 변환된 excel data download

    DATA: lv_filename TYPE localfile,
          lv_fullpath TYPE string.

    GET TIME.
    CONCATENATE 'C:\TEMP\_' gv_repid '_' sy-datlo '_' sy-timlo '.XLS' INTO lv_filename.

    me->save_file_temp( lv_filename ).

*---------------------------------------------------------------------*

    " text file 로 download
    lv_fullpath = lv_filename.

    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        filename                = lv_fullpath
        filetype                = 'ASC'
        codepage                = gv_codepage
        show_transfer_status    = space
      CHANGING
        data_tab                = lt_xls_data[]
      EXCEPTIONS
        file_write_error        = 1
        no_batch                = 2
        gui_refuse_filetransfer = 3
        invalid_type            = 4
        no_authority            = 5
        unknown_error           = 6
        header_not_allowed      = 7
        separator_not_allowed   = 8
        filesize_not_allowed    = 9
        header_too_long         = 10
        dp_error_create         = 11
        dp_error_send           = 12
        dp_error_write          = 13
        unknown_dp_error        = 14
        access_denied           = 15
        dp_out_of_memory        = 16
        disk_full               = 17
        dp_timeout              = 18
        file_not_found          = 19
        dataprovider_exception  = 20
        control_flush_error     = 21
        not_supported_by_gui    = 22
        error_no_gui            = 23
        OTHERS                  = 24.

    CHECK iv_xls_execute = 'X'.

    " excel 실행
    CALL METHOD cl_gui_frontend_services=>execute
      EXPORTING
        application            = 'EXCEL.EXE'
        parameter              = lv_fullpath
      EXCEPTIONS
        cntl_error             = 1
        error_no_gui           = 2
        bad_parameter          = 3
        file_not_found         = 4
        path_not_found         = 5
        file_extension_unknown = 6
        error_execute_failed   = 7
        synchronous_failed     = 8
        not_supported_by_gui   = 9
        OTHERS                 = 10.

  ENDMETHOD.


  METHOD xls_download_conv_default.

    DATA: lv_field_type TYPE char1,
          lv_datum      TYPE datum,
          lv_uzeit      TYPE uzeit.

    " field Type 에 따라서..
    DESCRIBE FIELD iv_value  TYPE lv_field_type.

    CASE lv_field_type.
*    WHEN 'P'.
      WHEN 'D'.  " Date
        IF iv_value IS INITIAL.
*        lv_datum = iv_value.
          lv_datum = space.
          ev_value = lv_datum.
        ELSE.
          WRITE iv_value TO ev_value USING EDIT MASK '____.__.__'.
*          ev_value = iv_value.
        ENDIF.

      WHEN 'T'.  " Time
        IF iv_value IS INITIAL.
*        lv_uzeit = iv_value.
          lv_uzeit = space.
          ev_value = lv_uzeit.
        ELSE.
*          ev_value = iv_value.
          WRITE iv_value TO ev_value USING EDIT MASK '__:__:__'.
        ENDIF.

      WHEN OTHERS.
        WRITE iv_value TO ev_value LEFT-JUSTIFIED.
    ENDCASE.

  ENDMETHOD.


  METHOD xls_download_template.

    DATA: lv_file         TYPE rlgrap-filename,
          lv_filename     TYPE string,
          lv_sap_workdir  TYPE string,
          lv_error_flag,
          ls_wwwdata_item TYPE wwwdatatab,
          lv_extension    TYPE char10.

    DATA: lv_mi TYPE wwwdata-relid VALUE 'MI'.

    DATA lv_len TYPE i.
    lv_len = strlen( iv_filename ).
    IF lv_len > gc_file_max_len.
      " 파일명(Paths 포함)이 너무 깁니다.
      "507  The file name (including Paths) is too long.
      MESSAGE i000(oo) WITH TEXT-e03.
      EXIT.
    ENDIF.

    SELECT SINGLE
           relid
           objid
           checkout
           checknew
           chname
           tdate
           ttime
           text
      FROM wwwdata
      INTO CORRESPONDING FIELDS OF ls_wwwdata_item
      WHERE objid = iv_objid
        AND relid = lv_mi.
    IF sy-subrc NE 0.
*    Excel Template File does not exist.
      " Excel Template File 이 없습니다.
      MESSAGE i000(oo) WITH TEXT-e04.
      EXIT.
    ENDIF.

    DATA(lv_rc) = me->check_mimetype( iv_objid ).
    IF lv_rc NE 0.
      " MineType 또는 연결프로그램이 등록되어 있지 않습니다.
      MESSAGE i000(oo) WITH TEXT-e05.
      EXIT.
    ENDIF.


    " iv_filename 이 없는경우 : save_file_name
    IF iv_filename = space OR iv_filename_popup = abap_true.
      IF iv_filename_popup = abap_true.
        lv_file = iv_filename.
      ENDIF.
      lv_error_flag = me->save_file_name( CHANGING cv_filename = lv_file ).
      IF lv_error_flag = 'X' OR lv_file IS INITIAL.
        EXIT.
      ENDIF.
    ELSE.
      lv_file = iv_filename.
    ENDIF.


    " lv_file 이 '!' 인 경우 temp name 적용
    " iv_is_display : 'D'  조회, space  download


*lv_file    is display
*!          space
*!          'D'          SHOW_WEB_OBJECT
*xx         space        DOWNLOAD_WEB_OBJECT
*xx         'D'          DOWNLOAD_WEB_OBJECT   cl_gui_frontend_services=>execute

    IF lv_file = '!'.
      CALL METHOD cl_gui_frontend_services=>get_sapgui_workdir
        CHANGING
          sapworkdir           = lv_sap_workdir
        EXCEPTIONS
          cntl_error           = 1
          error_no_gui         = 2
          not_supported_by_gui = 3
          OTHERS               = 4.

      CALL FUNCTION 'WWWPARAMS_READ'
        EXPORTING
          relid = ls_wwwdata_item-relid
          objid = ls_wwwdata_item-objid
          name  = gc_xls_extension
        IMPORTING
          value = lv_extension.

      lv_file = lv_sap_workdir && '\~' && iv_objid && '_' &&
                sy-datlo && '_' && sy-timlo && lv_extension.
    ENDIF.

    " template download
    CALL FUNCTION 'DOWNLOAD_WEB_OBJECT'
      EXPORTING
        key         = ls_wwwdata_item
        destination = lv_file.


    CASE iv_is_display.
      WHEN 'X'.
        lv_filename = lv_file .

*  DOWNLOAD FILE 실행..
        CALL METHOD cl_gui_frontend_services=>execute
          EXPORTING
            document               = lv_filename
          EXCEPTIONS
            cntl_error             = 1
            error_no_gui           = 2
            bad_parameter          = 3
            file_not_found         = 4
            path_not_found         = 5
            file_extension_unknown = 6
            error_execute_failed   = 7
            synchronous_failed     = 8
            not_supported_by_gui   = 9
            OTHERS                 = 10.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                     WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ELSE.
          " XLS Template Download complete.
          " XLS Template Download 가 완료 되었습니다.
          MESSAGE s000(oo) WITH TEXT-e06.
        ENDIF.

      WHEN OTHERS.
    ENDCASE.

    ev_filename = lv_file.

  ENDMETHOD.


  METHOD xls_is_scientific.

    " 문자와 지수를 구분하지 못함
    " 지수의 표현을 변경 1234E2 이것은 문자로,
    "                    1234E-1 또는 1234E+1 이것은 지수로 인식
    " 입력된 값이 xxE-xx 인데 문자인 경우 발생시
    " 지수 변경은 ce_numc_i 에서 수행 해야 함. -> 여기는 삭제

    DATA(u) = to_upper( iv_text ).
*    FIND REGEX '^[\+\-]?\d+(\.\d+)?E[\+\-]?\d+$' IN u ##REGEX_POSIX.
    FIND REGEX '^[+-]?[[:digit:]]+(\.[[:digit:]]+)?E[+-][[:digit:]]+$'
            IN u IGNORING CASE ##REGEX_POSIX.
    rv_yes = xsdbool( sy-subrc = 0 ).

  ENDMETHOD.


  METHOD xls_parse_meta_hidden.

    " dimension
    FIND REGEX '<dimension[^>]*ref="([A-Z]+)(\d+):([A-Z]+)(\d+)"' IN iv_sheet_xml IGNORING CASE
      SUBMATCHES DATA(c1) DATA(r1) DATA(c2) DATA(r2) ##REGEX_POSIX.
    ev_max_row = CONV i( r2 ).
    ev_max_col = xls_col_letters_to_idx( c2 ).

    " 숨김 열 범위
    DATA off TYPE i VALUE 0.
    WHILE off < strlen( iv_sheet_xml ).
      FIND REGEX '<col[^>]*min="(\d+)"[^>]*max="(\d+)"[^>]*hidden="1"' IN iv_sheet_xml+off
        IGNORING CASE MATCH OFFSET DATA(mo) MATCH LENGTH DATA(ml)
        SUBMATCHES DATA(mins) DATA(maxs) ##REGEX_POSIX.
      IF sy-subrc <> 0. EXIT. ENDIF.
      DO ( CONV i( maxs ) - CONV i( mins ) + 1 ) TIMES.
        APPEND ( CONV i( mins ) + sy-index - 1 ) TO et_hidden_cols.
      ENDDO.
      off = off + mo + ml.
    ENDWHILE.

    " 숨김 행
    off = 0.
    WHILE off < strlen( iv_sheet_xml ).
      FIND REGEX '<row[^>]*r="(\d+)"[^>]*hidden="1"' IN iv_sheet_xml+off IGNORING CASE
        MATCH OFFSET mo MATCH LENGTH ml SUBMATCHES DATA(rs) ##REGEX_POSIX.
      IF sy-subrc <> 0. EXIT. ENDIF.
      APPEND CONV i( rs ) TO et_hidden_rows.
      off = off + mo + ml.
    ENDWHILE.

    " autoFilter
    FIND REGEX '<autoFilter[^>]*ref="([^"]+)"' IN iv_sheet_xml IGNORING CASE
      SUBMATCHES ev_filter_ref ##REGEX_POSIX.
    ev_has_filter = xsdbool( sy-subrc = 0 ).

  ENDMETHOD.


  METHOD xls_parse_simple_filters.

    DATA out TYPE tyt_filters.
    DATA off TYPE i VALUE 0.
    WHILE off < strlen( iv_sheet_xml ).
      FIND REGEX
      '<filterColumn[^>]*colId="(\d+)"[^>]*>([^<]*)</filterColumn>'
      IN iv_sheet_xml+off
        IGNORING CASE MATCH OFFSET DATA(mo) MATCH LENGTH DATA(ml) SUBMATCHES DATA(cid_s) DATA(body) ##REGEX_POSIX.
      IF sy-subrc <> 0. EXIT. ENDIF.
      DATA cid TYPE i.
      cid = cid_s.
      DATA vals TYPE stringtab.
      DATA off2 TYPE i VALUE 0.
      WHILE off2 < strlen( body ).
        FIND REGEX '<filter[^>]*val="([^"]+)"' IN body+off2 IGNORING CASE
          MATCH OFFSET DATA(mo2) MATCH LENGTH DATA(ml2) SUBMATCHES DATA(v) ##REGEX_POSIX.
        IF sy-subrc <> 0. EXIT. ENDIF.
        APPEND v TO vals.
        off2 = off2 + mo2 + ml2.
      ENDWHILE.
      IF vals IS NOT INITIAL.
        INSERT VALUE #( col_id = cid values = vals ) INTO TABLE out.
      ENDIF.
      off = off + mo + ml.
    ENDWHILE.
    rt_filters = out.

  ENDMETHOD.


  METHOD xls_sheet_name_to_path.

    rv_path = ''.

    " 1) ZIP 로드 및 workbook.xml 추출
    DATA(zip) = NEW cl_abap_zip( ).
    TRY.
        zip->load( iv_zip ).
      CATCH cx_root.
        RETURN.
    ENDTRY.

    DATA lx_work TYPE xstring.
    zip->get( EXPORTING name = 'xl/workbook.xml' IMPORTING content = lx_work ).
    IF lx_work IS INITIAL.
      RETURN.
    ENDIF.
    DATA(workbook_xml) = cl_abap_codepage=>convert_from( lx_work ).

    " 2) workbook.xml 파싱, r 네임스페이스 URI 확보
    DATA(lo_ixml) = cl_ixml=>create( ).
    DATA(lo_sf)   = lo_ixml->create_stream_factory( ).
    DATA(lo_is)   = lo_sf->create_istream_string( workbook_xml ).
    DATA(lo_doc)  = lo_ixml->create_document( ).
    DATA(lo_par)  = lo_ixml->create_parser(
                      stream_factory = lo_sf
                      istream        = lo_is
                      document       = lo_doc ).
    IF lo_par->parse( ) <> 0.
      RETURN.
    ENDIF.

    DATA(lv_ruri) = lo_doc->get_root_element( )->get_attribute( name = 'xmlns:r' ).
    IF lv_ruri IS INITIAL.
      " OOXML 관습 URI 폴백
      lv_ruri = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'.
    ENDIF.

    " 3) <sheet>에서 시트명 매칭 → r:id 획득(get_attribute_ns 우선)
    DATA lv_rid TYPE string.
    DATA(lo_it)  = lo_doc->create_iterator( ).
    DATA(lo_nd)  = lo_it->get_next( ).

    WHILE lo_nd IS BOUND.
      IF lo_nd->get_type( ) = if_ixml_node=>co_node_element.
        DATA(lo_el) = CAST if_ixml_element( lo_nd ).
        IF to_upper( lo_el->get_name( ) ) = 'SHEET'.
          DATA(lv_name) = lo_el->get_attribute( name = 'name' ).  " string
          IF lv_name IS INITIAL OR to_upper( lv_name ) <> to_upper( iv_sheet_name ).
            lo_nd = lo_it->get_next( ).
            CONTINUE.
          ENDIF.

          " 네임스페이스 방식 우선
          DATA(lv_id) = lo_el->get_attribute_ns( name = 'id' uri = lv_ruri ).
          IF lv_id IS INITIAL.
            " 접두어 표기 폴백
            lv_id = lo_el->get_attribute( name = 'r:id' ).
          ENDIF.

          IF lv_id IS INITIAL.
            " 최후 폴백: 속성 맵 전수조사
            DATA(lo_attrs) = lo_el->get_attributes( ).
            IF lo_attrs IS BOUND.
              DO lo_attrs->get_length( ) TIMES.
                DATA(lo_attr) = lo_attrs->get_item( sy-index - 1 ).
                IF lo_attr IS BOUND.
                  DATA(aname) = lo_attr->get_name( ).
                  DATA(auri)  = lo_attr->get_namespace_uri( ).
                  IF ( to_upper( aname ) = 'R:ID' )
                   OR ( to_upper( aname ) = 'ID' AND auri = lv_ruri ).
                    lv_id = lo_attr->get_value( ).
                    EXIT.
                  ENDIF.
                ENDIF.
              ENDDO.
            ENDIF.
          ENDIF.

          IF lv_id IS NOT INITIAL.
            lv_rid = lv_id.
            EXIT.
          ENDIF.
        ENDIF.
      ENDIF.
      lo_nd = lo_it->get_next( ).
    ENDWHILE.

    IF lv_rid IS INITIAL.
      RETURN. " 시트명 매칭 실패 또는 r:id 획득 실패
    ENDIF.

    " 4) workbook.xml.rels 에서 r:id → Target 매핑
    DATA lx_rels TYPE xstring.
    zip->get( EXPORTING name = 'xl/_rels/workbook.xml.rels' IMPORTING content = lx_rels ).
    IF lx_rels IS INITIAL.
      RETURN.
    ENDIF.
    DATA(rels_xml) = cl_abap_codepage=>convert_from( lx_rels ).

    DATA(lo_doc2) = lo_ixml->create_document( ).
    DATA(lo_is2)  = lo_sf->create_istream_string( rels_xml ).
    DATA(lo_par2) = lo_ixml->create_parser(
                      stream_factory = lo_sf
                      istream        = lo_is2
                      document       = lo_doc2 ).
    IF lo_par2->parse( ) <> 0.
      RETURN.
    ENDIF.

    DATA(lo_it2) = lo_doc2->create_iterator( ).
    DATA(lo_nd2) = lo_it2->get_next( ).
    WHILE lo_nd2 IS BOUND.
      IF lo_nd2->get_type( ) = if_ixml_node=>co_node_element.
        DATA(lo_rel) = CAST if_ixml_element( lo_nd2 ).
        IF to_upper( lo_rel->get_name( ) ) = 'RELATIONSHIP'.
          lv_id  = lo_rel->get_attribute( name = 'Id' ).      " string
          IF lv_id = lv_rid.
            DATA(lv_tgt) = lo_rel->get_attribute( name = 'Target' ). " ex) 'worksheets/sheet1.xml'
            IF lv_tgt IS NOT INITIAL.
              " 상대경로 정리
              REPLACE ALL OCCURRENCES OF './' IN lv_tgt WITH ''.
              IF lv_tgt CP '/xl/*'. lv_tgt = lv_tgt+1. ENDIF.  " '/xl/...' → 'xl/...'
              IF lv_tgt CP 'xl/*'.
                rv_path = lv_tgt.
              ELSE.
                rv_path = |xl/{ lv_tgt }|.
              ENDIF.
              RETURN.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
      lo_nd2 = lo_it2->get_next( ).
    ENDWHILE.
    " 실패 시 rv_path = INITIAL

  ENDMETHOD.


  METHOD xls_to_char.

    DATA lv_txt TYPE string.
    lv_txt = iv_text.
    CONDENSE lv_txt.
    IF me->xls_is_scientific( lv_txt ) = abap_false.
      rv = lv_txt. RETURN.
    ENDIF.

    " 과학적 표기 -> 일반 십진 문자열
    DATA(lv_txt_u) =  to_upper( lv_txt ).
    DATA: lv_sign TYPE string.
*    IF u CP '-*' OR u CP '+*'. sign = u+0(1). u = u+1. ENDIF.
    IF lv_txt_u+0(1) = '-' OR lv_txt_u+0(1) = '+'. lv_sign = lv_txt_u+0(1). lv_txt_u = lv_txt_u+1. ENDIF.

    SPLIT lv_txt_u AT 'E' INTO DATA(mant) DATA(exp_s).
    DATA(exp_i) = exp_s.
    FIND FIRST OCCURRENCE OF '.' IN mant MATCH OFFSET DATA(dp).

    DATA(lv_dp_p) = dp + 1.
    DATA(int_part)  = COND string( WHEN sy-subrc = 0 THEN mant+0(dp) ELSE mant ).
    DATA(frac_part) = COND string( WHEN sy-subrc = 0 THEN mant+lv_dp_p ELSE '' ).
    DATA digits TYPE string.
    digits = int_part && frac_part.
    SHIFT digits LEFT DELETING LEADING '0'.
    IF digits IS INITIAL. digits = '0'. ENDIF.

    DATA: plain         TYPE string,
          lv_split_pos  TYPE i,
          lv_split_posx TYPE i.

    IF exp_i >= 0.
      DATA move_r TYPE i.
      move_r =  exp_i - strlen( frac_part ).
      IF move_r >= 0.
        plain = digits && repeat( val = '0' occ = move_r ).
      ELSE.
        lv_split_pos =  strlen( int_part ) + exp_i.
        IF lv_split_pos <= 0.
          lv_split_posx = lv_split_pos * '-1'.
          plain = '0.' && repeat( val = '0' occ = lv_split_posx ) && digits.
        ELSE.
          plain = digits+0(lv_split_pos) && '.' && digits+lv_split_pos.
        ENDIF.
      ENDIF.
    ELSE.
      DATA k TYPE i.
      k = exp_i * '-1'.
      plain = '0.' && repeat( val = '0' occ = k - strlen( int_part ) ) && digits.
    ENDIF.

    IF lv_sign = '-' AND plain <> '0'. plain = '-' && plain. ENDIF.

    rv = plain.


  ENDMETHOD.


  METHOD xls_unzip_get_xml.

    DATA(zip) = NEW cl_abap_zip( ). zip->load( iv_zip ).
    DATA lx TYPE xstring.
    zip->get( EXPORTING name = iv_path
              IMPORTING content = lx
              EXCEPTIONS OTHERS  = 1 ).
    rv_xml = cl_abap_codepage=>convert_from( lx ).

  ENDMETHOD.


  METHOD xls_upload.

    CONSTANTS:
      lc_upload_msg TYPE bapi_msg VALUE 'Excel File Upload'.

    TYPES: BEGIN OF tys_xls_col,
             field(1000),
           END OF tys_xls_col,
           tyt_xls_col TYPE TABLE OF tys_xls_col.

    DATA: lv_end_colv      TYPE i VALUE 70,
          lv_end_linev     TYPE i VALUE 14,
          lv_msg           TYPE bapi_msg,
          lv_disp_filename TYPE filep.

    DATA: lo_stru_ref TYPE REF TO cl_abap_structdescr,
          lo_tab_ref  TYPE REF TO cl_abap_tabledescr,
          lo_clss_ref TYPE REF TO cl_abap_classdescr.

    DATA: lv_filename    TYPE rlgrap-filename,
          lv_start_col   TYPE i VALUE '1',
          lv_start_row   TYPE i VALUE '2',
          lv_end_col     TYPE i VALUE '256',
          lv_end_row     TYPE i VALUE '65536',
          lt_execl_tmp   TYPE kcde_sender,
          ls_execl_tmp   TYPE kcde_sender_struc,
          ls_xls_comp    TYPE abap_componentdescr,
          lt_xls_comp    TYPE abap_component_tab,
          lt_comp_       TYPE abap_component_tab,
          ls_excel_col_n TYPE tys_xls_col,
          ls_excel_col   TYPE tys_xls_col,
          lt_excel_col   TYPE tyt_xls_col,
          ls_xls_error   TYPE tys_xls_error,
          lt_xls_error   TYPE tyt_xls_error,
          lv_separator   TYPE c,
          lv_flag        TYPE c,
          lv_linex       TYPE sy-tabix,
          lv_tabix       TYPE sy-tabix,
          lv_tabix_n     TYPE sy-tabix.

    DATA: lo_xls_data TYPE REF TO data.
    FIELD-SYMBOLS : <lt_excel>  TYPE STANDARD TABLE.

    IF go_alv_info IS INITIAL.
      CREATE OBJECT go_alv_info
        EXPORTING
          iv_repid = gv_repid.
    ENDIF.

    DATA: lo_new_line  TYPE REF TO data,  " DEREFERENCE <FS>
          lo_new_table TYPE REF TO data.
    FIELD-SYMBOLS: <ls_work>  TYPE any,
                   <lv_field> TYPE any.

    CREATE DATA lo_new_line  LIKE LINE OF et_xls_data.
    ASSIGN lo_new_line->*      TO <ls_work>.
    CREATE DATA lo_new_table LIKE et_xls_data.
    ASSIGN lo_new_table->*      TO <lt_excel>.

    CLEAR: lt_execl_tmp[], lt_xls_error[],
           lv_separator, et_xls_data[], ev_cnt.

    lv_filename = iv_filename.
    IF lv_filename IS INITIAL.
* UPLOAD FILE 명 가지고 오기
      me->get_file_name( IMPORTING ev_filename   = lv_filename
                                   ev_error_flag = lv_flag ).
      IF lv_flag = 'X'.
        EXIT.
      ENDIF.
    ENDIF.

    " 해당 파일이 있는지 여부 확인
    IF me->check_file_name( iv_msg_type  = 'I'
                            iv_filename  = lv_filename ) = abap_true.
      EXIT.
    ENDIF.


    " Header line 줄 의 갯수..
    lv_start_row = iv_start_row.

    lo_tab_ref  ?= cl_abap_typedescr=>describe_by_data( et_xls_data ).
    lo_stru_ref ?= lo_tab_ref->get_table_line_type( ).
    lt_comp_     = lo_stru_ref->get_components( ).

* Table Type ##
    CLEAR: lt_xls_comp.
    LOOP AT lt_comp_ INTO DATA(ls_comp).
      IF ls_comp-type IS INSTANCE OF cl_abap_tabledescr.
        CONTINUE.
      ENDIF.

      APPEND ls_comp TO lt_xls_comp.
    ENDLOOP.

    " Column 수 정의..
    IF iv_end_col = 0.
      lv_end_col = 0.
      IF line_exists( lt_xls_comp[ name = gc_xls_endcol ] ).
        lv_end_col = line_index( lt_xls_comp[ name = gc_xls_endcol ] ) - 1.
        IF lv_end_col = 0. lv_end_col = 1. ENDIF.
      ENDIF.

      IF lv_end_col = 0.
        lv_end_col = lines( lt_xls_comp ).
      ENDIF.

    ELSE.
      lv_end_col = iv_end_col. " 외부에서 end_col 을 지정
    ENDIF.
    IF lv_end_col > lines( lt_xls_comp ).
      lv_end_col = lines( lt_xls_comp ).
    ENDIF.

    lv_end_row = iv_end_row.

* EXCEL FILE UPLOAD..
    me->split_paths( EXPORTING iv_paths    = lv_filename
                     IMPORTING ev_filename = lv_disp_filename ).

    CONCATENATE lc_upload_msg `( ` lv_disp_filename ` )`
           INTO lv_msg.

    " 화면에 조회..
    CALL FUNCTION 'SAPGUI_PROGRESS_INDICATOR'
      EXPORTING
        text = lv_msg.

    DATA: lt_excel_tmp1 TYPE  truxs_t_text_data.
    CASE gv_xls_upload_module.
      WHEN '1'. " OLE
        lo_xls_data = me->xls_upload_ole( iv_filename   = lv_filename
                                          iv_start_row  = 1 " lv_start_row 아래에서
                                          iv_start_col  = lv_start_col
                                          iv_end_col    = lv_end_col
                                          iv_sheet_name = iv_sheetname
                                          is_xls_layout = <ls_work>     ).
*                                       iv_del_title  = iv_del_title ).
        ASSIGN lo_xls_data->* TO <lt_excel>.

      WHEN '2'. " FDT
        lo_xls_data = me->xls_upload_fdt( iv_filename   = lv_filename
                                          iv_sheet_name = iv_sheetname ).
        ASSIGN lo_xls_data->* TO <lt_excel>.

      WHEN '3'. " 3:FUNCTION.
        CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
          EXPORTING
*           I_FIELD_SEPERATOR    =
            i_line_header        = space "'X'        "라인헤더유무
            i_tab_raw_data       = lt_excel_tmp1
            i_filename           = lv_filename
            i_step               = 300 " lv_start_row 진행상황 표시 건수
          TABLES
            i_tab_converted_data = <lt_excel>
          EXCEPTIONS
            conversion_failed    = 1
            OTHERS               = 2.
      WHEN OTHERS.
        EXIT.
    ENDCASE.


*****
******    lv_separator = `"` && cl_abap_char_utilities=>horizontal_tab && `"`.
    lv_separator = cl_abap_char_utilities=>horizontal_tab.

*****    DELETE <lt_excel> WHERE table_line IS INITIAL.
*****
*****    " total 건수
*****    gv_sp_total = lines( <lt_excel> ).
*****    gv_sp_msg   = lc_upload_msg.
*****    rv_type     = space.
*****
*****    IF gv_xls_max_line < gv_sp_total.
*****      rv_type = abap_true.
*****      " Upload Data 건수가 많습니다. &1 건 이내로 조정 하십시오.
*****      DATA(lv_message) = me->make_message_text( iv_msg_txt = TEXT-e02
*****                                                iv_parm1   = gv_xls_max_line ).
*****      MESSAGE i000(oo) WITH lv_message DISPLAY LIKE 'E'.
*****      EXIT.
*****    ENDIF.



    CLEAR et_xls_data.

    DATA: lv_type.
*****    LOOP AT lt_execl_tmp INTO ls_execl_tmp.
    LOOP AT <lt_excel> ASSIGNING FIELD-SYMBOL(<ls_excel>) FROM iv_start_row.

      CHECK <ls_excel> IS ASSIGNED.

      lv_linex = sy-tabix.

      me->show_message_p( sy-tabix ).
*****
*****
*****      CHECK NOT ls_execl_tmp IS INITIAL.
*****      SPLIT ls_execl_tmp-line AT lv_separator
*****            INTO TABLE lt_excel_col.
*****
      CLEAR: <ls_work>.
*****
*****      LOOP AT lt_excel_col INTO ls_excel_col.
      DO lv_end_col TIMES.
*****        lv_tabix = sy-tabix.
        lv_tabix = sy-index.

        UNASSIGN <lv_field>.
        ASSIGN COMPONENT lv_tabix OF STRUCTURE <ls_work> TO <lv_field>.
        CHECK sy-subrc EQ 0.

        ASSIGN COMPONENT lv_tabix OF STRUCTURE <ls_excel> TO FIELD-SYMBOL(<lv_xls_data>).
        CHECK sy-subrc EQ 0.

        ls_excel_col-field  = <lv_xls_data>.

        READ TABLE lt_xls_comp INTO ls_xls_comp INDEX lv_tabix.
        CHECK sy-subrc = 0.

        me->xls_upload_conv_default( EXPORTING iv_value = ls_excel_col-field
                                     IMPORTING ev_value = ls_excel_col-field ).

        DESCRIBE FIELD <lv_field> TYPE lv_type.
        CASE lv_type.

          WHEN 'D'. " DATE.
            <lv_field> = me->ce_date_i( ls_excel_col-field ).

          WHEN 'T'. " TIME
            <lv_field> = me->ce_time_i( ls_excel_col-field ).

          WHEN 'I'  OR 'P' OR 'b' OR 's' OR '8'. " 숫자인 경우..
            me->ce_numc_i( EXPORTING  iv_input    = ls_excel_col-field
                           IMPORTING  ev_output   = ls_excel_col-field
                           EXCEPTIONS not_numeric = 1 ).
            IF sy-subrc = 0.
              TRY .
                  <lv_field> = ls_excel_col-field.

                CATCH cx_sy_conversion_no_number.
                  CLEAR: <lv_field>.
                  CLEAR: ls_xls_error.
                  ls_xls_error-line      = lv_linex.
                  ls_xls_error-fieldname = ls_xls_comp-name.
                  ls_xls_error-message   = |Invalid Value <{ ls_excel_col-field }>|.
                  APPEND ls_xls_error TO lt_xls_error.
              ENDTRY.

            ELSE.
              CLEAR: <lv_field>.
              CLEAR: ls_xls_error.
              ls_xls_error-line      = lv_linex.
              ls_xls_error-fieldname = ls_xls_comp-name.
              ls_xls_error-message   = |Invalid Value <{ ls_excel_col-field }>|.
              APPEND ls_xls_error TO lt_xls_error.
            ENDIF.

          WHEN OTHERS.
***            IF ls_excel_col-field IS INITIAL.
***              CLEAR: <lv_field>.
***
***            ELSE.
            WRITE ls_excel_col-field TO <lv_field>  LEFT-JUSTIFIED.

            " upload data 에 대한 check 사항이 있는 경우
            CASE iv_check_routine.
              WHEN space.
              WHEN 'DEFAULT'.
                me->xls_upload_conv_default( EXPORTING iv_value = <lv_field>
                                             IMPORTING ev_value = <lv_field> ).
              WHEN OTHERS.
                PERFORM (iv_check_routine) IN PROGRAM (gv_repid) IF FOUND
                                           USING    ls_xls_comp-name
                                           CHANGING <ls_work> <lv_field>.
            ENDCASE.
***            ENDIF.
        ENDCASE.
*****
*****      ENDLOOP.
      ENDDO.

      APPEND <ls_work> TO et_xls_data.

    ENDLOOP.

    IF lt_xls_error[] IS NOT INITIAL.
      me->xls_upload_display_error( lt_xls_error[] ).
      ev_cnt = 0.
      EXIT.
    ENDIF.

    ev_cnt = lines( et_xls_data ).
**********
**********    IF ev_cnt = 0.
**********      "Upload 된 Data 가 없습니다.;No data uploaded.
**********      MESSAGE s000(oo) WITH 'Upload 된 Data 가 없습니다.'.
**********    ELSE.
**********      " &1 건이 Upload 되었습니다.;& cases Uploaded.
**********      MESSAGE s000(oo) WITH ev_cnt '건이 Upload 되었습니다.'.
**********    ENDIF.
***********  ENDIF.

  ENDMETHOD.                    "XLS_UPLOAD


  METHOD xls_upload_conv_default.

    DATA: lv_field_value TYPE txt1024,
          lv_char_value  TYPE string,
          lv_char_valuex TYPE xstring,
          lo_convin      TYPE REF TO cl_abap_conv_in_ce.

    DATA: lv_len  TYPE i,
          lv_pos  TYPE i,
          lv_posx TYPE i.

    CHECK iv_value IS NOT INITIAL.

    lv_field_value = iv_value.

    " 처음 문자가 '"' 인 경우 마지막 문자도 '"' 인지 확인 한다
    " 동일한 경우 두 문자를 제거한다
    IF lv_field_value+0(1) = `"`.
      lv_pos  = me->strlenx( lv_field_value ) - 1.
      lv_posx = strlen( lv_field_value ) - 1.
      IF lv_field_value+lv_pos(1) = `"` OR
         lv_field_value+lv_posx(1) = `"`.

        IF lv_field_value+lv_pos(1) = `"`.
          lv_field_value+lv_pos(1) = ``.
        ENDIF.

        IF lv_field_value+lv_posx(1) = `"`.
          lv_field_value+lv_posx(1) = ``.
        ENDIF.

        lv_field_value+0(1) = ``.

      ENDIF.
    ENDIF.

    lv_char_value = lv_field_value.

    " "" 인 정보가 있는 경우 " 으로 변경
    REPLACE ALL OCCURRENCES OF `""` IN lv_char_value WITH `"`.

    " 공백제거
    SHIFT lv_field_value LEFT DELETING LEADING space.


    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text     = lv_char_value
        encoding = gv_codepage
      IMPORTING
        buffer   = lv_char_valuex.

    SHIFT lv_char_valuex RIGHT DELETING TRAILING gc_type_xc2a0 IN BYTE MODE.
    SHIFT lv_char_valuex RIGHT DELETING TRAILING gc_type_x00a0 IN BYTE MODE.
    SHIFT lv_char_valuex LEFT  DELETING LEADING  gc_type_x0000 IN BYTE MODE.
    SHIFT lv_char_valuex LEFT  DELETING LEADING  gc_type_x0900 IN BYTE MODE.

    " xstring to string
    CALL METHOD cl_abap_conv_in_ce=>create
      EXPORTING
        encoding = gv_codepage
        input    = lv_char_valuex
      RECEIVING
        conv     = lo_convin.

    CALL METHOD lo_convin->read
      IMPORTING
        data = lv_char_value.

    lv_field_value = lv_char_value.

    " 개행문자가 있는지 확인
    FIND cl_abap_char_utilities=>newline IN lv_field_value.
    IF sy-subrc = 0.
      REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline
              IN lv_field_value WITH ' '.
*    REPLACE ALL OCCURRENCES OF `"` IN lv_field_value WITH ''.
    ENDIF.

    ev_value = lv_field_value.

  ENDMETHOD.


  METHOD xls_upload_display_error.
  ENDMETHOD.


  METHOD xls_upload_fdt.

    DATA: lv_filepath     TYPE string,
          lt_bin          TYPE solix_tab,
          lv_xstr         TYPE xstring,
          lv_woksheetname TYPE string,
          lv_del_row      TYPE i,
          lv_rc           TYPE i,
          lv_active_idx   TYPE i,
          lo_excel_ref    TYPE REF TO cl_fdt_xl_spreadsheet,
          lo_data         TYPE REF TO data.

    lv_filepath = iv_filename.

    FIELD-SYMBOLS : <lt_excel>  TYPE STANDARD TABLE.

    " 2) 바이너리 업로드 → SOLIXTAB
    CALL METHOD cl_gui_frontend_services=>gui_upload
      EXPORTING
        filename                = lv_filepath
        filetype                = 'BIN'
      IMPORTING
        filelength              = DATA(lv_len)
      CHANGING
        data_tab                = lt_bin
      EXCEPTIONS
        file_open_error         = 1
        file_read_error         = 2
        no_batch                = 3
        gui_refuse_filetransfer = 4
        OTHERS                  = 5.
    IF sy-subrc <> 0.
***      lt_bin = me->xls_upload_ole( iv_filename = iv_filename ).
      IF lt_bin IS INITIAL.
        MESSAGE '파일 읽기 실패(GUI_UPLOAD)' TYPE 'E'.
        EXIT.
      ENDIF.
    ENDIF.

    " 3) SOLIXTAB → XSTRING
    lv_xstr = cl_bcs_convert=>solix_to_xstring( it_solix = lt_bin ).

    TRY .
        lo_excel_ref = NEW cl_fdt_xl_spreadsheet( document_name = lv_filepath
                                                  xdocument     = lv_xstr  ) .

      CATCH cx_fdt_excel_core INTO DATA(ls_oref).
        "Implement suitable error handling here

    ENDTRY .

    "Get List of Worksheets
    lo_excel_ref->if_fdt_doc_spreadsheet~get_worksheet_names( IMPORTING worksheet_names = DATA(lt_worksheets) ).

    CHECK lt_worksheets IS NOT INITIAL.

    " 입력된 sheet 가 있는 경우
    IF iv_sheet_name IS NOT INITIAL.
      READ TABLE lt_worksheets INTO lv_woksheetname WITH KEY table_line = iv_sheet_name.
      IF sy-subrc NE 0.
        CLEAR: lv_woksheetname.
      ENDIF.
    ENDIF.

    " 입력된 sheet 가 없거나 검색된 sheet 가 없는 경우
    IF iv_sheet_name IS INITIAL OR lv_woksheetname IS INITIAL.

      TRY.
          " 마지막에 저장된 sheet 정보를 가지고 온다
          lcl_active_sheet=>get_active( EXPORTING i_xlsx_xstr   = lv_xstr
                                        IMPORTING e_active_name = lv_woksheetname
                                                  e_active_idx  = lv_active_idx ).

        CATCH cx_root.
          " 에러 또는 없는 경우
          READ TABLE lt_worksheets INTO lv_woksheetname INDEX 1.

      ENDTRY.
    ENDIF.

    " 지정된 sheet 의 data 를 읽어서 return 한다
    DATA(lo_xls_data) = lo_excel_ref->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_woksheetname ).

*--------------------------------------------------------------------*
    FIELD-SYMBOLS: <lt_xls_data> TYPE STANDARD TABLE,
                   <ls_row>      TYPE any,
                   <cell>        TYPE any,
                   <lv_cellx>    TYPE any.

    ASSIGN lo_xls_data->* TO <lt_xls_data>.
    CHECK <lt_xls_data> IS ASSIGNED.

    DATA lv_rows TYPE i.
    DATA lv_row_idx TYPE i VALUE 0.
    DESCRIBE TABLE <lt_xls_data> LINES lv_rows.
    CHECK lv_rows > 0.

    " 2) (선택) 시트 XML에서 숨김/필터 메타 파싱
    DATA lt_hidden_rows TYPE tyt_hidden_rows.
    DATA lt_hidden_cols TYPE tyt_hidden_cols.
    DATA lt_filters     TYPE tyt_filters.

    " 필요 시: 아래 두 유틸은 앞서 드린 클래스( zcl_xlsx_fdt_visible_reader )에서 가져오세요
    DATA(lv_sheet_path) = me->xls_sheet_name_to_path( iv_zip        = lv_xstr
                                                      iv_sheet_name = lv_woksheetname ).
    IF lv_sheet_path IS INITIAL.
      lv_sheet_path = |xl/worksheets/{ lv_woksheetname }.xml|.
    ENDIF.

    DATA(lv_sheet_xml)  = me->xls_unzip_get_xml( iv_zip  = lv_xstr
                                                 iv_path = lv_sheet_path ).


    DATA lv_max_row TYPE i.
    DATA lv_max_col TYPE i.
    DATA lv_has_filter TYPE abap_bool.
    DATA lv_filter_ref TYPE string.
    me->xls_parse_meta_hidden( EXPORTING iv_sheet_xml   = lv_sheet_xml
                               IMPORTING ev_max_row     = lv_max_row
                                         ev_max_col     = lv_max_col
                                         et_hidden_rows = lt_hidden_rows
                                         et_hidden_cols = lt_hidden_cols
                                         ev_has_filter  = lv_has_filter
                                         ev_filter_ref  = lv_filter_ref ).

    IF lv_has_filter = abap_true.
      lt_filters = me->xls_parse_simple_filters( lv_sheet_xml ).
    ENDIF.

    " 3) FDT 테이블의 라인타입과 열 개수 파악
    DATA lo_tdesc TYPE REF TO cl_abap_tabledescr.
    DATA lo_lined TYPE REF TO cl_abap_typedescr.
    DATA lo_sdesc TYPE REF TO cl_abap_structdescr.
    lo_tdesc ?= cl_abap_tabledescr=>describe_by_data_ref( lo_xls_data ).
    lo_lined = lo_tdesc->get_table_line_type( ).

    DATA lv_comp_cnt TYPE i VALUE 1.
    DATA lt_comps TYPE abap_compdescr_tab.
    DATA lt_compx TYPE cl_abap_structdescr=>component_table.
    IF lo_lined->type_kind = cl_abap_typedescr=>typekind_struct1 OR "      typekind_struct.
       lo_lined->type_kind = cl_abap_typedescr=>typekind_struct2. "      typekind_struct.
      lo_sdesc ?= lo_lined.
      lt_comps = lo_sdesc->components.
      lv_comp_cnt = lines( lt_comps ).            " 열 개수

      lt_compx = me->build_component_tab( lt_comps ).

      IF lt_hidden_cols IS NOT INITIAL.
        SORT lt_hidden_cols BY table_line DESCENDING.
        LOOP AT lt_hidden_cols INTO lv_rows.
          DELETE lt_compx INDEX lv_rows.
        ENDLOOP.

        SORT lt_hidden_cols BY table_line.
      ENDIF.

      " 동적 구조/테이블 생성
      DATA(lo_sdescx) = cl_abap_structdescr=>create( lt_compx ).
      DATA(lo_tdescx) = cl_abap_tabledescr=>create( p_line_type = lo_sdescx ).

      DATA: lo_tabx TYPE REF TO data,
            lo_strx TYPE REF TO data.
      FIELD-SYMBOLS: <lt_tabx> TYPE STANDARD TABLE,
                     <ls_strx> TYPE any.

      CREATE DATA lo_tabx TYPE HANDLE lo_tdescx.
      CREATE DATA lo_strx TYPE HANDLE lo_sdescx.

      ASSIGN lo_tabx->* TO <lt_tabx>.
      ASSIGN lo_strx->* TO <ls_strx>.

    ENDIF.

    " 4) 결과: 보이는 행/열만 + 지수형 숫자 → 문자 평탄화
    DATA lt_cells TYPE stringtab.
    LOOP AT <lt_xls_data> ASSIGNING <ls_row>.
      lv_row_idx = lv_row_idx + 1.

      " 숨김 행이면 스킵
      IF line_exists( lt_hidden_rows[ table_line = lv_row_idx ] ).
        CONTINUE.
      ENDIF.

      CLEAR: lt_cells.
      IF lo_lined->type_kind = cl_abap_typedescr=>typekind_struct1 OR
         lo_lined->type_kind = cl_abap_typedescr=>typekind_struct2.
        DO lv_comp_cnt TIMES.
          " 숨김 열이면 스킵 (열 인덱스: 1-based)
          IF line_exists( lt_hidden_cols[ table_line = sy-index ] ).
            CONTINUE.
          ENDIF.

          ASSIGN COMPONENT sy-index OF STRUCTURE <ls_row> TO <cell>.
          IF sy-subrc <> 0.
            CONTINUE.
          ENDIF.

          DATA(lv_val) = CONV string( <cell> ).

          " 지수형 → 평문 숫자 문자열
          IF me->xls_is_scientific( lv_val ) = abap_true.
            lv_val = me->xls_to_char( lv_val ).
          ENDIF.

          APPEND lv_val TO lt_cells.
        ENDDO.

      ELSE.

        " 라인타입이 구조가 아니라 단일 문자열인 드문 케이스
        DATA(lv_val2) = CONV string( <ls_row> ).
        IF me->xls_is_scientific( lv_val2 ) = abap_true.
          lv_val2 = me->xls_to_char( lv_val2 ).
        ENDIF.
        APPEND lv_val2 TO lt_cells.
      ENDIF.

      " (선택) 필터(단순 값 목록) 적용
      IF lv_has_filter = abap_true AND lt_filters IS NOT INITIAL.
        DATA(lv_drop) = abap_false.
        LOOP AT lt_filters ASSIGNING FIELD-SYMBOL(<f>).
          DATA(lx) = <f>-col_id + 1.  " Excel colId는 0-based → 1-based 보정
          READ TABLE lt_cells INDEX lx INTO DATA(v).
          IF sy-subrc = 0 AND NOT line_exists( <f>-values[ table_line = v ] ).
            lv_drop = abap_true. EXIT.
          ENDIF.
        ENDLOOP.
        IF lv_drop = abap_true.
          CONTINUE.
        ENDIF.
      ENDIF.

      CLEAR: <ls_strx>.
      LOOP AT lt_cells INTO DATA(ls_cell).
        ASSIGN COMPONENT sy-tabix OF STRUCTURE <ls_strx> TO <lv_cellx>.
        IF sy-subrc NE 0. EXIT. ENDIF.
        <lv_cellx> = ls_cell.
      ENDLOOP.
      APPEND <ls_strx> TO <lt_tabx>.

    ENDLOOP.

    " 5) 기존 반환 레퍼런스(ro_xls_data)에 적재
    GET REFERENCE OF <lt_tabx> INTO ro_xls_data.

  ENDMETHOD.


  METHOD xls_upload_ole.

    DATA: lo_application    TYPE ole2_object,
          lo_workbook       TYPE ole2_object,
          lo_range          TYPE ole2_object,
          lo_activeworkbook TYPE ole2_object,
          lo_activesheet    TYPE ole2_object,
          lo_sheet_new      TYPE ole2_object,
          lo_start_cell     TYPE ole2_object,
          lo_end_cell       TYPE ole2_object,
          lo_end            TYPE ole2_object.

    " 입력된 paths 에서 파일명 분리
    DATA: lv_disp_filename TYPE filep,
          lt_excel_data    TYPE kcde_sender,
          lv_end_col       TYPE i,
          lo_work          TYPE REF TO data,
          lo_excel         TYPE REF TO data.

    DATA: lo_stru_ref TYPE REF TO cl_abap_structdescr,
          lo_clss_ref TYPE REF TO cl_abap_classdescr,
          lt_comp_    TYPE abap_component_tab,
          ls_xls_comp TYPE abap_componentdescr,
          lt_xls_comp TYPE abap_component_tab.

    FIELD-SYMBOLS:
      <lv_field> TYPE any,
      <ls_work>  TYPE any,
      <lt_excel> TYPE STANDARD TABLE.

    CREATE DATA lo_work LIKE is_xls_layout.
    ASSIGN lo_work->*      TO <ls_work>.

    CREATE DATA lo_excel LIKE TABLE OF is_xls_layout.
    ASSIGN lo_excel->*      TO <lt_excel>.

    IF <ls_work> IS NOT ASSIGNED OR <lt_excel> IS NOT ASSIGNED.
      RETURN.
    ENDIF.

    IF iv_end_col = 0.
      lo_stru_ref ?= cl_abap_typedescr=>describe_by_data( <ls_work> ).
      lt_comp_ = lo_stru_ref->get_components( ).

      CLEAR: lt_xls_comp.
      LOOP AT lt_comp_ INTO DATA(ls_comp).
        IF ls_comp-type IS INSTANCE OF cl_abap_tabledescr.
          CONTINUE.
        ENDIF.

        APPEND ls_comp TO lt_xls_comp.
      ENDLOOP.

      " Column 수 정의..
      lv_end_col = 0.
      IF line_exists( lt_xls_comp[ name = gc_xls_endcol ] ).
        lv_end_col = line_index( lt_xls_comp[ name = gc_xls_endcol ] ) - 1.
        IF lv_end_col = 0. lv_end_col = 1. ENDIF.
      ENDIF.

      IF lv_end_col = 0.
        lv_end_col = lines( lt_xls_comp ).
      ENDIF.

    ELSE.
      lv_end_col = iv_end_col.
    ENDIF.
    IF lv_end_col > lines( lt_xls_comp ).
      lv_end_col = lines( lt_xls_comp ).
    ENDIF.

    me->split_paths( EXPORTING iv_paths    = iv_filename
                     IMPORTING ev_filename = lv_disp_filename ).

    " 작업 directory 설정
    DATA: lv_sap_workdir TYPE string.
    CALL METHOD cl_gui_frontend_services=>get_sapgui_workdir
      CHANGING
        sapworkdir           = lv_sap_workdir
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        not_supported_by_gui = 3
        OTHERS               = 4.

    DATA: lv_filename TYPE string.
    lv_filename = lv_sap_workdir && '\~' && lv_disp_filename && '_' &&
                  sy-datum && '_' && sy-uzeit &&
                   '.upf'.

    IF lo_application-header = space OR lo_application-handle = -1.
      CREATE OBJECT lo_application 'EXCEL.APPLICATION'.
      _com_xls_msg.
    ENDIF.

    SET PROPERTY OF lo_application 'DisplayAlerts' = 0.
    SET PROPERTY OF lo_application 'Visible' = 0.

    CALL METHOD OF
      lo_application
        'WORKBOOKS' = lo_workbook.
    _com_xls_msg.

    CALL METHOD OF
      lo_workbook
      'OPEN'
      EXPORTING
        #1 = iv_filename.
    _com_xls_msg.

    " sheet 이름으로
    IF iv_sheet_name IS NOT INITIAL.
      CALL METHOD OF
        lo_application
          'ActiveWorkbook' = lo_activeworkbook.
      CALL METHOD OF
          lo_activeworkbook
          'Sheets'          = lo_activesheet
        EXPORTING
          #1                = iv_sheet_name.
      CALL METHOD OF
        lo_activesheet
        'Activate'.

    ELSE.
      GET PROPERTY OF lo_application 'ActiveWorkbook' = lo_activeworkbook.
      GET PROPERTY OF lo_application 'ActiveSheet' = lo_activesheet.
    ENDIF.
    _com_xls_msg.

    " start row & cell
    CALL METHOD OF
        lo_application
        'CELLS'        = lo_start_cell
      EXPORTING
        #1             = iv_start_row
        #2             = iv_start_col.
    _com_xls_msg.

    " end row & cell
    GET PROPERTY OF lo_application 'ActiveCell' = lo_end_cell.
    CALL METHOD OF
        lo_end_cell
        'SpecialCells' = lo_end
      EXPORTING
        #1             = '11'."'xlLastCell'.
    _com_xls_msg.

    CALL METHOD OF
        lo_application
        'RANGE'        = lo_range
      EXPORTING
        #1             = lo_start_cell
        #2             = lo_end.
    _com_xls_msg.

    CALL METHOD OF
      lo_range
      'SELECT'.
    _com_xls_msg.

    CALL METHOD OF
      lo_range
      'COPY'.
    _com_xls_msg.

    " Excel Clipboard 내용을 Internal Table로 Import
    CALL METHOD cl_gui_frontend_services=>clipboard_import
      IMPORTING
        data                 = lt_excel_data
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        not_supported_by_gui = 3
*       no_authority         = 4
        OTHERS               = 5.

    IF sy-subrc <> 0.
      CLEAR lt_excel_data.
    ENDIF.

    LOOP AT lt_excel_data INTO DATA(ls_excel_data).

      CLEAR <ls_work>.

      SPLIT ls_excel_data-line AT cl_abap_char_utilities=>horizontal_tab
            INTO TABLE DATA(lt_split_data).

      DO lv_end_col TIMES.
        DATA(lv_idx) = sy-index.

        UNASSIGN <lv_field>.
        ASSIGN COMPONENT lv_idx OF STRUCTURE <ls_work> TO <lv_field>.
        IF sy-subrc <> 0.
          EXIT.
        ENDIF.

        READ TABLE lt_split_data INTO DATA(lv_split_data) INDEX lv_idx.
        IF sy-subrc <> 0.
          EXIT.
        ENDIF.

        <lv_field> = lv_split_data.
      ENDDO.

      APPEND <ls_work> TO <lt_excel>.

    ENDLOOP.

    GET REFERENCE OF <lt_excel> INTO ro_excel_data.

***    " sheet 추가후 복사된 data를 붙여 넣는다
***    GET PROPERTY OF lo_activeworkbook 'Sheets' = lo_sheet_new .
***    CALL METHOD OF
***      lo_sheet_new
***        'Add' = lo_sheet_new.
***
***    CALL METHOD OF
***      lo_sheet_new
***      'Paste'.
***
***    " txt file 로 저장
***    CALL METHOD OF
***      lo_activeworkbook
***      'SaveAs'
***      EXPORTING
***        #1 = lv_filename
***        #2 = -4158. "42.

    CALL METHOD OF
      lo_activeworkbook
      'CLOSE'
      EXPORTING
        #1 = 0
        #2 = 0
        #3 = 0.
*  _com_xls_msg.

    CALL METHOD OF
      lo_application
      'QUIT'.

    FREE OBJECT lo_range.
    FREE OBJECT lo_end.
    FREE OBJECT lo_end_cell.
    FREE OBJECT lo_start_cell.
    FREE OBJECT lo_activesheet.
    FREE OBJECT lo_activeworkbook.
    FREE OBJECT lo_workbook.
    FREE OBJECT lo_application.


***    DATA: lv_filenames TYPE string,
***          lv_rc        TYPE i.
***
***    lv_filenames = lv_filename.
***
***
***    " text file upload
***    CALL METHOD cl_gui_frontend_services=>gui_upload
***      EXPORTING
***        filename                = lv_filenames
***        filetype                = 'ASC'
****       has_field_separator     = SPACE
****       header_length           = 0
****       read_by_line            = 'X'
****       dat_mode                = SPACE
***        codepage                = gv_codepage
****       ignore_cerr             = ABAP_TRUE
****       replacement             = '#'
****       virus_scan_profile      =
****    IMPORTING
****       filelength              =
****       header                  =
***      CHANGING
***        data_tab                = lt_excel_data[]
***      EXCEPTIONS
***        file_open_error         = 1
***        file_read_error         = 2
***        no_batch                = 3
***        gui_refuse_filetransfer = 4
***        invalid_type            = 5
***        no_authority            = 6
***        unknown_error           = 7
***        bad_data_format         = 8
***        header_not_allowed      = 9
***        separator_not_allowed   = 10
***        header_too_long         = 11
***        unknown_dp_error        = 12
***        access_denied           = 13
***        dp_out_of_memory        = 14
***        disk_full               = 15
***        dp_timeout              = 16
***        not_supported_by_gui    = 17
***        error_no_gui            = 18
***        OTHERS                  = 19.
***
***    " text file 삭제
***    CALL METHOD cl_gui_frontend_services=>file_delete
***      EXPORTING
***        filename             = lv_filenames
***      CHANGING
***        rc                   = lv_rc
***      EXCEPTIONS
***        file_delete_failed   = 1
***        cntl_error           = 2
***        error_no_gui         = 3
***        file_not_found       = 4
***        access_denied        = 5
***        unknown_error        = 6
***        not_supported_by_gui = 7
***        wrong_parameter      = 8
***        OTHERS               = 9.
*--------------------------------------------------------------------*
*****value( RT_XLS_DATA )	TYPE SOLIX_TAB


*****    DATA: lo_excel TYPE ole2_object,
*****          lo_wbs   TYPE ole2_object,
*****          lo_wb    TYPE ole2_object,
*****          lv_len   TYPE i,
*****          lv_rc    TYPE i.
*****
*****    " 미저장 변경분: FILE_COPY는 반영 안 됨 → 가능하면 SaveCopyAs 먼저.
*****
*****    TRY.
*****        " Excel 기동 (비가시)
*****        CREATE OBJECT lo_excel 'Excel.Application'.
*****        SET PROPERTY OF lo_excel 'Visible' = 0.
*****
*****        " 통합문서 읽기: ReadOnly := True
*****        GET PROPERTY OF lo_excel 'Workbooks' = lo_wbs.
*****        " Open( Filename, UpdateLinks, ReadOnly )
*****        CALL METHOD OF lo_wbs 'Open' = lo_wb
*****          EXPORTING
*****            #1 = iv_filename           " Filename
*****            #2 = 0                     " UpdateLinks
*****            #3 = 1.                    " ReadOnly = True
*****
*****        " 임시 폴더/파일 경로 : 작업 directory 설정
*****        DATA: lv_sap_workdir TYPE string.
*****        CALL METHOD cl_gui_frontend_services=>get_sapgui_workdir
*****          CHANGING
*****            sapworkdir           = lv_sap_workdir
*****          EXCEPTIONS
*****            cntl_error           = 1
*****            error_no_gui         = 2
*****            not_supported_by_gui = 3
*****            OTHERS               = 4.
*****
*****        DATA(lv_tmpfile) = |{ lv_sap_workdir }\\~zmdmmmole_{ sy-uname }{ sy-datlo }{ sy-timlo }.xlsx|.
*****
*****        " 현재 열려 있는 통합문서의 '복사본 저장'
*****        CALL METHOD OF lo_wb 'SaveCopyAs'
*****          EXPORTING
*****            #1 = lv_tmpfile.
*****
*****        " 종료
*****        " 원본은 닫되 저장은 하지 않음
*****        CALL METHOD OF lo_wb 'Close'
*****          EXPORTING
*****            #1 = 0.
*****
*****        " Excel 종료
*****        CALL METHOD OF lo_excel 'Quit'.
*****
*****        " OLE 오브젝트 해제
*****        FREE: lo_wb, lo_wbs, lo_excel.
*****
*****        " 복사본을 BIN 업로드
*****        CLEAR: rt_xls_data, lv_len.
*****        cl_gui_frontend_services=>gui_upload( EXPORTING filename   = lv_tmpfile
*****                                                        filetype   = 'BIN'
*****                                              IMPORTING filelength = lv_len
*****                                              CHANGING  data_tab   = rt_xls_data ).
*****
*****        " 복사본 file 삭제
*****        me->file_delete( iv_directory = lv_sap_workdir
*****                         iv_filename  = '~zmdmmm*.*' ).
*****
******        CALL METHOD cl_gui_frontend_services=>file_delete
******          EXPORTING
******            filename             = lv_tmpfile
******          CHANGING
******            rc                   = lv_rc
******          EXCEPTIONS
******            file_delete_failed   = 1
******            cntl_error           = 2
******            error_no_gui         = 3
******            file_not_found       = 4
******            access_denied        = 5
******            unknown_error        = 6
******            not_supported_by_gui = 7
******            wrong_parameter      = 8
******            OTHERS               = 9.
*****
*****      CATCH cx_root INTO DATA(lx).
******        ev_msg = lx->get_text( ).
*****    ENDTRY.

  ENDMETHOD.


  METHOD xls_upload_ole_x.

    DATA: lv_filepath     TYPE string,
          lt_bin          TYPE solix_tab,
          lv_xstr         TYPE xstring,
          lv_woksheetname TYPE string,
          lv_del_row      TYPE i,
          lv_rc           TYPE i,
          lv_active_idx   TYPE i,
          lo_excel_ref    TYPE REF TO cl_fdt_xl_spreadsheet,
          lo_data         TYPE REF TO data.

    lv_filepath = iv_filename.

    FIELD-SYMBOLS : <lt_excel>  TYPE STANDARD TABLE.

    " 2) 바이너리 업로드 → SOLIXTAB
    CALL METHOD cl_gui_frontend_services=>gui_upload
      EXPORTING
        filename                = lv_filepath
        filetype                = 'BIN'
      IMPORTING
        filelength              = DATA(lv_len)
      CHANGING
        data_tab                = lt_bin
      EXCEPTIONS
        file_open_error         = 1
        file_read_error         = 2
        no_batch                = 3
        gui_refuse_filetransfer = 4
        OTHERS                  = 5.
    IF sy-subrc <> 0.
      MESSAGE '파일 읽기 실패(GUI_UPLOAD)' TYPE 'E'.
      EXIT.
    ENDIF.

    " 3) SOLIXTAB → XSTRING
    lv_xstr = cl_bcs_convert=>solix_to_xstring( it_solix = lt_bin ).

    TRY .
        lo_excel_ref = NEW cl_fdt_xl_spreadsheet( document_name = lv_filepath
                                                  xdocument     = lv_xstr  ) .

      CATCH cx_fdt_excel_core INTO DATA(ls_oref).
        "Implement suitable error handling here

    ENDTRY .


    "Get List of Worksheets
    lo_excel_ref->if_fdt_doc_spreadsheet~get_worksheet_names( IMPORTING worksheet_names = DATA(lt_worksheets) ).

    CHECK lt_worksheets IS NOT INITIAL.

    IF iv_sheet_name IS INITIAL.
      TRY.
          lcl_active_sheet=>get_active(
                  EXPORTING i_xlsx_xstr   = lv_xstr
                  IMPORTING e_active_name = lv_woksheetname
                            e_active_idx  = lv_active_idx ).

        CATCH cx_root.
          READ TABLE lt_worksheets INTO lv_woksheetname INDEX 1.
      ENDTRY.

    ELSE.
      READ TABLE lt_worksheets INTO lv_woksheetname WITH KEY table_line = iv_sheet_name.
    ENDIF.

    ro_xls_data = lo_excel_ref->if_fdt_doc_spreadsheet~get_itab_from_worksheet( lv_woksheetname ).

  ENDMETHOD.


  METHOD call_mm03.
    CHECK iv_matnr IS NOT INITIAL.

    SELECT SINGLE matnr
      FROM mara
     WHERE bismt = @iv_matnr
      INTO @DATA(lv_matnr).
    IF sy-subrc NE 0.
      lv_matnr = iv_matnr.
    ENDIF.

    SET PARAMETER ID 'MAT' FIELD lv_matnr.
    SET PARAMETER ID 'MXX' FIELD 'K'." Basic View

    IF iv_werks IS NOT INITIAL.
      SET PARAMETER ID 'WRK' FIELD iv_werks.
      SET PARAMETER ID 'MXX' FIELD 'D'." MRP1 View
    ENDIF.

    CALL TRANSACTION 'MM03' AND SKIP FIRST SCREEN.

  ENDMETHOD.


  METHOD ce_unit_iso.

    IF gt_t006 IS INITIAL.
      SELECT msehi, isocode
        FROM t006
        INTO CORRESPONDING FIELDS OF TABLE @gt_t006.
    ENDIF.

    DATA(ls_t006) = VALUE #( gt_t006[ msehi = me->ce_unit_i( iv_unit  = iv_unit
                                                             iv_langu = iv_langu ) ] OPTIONAL ).
    rv_unit = ls_t006-isocode.

  ENDMETHOD.                    "ce_unit_iso


  METHOD ce_fltp_o.

    DATA: lv_num_dig    TYPE cha_class_data-stellen, " INT1
          lv_fltp_value TYPE cha_class_data-sollwert,
          lv_char_field TYPE cha_class_view-sollwert.

    CLEAR: rv_output.
    CHECK iv_fltp_value IS NOT INITIAL.

    lv_num_dig = iv_num_dig.
    lv_fltp_value = iv_fltp_value.
    CALL FUNCTION 'QSS0_FLTP_TO_CHAR_CONVERSION'
      EXPORTING
        i_number_of_digits = lv_num_dig
        i_fltp_value       = lv_fltp_value
*       I_VALUE_NOT_INITIAL_FLAG       = 'X'
*       I_SCREEN_FIELDLENGTH           = 16
      IMPORTING
        e_char_field       = lv_char_field.

    rv_output = lv_char_field.

  ENDMETHOD.                    "CE_DATE_I
ENDCLASS.
