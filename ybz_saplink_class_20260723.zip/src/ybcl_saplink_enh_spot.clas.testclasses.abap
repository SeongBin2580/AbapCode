*"* use this source file for your ABAP unit test classes
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   The code of this project is provided to you under the current     |
*|   version of the SAP Code Exchange Terms of Use. You can find the   |
*|   text on the SAP Code Exchange webpage at http://www.sdn.sap.com   |
*|                                                                     |
*|   SAPlink is provided to you AS IS with no guarantee, warranty or   |
*|   support.                                                          |
*\---------------------------------------------------------------------/

CLASS ltcl_check_enh_spot DEFINITION FINAL FOR TESTING.
  " DURATION SHORT
  " RISK LEVEL HARMLESS
  "#AU Duration Medium
  "#AU Risk_Level Harmless
  PUBLIC SECTION.
    METHODS:
      check_010_non_existing   FOR TESTING RAISING cx_static_check,
      check_020_create_slinkee FOR TESTING RAISING cx_static_check.

  PRIVATE SECTION.
    DATA targetobject TYPE REF TO ybcl_saplink.
    DATA ixml         TYPE REF TO if_ixml_document.
    DATA cx           TYPE REF TO cx_root.
    DATA msg  TYPE string.
    DATA name TYPE string.
    DATA devclass TYPE devclass.

    METHODS setup.

ENDCLASS.                    "ltcl_check_enh_spot DEFINITION

*----------------------------------------------------------------------*
*       CLASS ltcl_check_enh_spot IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS ltcl_check_enh_spot IMPLEMENTATION.

  METHOD setup.
  ENDMETHOD.                    "setup

  METHOD check_010_non_existing.
    name = 'ZDOES_NOT_EXIST'.
    CREATE OBJECT targetobject
      TYPE ybcl_saplink_enh_spot
      EXPORTING
        name = name.
    TRY.
        ixml = targetobject->createixmldocfromobject( ).
      CATCH ybcx_saplink INTO cx.    " SAPlink exception class
        msg = cx->get_text( ).
        cl_aunit_assert=>assert_bound( act = cx msg = msg ).
    ENDTRY.

  ENDMETHOD.                    "CHECK_CHECK_NON_EXISTING

  METHOD check_020_create_slinkee.
    DATA: xmlstring TYPE string.
    DATA: name_created TYPE string.
    name     = 'ZBPMAINTAIN_TEST'.
    devclass = '$TMP'.
    CREATE OBJECT targetobject
      TYPE ybcl_saplink_enh_spot
      EXPORTING
        name = name.
    TRY.
        ixml = targetobject->createixmldocfromobject( ).
      CATCH ybcx_saplink INTO cx.    " SAPlink exception class
        msg = cx->get_text( ).
        cl_aunit_assert=>fail( msg = msg ).
    ENDTRY.
    cl_aunit_assert=>assert_bound( act = ixml msg = 'iXML is not bound' ).

    xmlstring = targetobject->convertixmldoctostring( ixmldocument = ixml ).

    FREE: ixml, cx.

    ixml = targetobject->convertstringtoixmldoc( xmlstring = xmlstring ).

    " Test without overwrite
    TRY.

        targetobject->createobjectfromixmldoc(
          EXPORTING
            ixmldocument = ixml     " IF_IXML_DOCUMENT
            devclass     = devclass " Development class/package
*         overwrite    = overwrite    " Overwrite original objects
*       RECEIVING
*         name         = name    " Installed object name
        ).
      CATCH ybcx_saplink INTO cx.    " SAPlink exception class
        msg = cx->get_text( ).
        cl_aunit_assert=>assert_bound( act = cx msg = msg ).
    ENDTRY.
    " Test with overwrite
    TRY.
        name_created = targetobject->createobjectfromixmldoc(
            ixmldocument = ixml     " IF_IXML_DOCUMENT
            devclass     = devclass " Development class/package
            overwrite    = 'X'      " Overwrite original objects
        ).
        cl_aunit_assert=>assert_equals(
            exp                  = name    " Data Object with Expected Type
            act                  = name_created    " Data Object with Current Value
        ).
      CATCH ybcx_saplink INTO cx.    " SAPlink exception class
        msg = cx->get_text( ).
        cl_aunit_assert=>fail( msg = msg ).
    ENDTRY.
  ENDMETHOD.                    "check_030_xml_string

ENDCLASS.                    "ltcl_check_enh_spot IMPLEMENTATION
