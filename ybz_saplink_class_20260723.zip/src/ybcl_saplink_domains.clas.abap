class YBCL_SAPLINK_DOMAINS definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.
ENDCLASS.



CLASS YBCL_SAPLINK_DOMAINS IMPLEMENTATION.


METHOD checkexists.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

*      Plugin created by:
*      Thomas Jung
*      thomas.jung1@gmail.com

    DATA: l_name   TYPE ddobjname,
          dd01v_wa TYPE dd01v.
    l_name = objname.
    CALL FUNCTION 'DDIF_DOMA_GET'
      EXPORTING
        name          = l_name
      IMPORTING
        dd01v_wa      = dd01v_wa
      EXCEPTIONS
        illegal_input = 1
        OTHERS        = 2.
    IF sy-subrc = 0 AND dd01v_wa-domname IS NOT INITIAL.
      exists = 'X'.
    ENDIF.
  ENDMETHOD.


METHOD createixmldocfromobject.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

*      Plugin created by:
*      Thomas Jung
*      thomas.jung1@gmail.com

    DATA: gotstate  TYPE ddgotstate,
          dd01v_wa  TYPE dd01v,
          dd07v_tab TYPE STANDARD TABLE OF dd07v.

*xml nodes
    DATA rootnode   TYPE REF TO if_ixml_element.
    DATA dd07v_node TYPE REF TO if_ixml_element.
    DATA rc         TYPE sysubrc.
    DATA _domaname  TYPE ddobjname.
    _domaname = objname.

    CALL FUNCTION 'DDIF_DOMA_GET'
      EXPORTING
        name          = _domaname
        langu         = sy-langu
      IMPORTING
        gotstate      = gotstate
        dd01v_wa      = dd01v_wa
      TABLES
        dd07v_tab     = dd07v_tab
      EXCEPTIONS
        illegal_input = 1
        OTHERS        = 2.
    IF sy-subrc <> 0 OR dd01v_wa-domname IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

* Create parent node
    DATA _objtype TYPE string.
    _objtype = getobjecttype( ).
    rootnode = xmldoc->create_element( _objtype ).
    setattributesfromstructure( node = rootnode structure = dd01v_wa ).

    DATA: wa_dd07v LIKE LINE OF dd07v_tab.
    LOOP AT dd07v_tab INTO wa_dd07v.
      dd07v_node = xmldoc->create_element( 'dd07v' ).
      setattributesfromstructure( node = dd07v_node structure = wa_dd07v ).
      rc = rootnode->append_child( dd07v_node ).
    ENDLOOP.

*\--------------------------------------------------------------------/
    rc = xmldoc->append_child( rootnode ).
    ixmldocument = xmldoc.
  ENDMETHOD.


METHOD createobjectfromixmldoc.

  DATA: gotstate  TYPE ddgotstate,
        dd01v_wa  TYPE dd01v,
        dd07v_tab TYPE STANDARD TABLE OF dd07v.

*xml nodes
  DATA: rootnode    TYPE REF TO if_ixml_element,
        dd07v_node  TYPE REF TO if_ixml_element,
        node        TYPE REF TO if_ixml_element,
        filter      TYPE REF TO if_ixml_node_filter,
        iterator    TYPE REF TO if_ixml_node_iterator,
        rc          TYPE sysubrc,
        _domaname   TYPE ddobjname,
        _devclass   TYPE devclass,
        checkexists TYPE flag,
        _objtype    TYPE string.

  _devclass = devclass.
  _objtype = getobjecttype( ).

  xmldoc = ixmldocument.
  rootnode = xmldoc->find_from_name( _objtype ).

  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = rootnode
    CHANGING
      structure = dd01v_wa.

  dd01v_wa-ddlanguage = sy-langu.
  objname = dd01v_wa-domname.

  checkexists = checkexists( ).
  IF checkexists IS NOT INITIAL.
    IF overwrite IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>existing.
    ELSE.
*     delete object for new install
      deleteobject( ).
    ENDIF.
  ENDIF.

* retrieve Domain details
  FREE: filter, iterator, node.
  filter = xmldoc->create_filter_name( 'dd07v' ).
  iterator = xmldoc->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).

  DATA: wa_dd07v LIKE LINE OF dd07v_tab.
  WHILE node IS NOT INITIAL.
    CLEAR dd07v_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = wa_dd07v.

    wa_dd07v-ddlanguage = sy-langu.

    APPEND wa_dd07v TO dd07v_tab.
    node ?= iterator->get_next( ).
  ENDWHILE.

  DATA : l_pgmid      TYPE tadir-pgmid,
         l_object     TYPE tadir-object,
         l_obj_name   TYPE tadir-obj_name,
         l_dd_objname TYPE ddobjname,
         l_srcsystem  TYPE tadir-srcsystem,
         l_author     TYPE tadir-author,
         l_devclass   TYPE tadir-devclass,
         l_masterlang TYPE tadir-masterlang.


  l_pgmid      = 'R3TR'.
  l_object     = _objtype.
  l_obj_name   = objname.
  l_dd_objname = objname.
  l_srcsystem  = sy-sysid.
  l_author     = sy-uname.
  l_devclass   = _devclass.
  l_masterlang = sy-langu.

  DATA: itadir TYPE tadir.
  itadir-pgmid      = l_pgmid.
  itadir-object     = l_object.
  itadir-obj_name   = l_obj_name.
  itadir-srcsystem  = l_srcsystem.
  itadir-author     = l_author.
  itadir-devclass   = l_devclass.
  itadir-masterlang = l_masterlang.
  MODIFY tadir FROM itadir.

*    CALL FUNCTION 'TR_TADIR_INTERFACE'
*      EXPORTING
*        wi_test_modus                  = ' '
*        wi_delete_tadir_entry          = 'X'
*        wi_tadir_pgmid                 = l_pgmid
*        wi_tadir_object                = l_object
*        wi_tadir_obj_name              = l_obj_name
*        wi_tadir_srcsystem             = l_srcsystem
*        wi_tadir_author                = l_author
*        wi_tadir_devclass              = l_devclass
*        wi_tadir_masterlang            = l_masterlang
*        iv_set_edtflag                 = ''
*      EXCEPTIONS
*        tadir_entry_not_existing       = 1
*        tadir_entry_ill_type           = 2
*        no_systemname                  = 3
*        no_systemtype                  = 4
*        original_system_conflict       = 5
*        object_reserved_for_devclass   = 6
*        object_exists_global           = 7
*        object_exists_local            = 8
*        object_is_distributed          = 9
*        obj_specification_not_unique   = 10
*        no_authorization_to_delete     = 11
*        devclass_not_existing          = 12
*        simultanious_set_remove_repair = 13
*        order_missing                  = 14
*        no_modification_of_head_syst   = 15
*        pgmid_object_not_allowed       = 16
*        masterlanguage_not_specified   = 17
*        devclass_not_specified         = 18
*        specify_owner_unique           = 19
*        loc_priv_objs_no_repair        = 20
*        gtadir_not_reached             = 21
*        object_locked_for_order        = 22
*        change_of_class_not_allowed    = 23
*        no_change_from_sap_to_tmp      = 24
*        OTHERS                         = 25.
*    IF sy-subrc NE 0.
*      CASE sy-subrc.
*        WHEN 1 OR 9 OR 7 OR 8. "OK! - Doesn't exist yet
*        WHEN 11 OR 23 OR 24.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>not_authorized.
*        WHEN 22.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>locked.
*        WHEN OTHERS.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>system_error.
*      ENDCASE.
*    ENDIF.

  CALL FUNCTION 'DDIF_DOMA_PUT'
    EXPORTING
      name              = l_dd_objname
      dd01v_wa          = dd01v_wa
    TABLES
      dd07v_tab         = dd07v_tab
    EXCEPTIONS
      doma_not_found    = 1
      name_inconsistent = 2
      doma_inconsistent = 3
      put_failure       = 4
      put_refused       = 5
      OTHERS            = 6.
  IF sy-subrc <> 0.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>system_error.
  ENDIF.

  DATA: trobjtype  TYPE trobjtype,
        trobj_name TYPE trobj_name.
  trobjtype  = l_object.
  trobj_name = l_obj_name.
  CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
    EXPORTING
      object            = trobjtype
      obj_name          = trobj_name
    EXCEPTIONS
      wrong_object_name = 1.

  name = objname.

ENDMETHOD.


METHOD deleteobject.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

*      Plugin created by:
*      Thomas Jung
*      thomas.jung1@gmail.com

  ENDMETHOD.


METHOD getobjecttype.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

*      Plugin created by:
*      Thomas Jung
*      thomas.jung1@gmail.com

    objecttype = 'DOMA'.  "Domain
  ENDMETHOD.
ENDCLASS.
