class YBCL_SAPLINK_FUNCTION_GROUP definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.

  methods ACTUALIZE_OBJECT_TREE .
  methods CREATE_TEXTPOOL
    importing
      !TEXTPOOLNODE type ref to IF_IXML_ELEMENT .
  methods CREATE_FUNCTION_MODULES
    importing
      !FM_NODE type ref to IF_IXML_ELEMENT
      !FCT_GROUP type TLIBG-AREA
    raising
      YBCX_SAPLINK .
  methods CREATE_DOCUMENTATION
    importing
      !DOCNODE type ref to IF_IXML_ELEMENT
    raising
      YBCX_SAPLINK .
  methods CREATE_FM_DOCUMENTATION
    importing
      !DOCNODE type ref to IF_IXML_ELEMENT
    raising
      YBCX_SAPLINK .
  methods DEQUEUE_ABAP
    raising
      YBCX_SAPLINK .
  methods CREATE_INCLUDES
    importing
      !INCL_NODE type ref to IF_IXML_ELEMENT
      !DEVCLASS type DEVCLASS default '$TMP'
    raising
      YBCX_SAPLINK .
  methods GET_TEXTPOOL
    returning
      value(TEXTNODE) type ref to IF_IXML_ELEMENT .
  methods GET_DOCUMENTATION
    returning
      value(DOCNODE) type ref to IF_IXML_ELEMENT .
  methods GET_FM_DOCUMENTATION
    importing
      !FM_NAME type ANY
    returning
      value(DOCNODE) type ref to IF_IXML_ELEMENT .
  methods GET_INCLUDES
    importing
      !MAIN_PROG type SY-REPID
      !FCT_GROUP type TLIBT-AREA
    returning
      value(INCL_NODE) type ref to IF_IXML_ELEMENT .
  methods CREATE_SOURCE
    importing
      !SOURCE type TABLE_OF_STRINGS
      !ATTRIBS type TRDIR
    raising
      YBCX_SAPLINK .
  methods ENQUEUE_ABAP
    raising
      YBCX_SAPLINK .
  methods GET_FUNCTION_MODULES
    importing
      !FCT_GROUP type TLIBG-AREA
    returning
      value(FM_NODE) type ref to IF_IXML_ELEMENT .
  methods TRANSPORT_COPY
    importing
      !AUTHOR type SYUNAME
      !DEVCLASS type DEVCLASS
    raising
      YBCX_SAPLINK .
  methods GET_DYNPRO
    returning
      value(DYNP_NODE) type ref to IF_IXML_ELEMENT .
  methods CREATE_DYNPRO
    importing
      !DYNP_NODE type ref to IF_IXML_ELEMENT
    raising
      YBCX_SAPLINK .
  methods GET_PFSTATUS
    returning
      value(PFSTAT_NODE) type ref to IF_IXML_ELEMENT .
  methods CREATE_PFSTATUS
    importing
      !PFSTAT_NODE type ref to IF_IXML_ELEMENT
    raising
      YBCX_SAPLINK .
ENDCLASS.



CLASS YBCL_SAPLINK_FUNCTION_GROUP IMPLEMENTATION.


METHOD ACTUALIZE_OBJECT_TREE.
    DATA: l_offset TYPE i.
    DATA: l_tree_string TYPE string.

    CONCATENATE 'PG_' 'SAPL' objname INTO l_tree_string.

* If we supported namespaces, the following code would be required
*  FIND ALL OCCURRENCES OF '/' IN objname MATCH OFFSET l_offset.
*  IF sy-subrc = 0.
*    l_tree_string  = objname.
*    REPLACE SECTION OFFSET l_offset LENGTH 1 OF  l_tree_string  WITH '/SAPL'.
*    CONCATENATE 'PG_' l_tree_string  INTO l_tree_string.
*  ELSE.
*    CONCATENATE 'PG_' 'SAPL' objname INTO l_tree_string.
*  ENDIF.

    CALL FUNCTION 'WB_TREE_ACTUALIZE'
      EXPORTING
        tree_name = l_tree_string.

  ENDMETHOD.


METHOD CHECKEXISTS.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    SELECT SINGLE area FROM tlibg INTO objname WHERE area = objname.
    IF sy-subrc = 0.
      exists = 'X'.
    ENDIF.

  ENDMETHOD.


METHOD CREATEIXMLDOCFROMOBJECT.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

*      Plugin created by:
*      Rich Heilman
*      rich.heilman.jr@gmail.com

    TYPES: BEGIN OF t_tlibt,
             area  TYPE tlibt-area,
             spras TYPE tlibt-spras,
             areat TYPE tlibt-areat,
           END OF t_tlibt.

    DATA rootnode            TYPE REF TO if_ixml_element.
    DATA mainprognode        TYPE REF TO if_ixml_element.
    DATA includesnode        TYPE REF TO if_ixml_element.
    DATA functgroupnode      TYPE REF TO if_ixml_element.
    DATA functionmodulesnode TYPE REF TO if_ixml_element.
    DATA docnode             TYPE REF TO if_ixml_element.
    DATA textpoolnode        TYPE REF TO if_ixml_element.
    DATA dynpronode          TYPE REF TO if_ixml_element.
    DATA statusnode          TYPE REF TO if_ixml_element.
    DATA sourcenode          TYPE REF TO if_ixml_element.
    DATA fmdocumenation      TYPE REF TO if_ixml_element.

    DATA rc                TYPE sysubrc.
    DATA progattribs       TYPE trdir.
    DATA progsource        TYPE rswsourcet.
    DATA _objname(30)      TYPE c.
    DATA sourcestring      TYPE string.
    DATA _objtype          TYPE string.
    DATA functiongroupname TYPE  tlibg-area.
    DATA mainfgprogname    TYPE sy-repid.
    DATA l_offset          TYPE i.
    DATA xtlibt            TYPE t_tlibt.

    _objtype = getobjecttype( ).
    rootnode = xmldoc->create_element( _objtype ).

* function groups in reserved namespace, not supported.
    IF objname(1) = '/'.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Function Groups in / namespace are not supported'.
    ENDIF.

*  create main program name.  Other namespaces are not supported
    CONCATENATE 'SAPL' objname INTO mainfgprogname.

* If we did support namespaces, this is how we would
* build the main program name
*  FIND ALL OCCURRENCES OF '/' IN objname MATCH OFFSET l_offset.
*  IF sy-subrc = 0.
*    mainfgprogname = objname.
*    REPLACE SECTION OFFSET l_offset LENGTH 1 OF mainfgprogname WITH '/SAPL'.
*  ELSE.
*    CONCATENATE 'SAPL' objname INTO mainfgprogname.
*  ENDIF.

* Set function group name
    functiongroupname = objname.

* Get main program attributes
    SELECT SINGLE * FROM trdir
             INTO progattribs
                  WHERE name = mainfgprogname.
    IF sy-subrc <> 0.
      CLEAR ixmldocument.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

* Get Function group attributes
    CLEAR xtlibt.
    SELECT SINGLE * FROM tlibt
               INTO CORRESPONDING FIELDS OF xtlibt
                       WHERE spras = sy-langu
                         AND area  = functiongroupname.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

    setattributesfromstructure( node = rootnode
                                structure =  xtlibt  ).

    _objname = objname.
    objname  = mainfgprogname.    " Main program is object

* Write main program for function group.
    mainprognode = xmldoc->create_element( 'mainprogram' ).
    setattributesfromstructure( node = mainprognode
                                structure =   progattribs  ).

    sourcenode = xmldoc->create_element( 'source' ).
    READ REPORT mainfgprogname INTO progsource.
    sourcestring = buildsourcestring( sourcetable = progsource ).
    rc = sourcenode->if_ixml_node~set_value( sourcestring ).

    textpoolnode =  get_textpool( ).
    rc = mainprognode->append_child( textpoolnode ).

    docnode = get_documentation( ).
    rc = rootnode->append_child( docnode ).

    dynpronode = get_dynpro( ).
    rc = mainprognode->append_child( dynpronode ).

    statusnode =  get_pfstatus( ).
    rc = mainprognode->append_child( statusnode ).

    rc = mainprognode->append_child( sourcenode ).
    rc = rootnode->append_child( mainprognode ).

* Get the includes
    includesnode = get_includes( main_prog = mainfgprogname
                                 fct_group = functiongroupname ).
    rc = rootnode->append_child( includesnode ).

* Get function modules data.
    functionmodulesnode = get_function_modules( functiongroupname ).
    rc = rootnode->append_child( functionmodulesnode ).

    rc = xmldoc->append_child( rootnode ).

    ixmldocument = xmldoc.
    objname      =  _objname.

  ENDMETHOD.


METHOD createobjectfromixmldoc.

  TYPES: BEGIN OF t_tlibt,
           area  TYPE tlibt-area,
           spras TYPE tlibt-spras,
           areat TYPE tlibt-areat,
         END OF t_tlibt.

  DATA: rootnode             TYPE REF TO if_ixml_element,
        sourcenode           TYPE REF TO if_ixml_element,
        textnode             TYPE REF TO if_ixml_element,
        docnode              TYPE REF TO if_ixml_element,
        dynpnode             TYPE REF TO if_ixml_element,
        statnode             TYPE REF TO if_ixml_element,

        mainprog_node        TYPE REF TO if_ixml_element,
        functionmodule_node  TYPE REF TO if_ixml_element,
        functionmodules_node TYPE REF TO if_ixml_element,
        includes_node        TYPE REF TO if_ixml_element,
        fmdoc_node           TYPE REF TO if_ixml_element,

        progattribs          TYPE trdir,
        source               TYPE string,
        sourcetable          TYPE table_of_strings,
        _objname(30)         TYPE c,
        _objtype             TYPE string,
        checkexists          TYPE flag,

        xtlibt               TYPE t_tlibt,
        xstext               TYPE tftit-stext,

        functiongroupname    TYPE  tlibg-area.

  _objtype = getobjecttype( ).
  xmldoc   = ixmldocument.

  rootnode = xmldoc->find_from_name( _objtype ).

  _objname = objname.

  getstructurefromattributes(
    EXPORTING
      node      = rootnode
    CHANGING
      structure = xtlibt ).

  xtlibt-spras = sy-langu.
  functiongroupname = xtlibt-area.

* function groups in reserved namespace, not supported.
  IF functiongroupname(1) = '/'.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>error_message
        msg    = 'Function Groups in / namespace are not supported'.
  ENDIF.

  objname = functiongroupname.

  checkexists = checkexists( ).
  IF checkexists IS NOT INITIAL.
    IF overwrite IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>existing.
    ELSE.
*     delete object for new install
      deleteobject( ).
    ENDIF.
  ENDIF.

* Insert the function group
  xstext = xtlibt-areat.
  CALL FUNCTION 'RS_FUNCTION_POOL_INSERT'
    EXPORTING
      function_pool           = xtlibt-area
      short_text              = xstext
      devclass                = devclass
    EXCEPTIONS
      name_already_exists     = 1
      name_not_correct        = 2
      function_already_exists = 3
      invalid_function_pool   = 4
      invalid_name            = 5
      too_many_functions      = 6
      no_modify_permission    = 7
      no_show_permission      = 8
      enqueue_system_failure  = 9
      canceled_in_corr        = 10
      undefined_error         = 11
      OTHERS                  = 12.

* Create the function modules
  functionmodules_node  = rootnode->find_from_name( 'functionmodules' ).
  create_function_modules( fm_node   = functionmodules_node
                           fct_group = functiongroupname ).

* Create Includes
  includes_node  = rootnode->find_from_name( 'includeprograms' ).
  create_includes( devclass  = devclass
                   incl_node = includes_node ).

* Update main program..... with include statements, dynpros, gui status
  mainprog_node  = rootnode->find_from_name( 'mainprogram' ).

  getstructurefromattributes(
    EXPORTING
      node      = mainprog_node
    CHANGING
      structure = progattribs ).

  progattribs-rload = sy-langu.
  objname = progattribs-name.     " Main Program Name is now the object

* Update the main program
  enqueue_abap( ).
  transport_copy( author   = progattribs-cnam
                  devclass = devclass ).

* Source
  sourcenode  = mainprog_node->find_from_name( 'source' ).
  source      = sourcenode->get_value( ).
  sourcetable = buildtablefromstring( source ).
  create_source( source  = sourcetable
                 attribs = progattribs ).

* Documentation
  docnode = rootnode->find_from_name( 'functionGroupDocumentation' ).
  create_documentation( docnode ).

* text pool
  textnode = mainprog_node->find_from_name( 'textPool' ).
  create_textpool( textnode ).

* Dynpros
  dynpnode = mainprog_node->find_from_name( 'dynpros' ).
  create_dynpro( dynpnode ).

* Gui status, titles
  statnode = mainprog_node->find_from_name( 'pfstatus' ).
  create_pfstatus( statnode ).

  dequeue_abap( ).

* Rebuild tree structure for SE80
  actualize_object_tree( ).

  DATA: itadir TYPE tadir.
  itadir-pgmid      = 'R3TR'.
  itadir-object     = _objtype.
  itadir-obj_name   = _objname.
  itadir-srcsystem  = sy-sysid.
  itadir-author     = sy-uname.
  itadir-devclass   = devclass.
  itadir-masterlang = sy-langu.
  MODIFY tadir FROM itadir.


* successful install
  objname = functiongroupname.
  name = objname.

ENDMETHOD.


METHOD CREATE_DOCUMENTATION.

    DATA txtline_node     TYPE REF TO if_ixml_element.
    DATA txtline_filter   TYPE REF TO if_ixml_node_filter.
    DATA txtline_iterator TYPE REF TO if_ixml_node_iterator.

    DATA lang_node     TYPE REF TO if_ixml_element.
    DATA lang_filter   TYPE REF TO if_ixml_node_filter.
    DATA lang_iterator TYPE REF TO if_ixml_node_iterator.

    DATA obj_name TYPE dokhl-object.
    DATA prog_name TYPE string.
    DATA language  TYPE string.
    DATA obj_langu TYPE dokhl-langu.
    DATA lv_str TYPE string.
    DATA rc TYPE sy-subrc.

    DATA lt_lines  TYPE TABLE OF tline.
    FIELD-SYMBOLS: <ls_lines> LIKE LINE OF lt_lines.

    IF docnode IS NOT BOUND.
      RETURN.
    ENDIF.

    prog_name = docnode->get_attribute( name = 'OBJECT' ).
    obj_name = prog_name.

* If no prog name, then there was no program documenation, just return.
    IF prog_name IS INITIAL.
      RETURN.
    ENDIF.

* Get languages from XML
    FREE: lang_filter, lang_iterator, lang_node.
    lang_filter = docnode->create_filter_name( `language` ).
    lang_iterator = docnode->create_iterator_filtered( lang_filter ).
    lang_node ?= lang_iterator->get_next( ).
    WHILE lang_node IS NOT INITIAL.

      REFRESH lt_lines.
      language = lang_node->get_attribute( name = 'SPRAS' ).
      obj_langu = language.

* Get TextLines from XML
      FREE: txtline_filter, txtline_iterator, txtline_node.
      txtline_filter = lang_node->create_filter_name( `textLine` ).
      txtline_iterator = lang_node->create_iterator_filtered( txtline_filter ).
      txtline_node ?= txtline_iterator->get_next( ).
      WHILE txtline_node IS NOT INITIAL.
        APPEND INITIAL LINE TO lt_lines ASSIGNING <ls_lines>.
        me->getstructurefromattributes(
                EXPORTING   node      = txtline_node
                CHANGING    structure = <ls_lines> ).
        txtline_node ?= txtline_iterator->get_next( ).
      ENDWHILE.

* Delete any documentation that may currently exist.
      CALL FUNCTION 'DOCU_DEL'
        EXPORTING
          id       = 'RE'   "<-- Report/program documentation
          langu    = obj_langu
          object   = obj_name
          typ      = 'E'
        EXCEPTIONS
          ret_code = 1
          OTHERS   = 2.

* Now update with new documentation text
      CALL FUNCTION 'DOCU_UPD'
        EXPORTING
          id       = 'RE'
          langu    = obj_langu
          object   = obj_name
          typ      = 'E'
        TABLES
          line     = lt_lines
        EXCEPTIONS
          ret_code = 1
          OTHERS   = 2.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>error_message
            msg    = `Program Documentation object import failed`.
      ENDIF.

      lang_node ?= lang_iterator->get_next( ).
    ENDWHILE.

  ENDMETHOD.


METHOD create_dynpro.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

  TYPES: BEGIN OF tdyn_head_temp.
           INCLUDE TYPE d020s.
  TYPES:   dtext TYPE d020t-dtxt.
  TYPES: END OF tdyn_head_temp.

  DATA: idyn_fldl TYPE TABLE OF d021s,
        idyn_flow TYPE TABLE OF d022s,
        idyn_mcod TYPE TABLE OF d023s.

  DATA: xdyn_head TYPE  d020s,
        xdyn_fldl TYPE  d021s,
        xdyn_flow TYPE  d022s,
        xdyn_mcod TYPE  d023s.

  DATA: xdyn_text_string TYPE string.
  DATA: xdyn_text        TYPE d020t-dtxt .
  DATA: xdyn_head_temp   TYPE tdyn_head_temp.

  DATA _objname TYPE trobj_name.

  DATA dynpros_node       TYPE REF TO if_ixml_element.
  DATA dynpros_filter     TYPE REF TO if_ixml_node_filter.
  DATA dynpros_iterator   TYPE REF TO if_ixml_node_iterator.

  DATA dynpro_node        TYPE REF TO if_ixml_element.
  DATA dynpro_filter      TYPE REF TO if_ixml_node_filter.
  DATA dynpro_iterator    TYPE REF TO if_ixml_node_iterator.

  DATA dynfldl_node       TYPE REF TO if_ixml_element.
  DATA dynfldl_filter     TYPE REF TO if_ixml_node_filter.
  DATA dynfldl_iterator   TYPE REF TO if_ixml_node_iterator.

  DATA dynmcod_node       TYPE REF TO if_ixml_element.
  DATA dynmcod_filter     TYPE REF TO if_ixml_node_filter.
  DATA dynmcod_iterator   TYPE REF TO if_ixml_node_iterator.

  DATA dynflow_node       TYPE REF TO if_ixml_element.

  DATA xdynpro_flow_source TYPE string.
  DATA idynpro_flow_source TYPE table_of_strings.

  _objname = objname.

  dynpros_node =  dynp_node.
  CHECK dynpros_node IS NOT INITIAL.

  FREE: dynpro_filter, dynpro_iterator, dynpro_node.
  dynpro_filter = dynpros_node->create_filter_name( 'dynpro' ).
  dynpro_iterator =
    dynpros_node->create_iterator_filtered( dynpro_filter ).
  dynpro_node ?= dynpro_iterator->get_next( ).

  WHILE dynpro_node IS NOT INITIAL.

    CLEAR:    xdyn_head, xdyn_fldl, xdyn_flow, xdyn_mcod.
    REFRESH:  idyn_fldl, idyn_flow, idyn_mcod.

* Get the header data for the screen.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = dynpro_node
      CHANGING
        structure = xdyn_head_temp.

    xdyn_head      = xdyn_head_temp.
    xdyn_head-spra = sy-langu.
    xdyn_text      = xdyn_head_temp-dtext.

* Retrieve field list
    FREE: dynfldl_filter, dynfldl_iterator, dynfldl_node.
    dynfldl_filter = dynpro_node->create_filter_name( 'dynprofield' ).
    dynfldl_iterator =
      dynpro_node->create_iterator_filtered( dynfldl_filter ).
    dynfldl_node ?= dynfldl_iterator->get_next( ).
    WHILE dynfldl_node IS NOT INITIAL.
      CALL METHOD getstructurefromattributes
        EXPORTING
          node      = dynfldl_node
        CHANGING
          structure = xdyn_fldl.
      APPEND xdyn_fldl TO idyn_fldl.
      dynfldl_node ?= dynfldl_iterator->get_next( ).
    ENDWHILE.

* Retrieve matchcode data.
    FREE: dynmcod_filter, dynmcod_iterator, dynmcod_node.
    dynmcod_filter = dynpro_node->create_filter_name( 'dynprofield' ).
    dynmcod_iterator =
      dynpro_node->create_iterator_filtered( dynmcod_filter ).
    dynmcod_node ?= dynmcod_iterator->get_next( ).
    WHILE dynmcod_node IS NOT INITIAL.
      CALL METHOD getstructurefromattributes
        EXPORTING
          node      = dynmcod_node
        CHANGING
          structure = xdyn_mcod.
      APPEND xdyn_mcod TO idyn_mcod.
      dynmcod_node ?= dynmcod_iterator->get_next( ).
    ENDWHILE.

* retieve flow logic source.
    CLEAR xdynpro_flow_source.  REFRESH idynpro_flow_source.
    CLEAR xdyn_flow.            REFRESH idyn_flow.
    FREE dynflow_node.
    dynflow_node = dynpro_node->find_from_name( 'dynproflowsource' ).
    xdynpro_flow_source  = dynflow_node->get_value( ).
    idynpro_flow_source = buildtablefromstring( xdynpro_flow_source ).
    LOOP AT idynpro_flow_source INTO xdyn_flow.
      APPEND xdyn_flow  TO idyn_flow.
    ENDLOOP.

* Build dynpro from data
    CALL FUNCTION 'RPY_DYNPRO_INSERT_NATIVE'
      EXPORTING
*       suppress_corr_checks           = ' '
*       CORRNUM            = ' '
        header             = xdyn_head
        dynprotext         = xdyn_text
*       SUPPRESS_EXIST_CHECKS          = ' '
*       USE_CORRNUM_IMMEDIATEDLY       = ' '
*       SUPPRESS_COMMIT_WORK           = ' '
      TABLES
        fieldlist          = idyn_fldl
        flowlogic          = idyn_flow
        params             = idyn_mcod
      EXCEPTIONS
        cancelled          = 1
        already_exists     = 2
        program_not_exists = 3
        not_executed       = 4
        OTHERS             = 5.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>system_error.
    ENDIF.

    dynpro_node ?= dynpro_iterator->get_next( ).

  ENDWHILE.

ENDMETHOD.


METHOD create_fm_documentation.

  DATA: txtline_node     TYPE REF TO if_ixml_element,
        txtline_filter   TYPE REF TO if_ixml_node_filter,
        txtline_iterator TYPE REF TO if_ixml_node_iterator,

        lang_node        TYPE REF TO if_ixml_element,
        lang_filter      TYPE REF TO if_ixml_node_filter,
        lang_iterator    TYPE REF TO if_ixml_node_iterator,

        obj_name         TYPE dokhl-object,
        fm_parm_name     TYPE string,
        language         TYPE string,
        obj_langu        TYPE dokhl-langu,
        lv_str           TYPE string,
        rc               TYPE sy-subrc,

        lt_lines         TYPE TABLE OF tline.
  FIELD-SYMBOLS: <ls_lines> LIKE LINE OF lt_lines.

  IF docnode IS NOT BOUND.
    RETURN.
  ENDIF.

  fm_parm_name = docnode->get_attribute( name = 'OBJECT' ).
  obj_name = fm_parm_name.

* If no fm_parm_name, then there was no documenation, just return.
  IF fm_parm_name IS INITIAL.
    RETURN.
  ENDIF.

* Get languages from XML
  FREE: lang_filter, lang_iterator, lang_node.
  lang_filter = docnode->create_filter_name( `language` ).
  lang_iterator = docnode->create_iterator_filtered( lang_filter ).
  lang_node ?= lang_iterator->get_next( ).
  WHILE lang_node IS NOT INITIAL.

    REFRESH lt_lines.
    language = lang_node->get_attribute( name = 'SPRAS' ).
    obj_langu = language.
    obj_langu = sy-langu.

* Get TextLines from XML
    FREE: txtline_filter, txtline_iterator, txtline_node.
    txtline_filter = lang_node->create_filter_name( `textLine` ).
    txtline_iterator = lang_node->create_iterator_filtered( txtline_filter ).
    txtline_node ?= txtline_iterator->get_next( ).
    WHILE txtline_node IS NOT INITIAL.
      APPEND INITIAL LINE TO lt_lines ASSIGNING <ls_lines>.
      me->getstructurefromattributes(
        EXPORTING
          node      = txtline_node
        CHANGING
          structure = <ls_lines> ).
      txtline_node ?= txtline_iterator->get_next( ).
    ENDWHILE.

* Delete any documentation that may currently exist.
    CALL FUNCTION 'DOCU_DEL'
      EXPORTING
        id       = 'FU'   "<-- function module documentation
        langu    = obj_langu
        object   = obj_name
        typ      = 'T'
      EXCEPTIONS
        ret_code = 1
        OTHERS   = 2.

* Now update with new documentation text
    CALL FUNCTION 'DOCU_UPD'
      EXPORTING
        id       = 'FU'
        langu    = obj_langu
        object   = obj_name
        typ      = 'T'
      TABLES
        line     = lt_lines
      EXCEPTIONS
        ret_code = 1
        OTHERS   = 2.
    IF sy-subrc <> 0.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = `Program Documentation object import failed`.
    ENDIF.

    lang_node ?= lang_iterator->get_next( ).
  ENDWHILE.

ENDMETHOD.


METHOD create_function_modules.

  TYPES: BEGIN OF tfunct_head,
           name   TYPE rs38l-name,
           global TYPE rs38l-global,
           remote TYPE rs38l-remote,
           utask  TYPE rs38l-utask,
           stext  TYPE tftit-stext,
           area   TYPE rs38l-area,
         END OF tfunct_head.

  DATA: functionmodules_node TYPE REF TO if_ixml_element,

        source               TYPE string,
        sourcetable          TYPE table_of_strings,

        functiongroupname    TYPE  tlibg-area,
        mainfgprogname       TYPE trdir-name,

        xfunct_head          TYPE tfunct_head,
        iimport              TYPE TABLE OF rsimp,
        ichange              TYPE TABLE OF rscha,
        iexport              TYPE TABLE OF rsexp,
        itables              TYPE TABLE OF rstbl,
        iexcepl              TYPE TABLE OF rsexc,
        idocume              TYPE TABLE OF rsfdo,
        isource              TYPE TABLE OF rssource,
        isource_new          TYPE  rsfb_source,

        ximport              TYPE  rsimp,
        xchange              TYPE  rscha,
        xexport              TYPE  rsexp,
        xtables              TYPE  rstbl,
        xexcepl              TYPE  rsexc,
        xdocume              TYPE  rsfdo,
        xsource              TYPE  rssource,
        xsource_new          LIKE LINE OF isource_new,

        node                 TYPE REF TO if_ixml_element,
        filter               TYPE REF TO if_ixml_node_filter,
        iterator             TYPE REF TO if_ixml_node_iterator,

        im_node              TYPE REF TO if_ixml_element,
        im_filter            TYPE REF TO if_ixml_node_filter,
        im_iterator          TYPE REF TO if_ixml_node_iterator,

        ex_node              TYPE REF TO if_ixml_element,
        ex_filter            TYPE REF TO if_ixml_node_filter,
        ex_iterator          TYPE REF TO if_ixml_node_iterator,

        ch_node              TYPE REF TO if_ixml_element,
        ch_filter            TYPE REF TO if_ixml_node_filter,
        ch_iterator          TYPE REF TO if_ixml_node_iterator,

        ta_node              TYPE REF TO if_ixml_element,
        ta_filter            TYPE REF TO if_ixml_node_filter,
        ta_iterator          TYPE REF TO if_ixml_node_iterator,

        el_node              TYPE REF TO if_ixml_element,
        el_filter            TYPE REF TO if_ixml_node_filter,
        el_iterator          TYPE REF TO if_ixml_node_iterator,

        dm_node              TYPE REF TO if_ixml_element,
        dm_filter            TYPE REF TO if_ixml_node_filter,
        dm_iterator          TYPE REF TO if_ixml_node_iterator,

        sc_node              TYPE REF TO if_ixml_element,
        sc_filter            TYPE REF TO if_ixml_node_filter,
        sc_iterator          TYPE REF TO if_ixml_node_iterator,

        scn_node             TYPE REF TO if_ixml_element,
        scn_filter           TYPE REF TO if_ixml_node_filter,
        scn_iterator         TYPE REF TO if_ixml_node_iterator,

        fmdoc_node           TYPE REF TO if_ixml_element.

  functionmodules_node = fm_node.
  functiongroupname    = fct_group.

  IF functionmodules_node  IS NOT INITIAL.

    FREE: filter, iterator, node.
    filter =
      functionmodules_node->create_filter_name( 'functionmodule' ).
    iterator = functionmodules_node->create_iterator_filtered( filter ).
    node ?= iterator->get_next( ).
    WHILE node IS NOT INITIAL.

      CALL METHOD getstructurefromattributes
        EXPORTING
          node      = node
        CHANGING
          structure = xfunct_head.

      REFRESH: iimport, ichange, iexport,
               itables, iexcepl, idocume, isource, isource_new.

* Get importing
      FREE: im_filter, im_iterator, im_node.
      im_filter = node->create_filter_name( 'importing' ).
      im_iterator = node->create_iterator_filtered( im_filter ).
      im_node ?= im_iterator->get_next( ).
      WHILE im_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = im_node
          CHANGING
            structure = ximport.
        APPEND ximport TO iimport.
        im_node ?= im_iterator->get_next( ).
      ENDWHILE.

* Get exporting
      FREE: ex_filter, ex_iterator, ex_node.
      ex_filter = node->create_filter_name( 'exporting' ).
      ex_iterator = node->create_iterator_filtered( ex_filter ).
      ex_node ?= ex_iterator->get_next( ).
      WHILE ex_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = ex_node
          CHANGING
            structure = xexport.
        APPEND xexport TO iexport.
        ex_node ?= ex_iterator->get_next( ).
      ENDWHILE.

* Get changing
      FREE: ch_filter, ch_iterator, ch_node.
      ch_filter = node->create_filter_name( 'changing' ).
      ch_iterator = node->create_iterator_filtered( ch_filter ).
      ch_node ?= ch_iterator->get_next( ).
      WHILE ch_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = ch_node
          CHANGING
            structure = xchange.
        APPEND xchange TO ichange.
        ch_node ?= ch_iterator->get_next( ).
      ENDWHILE.

* Get tables
      FREE: ta_filter, ta_iterator, ta_node.
      ta_filter = node->create_filter_name( 'tables' ).
      ta_iterator = node->create_iterator_filtered( ta_filter ).
      ta_node ?= ta_iterator->get_next( ).
      WHILE ta_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = ta_node
          CHANGING
            structure = xtables.
        APPEND xtables TO itables.
        ta_node ?= ta_iterator->get_next( ).
      ENDWHILE.

* Get exception list
      FREE: el_filter, el_iterator, el_node.
      el_filter = node->create_filter_name( 'exceptions' ).
      el_iterator = node->create_iterator_filtered( el_filter ).
      el_node ?= el_iterator->get_next( ).
      WHILE el_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = el_node
          CHANGING
            structure = xexcepl.
        APPEND xexcepl TO iexcepl.
        el_node ?= el_iterator->get_next( ).
      ENDWHILE.

* Get documentation
      FREE: dm_filter, dm_iterator, dm_node.
      dm_filter = node->create_filter_name( 'documentation' ).
      dm_iterator = node->create_iterator_filtered( dm_filter ).
      dm_node ?= dm_iterator->get_next( ).
      WHILE dm_node IS NOT INITIAL.
        CALL METHOD getstructurefromattributes
          EXPORTING
            node      = dm_node
          CHANGING
            structure = xdocume.
        APPEND xdocume TO idocume.
        dm_node ?= dm_iterator->get_next( ).
      ENDWHILE.

* Get fm source

      FREE: sc_filter, sc_iterator, sc_node.
      sc_filter = node->create_filter_name( 'fm_source' ).
      sc_iterator = node->create_iterator_filtered( sc_filter ).
      sc_node ?= sc_iterator->get_next( ).
      WHILE sc_node IS NOT INITIAL.
        source = sc_node->get_value( ).
        sourcetable = buildtablefromstring( source ).
        LOOP AT sourcetable INTO xsource.
          APPEND xsource TO isource.
        ENDLOOP.
        sc_node ?= sc_iterator->get_next( ).
      ENDWHILE.

* Get fm source new
      FREE: scn_filter, scn_iterator, scn_node.
      scn_filter = node->create_filter_name( 'fm_source_new' ).
      scn_iterator = node->create_iterator_filtered( scn_filter ).
      scn_node ?= scn_iterator->get_next( ).
      WHILE scn_node IS NOT INITIAL.
        source = scn_node->get_value( ).
        sourcetable = buildtablefromstring( source ).
        LOOP AT sourcetable INTO xsource_new.
          APPEND xsource_new TO isource_new.
        ENDLOOP.
        scn_node ?= scn_iterator->get_next( ).
      ENDWHILE.

* INsert the function module
      CALL FUNCTION 'RS_FUNCTIONMODULE_INSERT'
        EXPORTING
          funcname                = xfunct_head-name
          function_pool           = functiongroupname
          interface_global        = xfunct_head-global
          remote_call             = xfunct_head-remote
          update_task             = xfunct_head-utask
          short_text              = xfunct_head-stext
          save_active             = ' ' "<-- Need to set inactive
          new_source              = isource_new
        TABLES
          import_parameter        = iimport
          export_parameter        = iexport
          tables_parameter        = itables
          changing_parameter      = ichange
          exception_list          = iexcepl
          parameter_docu          = idocume
          source                  = isource
        EXCEPTIONS
          double_task             = 1
          error_message           = 2
          function_already_exists = 3
          invalid_function_pool   = 4
          invalid_name            = 5
          too_many_functions      = 6
          no_modify_permission    = 7
          no_show_permission      = 8
          enqueue_system_failure  = 9
          canceled_in_corr        = 10
          OTHERS                  = 11.

* Create function module documentation
      fmdoc_node = node->find_from_name( 'functionModuleDocumentation' ).
      create_fm_documentation( fmdoc_node ).

      node ?= iterator->get_next( ).
    ENDWHILE.

  ENDIF.

ENDMETHOD.


METHOD create_includes.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

  TYPES: BEGIN OF tinclude,
           name(40),
         END OF tinclude.

  DATA iinclude TYPE TABLE OF tinclude.
  DATA xinclude TYPE tinclude.

  DATA inc_node       TYPE REF TO if_ixml_element.
  DATA inc_filter     TYPE REF TO if_ixml_node_filter.
  DATA inc_iterator   TYPE REF TO if_ixml_node_iterator.

  DATA progattribs TYPE trdir.

  DATA includes_node     TYPE REF TO if_ixml_element.
  DATA includesourcenode TYPE REF TO if_ixml_element.

  DATA source      TYPE string.
  DATA sourcetable TYPE table_of_strings.

  includes_node = incl_node.

  CHECK includes_node IS NOT INITIAL.

  FREE: inc_filter, inc_iterator, inc_node.
  inc_filter = includes_node->create_filter_name( 'include' ).
  inc_iterator = includes_node->create_iterator_filtered( inc_filter ).
  inc_node ?= inc_iterator->get_next( ).

  WHILE inc_node IS NOT INITIAL.

    getstructurefromattributes(
      EXPORTING
        node      = inc_node
      CHANGING
        structure = progattribs ).

    progattribs-rload = sy-langu.

    includesourcenode = inc_node->find_from_name( 'include_source' ).
    source      = includesourcenode->get_value( ).
    sourcetable = buildtablefromstring( source ).

    IF sourcetable IS NOT INITIAL.
      objname = progattribs-name.   " Include Program Name is the object

      enqueue_abap( ).
      transport_copy( author   = progattribs-cnam
                      devclass = devclass ).
      create_source( source  = sourcetable
                     attribs = progattribs ).
      dequeue_abap( ).
    ENDIF.

    inc_node  ?=  inc_iterator->get_next( ).

  ENDWHILE.

ENDMETHOD.


METHOD create_pfstatus.

  DATA: ista      TYPE TABLE OF rsmpe_stat,
        ifun      TYPE TABLE OF rsmpe_funt,
        imen      TYPE TABLE OF rsmpe_men,
        imtx      TYPE TABLE OF rsmpe_mnlt,
        iact      TYPE TABLE OF rsmpe_act,
        ibut      TYPE TABLE OF rsmpe_but,
        ipfk      TYPE TABLE OF rsmpe_pfk,
        iset      TYPE TABLE OF rsmpe_staf,
        idoc      TYPE TABLE OF rsmpe_atrt,
        itit      TYPE TABLE OF rsmpe_titt,
        ibiv      TYPE TABLE OF rsmpe_buts,

        xsta      TYPE rsmpe_stat,
        xfun      TYPE rsmpe_funt,
        xmen      TYPE rsmpe_men,
        xmtx      TYPE rsmpe_mnlt,
        xact      TYPE rsmpe_act,
        xbut      TYPE rsmpe_but,
        xpfk      TYPE rsmpe_pfk,
        xset      TYPE rsmpe_staf,
        xdoc      TYPE rsmpe_atrt,
        xtit      TYPE rsmpe_titt,
        xbiv      TYPE rsmpe_buts,

        xtrkey    TYPE trkey,
        xadm      TYPE rsmpe_adm,
        _program  TYPE  trdir-name,
        _objname  TYPE trobj_name,

        stat_node TYPE REF TO if_ixml_element,
        node      TYPE REF TO if_ixml_element,
        filter    TYPE REF TO if_ixml_node_filter,
        iterator  TYPE REF TO if_ixml_node_iterator.

  _objname = objname.

  stat_node =  pfstat_node.
  CHECK stat_node IS NOT INITIAL.

* read pfstatus_sta node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_sta' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xsta.
    APPEND xsta TO ista.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_fun node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_fun' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xfun.
    APPEND xfun TO ifun.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_men node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_men' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xmen.
    APPEND xmen TO imen.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_mtx node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_mtx' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xmtx.
    APPEND xmtx TO imtx.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_act node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_act' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xact.
    APPEND xact TO iact.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_but node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_but' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xbut.
    APPEND xbut TO ibut.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_pfk node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_pfk' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xpfk.
    APPEND xpfk TO ipfk.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_set node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_set' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xset.
    APPEND xset TO iset.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_doc node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_doc' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xdoc.
    APPEND xdoc TO idoc.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_tit node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_tit' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xtit.
    APPEND xtit TO itit.
    node ?= iterator->get_next( ).
  ENDWHILE.

* read pfstatus_biv node
  FREE: filter, iterator, node.
  filter = stat_node->create_filter_name( 'pfstatus_biv' ).
  iterator = stat_node->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = xbiv.
    APPEND xbiv TO ibiv.
    node ?= iterator->get_next( ).
  ENDWHILE.

* Update the gui status
  _program = _objname.

  xtrkey-obj_type = 'PROG'.
  xtrkey-obj_name = _program.
  xtrkey-sub_type = 'CUAD'.
  xtrkey-sub_name = _program.

  xadm-actcode = '000000'.
  xadm-mencode = '000000'.
  xadm-pfkcode = '000000'.

  CALL FUNCTION 'RS_CUA_INTERNAL_WRITE'
    EXPORTING
      program   = _program
      language  = sy-langu
      tr_key    = xtrkey
      adm       = xadm
      state     = 'I'
    TABLES
      sta       = ista
      fun       = ifun
      men       = imen
      mtx       = imtx
      act       = iact
      but       = ibut
      pfk       = ipfk
      set       = iset
      doc       = idoc
      tit       = itit
      biv       = ibiv
    EXCEPTIONS
      not_found = 1
      OTHERS    = 2.

  IF sy-subrc <> 0.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>system_error.
  ENDIF.

  CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
    EXPORTING
      object   = 'CUAD'
      obj_name = _objname
    EXCEPTIONS
      OTHERS   = 0.

ENDMETHOD.


METHOD create_source.

  DATA: _objname   TYPE trobj_name,
        progline   TYPE progdir,
        titleinfo  TYPE trdirti,
        reportline TYPE string,
        minireport TYPE table_of_strings.

  _objname = objname.

  CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
    EXPORTING
      object            = 'REPS'
      obj_name          = _objname
    EXCEPTIONS
      wrong_object_name = 1.

  INSERT REPORT _objname FROM source STATE 'I'
         PROGRAM TYPE attribs-subc.  "added to handle includes, etc.
  MOVE 'I' TO progline-state.
  MOVE-CORRESPONDING attribs TO progline.
  progline-rload = sy-langu.
  MODIFY progdir FROM progline.

  CONCATENATE 'REPORT' _objname '.' INTO reportline SEPARATED BY space.
  APPEND reportline TO minireport.
  INSERT REPORT _objname FROM minireport STATE 'A'
         PROGRAM TYPE attribs-subc.
  MOVE 'A' TO progline-state.
  MODIFY progdir FROM progline.

ENDMETHOD.


METHOD create_textpool.

  DATA: textpooltable       TYPE STANDARD TABLE OF textpool,
        textpoolrow         TYPE textpool,
        langiterator        TYPE REF TO if_ixml_node_iterator,
        filter              TYPE REF TO if_ixml_node_filter,
        textfilter          TYPE REF TO if_ixml_node_filter,
        textiterator        TYPE REF TO if_ixml_node_iterator,
        langnode            TYPE REF TO if_ixml_element,
        atextnode           TYPE REF TO if_ixml_element,
        _objname            TYPE trobj_name,
        lang                TYPE spras,
        langnodeexists      TYPE flag,
        logonlanguageexists TYPE flag,
        _state(1)           TYPE c.

  _objname = objname.

  filter = textpoolnode->create_filter_name( 'language' ).
  langiterator = textpoolnode->create_iterator_filtered( filter ).
  langnode ?= langiterator->get_next( ).

  WHILE langnode IS NOT INITIAL.
    langnodeexists = 'X'.
    CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
      EXPORTING
        object   = 'REPT'
        obj_name = _objname
      EXCEPTIONS
        OTHERS   = 0.

    REFRESH textpooltable.
    textiterator = langnode->create_iterator( ).
    atextnode ?= textiterator->get_next( ).
*For some reason the 1st one is blank... not sure why.
    atextnode ?= textiterator->get_next( ).
    WHILE atextnode IS NOT INITIAL.
      CALL METHOD getstructurefromattributes
        EXPORTING
          node      = atextnode
        CHANGING
          structure = textpoolrow.
      APPEND textpoolrow TO textpooltable.
      atextnode ?= textiterator->get_next( ).
    ENDWHILE.
    IF textpooltable IS NOT INITIAL.
      lang = langnode->get_attribute( 'SPRAS' ).
      lang = sy-langu.
      IF lang = sy-langu.
        logonlanguageexists = 'X'.
        _state = 'I'.
      ELSE.
*       seems that if a textpool is inserted as inactive for language
*       other than the logon language, it is lost upon activation
*       not sure inserting as active is best solution,but seems to work
        _state = 'A'.
      ENDIF.
    ENDIF.
    INSERT TEXTPOOL _objname FROM textpooltable LANGUAGE lang STATE _state.
    langnode ?= langiterator->get_next( ).
  ENDWHILE.

ENDMETHOD.


METHOD DELETEOBJECT.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    DATA area TYPE rs38l-area.

    area = objname.

    CALL FUNCTION 'RS_FUNCTION_POOL_DELETE'
      EXPORTING
        area                   = area
*       CORRNUM                = ' '
*       TEXT                   = ' '
*       UNAME                  = ' '
        with_korr              = ' '
*       WB_FB_MANAGER          =
        suppress_popups        = 'X'
*       SKIP_PROGRESS_IND      = ' '
* IMPORTING
*       E_CORRNUM              =
      EXCEPTIONS
        canceled_in_corr       = 1
        enqueue_system_failure = 2
        function_exist         = 3
        not_executed           = 4
        no_modify_permission   = 5
        no_show_permission     = 6
        permission_failure     = 7
        pool_not_exist         = 8
        cancelled              = 9
        OTHERS                 = 10.
    .
    IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
    ENDIF.


  ENDMETHOD.


METHOD DEQUEUE_ABAP.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    CALL FUNCTION 'RS_ACCESS_PERMISSION'
      EXPORTING
        global_lock              = 'X'
        mode                     = 'FREE'
        object                   = objname
        object_class             = 'ABAP'
      EXCEPTIONS
        canceled_in_corr         = 1
        enqueued_by_user         = 3
        enqueue_system_failure   = 4
        locked_by_author         = 5
        illegal_parameter_values = 6
        no_modify_permission     = 7
        no_show_permission       = 8
        permission_failure       = 9.

    IF sy-subrc <> 0.
      CASE sy-subrc.
        WHEN 7 OR 8 OR 9.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>not_authorized.
        WHEN 5.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>error_message
              msg    = 'object locked'.
        WHEN OTHERS.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>system_error.
      ENDCASE.
    ENDIF.

  ENDMETHOD.


METHOD ENQUEUE_ABAP.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/


    CALL FUNCTION 'RS_ACCESS_PERMISSION'
      EXPORTING
*       authority_check          = authority_check
        global_lock              = 'X'
        mode                     = 'INSERT'
*       master_language          = trdir-rload
        object                   = objname
        object_class             = 'ABAP'
*       importing
*       transport_key            = trkey_global
*       new_master_language      = trdir-rload
*       devclass                 = devclass_local
      EXCEPTIONS
        canceled_in_corr         = 1
        enqueued_by_user         = 3
        enqueue_system_failure   = 4
        locked_by_author         = 5
        illegal_parameter_values = 6
        no_modify_permission     = 7
        no_show_permission       = 8
        permission_failure       = 9.

    IF sy-subrc <> 0.
      CASE sy-subrc.
        WHEN 7 OR 8 OR 9.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>not_authorized.
        WHEN 5.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>error_message
              msg    = 'object locked'.
        WHEN OTHERS.
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>system_error.
      ENDCASE.
    ENDIF.

  ENDMETHOD.


METHOD GETOBJECTTYPE.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/
    objecttype = 'FUGR'. " Function Group
  ENDMETHOD.


METHOD GET_DOCUMENTATION.

    DATA languagenode   TYPE REF TO if_ixml_element.
    DATA txtlines_node TYPE REF TO if_ixml_element.
    DATA rc            TYPE sysubrc.
    DATA _objtype      TYPE string.

    TYPES: BEGIN OF t_dokhl,
             id         TYPE dokhl-id,
             object     TYPE dokhl-object,
             langu      TYPE dokhl-langu,
             typ        TYPE dokhl-typ,
             dokversion TYPE dokhl-dokversion,
           END OF t_dokhl.

    DATA lt_dokhl TYPE TABLE OF t_dokhl.
    DATA ls_dokhl LIKE LINE OF lt_dokhl.

    DATA lt_lines TYPE TABLE OF tline.
    DATA ls_lines LIKE LINE OF lt_lines.

    DATA lv_str TYPE string.
    DATA _objname TYPE e071-obj_name.

    _objname = objname.

* Check against database
    SELECT  id object langu typ dokversion
          INTO CORRESPONDING FIELDS OF TABLE lt_dokhl
             FROM dokhl
               WHERE id = 'RE'
                  AND object = _objname.

* Use only most recent version.
    SORT lt_dokhl BY id object langu typ ASCENDING dokversion DESCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_dokhl COMPARING id object typ langu.

    docnode = xmldoc->create_element( 'functionGroupDocumentation' ).

* Make sure there is at least one record here.
    CLEAR ls_dokhl.
    READ TABLE lt_dokhl INTO ls_dokhl INDEX 1.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Set docNode object attribute
    lv_str = ls_dokhl-object.
    rc = docnode->set_attribute( name = 'OBJECT' value = lv_str ).

    LOOP AT lt_dokhl INTO ls_dokhl.

* Create language node, and set attribute
      languagenode = xmldoc->create_element( 'language' ).
      lv_str = ls_dokhl-langu.
      rc = languagenode->set_attribute( name = 'SPRAS' value = lv_str ).

* Read the documentation text
      CALL FUNCTION 'DOCU_READ'
        EXPORTING
          id      = ls_dokhl-id
          langu   = ls_dokhl-langu
          object  = ls_dokhl-object
          typ     = ls_dokhl-typ
          version = ls_dokhl-dokversion
        TABLES
          line    = lt_lines.

* Write records to XML node
      LOOP AT lt_lines INTO ls_lines.
        txtlines_node = xmldoc->create_element( `textLine` ).
        me->setattributesfromstructure( node = txtlines_node structure = ls_lines ).
        rc = languagenode->append_child( txtlines_node ).
      ENDLOOP.
      rc = docnode->append_child( languagenode ) .
    ENDLOOP.

  ENDMETHOD.


METHOD GET_DYNPRO.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    TYPES: BEGIN OF tdynp,
             prog TYPE d020s-prog,
             dnum TYPE d020s-dnum,
           END OF tdynp.

    DATA: idyn_fldl TYPE TABLE OF d021s,
          idyn_flow TYPE TABLE OF d022s,
          idyn_mcod TYPE TABLE OF d023s.

    DATA: xdyn_head TYPE  d020s,
          xdyn_fldl TYPE  d021s,
          xdyn_flow TYPE  d022s,
          xdyn_mcod TYPE  d023s.

    DATA idynp TYPE TABLE OF tdynp.
    DATA xdynp TYPE tdynp.

    DATA xdyn_text TYPE d020t-dtxt.
    DATA xdyn_text_string TYPE string.

    DATA _objname TYPE trobj_name.
    DATA rc TYPE sy-subrc .

    DATA iflowsource TYPE rswsourcet.
    DATA xflowsource LIKE LINE OF iflowsource.
    DATA flowsourcestring TYPE string.

    DATA dynnr_node TYPE REF TO if_ixml_element.
    DATA dynpromatchnode TYPE REF TO if_ixml_element.
    DATA dynprofieldsnode TYPE REF TO if_ixml_element.
    DATA dynproflownode TYPE REF TO if_ixml_element.

    _objname = objname.

* Get all dynpros for program object
    CLEAR xdynp.  REFRESH idynp.
    SELECT prog dnum INTO TABLE idynp
                  FROM d020s
                     WHERE prog = _objname
                       AND type <> 'S'    " No Selection Screens
                       AND type <> 'J'.   " No selection subscreens
    CHECK sy-subrc  = 0 .

    dynp_node = xmldoc->create_element( 'dynpros' ).

    LOOP AT idynp INTO xdynp.

* Retrieve dynpro imformation
      dynnr_node =  xmldoc->create_element( 'dynpro' ).

      CLEAR:    xdyn_head, xdyn_fldl, xdyn_flow, xdyn_mcod.
      REFRESH:  idyn_fldl, idyn_flow, idyn_mcod.

      CALL FUNCTION 'RPY_DYNPRO_READ_NATIVE'
        EXPORTING
          progname         = xdynp-prog
          dynnr            = xdynp-dnum
*         SUPPRESS_EXIST_CHECKS       = ' '
*         SUPPRESS_CORR_CHECKS        = ' '
        IMPORTING
          header           = xdyn_head
          dynprotext       = xdyn_text
        TABLES
          fieldlist        = idyn_fldl
          flowlogic        = idyn_flow
          params           = idyn_mcod
*         FIELDTEXTS       =
        EXCEPTIONS
          cancelled        = 1
          not_found        = 2
          permission_error = 3
          OTHERS           = 4.

      CHECK sy-subrc = 0.

* Add heading information for screen.
      setattributesfromstructure(
                       node = dynnr_node structure =  xdyn_head  ).
* Add the dynpro text also.
      xdyn_text_string =  xdyn_text.
      rc = dynnr_node->set_attribute(
                 name = 'DTEXT'  value = xdyn_text_string ).
      rc = dynp_node->append_child( dynnr_node ).

* Add fields information for screen.
      IF NOT idyn_fldl[] IS INITIAL.
        LOOP AT idyn_fldl INTO xdyn_fldl.
          dynprofieldsnode = xmldoc->create_element( 'dynprofield' ).
          setattributesfromstructure(
                   node = dynprofieldsnode structure =  xdyn_fldl ).
          rc = dynnr_node->append_child( dynprofieldsnode ).
        ENDLOOP.
      ENDIF.

* Add flow logic of screen
      IF NOT idyn_flow[] IS INITIAL.
        CLEAR xflowsource. REFRESH  iflowsource.
        LOOP AT idyn_flow INTO xdyn_flow.
          xflowsource  = xdyn_flow.
          APPEND xflowsource TO iflowsource.
        ENDLOOP.

        dynproflownode = xmldoc->create_element( 'dynproflowsource' ).
        flowsourcestring = buildsourcestring( sourcetable = iflowsource ).
        rc = dynproflownode->if_ixml_node~set_value( flowsourcestring ).
        rc = dynnr_node->append_child( dynproflownode  ).
      ENDIF.

* Add matchcode information for screen.
      IF NOT idyn_mcod[] IS INITIAL.
        LOOP AT idyn_mcod INTO xdyn_mcod.
          CHECK NOT xdyn_mcod-type IS INITIAL
            AND NOT xdyn_mcod-content IS INITIAL.
          dynpromatchnode = xmldoc->create_element( 'dynpromatchcode' ).
          setattributesfromstructure(
                   node = dynpromatchnode structure =  xdyn_mcod ).
          rc = dynnr_node->append_child( dynpromatchnode ).
        ENDLOOP.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


METHOD GET_FM_DOCUMENTATION.

    DATA languagenode   TYPE REF TO if_ixml_element.
    DATA txtlines_node TYPE REF TO if_ixml_element.
    DATA rc            TYPE sysubrc.
    DATA _objtype      TYPE string.

    TYPES: BEGIN OF t_dokhl,
             id         TYPE dokhl-id,
             object     TYPE dokhl-object,
             langu      TYPE dokhl-langu,
             typ        TYPE dokhl-typ,
             dokversion TYPE dokhl-dokversion,
           END OF t_dokhl.

    DATA lt_dokhl TYPE TABLE OF t_dokhl.
    DATA ls_dokhl LIKE LINE OF lt_dokhl.

    DATA lt_lines TYPE TABLE OF tline.
    DATA ls_lines LIKE LINE OF lt_lines.

    DATA lv_str TYPE string.
    DATA _objname TYPE e071-obj_name.

    _objname = fm_name.

* Check against database
    SELECT  id object langu typ dokversion
          INTO CORRESPONDING FIELDS OF TABLE lt_dokhl
             FROM dokhl
               WHERE id = 'FU'
                  AND object = _objname.

* Use only most recent version.
    SORT lt_dokhl BY id object langu typ ASCENDING dokversion DESCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_dokhl COMPARING id object typ langu.

    docnode = xmldoc->create_element( 'functionModuleDocumentation' ).

* Make sure there is at least one record here.
    CLEAR ls_dokhl.
    READ TABLE lt_dokhl INTO ls_dokhl INDEX 1.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Set docNode object attribute
    lv_str = ls_dokhl-object.
    rc = docnode->set_attribute( name = 'OBJECT' value = lv_str ).

    LOOP AT lt_dokhl INTO ls_dokhl.

* Create language node, and set attribute
      languagenode = xmldoc->create_element( 'language' ).
      lv_str = ls_dokhl-langu.
      rc = languagenode->set_attribute( name = 'SPRAS' value = lv_str ).

* Read the documentation text
      CALL FUNCTION 'DOCU_READ'
        EXPORTING
          id      = ls_dokhl-id
          langu   = ls_dokhl-langu
          object  = ls_dokhl-object
          typ     = ls_dokhl-typ
          version = ls_dokhl-dokversion
        TABLES
          line    = lt_lines.

* Write records to XML node
      LOOP AT lt_lines INTO ls_lines.
        txtlines_node = xmldoc->create_element( `textLine` ).
        me->setattributesfromstructure( node = txtlines_node structure = ls_lines ).
        rc = languagenode->append_child( txtlines_node ).
      ENDLOOP.
      rc = docnode->append_child( languagenode ) .
    ENDLOOP.

  ENDMETHOD.


METHOD get_function_modules.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    TYPES: BEGIN OF tfunct_head,
             name   TYPE rs38l-name,
             global TYPE rs38l-global,
             remote TYPE rs38l-remote,
             utask  TYPE rs38l-utask,
             stext  TYPE tftit-stext,
             area   TYPE rs38l-area,
           END OF tfunct_head.

    DATA xfunct_head TYPE tfunct_head.
    DATA iimport     TYPE TABLE OF rsimp.
    DATA ichange     TYPE TABLE OF rscha.
    DATA iexport     TYPE TABLE OF rsexp.
    DATA itables     TYPE TABLE OF rstbl.
    DATA iexcepl     TYPE TABLE OF rsexc.
    DATA idocume     TYPE TABLE OF rsfdo.
    DATA isource     TYPE TABLE OF rssource.
    DATA isource_new TYPE rsfb_source .

    DATA ximport     TYPE  rsimp.
    DATA xchange     TYPE  rscha.
    DATA xexport     TYPE  rsexp.
    DATA xtables     TYPE  rstbl.
    DATA xexcepl     TYPE  rsexc.
    DATA xdocume     TYPE  rsfdo.
    DATA xsource     TYPE  rssource.
    DATA xsource_new LIKE LINE OF isource_new.

    DATA functionmodulesnode TYPE REF TO if_ixml_element.
    DATA functionmodulenode  TYPE REF TO if_ixml_element.
    DATA importsnode TYPE REF TO if_ixml_element.
    DATA changesnode TYPE REF TO if_ixml_element.
    DATA exportsnode TYPE REF TO if_ixml_element.
    DATA tablesnode  TYPE REF TO if_ixml_element.
    DATA exceplnode  TYPE REF TO if_ixml_element.
    DATA documsnode  TYPE REF TO if_ixml_element.
    DATA fmsrcenode  TYPE REF TO if_ixml_element.
    DATA fmsrcenewnode  TYPE REF TO if_ixml_element.
    DATA fmdocumenation TYPE REF TO if_ixml_element.
    DATA fmparmdocumenation TYPE REF TO if_ixml_element.

    DATA functiongroupname TYPE  tlibg-area.

    DATA ifunct TYPE TABLE OF  rs38l_incl.
    DATA xfunct TYPE  rs38l_incl.

    DATA rc           TYPE sysubrc.
    DATA progattribs  TYPE trdir.
    DATA progsource   TYPE rswsourcet.
    DATA _objname(30) TYPE c.
    DATA sourcestring TYPE string.
    DATA function_deleted    TYPE c.
    DATA endfunction_deleted TYPE c.

    functiongroupname = fct_group.

* Now get the function pool contents
    CALL FUNCTION 'RS_FUNCTION_POOL_CONTENTS'
      EXPORTING
        function_pool           = functiongroupname
      TABLES
        functab                 = ifunct
      EXCEPTIONS
        function_pool_not_found = 1
        OTHERS                  = 2.

* Now write out function modules data.
    functionmodulesnode = xmldoc->create_element( 'functionmodules' ).

    LOOP AT ifunct INTO xfunct.

      functionmodulenode = xmldoc->create_element( 'functionmodule' ).
      xfunct_head-name =  xfunct-funcname.

      REFRESH: iimport, ichange, iexport,
               itables, iexcepl, idocume, isource, isource_new.

* Read the function module data
      CALL FUNCTION 'RPY_FUNCTIONMODULE_READ_NEW'
        EXPORTING
          functionname       = xfunct_head-name
        IMPORTING
          global_flag        = xfunct_head-global
          remote_call        = xfunct_head-remote
          update_task        = xfunct_head-utask
          short_text         = xfunct_head-stext
*         FUNCTION_POOL      =
        TABLES
          import_parameter   = iimport
          changing_parameter = ichange
          export_parameter   = iexport
          tables_parameter   = itables
          exception_list     = iexcepl
          documentation      = idocume
          source             = isource
        CHANGING
          new_source         = isource_new
        EXCEPTIONS
          error_message      = 1
          function_not_found = 2
          invalid_name       = 3
          OTHERS             = 4.

* Set the header attributes
      setattributesfromstructure(
                 node = functionmodulenode
                 structure =  xfunct_head  ).

* IMports
      IF NOT iimport[] IS INITIAL.
        LOOP AT iimport INTO ximport.
          importsnode = xmldoc->create_element( 'importing' ).
          setattributesfromstructure(
                   node = importsnode structure =  ximport ).
          rc = functionmodulenode->append_child( importsnode ).
        ENDLOOP.
      ENDIF.

* Exports
      IF NOT iexport[] IS INITIAL.
        LOOP AT iexport INTO xexport.
          exportsnode = xmldoc->create_element( 'exporting' ).
          setattributesfromstructure(
                   node = exportsnode structure =  xexport ).
          rc = functionmodulenode->append_child( exportsnode ).
        ENDLOOP.
      ENDIF.

* Changing
      IF NOT ichange[] IS INITIAL.
        LOOP AT ichange INTO xchange.
          changesnode = xmldoc->create_element( 'changing' ).
          setattributesfromstructure(
                   node = changesnode structure =  xchange ).
          rc = functionmodulenode->append_child( changesnode ).
        ENDLOOP.
      ENDIF.

* Tables
      IF NOT itables[] IS INITIAL.
        LOOP AT itables INTO xtables.
          tablesnode = xmldoc->create_element( 'tables' ).
          setattributesfromstructure(
                   node = tablesnode structure =  xtables ).
          rc = functionmodulenode->append_child( tablesnode ).
        ENDLOOP.
      ENDIF.

* Exception list
      IF NOT iexcepl[] IS INITIAL.
        LOOP AT iexcepl INTO xexcepl.
          exceplnode = xmldoc->create_element( 'exceptions' ).
          setattributesfromstructure(
                   node = exceplnode structure =  xexcepl ).
          rc = functionmodulenode->append_child( exceplnode ).
        ENDLOOP.
      ENDIF.

* Documentation - this is short text
      IF NOT idocume[] IS INITIAL.
        LOOP AT idocume INTO xdocume .
          documsnode = xmldoc->create_element( 'documentation' ).
          setattributesfromstructure(
                   node = documsnode structure =  xdocume  ).

          rc = functionmodulenode->append_child( documsnode ).
        ENDLOOP.
      ENDIF.

* Source code for function module
      IF NOT isource[] IS INITIAL.

* Get rid of the FUNCTION and ENDFUNCTION statements.
* And the signature comments
* All of this will be inserted automatically, when imported.
        CLEAR: function_deleted, endfunction_deleted.
        LOOP AT isource INTO xsource.
          IF xsource+0(2) = '*"'.
            DELETE isource INDEX sy-tabix.
            CONTINUE.
          ENDIF.
          SEARCH xsource FOR 'FUNCTION'.
          "Got it and not a comment?
          IF sy-subrc  = 0 AND xsource+0(1) <> '*'.
            DELETE isource INDEX sy-tabix.
            function_deleted = 'X'.
            CONTINUE.
          ENDIF.
          SEARCH xsource FOR 'ENDFUNCTION'.
          IF sy-subrc  = 0.
            DELETE isource INDEX sy-tabix.
            endfunction_deleted = 'X'.
            CONTINUE.
          ENDIF.
        ENDLOOP.

        fmsrcenode = xmldoc->create_element( 'fm_source' ).
        REFRESH progsource.
        LOOP AT isource INTO xsource.
          APPEND xsource TO progsource.
        ENDLOOP.
        sourcestring = buildsourcestring( sourcetable = progsource ).
        rc = fmsrcenode->if_ixml_node~set_value( sourcestring ).
        rc = functionmodulenode->append_child( fmsrcenode ).

      ENDIF.

      DATA: lv_len TYPE i.
* Source code for function module
      IF NOT isource_new[] IS INITIAL.

* Get rid of the FUNCTION and ENDFUNCTION statements.
* And the signature comments
* All of this will be inserted automatically, when imported.
        CLEAR: function_deleted, endfunction_deleted.
        LOOP AT isource_new INTO xsource_new.
          CHECK xsource_new IS NOT INITIAL.
          lv_len = strlen( xsource_new ).
          IF lv_len > 1 AND xsource_new+0(2) = '*"'.
            DELETE isource_new INDEX sy-tabix.
            CONTINUE.
          ENDIF.

          SEARCH xsource_new FOR 'FUNCTION'.
          "Got it and not a comment?
          IF sy-subrc  = 0 AND xsource_new+0(1) <> '*'.
            DELETE isource_new INDEX sy-tabix.
            function_deleted = 'X'.
            CONTINUE.
          ENDIF.
          SEARCH xsource_new FOR 'ENDFUNCTION'.
          IF sy-subrc  = 0.
            DELETE isource_new INDEX sy-tabix.
            endfunction_deleted = 'X'.
            CONTINUE.
          ENDIF.
        ENDLOOP.

        fmsrcenewnode = xmldoc->create_element( 'fm_source_new' ).
        REFRESH progsource.
        LOOP AT isource_new INTO xsource_new.
          APPEND xsource_new TO progsource.
        ENDLOOP.
        sourcestring = buildsourcestring( sourcetable = progsource ).
        rc = fmsrcenewnode->if_ixml_node~set_value( sourcestring ).
        rc = functionmodulenode->append_child( fmsrcenewnode ).

      ENDIF.

* Get function module documentation
      fmdocumenation = get_fm_documentation( xfunct-funcname ).
      rc = functionmodulenode->append_child( fmdocumenation ).

* Add to functionmodules node
      rc = functionmodulesnode->append_child( functionmodulenode ).

    ENDLOOP.


    fm_node = functionmodulesnode.

  ENDMETHOD.


METHOD GET_INCLUDES.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    TYPES: BEGIN OF tinclude,
             name(40),
           END OF tinclude.

    DATA iinclude TYPE TABLE OF tinclude.
    DATA xinclude TYPE tinclude.

    DATA ifunct TYPE TABLE OF  rs38l_incl.
    DATA xfunct TYPE  rs38l_incl.

    DATA functiongroupname TYPE  tlibg-area.
    DATA mainfgprogname    TYPE sy-repid.

    DATA includenode  TYPE REF TO if_ixml_element.
    DATA includesnode TYPE REF TO if_ixml_element.
    DATA includesourcenode TYPE REF TO if_ixml_element.

    DATA progattribs  TYPE trdir.
    DATA rc           TYPE sysubrc.
    DATA progsource   TYPE rswsourcet.
    DATA _objname(30) TYPE c.
    DATA sourcestring TYPE string.

    functiongroupname = fct_group.
    mainfgprogname    = main_prog.

    CALL FUNCTION 'RS_FUNCTION_POOL_CONTENTS'
      EXPORTING
        function_pool           = functiongroupname
      TABLES
        functab                 = ifunct
      EXCEPTIONS
        function_pool_not_found = 1
        OTHERS                  = 2.

* Get all includes
    CALL FUNCTION 'RS_GET_ALL_INCLUDES'
      EXPORTING
        program      = mainfgprogname
      TABLES
        includetab   = iinclude
      EXCEPTIONS
        not_existent = 1
        no_program   = 2
        OTHERS       = 3.

* Get rid of any includes that are for the function modules
* and any includes that are in SAP namespace
    LOOP AT iinclude INTO xinclude.
      READ TABLE ifunct
               INTO xfunct
                     WITH KEY include = xinclude-name.
      IF sy-subrc  = 0.
        DELETE iinclude WHERE name = xinclude-name.
        CONTINUE.
      ENDIF.
      SELECT SINGLE * FROM trdir
              INTO progattribs
                     WHERE name = xinclude-name.
      IF progattribs-cnam = 'SAP'.
        DELETE iinclude WHERE name = xinclude-name.
        CONTINUE.
      ENDIF.
      IF xinclude-name(2) <> 'LZ'
         AND xinclude-name(2) <> 'LY'
         AND xinclude-name(1) <> 'Z'
         AND xinclude-name(1) <> 'Y'.
        DELETE iinclude WHERE name = xinclude-name.
        CONTINUE.
      ENDIF.
    ENDLOOP.

* Write out include programs.....
    includesnode = xmldoc->create_element( 'includeprograms' ).

    LOOP AT iinclude INTO xinclude.

      includenode = xmldoc->create_element( 'include' ).
      SELECT SINGLE * FROM trdir
              INTO progattribs
                     WHERE name = xinclude-name.
      setattributesfromstructure(
                 node = includenode
                 structure =  progattribs  ).

      includesourcenode = xmldoc->create_element( 'include_source' ).
      READ REPORT xinclude-name INTO progsource.
      sourcestring = buildsourcestring( sourcetable = progsource ).
      rc = includesourcenode->if_ixml_node~set_value( sourcestring ).
      rc = includenode->append_child( includesourcenode ).
      rc = includesnode->append_child( includenode ).

    ENDLOOP.

    incl_node = includesnode.

  ENDMETHOD.


METHOD GET_PFSTATUS.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    DATA: ista TYPE TABLE OF rsmpe_stat,
          ifun TYPE TABLE OF rsmpe_funt,
          imen TYPE TABLE OF rsmpe_men,
          imtx TYPE TABLE OF rsmpe_mnlt,
          iact TYPE TABLE OF rsmpe_act,
          ibut TYPE TABLE OF rsmpe_but,
          ipfk TYPE TABLE OF rsmpe_pfk,
          iset TYPE TABLE OF rsmpe_staf,
          idoc TYPE TABLE OF rsmpe_atrt,
          itit TYPE TABLE OF rsmpe_titt,
          ibiv TYPE TABLE OF rsmpe_buts.

    DATA: xsta TYPE rsmpe_stat,
          xfun TYPE rsmpe_funt,
          xmen TYPE rsmpe_men,
          xmtx TYPE rsmpe_mnlt,
          xact TYPE rsmpe_act,
          xbut TYPE rsmpe_but,
          xpfk TYPE rsmpe_pfk,
          xset TYPE rsmpe_staf,
          xdoc TYPE rsmpe_atrt,
          xtit TYPE rsmpe_titt,
          xbiv TYPE rsmpe_buts.

    DATA sta_node TYPE REF TO if_ixml_element.
    DATA fun_node TYPE REF TO if_ixml_element.
    DATA men_node TYPE REF TO if_ixml_element.
    DATA mtx_node TYPE REF TO if_ixml_element.
    DATA act_node TYPE REF TO if_ixml_element.
    DATA but_node TYPE REF TO if_ixml_element.
    DATA pfk_node TYPE REF TO if_ixml_element.
    DATA set_node TYPE REF TO if_ixml_element.
    DATA doc_node TYPE REF TO if_ixml_element.
    DATA tit_node TYPE REF TO if_ixml_element.
    DATA biv_node TYPE REF TO if_ixml_element.

    DATA _objname TYPE trobj_name.
    DATA _program TYPE  trdir-name.
    DATA rc TYPE sy-subrc.

    _objname = objname.
    _program = objname.

    CALL FUNCTION 'RS_CUA_INTERNAL_FETCH'
      EXPORTING
        program         = _program
        language        = sy-langu
      TABLES
        sta             = ista
        fun             = ifun
        men             = imen
        mtx             = imtx
        act             = iact
        but             = ibut
        pfk             = ipfk
        set             = iset
        doc             = idoc
        tit             = itit
        biv             = ibiv
      EXCEPTIONS
        not_found       = 1
        unknown_version = 2
        OTHERS          = 3.

    CHECK sy-subrc = 0.

* if there is a gui status or gui title present, then
* create pfstatus node.
    IF ista[] IS NOT INITIAL
       OR itit[] IS NOT INITIAL.
      pfstat_node = xmldoc->create_element( 'pfstatus' ).
    ENDIF.


* if ista is filled, assume there are one or more
* gui statuses
    IF ista[] IS NOT INITIAL.

      LOOP AT ista INTO xsta.
        sta_node = xmldoc->create_element( 'pfstatus_sta' ).
        setattributesfromstructure(
                 node = sta_node
                 structure =  xsta ).
        rc = pfstat_node->append_child( sta_node ).
      ENDLOOP.

      LOOP AT ifun INTO xfun.
        fun_node = xmldoc->create_element( 'pfstatus_fun' ).
        setattributesfromstructure(
                 node = fun_node
                 structure =  xfun ).
        rc = pfstat_node->append_child( fun_node ).
      ENDLOOP.

      LOOP AT imen INTO xmen.
        men_node = xmldoc->create_element( 'pfstatus_men' ).
        setattributesfromstructure(
                 node = men_node
                 structure =  xmen ).
        rc = pfstat_node->append_child( men_node ).
      ENDLOOP.

      LOOP AT imtx INTO xmtx.
        mtx_node = xmldoc->create_element( 'pfstatus_mtx' ).
        setattributesfromstructure(
                 node = mtx_node
                 structure =  xmtx ).
        rc = pfstat_node->append_child( mtx_node ).
      ENDLOOP.

      LOOP AT iact INTO xact.
        act_node = xmldoc->create_element( 'pfstatus_act' ).
        setattributesfromstructure(
                 node = act_node
                 structure =  xact ).
        rc = pfstat_node->append_child( act_node ).
      ENDLOOP.

      LOOP AT ibut INTO xbut.
        but_node = xmldoc->create_element( 'pfstatus_but' ).
        setattributesfromstructure(
                 node = but_node
                 structure =  xbut ).
        rc = pfstat_node->append_child( but_node ).
      ENDLOOP.

      LOOP AT ipfk INTO xpfk.
        pfk_node = xmldoc->create_element( 'pfstatus_pfk' ).
        setattributesfromstructure(
                 node = pfk_node
                 structure =  xpfk ).
        rc = pfstat_node->append_child( pfk_node ).
      ENDLOOP.

      LOOP AT iset INTO xset.
        set_node = xmldoc->create_element( 'pfstatus_set' ).
        setattributesfromstructure(
                 node = set_node
                 structure =  xset ).
        rc = pfstat_node->append_child( set_node ).
      ENDLOOP.

      LOOP AT idoc INTO xdoc.
        doc_node = xmldoc->create_element( 'pfstatus_doc' ).
        setattributesfromstructure(
                 node = doc_node
                 structure =  xdoc ).
        rc = pfstat_node->append_child( doc_node ).
      ENDLOOP.


      LOOP AT ibiv INTO xbiv.
        biv_node = xmldoc->create_element( 'pfstatus_biv' ).
        setattributesfromstructure(
                 node = biv_node
                 structure =  xbiv ).
        rc = pfstat_node->append_child( biv_node ).
      ENDLOOP.

    ENDIF.


* It itit is filled, assume one or more titles
    IF itit[] IS NOT INITIAL.

      LOOP AT itit INTO xtit.
        tit_node = xmldoc->create_element( 'pfstatus_tit' ).
        setattributesfromstructure(
                 node = tit_node
                 structure =  xtit ).
        rc = pfstat_node->append_child( tit_node ).
      ENDLOOP.

    ENDIF.

  ENDMETHOD.


METHOD GET_TEXTPOOL.
*/---------------------------------------------------------------------\
*|   This file is part of SAPlink.                                     |
*|                                                                     |
*|   SAPlink is free software; you can redistribute it and/or modify   |
*|   it under the terms of the GNU General Public License as published |
*|   by the Free Software Foundation; either version 2 of the License, |
*|   or (at your option) any later version.                            |
*|                                                                     |
*|   SAPlink is distributed in the hope that it will be useful,        |
*|   but WITHOUT ANY WARRANTY; without even the implied warranty of    |
*|   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     |
*|   GNU General Public License for more details.                      |
*|                                                                     |
*|   You should have received a copy of the GNU General Public License |
*|   along with SAPlink; if not, write to the                          |
*|   Free Software Foundation, Inc.,                                   |
*|   51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA          |
*\---------------------------------------------------------------------/

    DATA atext TYPE REF TO if_ixml_element.
    DATA textpooltable TYPE STANDARD TABLE OF textpool.
    DATA textpoolrow TYPE textpool.
    DATA languagelist TYPE instlang.
    DATA alanguage TYPE spras.
    DATA _objname(30) TYPE c.
    DATA rc TYPE i.
    DATA stemp TYPE string.
    DATA languagenode TYPE REF TO if_ixml_element.

    _objname = objname.


    textnode = xmldoc->create_element( 'textPool' ).

    CALL FUNCTION 'RS_TEXTLOG_GET_PARAMETERS'
      CHANGING
        installed_languages = languagelist.

    LOOP AT languagelist INTO alanguage.
      READ TEXTPOOL _objname INTO textpooltable LANGUAGE alanguage.
      IF sy-subrc = 0.
        languagenode = xmldoc->create_element( 'language' ).
        stemp = alanguage.
        rc = languagenode->set_attribute( name = 'SPRAS' value = stemp ).
        LOOP AT textpooltable INTO textpoolrow.
          atext = xmldoc->create_element( 'textElement' ).
          setattributesfromstructure( node = atext structure =
          textpoolrow ).
          rc = languagenode->append_child( atext ).
        ENDLOOP.
        rc = textnode->append_child( languagenode ).
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


METHOD transport_copy.

*  CALL FUNCTION 'RS_CORR_INSERT'
*    EXPORTING
*      author              = author
*      global_lock         = 'X'
*      object              = objname
*      object_class        = 'ABAP'
*      devclass            = devclass
**     KORRNUM             = CORRNUMBER_LOCAL
*      master_language     = sy-langu
**     PROGRAM             = PROGRAM_LOCAL
*      mode                = 'INSERT'
**       IMPORTING
**     AUTHOR              = UNAME
**     KORRNUM             = CORRNUMBER_LOCAL
**     DEVCLASS            = DEVCLASS_LOCAL
*    EXCEPTIONS
*      cancelled           = 1
*      permission_failure  = 2
*      unknown_objectclass = 3.
*
*  IF sy-subrc <> 0.
*    CASE sy-subrc.
*      WHEN 2.
*        RAISE EXCEPTION TYPE ybcx_saplink
*          EXPORTING
*            textid = ybcx_saplink=>not_authorized.
*      WHEN OTHERS.
*        RAISE EXCEPTION TYPE ybcx_saplink
*          EXPORTING
*            textid = ybcx_saplink=>system_error.
*    ENDCASE.
*  ENDIF.

ENDMETHOD.
ENDCLASS.
