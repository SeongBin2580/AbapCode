*----------------------------------------------------------------------*
*       CLASS lc_Zsaplink_Program_Test DEFINITION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lc_saplink_program_test DEFINITION FOR TESTING
  " DURATION SHORT
  " RISK LEVEL HARMLESS
  "#AU DURATION MEDIUM
  "#AU RISK_LEVEL HARMLESS
.
*?Ï»¿<ASX:ABAP XMLNS:ASX="HTTP://WWW.SAP.COM/ABAPXML" VERSION="1.0">
*?<ASX:VALUES>
*?<TESTCLASS_OPTIONS>
*?<TEST_CLASS>LC_ZSAPLINK_PROGRAM_TEST
*?</TEST_CLASS>
*?<TEST_MEMBER>F_CUT
*?</TEST_MEMBER>
*?<OBJECT_UNDER_TEST>ZSAPLINK_PROGRAM
*?</OBJECT_UNDER_TEST>
*?<OBJECT_IS_LOCAL/>
*?<GENERATE_FIXTURE/>
*?<GENERATE_CLASS_FIXTURE/>
*?<GENERATE_INVOCATION/>
*?<GENERATE_ASSERT_EQUAL/>
*?</TESTCLASS_OPTIONS>
*?</ASX:VALUES>
*?</ASX:ABAP>
  PRIVATE SECTION.
* ================
    DATA:
      f_cut TYPE REF TO ybcl_saplink_program.  "CLASS UNDER TEST

    METHODS: createstringfromobject FOR TESTING
      RAISING
        ybcx_saplink .

ENDCLASS.       "LC_SAPLINK_PROGRAM_TEST


*----------------------------------------------------------------------*
*       CLASS LC_SAPLINK_PROGRAM_TEST IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lc_saplink_program_test IMPLEMENTATION.
* ==============================================

  METHOD createstringfromobject.
    CONSTANTS: object_name TYPE string VALUE 'SFLIGHT_DATA_GEN'.
    DATA: source_string TYPE string.

    CREATE OBJECT f_cut
      EXPORTING
        name = object_name.

    source_string = f_cut->createstringfromobject( ).
    cl_aunit_assert=>assert_not_initial(
        act = source_string               " Actual Data Object
        msg = 'No source string found'    " Message in Case of Error
    ).
  ENDMETHOD.       "createstringfromobject




ENDCLASS.       "LC_SAPLINK_PROGRAM_TEST
