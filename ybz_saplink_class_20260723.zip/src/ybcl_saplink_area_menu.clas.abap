class YBCL_SAPLINK_AREA_MENU definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.
ENDCLASS.



CLASS YBCL_SAPLINK_AREA_MENU IMPLEMENTATION.


METHOD checkexists.

    DATA: lv_tree_id    TYPE hier_treeg,
          ls_bmenu_info TYPE bmenu_info.

    lv_tree_id = objname.

    SELECT SINGLE *
      FROM bmenu_info
      INTO ls_bmenu_info
     WHERE id = lv_tree_id
       AND spras   = sy-langu.
    IF sy-subrc = 0 .
      exists = 'X'.
    ENDIF.

  ENDMETHOD.


METHOD createixmldocfromobject.

    DATA: gotstate      TYPE ddgotstate,
          lv_tree_id    TYPE hier_treeg,
          ls_tmenu_root TYPE bmenu_info.

*xml nodes
    DATA: lo_rootnode  TYPE REF TO if_ixml_element,
          lo_node_node TYPE REF TO if_ixml_element,
          lo_text_node TYPE REF TO if_ixml_element,
          lo_ref_node  TYPE REF TO if_ixml_element,
          lo_parm_node TYPE REF TO if_ixml_element,
          lv_rc        TYPE sysubrc.

    lv_tree_id = objname.
    SELECT SINGLE *
      FROM bmenu_info
      INTO ls_tmenu_root
     WHERE id = lv_tree_id
       AND spras   = sy-langu.
    IF sy-subrc <> 0 .
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

* Create parent node
    DATA _objtype TYPE string.
    _objtype = getobjecttype( ).
    lo_rootnode = xmldoc->create_element( _objtype ).
    setattributesfromstructure( node = lo_rootnode structure = ls_tmenu_root ).

    " create sub node
    DATA: lv_id      TYPE ttree-id,
          lv_message TYPE hier_mess,
          ls_node    TYPE hier_iface,
          lt_nodes   TYPE TABLE OF hier_iface,
          ls_ref     TYPE hier_ref,
          lt_refs    TYPE TABLE OF hier_ref,
          ls_parm    TYPE streeprop,
          lt_parms   TYPE TABLE OF streeprop,
          ls_text    TYPE hier_texts,
          lt_texts   TYPE TABLE OF hier_texts.

    lv_id = objname.
    CALL FUNCTION 'STREE_HIERARCHY_READ'
      EXPORTING
        structure_id       = lv_id
        read_also_texts    = 'X'
        language           = sy-langu
      IMPORTING
        message            = lv_message
      TABLES
        list_of_nodes      = lt_nodes
        list_of_references = lt_refs
        list_of_texts      = lt_texts
        user_parameters    = lt_parms.
    IF sy-subrc <> 0 OR lt_nodes[] IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

    " Nodes
    LOOP AT lt_nodes INTO ls_node.
      lo_node_node = xmldoc->create_element( 'nodes' ).
      setattributesfromstructure( node = lo_node_node structure = ls_node ).
      lv_rc = lo_rootnode->append_child( lo_node_node ).
    ENDLOOP.

    " References
    LOOP AT lt_refs INTO ls_ref.
      lo_ref_node = xmldoc->create_element( 'references' ).
      setattributesfromstructure( node = lo_ref_node structure = ls_ref ).
      lv_rc = lo_rootnode->append_child( lo_ref_node ).
    ENDLOOP.

    " Parameters
    LOOP AT lt_parms INTO ls_parm.
      lo_parm_node = xmldoc->create_element( 'parameters' ).
      setattributesfromstructure( node = lo_parm_node structure = ls_parm ).
      lv_rc = lo_rootnode->append_child( lo_parm_node ).
    ENDLOOP.

    " texts
    LOOP AT lt_texts INTO ls_text.
      lo_text_node = xmldoc->create_element( 'texts' ).
      setattributesfromstructure( node = lo_text_node structure = ls_text ).
      lv_rc = lo_rootnode->append_child( lo_text_node ).
    ENDLOOP.
*\--------------------------------------------------------------------/
    lv_rc = xmldoc->append_child( lo_rootnode ).
    ixmldocument = xmldoc.

  ENDMETHOD.


METHOD createobjectfromixmldoc.

  DATA: gotstate TYPE ddgotstate,
        ls_tpara TYPE tparat.

*xml nodes
  DATA: lo_rootnode   TYPE REF TO if_ixml_element,
        lo_node_node  TYPE REF TO if_ixml_element,
        lo_text_node  TYPE REF TO if_ixml_element,
        lo_ref_node   TYPE REF TO if_ixml_element,
        lo_parm_node  TYPE REF TO if_ixml_element,
        lo_node       TYPE REF TO if_ixml_element,
        lo_filter     TYPE REF TO if_ixml_node_filter,
        lo_iterator   TYPE REF TO if_ixml_node_iterator,
        ls_tmenu_root TYPE bmenu_info,
        lv_rc         TYPE sysubrc.

  DATA: _devclass   TYPE devclass,
        checkexists TYPE flag,
        _objtype    TYPE string.

  _devclass = devclass.
  _objtype  = getobjecttype( ).

  xmldoc = ixmldocument.
  lo_rootnode = xmldoc->find_from_name( _objtype ).

  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = lo_rootnode
    CHANGING
      structure = ls_tmenu_root.

  ls_tmenu_root-spras = sy-langu.

  objname = ls_tmenu_root-id.

  checkexists = checkexists( ).
  IF checkexists IS NOT INITIAL.
    IF overwrite IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>existing.
    ELSE.
*     delete object for new install
      deleteobject( ).
    ENDIF.
  ENDIF.

  DATA: ls_node  TYPE hier_iface,
        lt_nodes TYPE TABLE OF hier_iface,
        ls_ref   TYPE hier_ref,
        lt_refs  TYPE TABLE OF hier_ref,
        ls_parm  TYPE streeprop,
        lt_parms TYPE TABLE OF streeprop,
        ls_text  TYPE hier_texts,
        lt_texts TYPE TABLE OF hier_texts.


* retrieve Domain details
  FREE: lo_filter, lo_iterator, lo_node.
  lo_filter = xmldoc->create_filter_name( 'nodes' ).
  lo_iterator = xmldoc->create_iterator_filtered( lo_filter ).
  lo_node ?= lo_iterator->get_next( ).

  WHILE lo_node IS NOT INITIAL.
    CLEAR ls_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = lo_node
      CHANGING
        structure = ls_node.
    APPEND ls_node TO lt_nodes.
    lo_node ?= lo_iterator->get_next( ).
  ENDWHILE.

  FREE: lo_filter, lo_iterator, lo_node.
  lo_filter = xmldoc->create_filter_name( 'references' ).
  lo_iterator = xmldoc->create_iterator_filtered( lo_filter ).
  lo_node ?= lo_iterator->get_next( ).

  WHILE lo_node IS NOT INITIAL.
    CLEAR ls_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = lo_node
      CHANGING
        structure = ls_ref.
    APPEND ls_ref TO lt_refs.
    lo_node ?= lo_iterator->get_next( ).
  ENDWHILE.

  FREE: lo_filter, lo_iterator, lo_node.
  lo_filter = xmldoc->create_filter_name( 'parameters' ).
  lo_iterator = xmldoc->create_iterator_filtered( lo_filter ).
  lo_node ?= lo_iterator->get_next( ).

  WHILE lo_node IS NOT INITIAL.
    CLEAR ls_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = lo_node
      CHANGING
        structure = ls_parm.
    APPEND ls_parm TO lt_parms.
    lo_node ?= lo_iterator->get_next( ).
  ENDWHILE.

  FREE: lo_filter, lo_iterator, lo_node.
  lo_filter = xmldoc->create_filter_name( 'texts' ).
  lo_iterator = xmldoc->create_iterator_filtered( lo_filter ).
  lo_node ?= lo_iterator->get_next( ).

  WHILE lo_node IS NOT INITIAL.
    CLEAR ls_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = lo_node
      CHANGING
        structure = ls_text.
    ls_text-spras = sy-langu.
    APPEND ls_text TO lt_texts.
    lo_node ?= lo_iterator->get_next( ).
  ENDWHILE.

  DATA : l_pgmid      TYPE tadir-pgmid,
         l_object     TYPE tadir-object,
         l_obj_name   TYPE tadir-obj_name,
         l_dd_objname TYPE ddobjname,
         l_srcsystem  TYPE tadir-srcsystem,
         l_author     TYPE tadir-author,
         l_devclass   TYPE tadir-devclass,
         l_masterlang TYPE tadir-masterlang.


  l_pgmid      = 'R3TR'.
  l_object     = _objtype.
  l_obj_name   = objname.
  l_dd_objname = objname.
  l_srcsystem  = sy-sysid.
  l_author     = sy-uname.
  l_devclass   = _devclass.
  l_masterlang = sy-langu.

  DATA: itadir TYPE tadir.
  itadir-pgmid      = l_pgmid.
  itadir-object     = l_object.
  itadir-obj_name   = l_obj_name.
  itadir-srcsystem  = l_srcsystem.
  itadir-author     = l_author.
  itadir-devclass   = l_devclass.
  itadir-masterlang = l_masterlang.
  MODIFY tadir FROM itadir.

*    CALL FUNCTION 'TR_TADIR_INTERFACE'
*      EXPORTING
*        wi_test_modus                  = ' '
*        wi_delete_tadir_entry          = 'X'
*        wi_tadir_pgmid                 = l_pgmid
*        wi_tadir_object                = l_object
*        wi_tadir_obj_name              = l_obj_name
*        wi_tadir_srcsystem             = l_srcsystem
*        wi_tadir_author                = l_author
*        wi_tadir_devclass              = l_devclass
*        wi_tadir_masterlang            = l_masterlang
*        iv_set_edtflag                 = ''
*      EXCEPTIONS
*        tadir_entry_not_existing       = 1
*        tadir_entry_ill_type           = 2
*        no_systemname                  = 3
*        no_systemtype                  = 4
*        original_system_conflict       = 5
*        object_reserved_for_devclass   = 6
*        object_exists_global           = 7
*        object_exists_local            = 8
*        object_is_distributed          = 9
*        obj_specification_not_unique   = 10
*        no_authorization_to_delete     = 11
*        devclass_not_existing          = 12
*        simultanious_set_remove_repair = 13
*        order_missing                  = 14
*        no_modification_of_head_syst   = 15
*        pgmid_object_not_allowed       = 16
*        masterlanguage_not_specified   = 17
*        devclass_not_specified         = 18
*        specify_owner_unique           = 19
*        loc_priv_objs_no_repair        = 20
*        gtadir_not_reached             = 21
*        object_locked_for_order        = 22
*        change_of_class_not_allowed    = 23
*        no_change_from_sap_to_tmp      = 24
*        OTHERS                         = 25.
*    IF sy-subrc NE 0.
*      CASE sy-subrc.
*        WHEN 1 OR 9 OR 7 OR 8. "OK! - Doesn't exist yet
*        WHEN 11 OR 23 OR 24.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>not_authorized.
*        WHEN 22.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>locked.
*        WHEN OTHERS.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>system_error.
*      ENDCASE.
*    ENDIF.

  DATA: ls_guid    TYPE sys_uid,
        lv_message TYPE hier_mess.
  DATA: lv_new_id      TYPE ttree-id,
        lv_top_node    TYPE ttree-node_id,
        ls_description TYPE ttreet,
        lt_description TYPE TABLE OF ttreet.

  lv_new_id = objname.
  CONCATENATE lv_new_id '_T' INTO lv_top_node.

  LOOP AT lt_nodes INTO ls_node.

    IF ls_node-node_level EQ 1 AND ls_tmenu_root-id NE space.
      ls_guid-id = lv_top_node.
    ELSE.
      CALL FUNCTION 'STREE_GET_UNIQUE_ID'
        IMPORTING
          unique_id = ls_guid
          message   = lv_message.
    ENDIF.

    ls_ref-node_id = ls_guid-id.
    MODIFY lt_refs FROM ls_ref
           TRANSPORTING node_id
           WHERE node_id EQ ls_node-node_id.
*
    ls_text-node_id = ls_guid-id.
    MODIFY lt_texts FROM ls_text
           TRANSPORTING node_id
           WHERE node_id EQ ls_node-node_id.

    ls_node-fuser = sy-uname.
    ls_node-fdate = sy-datum.
    ls_node-ftime = sy-uzeit.
    ls_node-frelease = sy-saprl.

    CLEAR: ls_node-copy_node,  ls_node-copy_tree, ls_node-copnodfrst,
           ls_node-coptrefrst, ls_node-luser,     ls_node-ldate, ls_node-ltime,
           ls_node-lrelease.

    ls_node-node_id   = ls_guid-id.
    MODIFY lt_nodes FROM ls_node.

  ENDLOOP.


*    ls_description-spras     = ls_tmenu_root-spras.
  ls_description-spras     = sy-langu.
  ls_description-id        = ls_tmenu_root-id.
  ls_description-text      = ls_tmenu_root-text.
  ls_description-text_cap  = ls_tmenu_root-text.
  TRANSLATE  ls_description-text_cap TO UPPER CASE.
  APPEND ls_description TO lt_description.


  CALL FUNCTION 'STREE_HIERARCHY_SAVE'
    EXPORTING
      structure_id             = lv_new_id
      structure_type           = 'BMENU'
      structure_top_node       = lv_top_node
      structure_extension      = ' '
      structure_description    = ls_tmenu_root-text
      structure_external_key   = space
      language                 = ls_tmenu_root-spras
      structure_masterlanguage = sy-langu
      structure_responsible    = sy-uname
      structure_buffermode     = '1'
      no_transport_check       = space
      transport_order          = space
      development_class        = _devclass
    IMPORTING
      message                  = lv_message
      new_structure_id         = lv_new_id
*     NEW_STRUCTURE_HEADER     =
*     NEW_STRUCTURE_TADIR      =
    TABLES
      list_of_nodes            = lt_nodes
      list_of_references       = lt_refs
      list_of_texts            = lt_texts
      structure_descriptions   = lt_description.
*    IF message-msgid NE space AND message-msgty NE message_success.
*      EXIT.
*    ENDIF.

  name = objname.

ENDMETHOD.


METHOD deleteobject.

    DATA: lv_deletion_canc,
          lv_message         TYPE hier_mess,
          lv_korr            TYPE trkorr,
          lv_id	             TYPE hier_treeg,
          ls_tree_list       TYPE ttree,
          lt_user_parameters TYPE TABLE OF streeprop.

    ls_tree_list-id = objname.

    SELECT SINGLE * FROM ttree INTO ls_tree_list WHERE id = ls_tree_list-id.
    CHECK sy-subrc = 0.

*   delete structure itself
    CALL FUNCTION 'STREE_EXTERNAL_DELETE'
      EXPORTING
        structure_id          = ls_tree_list-id
        no_confirmation_popup = 'X' " no_confirmation
        transport_order       = lv_korr
      IMPORTING
        message               = lv_message
        deletion_canceled     = lv_deletion_canc
      TABLES
        user_parameters       = lt_user_parameters.

  ENDMETHOD.


METHOD getobjecttype.

    objecttype = 'SHI3'. "  일반구조저장: 구조정의(Area Menu)

  ENDMETHOD.
ENDCLASS.
