class YBCL_SAPLINK_MEMORY_ID definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.
ENDCLASS.



CLASS YBCL_SAPLINK_MEMORY_ID IMPLEMENTATION.


METHOD checkexists.

    DATA: lv_name  TYPE memoryid,
          ls_tpara TYPE tpara.

    lv_name = objname.
    SELECT SINGLE paramid
      FROM tpara
      INTO CORRESPONDING FIELDS OF ls_tpara
     WHERE paramid = lv_name.
    IF sy-subrc = 0 AND ls_tpara-paramid IS NOT INITIAL.
      exists = 'X'.
    ENDIF.

  ENDMETHOD.


METHOD createixmldocfromobject.

    DATA: gotstate    TYPE ddgotstate,
          lv_memoryid TYPE memoryid,
          ls_tpara    TYPE tparat.

*xml nodes
    DATA rootnode   TYPE REF TO if_ixml_element.
    DATA tpara_node TYPE REF TO if_ixml_element.
    DATA rc         TYPE sysubrc.

    lv_memoryid = objname.

    SELECT SINGLE *
      FROM tparat
      INTO ls_tpara
     WHERE paramid = lv_memoryid.
    IF sy-subrc <> 0 .
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

* Create parent node
    DATA _objtype TYPE string.
    _objtype = getobjecttype( ).
    rootnode = xmldoc->create_element( _objtype ).
    setattributesfromstructure( node = rootnode structure = ls_tpara ).

*\--------------------------------------------------------------------/
    rc = xmldoc->append_child( rootnode ).
    ixmldocument = xmldoc.

  ENDMETHOD.


METHOD createobjectfromixmldoc.

  DATA: gotstate TYPE ddgotstate,
        ls_tpara TYPE tparat.

*xml nodes
  DATA rootnode    TYPE REF TO if_ixml_element.
  DATA tpara_node  TYPE REF TO if_ixml_element.
  DATA node        TYPE REF TO if_ixml_element.
  DATA filter      TYPE REF TO if_ixml_node_filter.
  DATA iterator    TYPE REF TO if_ixml_node_iterator.
  DATA rc          TYPE sysubrc.

  DATA _devclass   TYPE devclass.
  DATA checkexists TYPE flag.
  DATA _objtype    TYPE string.

  _devclass = devclass.
  _objtype  = getobjecttype( ).

  xmldoc = ixmldocument.
  rootnode = xmldoc->find_from_name( _objtype ).

  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = rootnode
    CHANGING
      structure = ls_tpara.

  ls_tpara-sprache = sy-langu.
  objname = ls_tpara-paramid.

  checkexists = checkexists( ).
  IF checkexists IS NOT INITIAL.
    IF overwrite IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>existing.
    ELSE.
*     delete object for new install
      deleteobject( ).
    ENDIF.
  ENDIF.

  DATA : l_pgmid      TYPE tadir-pgmid,
         l_object     TYPE tadir-object,
         l_obj_name   TYPE tadir-obj_name,
         l_dd_objname TYPE ddobjname,
         l_srcsystem  TYPE tadir-srcsystem,
         l_author     TYPE tadir-author,
         l_devclass   TYPE tadir-devclass,
         l_masterlang TYPE tadir-masterlang.


  l_pgmid      = 'R3TR'.
  l_object     = _objtype.
  l_obj_name   = objname.
  l_dd_objname = objname.
  l_srcsystem  = sy-sysid.
  l_author     = sy-uname.
  l_devclass   = _devclass.
  l_masterlang = sy-langu.

  DATA: itadir TYPE tadir.
  itadir-pgmid      = l_pgmid.
  itadir-object     = l_object.
  itadir-obj_name   = l_obj_name.
  itadir-srcsystem  = l_srcsystem.
  itadir-author     = l_author.
  itadir-devclass   = l_devclass.
  itadir-masterlang = l_masterlang.
  MODIFY tadir FROM itadir.

*    CALL FUNCTION 'TR_TADIR_INTERFACE'
*      EXPORTING
*        wi_test_modus                  = ' '
*        wi_delete_tadir_entry          = 'X'
*        wi_tadir_pgmid                 = l_pgmid
*        wi_tadir_object                = l_object
*        wi_tadir_obj_name              = l_obj_name
*        wi_tadir_srcsystem             = l_srcsystem
*        wi_tadir_author                = l_author
*        wi_tadir_devclass              = l_devclass
*        wi_tadir_masterlang            = l_masterlang
*        iv_set_edtflag                 = ''
*      EXCEPTIONS
*        tadir_entry_not_existing       = 1
*        tadir_entry_ill_type           = 2
*        no_systemname                  = 3
*        no_systemtype                  = 4
*        original_system_conflict       = 5
*        object_reserved_for_devclass   = 6
*        object_exists_global           = 7
*        object_exists_local            = 8
*        object_is_distributed          = 9
*        obj_specification_not_unique   = 10
*        no_authorization_to_delete     = 11
*        devclass_not_existing          = 12
*        simultanious_set_remove_repair = 13
*        order_missing                  = 14
*        no_modification_of_head_syst   = 15
*        pgmid_object_not_allowed       = 16
*        masterlanguage_not_specified   = 17
*        devclass_not_specified         = 18
*        specify_owner_unique           = 19
*        loc_priv_objs_no_repair        = 20
*        gtadir_not_reached             = 21
*        object_locked_for_order        = 22
*        change_of_class_not_allowed    = 23
*        no_change_from_sap_to_tmp      = 24
*        OTHERS                         = 25.
*    IF sy-subrc NE 0.
*      CASE sy-subrc.
*        WHEN 1 OR 9 OR 7 OR 8. "OK! - Doesn't exist yet
*        WHEN 11 OR 23 OR 24.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>not_authorized.
*        WHEN 22.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>locked.
*        WHEN OTHERS.
*          RAISE EXCEPTION TYPE ybcx_saplink
*            EXPORTING
*              textid = ybcx_saplink=>system_error.
*      ENDCASE.
*    ENDIF.

  DATA: ls_tpara_wa  TYPE tpara,
        ls_tparat_wa TYPE tparat.

  CLEAR: ls_tpara_wa, ls_tparat_wa.
  ls_tpara_wa-paramid = ls_tpara-paramid.

  ls_tparat_wa-paramid = ls_tpara-paramid.
  ls_tparat_wa-partext = ls_tpara-partext.
  ls_tparat_wa-sprache = ls_tpara-sprache.

  MODIFY tpara FROM ls_tpara_wa.
  IF sy-subrc <> 0.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>system_error.
  ENDIF.

  MODIFY tparat FROM ls_tparat_wa.
  IF sy-subrc <> 0.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>system_error.
  ENDIF.

  DATA: trobjtype  TYPE trobjtype,
        trobj_name TYPE trobj_name.
  trobjtype  = l_object.
  trobj_name = l_obj_name.
  CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
    EXPORTING
      object            = trobjtype
      obj_name          = trobj_name
    EXCEPTIONS
      wrong_object_name = 1.

  name = objname.

ENDMETHOD.


METHOD deleteobject.

  DATA: ls_tpara TYPE tpara.
  ls_tpara-paramid  = objname.
  DELETE FROM tpara  WHERE paramid = ls_tpara-paramid.
  DELETE FROM tparat WHERE paramid = ls_tpara-paramid.
  IF sy-subrc = 0.
    CALL FUNCTION 'RS_TREE_OBJECT_PLACEMENT'
      EXPORTING
        object    = ls_tpara-paramid
        operation = 'DELETE'
        type      = 'CR'.
  ENDIF.

ENDMETHOD.


METHOD getobjecttype.

    objecttype = 'PARA'.  " Memory ID(SPA/GPA Parameters)

  ENDMETHOD.
ENDCLASS.
