class YBCL_SAPLINK_CDSVIEW definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.
ENDCLASS.



CLASS YBCL_SAPLINK_CDSVIEW IMPLEMENTATION.


METHOD checkexists.

    DATA: ls_cdssqlview TYPE cds_sql_view.

    CLEAR: exists.

    ls_cdssqlview-ddlsourcename = objname.
    SELECT SINGLE ddlsourcename
      FROM cds_sql_view
      INTO CORRESPONDING FIELDS OF @ls_cdssqlview
     WHERE ddlsourcename = @ls_cdssqlview-ddlsourcename.
    IF sy-subrc = 0 AND ls_cdssqlview-ddlsourcename IS NOT INITIAL.
      exists = 'X'.
    ENDIF.


  ENDMETHOD.


METHOD createixmldocfromobject.

    DATA rootnode TYPE REF TO if_ixml_element.
    DATA sourcenode TYPE REF TO if_ixml_element.
    DATA dd09v_node TYPE REF TO if_ixml_element.
    DATA dd12v_node TYPE REF TO if_ixml_element.
    DATA dd17v_node TYPE REF TO if_ixml_element.
    DATA rc TYPE sysubrc.
    DATA lv_source TYPE string.
    DATA _objtype TYPE string.

    _objtype = getobjecttype( ).
    objname = objname.

    TRY.
        cl_dd_ddl_handler_factory=>create( )->read(
              EXPORTING
                name         = CONV ddlname( to_upper( objname ) )
              IMPORTING
                ddddlsrcv_wa = DATA(ddddlsrcv_wa)  " source 및 정보
                ddddlsrc09bv_wa = DATA(ddddlsrc09bv_wa)
                ddddlsrc12bv_tab = DATA(ddddlsrc12bv_tab)
                ddddlsrc17bv_tab = DATA(ddddlsrc17bv_tab)
              ).
      CATCH cx_dd_ddl_read INTO DATA(exc).
*      cl_demo_output=>display( exc->get_text( ) ).

    ENDTRY.

    lv_source = ddddlsrcv_wa-source.
    CLEAR: ddddlsrcv_wa-source.

*     XML  생성
    rootnode = xmldoc->create_element( _objtype ).
    setattributesfromstructure( node = rootnode structure = ddddlsrcv_wa ).

    sourcenode = xmldoc->create_element( 'source' ).
    rc = sourcenode->if_ixml_node~set_value( lv_source ).
    rc = rootnode->append_child( sourcenode ).

    dd09v_node = xmldoc->create_element( 'dd09v' ).
    setattributesfromstructure( node = dd09v_node structure = ddddlsrc09bv_wa ).
    rc = rootnode->append_child( dd09v_node ).

    LOOP AT ddddlsrc12bv_tab INTO DATA(ddddlsrc12bv_wa).
      dd12v_node = xmldoc->create_element( 'dd12v' ).
      setattributesfromstructure( node = dd12v_node structure = ddddlsrc12bv_wa ).
      rc = rootnode->append_child( dd12v_node ).
    ENDLOOP.

    LOOP AT ddddlsrc17bv_tab INTO DATA(ddddlsrc17bv_wa).
      dd17v_node = xmldoc->create_element( 'dd17v' ).
      setattributesfromstructure( node = dd17v_node structure = ddddlsrc17bv_wa ).
      rc = rootnode->append_child( dd17v_node ).
    ENDLOOP.

*\--------------------------------------------------------------------/
    rc = xmldoc->append_child( rootnode ).
    ixmldocument = xmldoc.

  ENDMETHOD.


METHOD createobjectfromixmldoc.

  DATA: gotstate  TYPE ddgotstate,
        ddscrv_wa TYPE ddddlsrcv,
        dd09v_wa  TYPE ddddlsrc09bv,
        dd12v_tab TYPE ddddlsrc12bvtab,
        dd12v_wa  TYPE ddddlsrc12bv,
        dd17v_tab TYPE ddddlsrc17bvtab,
        dd17v_wa  TYPE ddddlsrc17bv.

*xml nodes
  DATA: rootnode     TYPE REF TO if_ixml_element,
        sourcenode   TYPE REF TO if_ixml_element,
        dd09v_node   TYPE REF TO if_ixml_element,
        dd12v_node   TYPE REF TO if_ixml_element,
        dd17v_node   TYPE REF TO if_ixml_element,
        node         TYPE REF TO if_ixml_element,
        filter       TYPE REF TO if_ixml_node_filter,
        iterator     TYPE REF TO if_ixml_node_iterator,
        rc           TYPE sysubrc,
        _devclass    TYPE devclass,
        checkexists  TYPE flag,
        _objtype     TYPE string,
        lv_source    TYPE string,
        lv_save_date TYPE as4date,
        lv_save_time TYPE as4time.

  _devclass = devclass.
  _objtype = getobjecttype( ).

  xmldoc = ixmldocument.
  rootnode = xmldoc->find_from_name( _objtype ).

  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = rootnode
    CHANGING
      structure = ddscrv_wa.

  ddscrv_wa-ddlanguage = sy-langu.

  objname = ddscrv_wa-ddlname.
  checkexists = checkexists( ).
  IF checkexists IS NOT INITIAL.
    IF overwrite IS INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>existing.
    ELSE.
*     delete object for new install
      deleteobject( ).
    ENDIF.
  ENDIF.

  sourcenode = rootnode->find_from_name( 'source' ).
  lv_source = sourcenode->get_value( ).

  " dd09v
  dd09v_node = xmldoc->find_from_name( 'dd09v' ).
  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = dd09v_node
    CHANGING
      structure = dd09v_wa.

  " dd12v_tab
  FREE: filter, iterator, node.
  filter = xmldoc->create_filter_name( 'dd12v' ).
  iterator = xmldoc->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CLEAR dd12v_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = dd12v_wa.
    dd12v_wa-ddlanguage = sy-langu.
    APPEND dd12v_wa TO dd12v_tab.
    node ?= iterator->get_next( ).
  ENDWHILE.

  " dd17v_tab
  FREE: filter, iterator, node.
  filter = xmldoc->create_filter_name( 'dd17v' ).
  iterator = xmldoc->create_iterator_filtered( filter ).
  node ?= iterator->get_next( ).
  WHILE node IS NOT INITIAL.
    CLEAR dd17v_node.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = node
      CHANGING
        structure = dd17v_wa.
    APPEND dd17v_wa TO dd17v_tab.
    node ?= iterator->get_next( ).
  ENDWHILE.

  " dic 정보
  TRY.
      rc = cl_dd_ddl_handler_factory=>create( )->write_tadir(
            EXPORTING
              objectname  =  ddscrv_wa-ddlname
              devclass    = _devclass
              prid        = '-1' ).

    CATCH cx_dd_ddl_save INTO DATA(exc).
*        cl_demo_output=>display( exc->get_text( ) ).
  ENDTRY.

  " 저장
  ddscrv_wa-source = lv_source.
  TRY.
      cl_dd_ddl_handler_factory=>create( )->save(
            EXPORTING
              name  =  ddscrv_wa-ddlname
              put_state    = 'N'
              ddddlsrcv_wa = ddscrv_wa
              ddddlsrc09bv_wa = dd09v_wa
              ddddlsrc12bv_tab = dd12v_tab
              ddddlsrc17bv_tab = dd17v_tab
            IMPORTING
              save_date = lv_save_date
              save_time = lv_save_time
           ).

*        COMMIT WORK AND WAIT.
    CATCH cx_dd_ddl_save INTO exc.
*        cl_demo_output=>display( exc->get_text( ) ).
  ENDTRY.

* successful install
  DATA: trobjtype  TYPE trobjtype,
        trobj_name TYPE trobj_name.
  trobjtype  = _objtype.
  trobj_name = objname.
  CALL FUNCTION 'RS_INSERT_INTO_WORKING_AREA'
    EXPORTING
      object            = trobjtype
      obj_name          = trobj_name
    EXCEPTIONS
      wrong_object_name = 1.

  name = objname.

ENDMETHOD.


METHOD deleteobject.

    TRY.
        cl_dd_ddl_handler_factory=>create( )->delete( name = CONV ddlname( to_upper( objname ) ) ).
      CATCH cx_dd_ddl_delete INTO DATA(exc).
*        cl_demo_output=>display( exc->get_text( ) ).
    ENDTRY.

  ENDMETHOD.


METHOD getobjecttype.

    objecttype = 'DDLS'. " DDL Source

  ENDMETHOD.
ENDCLASS.
