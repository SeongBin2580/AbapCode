class YBCL_SAPLINK definition
  public
  abstract
  create public .

public section.

  types:
    BEGIN OF  gts_version_info,
*     Change this if import or export is incompatible to older major versions or if enhancements are so important to force the new version of the plugin
*     Please comment changes in major version in class documentation
        ybcl_saplink_plugin_major_ver TYPE i,
*     Change this if bugfixes are being done but the basic structure and im- and exportbehaviour don't change.  Reset to 0 when incrementing major version
*     Please comment changes in minor version in class documentation
        ybcl_saplink_plugin_minor_ver TYPE i,
*     Change this if cosmetic changes are being done or if internal handling changed but no change to import- or exportbehaviour
*    ( i.e. speeding up the plugin will fall into this ).  Reset to 0 when incrementeing major or minor version
        ybcl_saplink_plugin_build_ver TYPE i,
*
        ybcl_saplink_plugin_info1         TYPE string,  " Plugin info - part 1    -  See demoimplementation how this may be used
        ybcl_saplink_plugin_info2         TYPE string,  " Plugin info - part 2
        ybcl_saplink_plugin_info3         TYPE string,  " Plugin info - part 3
        ybcl_saplink_plugin_info4         TYPE string,  " Plugin info - part 4
        ybcl_saplink_plugin_info5         TYPE string,  " Plugin info - part 5
      END OF gts_version_info .

  data NUGGET_LEVEL type INT4 read-only value 0 ##NO_TEXT.

  class-methods GETOBJECTINFOFROMIXMLDOC
    importing
      !IXMLDOCUMENT type ref to IF_IXML_DOCUMENT
    exporting
      !OBJTYPENAME type STRING
      !OBJNAME type STRING
    raising
      YBCX_SAPLINK .
  class-methods CONVERTSTRINGTOIXMLDOC
    importing
      value(XMLSTRING) type STRING
    returning
      value(IXMLDOCUMENT) type ref to IF_IXML_DOCUMENT .
  class-methods CONVERTIXMLDOCTOSTRING
    importing
      !IXMLDOCUMENT type ref to IF_IXML_DOCUMENT
    returning
      value(XMLSTRING) type STRING .
  class-methods GET_VERSION_INFO_STATIC
    importing
      !IV_CLASSNAME type CLIKE
    returning
      value(RS_VERSION_INFO) type GTS_VERSION_INFO .
  methods CREATEOBJECTFROMIXMLDOC
  abstract
    importing
      !IXMLDOCUMENT type ref to IF_IXML_DOCUMENT
      !DEVCLASS type DEVCLASS default '$TMP'
      !OVERWRITE type FLAG optional
    returning
      value(NAME) type STRING
    raising
      YBCX_SAPLINK .
  methods CREATEIXMLDOCFROMOBJECT
  abstract
    returning
      value(IXMLDOCUMENT) type ref to IF_IXML_DOCUMENT
    raising
      YBCX_SAPLINK .
  methods CREATESTRINGFROMOBJECT
    returning
      value(STRING) type STRING
    raising
      YBCX_SAPLINK .
  methods CONSTRUCTOR
    importing
      !NAME type STRING .
  methods UPLOADXML
  final
    importing
      !XMLDATA type STRING .
  class-methods GETPLUGINS
    changing
      value(OBJECTTABLE) type TABLE .
  methods CHECKEXISTS
  abstract
    returning
      value(EXISTS) type FLAG .
  methods VALUEHELP
    importing
      !I_OBJTYPE type STRING
    returning
      value(E_OBJNAME) type STRING .
  class-methods CHECKOBJECT
    importing
      !I_IXMLDOCUMENT type ref to IF_IXML_DOCUMENT
    exporting
      !E_OBJTYPE type STRING
      !E_OBJNAME type STRING
      !E_PLUGINEXISTS type FLAG
      !E_OBJECTEXISTS type FLAG
      !E_TARGETOBJECT type ref to YBCL_SAPLINK .
  methods GET_VERSION_INFO
    returning
      value(RS_VERSION_INFO) type GTS_VERSION_INFO .
protected section.

  data OBJNAME type STRING .
  data IXML type ref to IF_IXML .
  data XMLDOC type ref to IF_IXML_DOCUMENT .

  methods DELETEOBJECT
  abstract
    raising
      YBCX_SAPLINK .
  class-methods SETATTRIBUTESFROMSTRUCTURE
    importing
      !NODE type ref to IF_IXML_ELEMENT
      !STRUCTURE type DATA .
  class-methods GETSTRUCTUREFROMATTRIBUTES
    importing
      !NODE type ref to IF_IXML_ELEMENT
      !PRESERVEVERSION type FLAG optional
    changing
      !STRUCTURE type DATA .
  methods CREATEXMLSTRING
  final
    returning
      value(XML) type STRING .
  class-methods BUILDTABLEFROMSTRING
    importing
      !SOURCE type STRING
    returning
      value(SOURCETABLE) type TABLE_OF_STRINGS .
  class-methods BUILDSOURCESTRING
    importing
      !SOURCETABLE type RSWSOURCET optional
      !PAGETABLE type O2PAGELINE_TABLE optional
    returning
      value(SOURCESTRING) type STRING .
  methods GETOBJECTTYPE
  abstract
    returning
      value(OBJECTTYPE) type STRING .
  methods CREATEOTRFROMNODE
    importing
      value(NODE) type ref to IF_IXML_ELEMENT
      !DEVCLASS type DEVCLASS default '$TMP'
    exporting
      !CONCEPT type SOTR_TEXT-CONCEPT
    raising
      YBCX_SAPLINK .
  methods CREATENODEFROMOTR
    importing
      !OTRGUID type SOTR_CONC
    returning
      value(NODE) type ref to IF_IXML_ELEMENT .
private section.

  types:
    BEGIN OF t_objecttable,
        classname TYPE string,
        object    TYPE ko100-object,
        text      TYPE ko100-text,
      END OF t_objecttable .

  data STREAMFACTORY type ref to IF_IXML_STREAM_FACTORY .
  data XMLDATA type STRING .
  data:
    objecttable TYPE TABLE OF t_objecttable .
ENDCLASS.



CLASS YBCL_SAPLINK IMPLEMENTATION.


METHOD buildsourcestring.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA stemp TYPE string.
    DATA pageline TYPE o2pageline.

    IF sourcetable IS NOT INITIAL.
      LOOP AT sourcetable INTO stemp.
        CONCATENATE sourcestring stemp cl_abap_char_utilities=>newline
          INTO sourcestring.
      ENDLOOP.
    ELSEIF pagetable IS NOT INITIAL.
      LOOP AT pagetable INTO pageline.
        CONCATENATE sourcestring pageline-line
          cl_abap_char_utilities=>newline
          INTO sourcestring.
      ENDLOOP.
    ENDIF.

* remove extra newline characters for conversion comparison consistency
    SHIFT sourcestring LEFT DELETING LEADING
      cl_abap_char_utilities=>newline.
    SHIFT sourcestring RIGHT DELETING TRAILING
      cl_abap_char_utilities=>newline.
    SHIFT sourcestring LEFT DELETING LEADING space.
  ENDMETHOD.


METHOD buildtablefromstring.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    SPLIT source AT cl_abap_char_utilities=>newline
      INTO TABLE sourcetable.
  ENDMETHOD.


METHOD checkobject.

  DATA l_objtable LIKE objecttable.
  DATA l_objline  LIKE LINE OF objecttable.

  CLEAR: e_objtype, e_objname, e_pluginexists, e_objectexists.
  TRY.
      CALL METHOD ybcl_saplink=>getobjectinfofromixmldoc
        EXPORTING
          ixmldocument = i_ixmldocument
        IMPORTING
          objtypename  = e_objtype
          objname      = e_objname.
    CATCH ybcx_saplink.
  ENDTRY.

  CALL METHOD ybcl_saplink=>getplugins( CHANGING objecttable = l_objtable ).

  READ TABLE l_objtable INTO l_objline WITH KEY object = e_objtype.

  IF sy-subrc = 0.
    e_pluginexists = 'X'.
    CREATE OBJECT e_targetobject TYPE (l_objline-classname)
      EXPORTING
        name                  = e_objname.

    e_objectexists = e_targetobject->checkexists( ).
  ENDIF.

ENDMETHOD.


METHOD constructor.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/

*  data meTypeDescr type ref to CL_ABAP_TYPEDESCR.
*  clear className.
*
*  objName = name.
*  meTypeDescr = CL_ABAP_TYPEDESCR=>DESCRIBE_BY_OBJECT_REF( me ).
*  className = meTypeDescr->get_relative_name( ).

  objname = name.
  TRANSLATE objname TO UPPER CASE.

  ixml = cl_ixml=>create( ).
  xmldoc = ixml->create_document( ).
  streamfactory = ixml->create_stream_factory( ).

ENDMETHOD.


METHOD convertixmldoctostring.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA _ixml TYPE REF TO if_ixml.
    DATA _encoding   TYPE REF TO if_ixml_encoding.
    DATA _streamfactory TYPE REF TO if_ixml_stream_factory.
    DATA _outputstream TYPE REF TO if_ixml_ostream.
    DATA _renderer TYPE REF TO if_ixml_renderer.
    DATA _tempstring  TYPE string.
    DATA _tempstringx TYPE xstring.
    DATA _printxmldoc TYPE REF TO cl_xml_document.
    DATA _rc TYPE sysubrc.

    _ixml = cl_ixml=>create( ).
    _encoding = _ixml->create_encoding(
        byte_order    = if_ixml_encoding=>co_none
        character_set = 'utf-8' ).
    _streamfactory = _ixml->create_stream_factory( ).
    _outputstream = _streamfactory->create_ostream_xstring( _tempstringx ).
    _outputstream->set_encoding( encoding = _encoding ).
    _renderer = _ixml->create_renderer(
                  document = ixmldocument
                  ostream  = _outputstream
                ).
    _renderer->set_normalizing( ).
    _rc = _renderer->render( ).
    CREATE OBJECT _printxmldoc.
    _rc = _printxmldoc->parse_string( _tempstring ).

    CALL FUNCTION 'ECATT_CONV_XSTRING_TO_STRING'
      EXPORTING
        im_xstring  = _tempstringx
        im_encoding = 'UTF-8'
      IMPORTING
        ex_string   = _tempstring.

    xmlstring = _tempstring.
  ENDMETHOD.


METHOD convertstringtoixmldoc.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA ixml TYPE REF TO if_ixml.
    DATA streamfactory TYPE REF TO if_ixml_stream_factory.
    DATA istream TYPE REF TO if_ixml_istream.
    DATA ixmlparser TYPE REF TO if_ixml_parser.
    DATA xmldoc TYPE REF TO if_ixml_document.

    " Make sure to convert Windows Line Break to Unix as
    " this linebreak is used to get a correct import
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf
      IN xmlstring WITH cl_abap_char_utilities=>newline.

    ixml = cl_ixml=>create( ).
    xmldoc = ixml->create_document( ).
    streamfactory = ixml->create_stream_factory( ).
    istream = streamfactory->create_istream_string( xmlstring ).
    ixmlparser = ixml->create_parser(  stream_factory = streamfactory
                                       istream        = istream
                                       document       = xmldoc ).
    ixmlparser->parse( ).
    ixmldocument = xmldoc.
  ENDMETHOD.


METHOD createnodefromotr.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA rootnode TYPE REF TO if_ixml_element.
    DATA txtnode TYPE REF TO if_ixml_element.
    DATA rc TYPE sysubrc.

    DATA sotrheader TYPE sotr_head.
    DATA sotrtextline TYPE sotr_text.
    DATA sotrtexttable TYPE TABLE OF sotr_text.

    DATA _ixml TYPE REF TO if_ixml.
    DATA _xmldoc TYPE REF TO if_ixml_document.

    CALL FUNCTION 'SOTR_GET_CONCEPT'
      EXPORTING
        concept        = otrguid
      IMPORTING
        header         = sotrheader
      TABLES
        entries        = sotrtexttable
      EXCEPTIONS
        no_entry_found = 1
        OTHERS         = 2.
    IF sy-subrc <> 0.
      EXIT.
    ENDIF.

    sotrheader-paket = '$TMP'. "change devclass to $TMP for exports

* Create xml doc
*  _ixml = cl_ixml=>create( ).
*  _xmldoc = _ixml->create_document( ).
*  streamfactory = _ixml->create_stream_factory( ).

* Create parent node
    rootnode = xmldoc->create_element( ybcl_saplink_oo=>c_xml_key_sotr ). "OTR object type
    CLEAR sotrheader-concept.                                 "ewH:33
    setattributesfromstructure( node = rootnode structure = sotrheader ).

* Create nodes for texts
    LOOP AT sotrtexttable INTO sotrtextline.
      txtnode = xmldoc->create_element( ybcl_saplink_oo=>c_xml_key_sotrtext ).
      CLEAR: sotrtextline-concept, sotrtextline-object.       "ewH:33
      setattributesfromstructure(
        node = txtnode structure = sotrtextline ).
      rc = rootnode->append_child( txtnode ).
    ENDLOOP.

    node = rootnode.

  ENDMETHOD.


METHOD createotrfromnode.

  DATA txtnode TYPE REF TO if_ixml_element.
  DATA filter TYPE REF TO if_ixml_node_filter.
  DATA iterator TYPE REF TO if_ixml_node_iterator.

  DATA sotrheader TYPE sotr_head.
  DATA sotrtextline TYPE sotr_text.
  DATA sotrtexttable TYPE TABLE OF sotr_text.
  DATA sotrpaket TYPE sotr_pack.

* get OTR header info
  CALL METHOD getstructurefromattributes
    EXPORTING
      node      = node
    CHANGING
      structure = sotrheader.

  sotrheader-crea_lan = sy-langu.

* get OTR text info
  filter = node->create_filter_name( ybcl_saplink_oo=>c_xml_key_sotrtext ).
  iterator = node->create_iterator_filtered( filter ).
  txtnode ?= iterator->get_next( ).

  WHILE txtnode IS NOT INITIAL.
    CLEAR sotrtextline.
    CALL METHOD getstructurefromattributes
      EXPORTING
        node      = txtnode
      CHANGING
        structure = sotrtextline.
    CLEAR: sotrtextline-concept, sotrtextline-object.       "ewH:33
    sotrtextline-langu = sy-langu.
    APPEND sotrtextline TO sotrtexttable.
    txtnode ?= iterator->get_next( ).
  ENDWHILE.

* ewH:issue 33--> in 6.40 and above, you cannot pass a default concept
*  (otr) guid, so we will always create new
*  CALL FUNCTION 'SOTR_GET_CONCEPT'
*    EXPORTING
*      concept              = sotrHeader-concept
**   IMPORTING
**     HEADER               =
**   TABLES
**     ENTRIES              =
*   EXCEPTIONS
*     NO_ENTRY_FOUND       = 1
*     OTHERS               = 2
*            .
*  IF sy-subrc <> 1.
**   delete OTR if exists already
*    CALL FUNCTION 'SOTR_DELETE_CONCEPT'
*      EXPORTING
*        concept                     = sotrHeader-concept
*     EXCEPTIONS
*       NO_AUTHORIZATION            = 1
*       NO_ENTRY_FOUND              = 2. "who cares
**       CONCEPT_USED                = 3
**       NO_MASTER_LANGUAGE          = 4
**       NO_SOURCE_SYSTEM            = 5
**       NO_TADIR_ENTRY              = 6
**       ERROR_IN_CORRECTION         = 7
**       USER_CANCELLED              = 8
**       OTHERS                      = 9
**              .
*    if sy-subrc = 1.
*      raise exception type YBCX_SAPLINK
*        exporting textid = YBCX_SAPLINK=>not_authorized.
*    endif.
*  ENDIF.


  DATA objecttable TYPE sotr_objects.
  DATA objecttype TYPE LINE OF sotr_objects.
* Retrieve object type of OTR
  CALL FUNCTION 'SOTR_OBJECT_GET_OBJECTS'
    EXPORTING
      object_vector    = sotrheader-objid_vec
    IMPORTING
      objects          = objecttable
    EXCEPTIONS
      object_not_found = 1
      OTHERS           = 2.

  READ TABLE objecttable INTO objecttype INDEX 1.

* create OTR
  sotrpaket-paket = devclass.
  CALL FUNCTION 'SOTR_CREATE_CONCEPT'
    EXPORTING
      paket                         = sotrpaket
      crea_lan                      = sotrheader-crea_lan
      alias_name                    = sotrheader-alias_name
*     CATEGORY                      =
      object                        = objecttype
      entries                       = sotrtexttable
*     FLAG_CORRECTION_ENTRY         =
*     IN_UPDATE_TASK                =
*     CONCEPT_DEFAULT               = sotrHeader-concept "ewH:33
    IMPORTING
      concept                       = concept         "ewH:33
    EXCEPTIONS
      package_missing               = 1
      crea_lan_missing              = 2
      object_missing                = 3
      paket_does_not_exist          = 4
      alias_already_exist           = 5
      object_type_not_found         = 6
      langu_missing                 = 7
      identical_context_not_allowed = 8
      text_too_long                 = 9
      error_in_update               = 10
      no_master_langu               = 11
      error_in_concept_id           = 12
      alias_not_allowed             = 13
      tadir_entry_creation_failed   = 14
      internal_error                = 15
      error_in_correction           = 16
      user_cancelled                = 17
      no_entry_found                = 18
      OTHERS                        = 19.
  IF sy-subrc <> 0.
*   MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*           WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.

ENDMETHOD.


METHOD createstringfromobject.
  ENDMETHOD.


METHOD createxmlstring.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA streamfactory TYPE REF TO if_ixml_stream_factory.
    DATA outputstream TYPE REF TO if_ixml_ostream.
    DATA renderer TYPE REF TO if_ixml_renderer.
    DATA tempstring TYPE string.
    DATA printxmldoc TYPE REF TO cl_xml_document.
    DATA rc TYPE sysubrc.

    streamfactory = ixml->create_stream_factory( ).
    outputstream = streamfactory->create_ostream_cstring( tempstring ).
    renderer = ixml->create_renderer(
      document = xmldoc ostream = outputstream ).
    rc = renderer->render( ).
    CREATE OBJECT printxmldoc.
    rc = printxmldoc->parse_string( tempstring ).
    xml = tempstring.
  ENDMETHOD.


METHOD getobjectinfofromixmldoc.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
  DATA rootnode TYPE REF TO if_ixml_node.
  DATA rootattr TYPE REF TO if_ixml_named_node_map.
  DATA attrnode TYPE REF TO if_ixml_node.
  DATA nodename TYPE string.

  rootnode ?= ixmldocument->get_root_element( ).
* Check whether got a valid ixmldocument
  IF rootnode IS NOT BOUND.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>incorrect_file_format.
  ENDIF.

* get object type
  objtypename = rootnode->get_name( ).
  TRANSLATE objtypename TO UPPER CASE.

* get object name
  rootattr = rootnode->get_attributes( ).
  attrnode = rootattr->get_item( 0 ).
  objname = attrnode->get_value( ).

ENDMETHOD.


METHOD getplugins.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
  DATA classlist TYPE seo_inheritances.
  DATA classline TYPE vseoextend.
  DATA classobject TYPE REF TO ybcl_saplink.
  DATA objectline TYPE t_objecttable.
  DATA tabletypeline TYPE ko105.
  DATA tabletypesin TYPE TABLE OF ko105.
  DATA tabletypesout TYPE tr_object_texts.
  DATA tabletypeoutline TYPE ko100.
  DATA clsname TYPE string.
  DATA objtype TYPE trobjtype.

  REFRESH objecttable.

  SELECT * FROM vseoextend INTO TABLE classlist
    WHERE refclsname LIKE 'YBCL_SAPLINK%'
    AND version = '1'.

  LOOP AT classlist INTO classline.
    clsname = classline-clsname.
    TRY.
        CREATE OBJECT classobject TYPE (clsname)
          EXPORTING
            name      = 'foo'.
        objtype = classobject->getobjecttype( ).
      CATCH cx_root.
        CONTINUE.
    ENDTRY.
    CLEAR tabletypeline.
    REFRESH tabletypesin.

    tabletypeline-object = objtype.
    APPEND tabletypeline TO tabletypesin.

    CALL FUNCTION 'TRINT_OBJECT_TABLE'
      TABLES
        tt_types_in  = tabletypesin
        tt_types_out = tabletypesout.

    LOOP AT tabletypesout INTO tabletypeoutline.
      objectline-classname = clsname.
      MOVE-CORRESPONDING tabletypeoutline TO objectline.
      APPEND objectline TO objecttable.
    ENDLOOP.
  ENDLOOP.

ENDMETHOD.


METHOD getstructurefromattributes.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA attributelist TYPE REF TO if_ixml_named_node_map.
    DATA nodeiterator TYPE REF TO if_ixml_node_iterator.
    DATA attributenode TYPE REF TO if_ixml_node.
    DATA value TYPE string.
    DATA name TYPE string.
    FIELD-SYMBOLS <value> TYPE any.

    CLEAR structure.
    attributelist = node->get_attributes( ).
    nodeiterator = attributelist->create_iterator( ).
    attributenode = nodeiterator->get_next( ).
    WHILE attributenode IS NOT INITIAL.
      name = attributenode->get_name( ).
      IF name = 'VERSION' AND preserveversion IS INITIAL. "ewh:issue 45
*    if name = 'VERSION'.
        value = '0'.
      ELSE.
        value = attributenode->get_value( ).
      ENDIF.
      ASSIGN COMPONENT name OF STRUCTURE structure TO <value>.
      IF sy-subrc = 0.
        <value> = value.
      ENDIF.
      attributenode = nodeiterator->get_next( ).
    ENDWHILE.















*    .-"-.
*  .'=^=^='.
* /=^=^=^=^=\
*:^=SAPLINK=^;
*|^ EASTER  ^|
*:^=^EGG^=^=^:
* \=^=^=^=^=/
*  `.=^=^=.'
*    `~~~`
* Don't like the way we did something?
* Help us fix it!  Tell us what you think!
* http://saplink.org
  ENDMETHOD.


METHOD get_version_info.

*--------------------------------------------------------------------*
* Please use the following 6 lines of code when versioning a
* SAPLINK-Plugin.  See documentation of Type GTS_VERSION_INFO
* what should be put here
*--------------------------------------------------------------------*
    rs_version_info-ybcl_saplink_plugin_major_ver = 0.  " Default for all child classes, that have not been updated to return a version info.
    rs_version_info-ybcl_saplink_plugin_minor_ver = 0.  " Default for all child classes, that have not been updated to return a version info.
    rs_version_info-ybcl_saplink_plugin_build_ver = 0.  " Default for all child classes, that have not been updated to return a version info.

    rs_version_info-ybcl_saplink_plugin_info1         = ''. " Sufficient to set this the first time a child class is being updated
    rs_version_info-ybcl_saplink_plugin_info2         = ''. " Sufficient to set this the first time a child class is being updated
    rs_version_info-ybcl_saplink_plugin_info3         = ''. " Sufficient to set this the first time a child class is being updated
    rs_version_info-ybcl_saplink_plugin_info4         = ''. " Sufficient to set this the first time a child class is being updated
    rs_version_info-ybcl_saplink_plugin_info5         = ''. " Sufficient to set this the first time a child class is being updated

* Hint - see redefinition of this class in YBCL_SAPLINK_CLASS how information may be set
  ENDMETHOD.


METHOD get_version_info_static.

    DATA: lo_ybcl_saplink TYPE REF TO ybcl_saplink.

    TRY.
        CREATE OBJECT lo_ybcl_saplink TYPE (iv_classname)
           EXPORTING
             name = 'Not needed for versio info'.
        rs_version_info = lo_ybcl_saplink->get_version_info( ).
      CATCH cx_root.  " Don't pass version info for unknown or abstract classes
    ENDTRY.

  ENDMETHOD.


METHOD setattributesfromstructure.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA int TYPE i.
    int = int.
    DATA structdescr TYPE REF TO cl_abap_structdescr.
    DATA acomponent TYPE abap_compdescr.
    FIELD-SYMBOLS <fieldvalue> TYPE any.
    DATA rc TYPE sysubrc.
    DATA sname TYPE string.
    DATA svalue TYPE string.

    structdescr ?= cl_abap_structdescr=>describe_by_data( structure ).
    LOOP AT structdescr->components INTO acomponent.
      ASSIGN COMPONENT acomponent-name OF STRUCTURE
        structure TO <fieldvalue>.
      IF sy-subrc = 0.
        sname = acomponent-name.
*      sValue = <fieldValue>.
*     for certain attributes, set to a standard for exporting
        CASE sname.
*        when 'VERSION'. "version should always export as inactive
*          sValue = '0'. "commented by ewH: issue 45
          WHEN 'DEVCLASS'. "development class should always be $TMP
            svalue = '$TMP'.
            " Developer, Date and Time Metadata has to be removed to
            " not clutter diffs
            "
            " Meta Attributes for DDIC Types
          WHEN 'AS4USER'.
            CLEAR svalue.
          WHEN 'AS4DATE'.
            CLEAR svalue.
          WHEN 'AS4TIME'.
            CLEAR svalue.
            " Meta Attributes for PROG
          WHEN 'CNAM'.
            CLEAR svalue.
          WHEN 'CDAT'.
            CLEAR svalue.
          WHEN 'UNAM'.
            CLEAR svalue.
          WHEN 'UDAT'.
            CLEAR svalue.
          WHEN 'VERN'.
            CLEAR svalue.
          WHEN 'SDATE'.
            CLEAR svalue.
          WHEN 'STIME'.
            CLEAR svalue.
          WHEN 'IDATE'.
            CLEAR svalue.
          WHEN 'ITIME'.
            CLEAR svalue.
            " Meta Attributes for CLAS
          WHEN 'AUTHOR'.
            CLEAR svalue.
          WHEN 'CREATEDON'.
            CLEAR svalue.
          WHEN 'CHANGEDBY'.
            CLEAR svalue.
          WHEN 'CHANGEDON'.
            CLEAR svalue.
          WHEN 'CHANGETIME'.
            CLEAR svalue.
          WHEN 'CHGDANYON'.
            CLEAR svalue.
          WHEN 'R3RELEASE'.
            CLEAR svalue.
          WHEN 'UUID'.
            CLEAR svalue.
            " SOTR
          WHEN 'CREA_NAME'.
            CLEAR svalue.
          WHEN 'CHAN_NAME'.
            CLEAR svalue.
          WHEN 'CREA_TSTUT'.
            CLEAR svalue.
          WHEN 'CHAN_TSTUT'.
            CLEAR svalue.
            " MSAG
          WHEN 'LASTUSER'.
            CLEAR svalue.
          WHEN 'LDATE'.
            CLEAR svalue.
          WHEN 'LTIME'.
            CLEAR svalue.
          WHEN 'DGEN'.
            CLEAR svalue.
          WHEN 'TGEN'.
            CLEAR svalue.
          WHEN 'GENDATE'.
            CLEAR svalue.
          WHEN 'GENTIME'.
            CLEAR svalue.
            " BSP
          WHEN 'IMPLCLASS'.
            CLEAR svalue.
          WHEN OTHERS.
            svalue = <fieldvalue>.
        ENDCASE.
        IF svalue IS NOT INITIAL.
          rc = node->set_attribute( name = sname value = svalue ).
        ENDIF.
      ELSE.
* WHAT?>!??
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD uploadxml.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA istream TYPE REF TO if_ixml_istream.
    DATA ixmlparser TYPE REF TO if_ixml_parser.

    istream = streamfactory->create_istream_string( xmldata ).
    ixmlparser = ixml->create_parser(  stream_factory = streamfactory
                                       istream        = istream
                                       document       = xmldoc ).
    ixmlparser->parse( ).

  ENDMETHOD.


METHOD valuehelp.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA l_object_type TYPE  euobj-id.
    DATA objname(40) TYPE c.

    l_object_type = i_objtype.


    CALL FUNCTION 'REPOSITORY_INFO_SYSTEM_F4'
      EXPORTING
        object_type           = l_object_type
        object_name           = objname
        suppress_selection    = 'X'
        use_alv_grid          = ''
        without_personal_list = ''
      IMPORTING
        object_name_selected  = objname
      EXCEPTIONS
        cancel                = 1.

    e_objname = objname.
  ENDMETHOD.
ENDCLASS.
