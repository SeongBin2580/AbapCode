class YBCL_SAPLINK_W3MI definition
  public
  inheriting from YBCL_SAPLINK
  final
  create public .

public section.

  methods CHECKEXISTS
    redefinition .
  methods CREATEIXMLDOCFROMOBJECT
    redefinition .
  methods CREATEOBJECTFROMIXMLDOC
    redefinition .
protected section.

  methods DELETEOBJECT
    redefinition .
  methods GETOBJECTTYPE
    redefinition .
private section.

  types:
    ty_wwwparams_tt TYPE STANDARD TABLE OF wwwparams WITH DEFAULT KEY .

  constants:
    BEGIN OF c_param_names,
      version  TYPE w3_name VALUE 'version',
      fileext  TYPE w3_name VALUE 'fileextension',
      filesize TYPE w3_name VALUE 'filesize',
      filename TYPE w3_name VALUE 'filename',
      mimetype TYPE w3_name VALUE 'mimetype',
    END OF c_param_names .
  data MS_KEY type WWWDATATAB .

  methods _INIT_KEY
    importing
      !IV_NAME type STRING .
  methods FIND_PARAM
    importing
      !IT_PARAMS type TY_WWWPARAMS_TT
      !IV_NAME type W3_NAME
    returning
      value(RV_VALUE) type STRING
    raising
      YBCX_SAPLINK .
  methods NORMALIZE_PARAMS
    importing
      !IV_SIZE type I
    changing
      !CT_PARAMS type TY_WWWPARAMS_TT
    raising
      YBCX_SAPLINK .
  methods STRIP_PARAMS
    changing
      !CT_PARAMS type TY_WWWPARAMS_TT
    raising
      YBCX_SAPLINK .
  methods ADD
    importing
      !IO_ELEM type ref to IF_IXML_ELEMENT
      !IV_NAME type CLIKE
      !IG_DATA type ANY
    raising
      YBCX_SAPLINK .
  methods READ
    importing
      !IO_DOC type ref to IF_IXML_DOCUMENT
      !IV_NAME type CLIKE
    changing
      !CG_DATA type ANY
    raising
      YBCX_SAPLINK .
  class-methods GET_FILENAME_FROM_SYSPATH
    importing
      !IV_PATH type CSEQUENCE
    returning
      value(RV_FILENAME) type STRING .
ENDCLASS.



CLASS YBCL_SAPLINK_W3MI IMPLEMENTATION.


METHOD add.
    DATA: li_node TYPE REF TO if_ixml_node,
          li_doc  TYPE REF TO if_ixml_document,
          lt_stab TYPE abap_trans_srcbind_tab.

    FIELD-SYMBOLS: <ls_stab> LIKE LINE OF lt_stab.
    ASSERT NOT iv_name IS INITIAL.

    IF ig_data IS INITIAL.
      RETURN.
    ENDIF.

    APPEND INITIAL LINE TO lt_stab ASSIGNING <ls_stab>.
    <ls_stab>-name = iv_name.
    GET REFERENCE OF ig_data INTO <ls_stab>-value.

    DATA lo_xml TYPE REF TO if_ixml.
    lo_xml = cl_ixml=>create( ).
    li_doc = lo_xml->create_document( ).

    CALL TRANSFORMATION id
      OPTIONS initial_components = 'suppress'
      SOURCE (lt_stab)
      RESULT XML li_doc.

    DATA lo_node TYPE REF TO if_ixml_node.
    lo_node = li_doc->get_root( ).
    DO 1 TIMES.
      lo_node = lo_node->get_first_child( ).
    ENDDO.
    io_elem->append_child( lo_node ).

*  li_node = io_doc->get_root( )->get_first_child( ).
*  IF li_node IS BOUND.
*    io_doc->get_root( )->get_first_child( )->get_first_child( )->append_child(
*      li_doc->get_root( )->get_first_child( )->get_first_child( )->get_first_child( ) ).
*  ELSE.
*    io_doc->get_root( )->append_child( li_doc->get_root( )->get_first_child( ) ).
*  ENDIF.
  ENDMETHOD.


METHOD checkexists.
    _init_key( objname ).

    SELECT SINGLE objid INTO ms_key-objid
      FROM wwwdata
      WHERE relid = ms_key-relid
      AND   objid = ms_key-objid
      AND   srtf2 = 0.

    IF sy-subrc IS NOT INITIAL.
      RETURN.
    ENDIF.

    exists = abap_true.
  ENDMETHOD.


METHOD createixmldocfromobject.
    DATA lt_w3mime    TYPE STANDARD TABLE OF w3mime.
    DATA lt_w3html    TYPE STANDARD TABLE OF w3html.
    DATA lt_w3params  TYPE ty_wwwparams_tt.
    DATA lv_xstring   TYPE xstring.
    DATA lv_size      TYPE int4.

    _init_key( objname ).

    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ms_key
      FROM wwwdata
      WHERE relid = ms_key-relid
      AND   objid = ms_key-objid
      AND   srtf2 = 0.
    CHECK sy-subrc = 0.

    CALL FUNCTION 'WWWDATA_IMPORT'
      EXPORTING
        key               = ms_key
      TABLES
        mime              = lt_w3mime
        html              = lt_w3html
      EXCEPTIONS
        wrong_object_type = 1
        import_error      = 2.

    IF sy-subrc IS NOT INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>not_found.
    ENDIF.

    CALL FUNCTION 'WWWPARAMS_READ_ALL'
      EXPORTING
        type             = ms_key-relid
        objid            = ms_key-objid
      TABLES
        params           = lt_w3params
      EXCEPTIONS
        entry_not_exists = 1.

    IF sy-subrc IS NOT INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Cannot read W3xx data'.
    ENDIF.

    lv_size = find_param( it_params = lt_w3params iv_name = c_param_names-filesize ).
    " Clean params (remove version, filesize & clear filename from path)
    strip_params( CHANGING  ct_params = lt_w3params ).

    CASE ms_key-relid.
      WHEN 'MI'.
        CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
          EXPORTING
            input_length = lv_size
          IMPORTING
            buffer       = lv_xstring
          TABLES
            binary_tab   = lt_w3mime
          EXCEPTIONS
            failed       = 1.
      WHEN 'HT'.
        CALL FUNCTION 'SCMS_TEXT_TO_XSTRING'
          IMPORTING
            buffer   = lv_xstring
          TABLES
            text_tab = lt_w3html
          EXCEPTIONS
            failed   = 1.
      WHEN OTHERS.
        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>error_message
            msg    = 'Wrong W3xx type'.
    ENDCASE.

    IF sy-subrc IS NOT INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Cannot convert W3xx to xstring'.
    ENDIF.

    DATA: _objtype TYPE string, rootnode TYPE REF TO if_ixml_element. " if_ixml_document
    _objtype = getobjecttype( ).
    rootnode = xmldoc->create_element( _objtype ).

    add( io_elem = rootnode
         iv_name = 'NAME'
         ig_data = ms_key-objid ).

    add( io_elem = rootnode
         iv_name = 'TEXT'
         ig_data = ms_key-text ).

    add( io_elem = rootnode
         iv_name = 'PARAMS'
         ig_data = lt_w3params ).

    add( io_elem = rootnode
         iv_name = 'DATA'
         ig_data = lv_xstring ).

*  " Seriazation v2, separate data file. 'extra' added to prevent conflict with .xml
*  zif_abapgit_object~mo_files->add_raw( iv_data  = lv_xstring
*                                iv_extra = 'data'
*                                iv_ext   = get_ext( lt_w3params ) ).

    DATA l_name TYPE string.
    l_name = ms_key-objid.
    rootnode->set_attribute( name  = 'NAME'
                             value = l_name ).

    DATA lo_key TYPE REF TO if_ixml_element.
    lo_key = xmldoc->create_element( 'KEY' ).
    setattributesfromstructure( node = lo_key structure = ms_key ).
    rootnode->append_child( lo_key ).

    xmldoc->append_child( rootnode ).
    ixmldocument = xmldoc.
  ENDMETHOD.


METHOD createobjectfromixmldoc.

  DATA lo_key TYPE REF TO if_ixml_element.
  lo_key = ixmldocument->find_from_name( 'KEY' ).
  getstructurefromattributes( EXPORTING node      = lo_key
                              CHANGING  structure = ms_key ).

  DATA lv_base64str TYPE string.
  DATA lt_w3params  TYPE STANDARD TABLE OF wwwparams.
  DATA lv_xstring   TYPE xstring.
  DATA lt_w3mime    TYPE STANDARD TABLE OF w3mime.
  DATA lt_w3html    TYPE STANDARD TABLE OF w3html.
  DATA lv_size      TYPE int4.
  DATA lv_tadir_obj TYPE tadir-object.

  read( EXPORTING io_doc  = ixmldocument
                  iv_name = 'TEXT'
        CHANGING  cg_data = ms_key-text ).

  read( EXPORTING io_doc  = ixmldocument
                  iv_name = 'PARAMS'
        CHANGING  cg_data = lt_w3params ).

  read( EXPORTING io_doc  = ixmldocument
                  iv_name = 'DATA'
        CHANGING  cg_data = lv_base64str ).
  REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline IN lv_base64str WITH ``.

  " CL_HTTP_UTILITY=>DECODE_X_BASE64( )
  DATA lv_error TYPE i.
  SYSTEM-CALL ict                                    "#EC CI_SYSTEMCALL
  DID
    87
  PARAMETERS
    lv_base64str
    lv_xstring
    lv_error.                      " < return code

  CASE ms_key-relid.
    WHEN 'MI'.
      CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
        EXPORTING
          buffer        = lv_xstring
        IMPORTING
          output_length = lv_size
        TABLES
          binary_tab    = lt_w3mime.
    WHEN 'HT'.
      CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
        EXPORTING
          buffer        = lv_xstring
        IMPORTING
          output_length = lv_size
        TABLES
          binary_tab    = lt_w3mime.

      CALL FUNCTION 'SCMS_BINARY_TO_TEXT'
        EXPORTING
          input_length  = lv_size
        IMPORTING
          output_length = lv_size
        TABLES
          binary_tab    = lt_w3mime
          text_tab      = lt_w3html
        EXCEPTIONS
          failed        = 1.
      IF sy-subrc IS NOT INITIAL.
        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>error_message
            msg    = 'Cannot update W3xx params'.
      ENDIF.

      CLEAR lt_w3mime.
    WHEN OTHERS.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Wrong W3xx type'.
  ENDCASE.

  " Update size of file based on actual data file size, prove param object name
  normalize_params( EXPORTING iv_size   = lv_size
                    CHANGING  ct_params = lt_w3params ).

  CALL FUNCTION 'WWWPARAMS_UPDATE'
    TABLES
      params       = lt_w3params
    EXCEPTIONS
      update_error = 1.

  IF sy-subrc IS NOT INITIAL.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>error_message
        msg    = 'Cannot update W3xx params'.
  ENDIF.

  ms_key-tdate    = sy-datum.
  ms_key-ttime    = sy-uzeit.
  ms_key-chname   = sy-uname.
  ms_key-devclass = devclass. "iv_package.

  CALL FUNCTION 'WWWDATA_EXPORT'
    EXPORTING
      key               = ms_key
    TABLES
      mime              = lt_w3mime
      html              = lt_w3html
    EXCEPTIONS
      wrong_object_type = 1
      export_error      = 2.

  IF sy-subrc IS NOT INITIAL.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>error_message
        msg    = 'Cannot upload W3xx data'.
  ENDIF.

  CONCATENATE 'W3' ms_key-relid INTO lv_tadir_obj.

  CALL FUNCTION 'TR_TADIR_INTERFACE'
    EXPORTING
      wi_tadir_pgmid                 = 'R3TR'
      wi_tadir_object                = lv_tadir_obj
      wi_tadir_devclass              = devclass " iv_package
      wi_tadir_obj_name              = ms_key-objid
      wi_test_modus                  = space
    EXCEPTIONS
      tadir_entry_not_existing       = 1
      tadir_entry_ill_type           = 2
      no_systemname                  = 3
      no_systemtype                  = 4
      original_system_conflict       = 5
      object_reserved_for_devclass   = 6
      object_exists_global           = 7
      object_exists_local            = 8
      object_is_distributed          = 9
      obj_specification_not_unique   = 10
      no_authorization_to_delete     = 11
      devclass_not_existing          = 12
      simultanious_set_remove_repair = 13
      order_missing                  = 14
      no_modification_of_head_syst   = 15
      pgmid_object_not_allowed       = 16
      masterlanguage_not_specified   = 17
      devclass_not_specified         = 18
      specify_owner_unique           = 19
      loc_priv_objs_no_repair        = 20
      gtadir_not_reached             = 21
      object_locked_for_order        = 22
      change_of_class_not_allowed    = 23
      no_change_from_sap_to_tmp      = 24
      OTHERS                         = 99.

  IF sy-subrc IS NOT INITIAL.
    RAISE EXCEPTION TYPE ybcx_saplink
      EXPORTING
        textid = ybcx_saplink=>error_message
        msg    = 'Cannot update TADIR for W3xx'.
  ENDIF.

ENDMETHOD.


METHOD deleteobject.
    _init_key( objname ).
    CALL FUNCTION 'WWWDATA_DELETE'
      EXPORTING
        key               = ms_key
      EXCEPTIONS
        wrong_object_type = 1
        delete_error      = 2.

    IF sy-subrc IS NOT INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Cannot delete W3xx data'.
    ENDIF.

    CALL FUNCTION 'WWWPARAMS_DELETE_ALL'
      EXPORTING
        key          = ms_key
      EXCEPTIONS
        delete_error = 1.

    IF sy-subrc IS NOT INITIAL.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = 'Cannot delete W3xx params'.
    ENDIF.
  ENDMETHOD.


METHOD find_param.
    FIELD-SYMBOLS <ls_param> LIKE LINE OF it_params.
    READ TABLE it_params ASSIGNING <ls_param> WITH KEY name = iv_name.
    IF sy-subrc > 0.
      DATA lv_msg TYPE string.
      CONCATENATE `W3xx: Cannot find ` iv_name ` for ` ms_key-objid INTO lv_msg.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>error_message
          msg    = lv_msg.
    ENDIF.

    rv_value = <ls_param>-value.
  ENDMETHOD.


METHOD getobjecttype.
    objecttype = 'W3MI'.
  ENDMETHOD.


METHOD get_filename_from_syspath.
    DATA: lv_split TYPE c LENGTH 1,
          lv_index TYPE i,
          lt_split TYPE TABLE OF string.

    " filename | c:\filename | /dir/filename | \\server\filename
    IF iv_path CA '/'.
      lv_split = '/'.
    ELSE.
      lv_split = '\'.
    ENDIF.

    SPLIT iv_path AT lv_split INTO TABLE lt_split.

    lv_index = lines( lt_split ).

    READ TABLE lt_split INDEX lv_index INTO rv_filename.
  ENDMETHOD.


METHOD normalize_params.
    FIELD-SYMBOLS <ls_param> LIKE LINE OF ct_params.

    " Ensure filesize param exists
    READ TABLE ct_params ASSIGNING <ls_param> WITH KEY name = c_param_names-filesize.
    IF sy-subrc <> 0.
      APPEND INITIAL LINE TO ct_params ASSIGNING <ls_param>.
      <ls_param>-name  = c_param_names-filesize.
    ENDIF.

    LOOP AT ct_params ASSIGNING <ls_param>.
      <ls_param>-relid = ms_key-relid. " Ensure param key = object key
      <ls_param>-objid = ms_key-objid.
      IF <ls_param>-name = c_param_names-filesize. " Patch filesize = real file size
        <ls_param>-value = iv_size.
        CONDENSE <ls_param>-value.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD read.
    DATA lo_elem    TYPE REF TO if_ixml_element.
    DATA lo_xml     TYPE REF TO if_ixml.
    DATA lo_encode  TYPE REF TO if_ixml_encoding.
    DATA lo_factory TYPE REF TO if_ixml_stream_factory.
    DATA lo_stream  TYPE REF TO if_ixml_ostream.
    DATA lt_rtab    TYPE abap_trans_resbind_tab.
    DATA ls_rtab    TYPE REF TO abap_trans_resbind.
    DATA lx_error   TYPE REF TO cx_transformation_error.
    DATA lv_xml     TYPE string.


    lo_elem  = io_doc->find_from_name( iv_name ).

    " XML doc UTF-8
    lo_xml = cl_ixml=>create( ).
    lo_encode = lo_xml->create_encoding( byte_order    = if_ixml_encoding=>co_platform_endian
                                         character_set = 'UTF-8' ).
    io_doc->set_encoding( lo_encode ).

    " Convert to string with tags
    lo_factory = lo_xml->create_stream_factory( ).
    lo_stream = lo_factory->create_ostream_cstring( string = lv_xml ).
    lo_elem->render( lo_stream ).

    CONCATENATE
    `<?xml version="1.0" encoding="UTF-8"?><asx:abap xmlns:asx="http://www.sap.com/abapxml" version="1.0"><asx:values>`
    lv_xml
    `</asx:values></asx:abap>` INTO lv_xml.

    CLEAR cg_data. "Initialize result to avoid problems with empty values

    APPEND INITIAL LINE TO lt_rtab REFERENCE INTO ls_rtab.
    ls_rtab->name = iv_name.
    GET REFERENCE OF cg_data INTO ls_rtab->value.

    TRY.
        CALL TRANSFORMATION id
          SOURCE XML lv_xml
          RESULT (lt_rtab).
      CATCH cx_transformation_error INTO lx_error.
        DATA lv_msg TYPE string.
        lv_msg = lx_error->if_message~get_text( ).

        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>error_message
            msg    = lv_msg.
    ENDTRY.
  ENDMETHOD.


METHOD strip_params.
    FIELD-SYMBOLS <ls_param> LIKE LINE OF ct_params.

    " Remove path from filename
    find_param( it_params = ct_params iv_name = c_param_names-filename ). " Check exists
    READ TABLE ct_params ASSIGNING <ls_param> WITH KEY name = c_param_names-filename.
    <ls_param>-value = get_filename_from_syspath( <ls_param>-value ).

    " Clear version & filesize
    DELETE ct_params WHERE name = c_param_names-version.
    DELETE ct_params WHERE name = c_param_names-filesize.
  ENDMETHOD.


METHOD _init_key.
    SELECT SINGLE * INTO CORRESPONDING FIELDS OF ms_key
    FROM wwwdata
    WHERE objid = iv_name
      AND srtf2 = 0.
  ENDMETHOD.
ENDCLASS.
