class YBCL_SAPLINK_NUGGET definition
  public
  final
  create public .

public section.

  methods ADDOBJECTTONUGGET
    importing
      !OBJNAME type STRING optional
      !OBJTYPE type STRING optional
      !XMLDOCUMENT type ref to IF_IXML_DOCUMENT optional
    raising
      YBCX_SAPLINK .
  methods CREATEIXMLDOCFROMNUGGET
    returning
      value(IXMLDOCUMENT) type ref to IF_IXML_DOCUMENT .
  methods GETNEXTOBJECT
    returning
      value(IXMLDOCUMENT) type ref to IF_IXML_DOCUMENT .
  methods RESET .
  class-methods CREATEEMPTYXML
    importing
      !NUGGETNAME type STRING
    returning
      value(IXMLDOCUMENT) type ref to IF_IXML_DOCUMENT .
  class-methods GETNUGGETINFO
    importing
      !IXMLDOCUMENT type ref to IF_IXML_DOCUMENT
    returning
      value(NAME) type STRING
    raising
      YBCX_SAPLINK .
  methods CONSTRUCTOR
    importing
      !NAME type STRING optional
      !IXMLDOCUMENT type ref to IF_IXML_DOCUMENT optional
    raising
      YBCX_SAPLINK .
  methods CHECKOBJECTEXISTS
    importing
      !OBJNAME type STRING
      !OBJTYPE type STRING
    returning
      value(RETVAL) type SY-SUBRC .
  methods DELETEOBJECTFROMNUGGET
    importing
      !OBJNAME type STRING
      !OBJTYPE type STRING
    returning
      value(RETVAL) type SY-SUBRC .
protected section.

  data IXML type ref to IF_IXML .
  data XMLDOC type ref to IF_IXML_DOCUMENT .
private section.

  data ITERATOR type ref to IF_IXML_NODE_ITERATOR .
  data NUGGNAME type STRING .
  data STREAMFACTORY type ref to IF_IXML_STREAM_FACTORY .
  data XMLDATA type STRING .
  data WT_OBJECTS type TT_OBJECTS .
  data W_INDEX type SY-TABIX .
ENDCLASS.



CLASS YBCL_SAPLINK_NUGGET IMPLEMENTATION.


METHOD addobjecttonugget.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    TYPES: BEGIN OF t_objecttable,
             classname TYPE string,
             object    TYPE ko100-object,
             text      TYPE ko100-text,
           END OF t_objecttable.
    DATA rootnode TYPE REF TO if_ixml_element.
    DATA saplink TYPE REF TO ybcl_saplink.
    DATA objecttable TYPE TABLE OF t_objecttable.
    DATA objectline TYPE t_objecttable.
    DATA ixmldocument TYPE REF TO if_ixml_document.
    DATA rval TYPE i.
    DATA objelement TYPE REF TO if_ixml_element.

    rootnode = xmldoc->get_root_element( ).

* create new object
    IF xmldocument IS INITIAL.
      CALL METHOD ybcl_saplink=>getplugins( CHANGING objecttable = objecttable ).

      READ TABLE objecttable INTO objectline WITH KEY object = objtype.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>no_plugin.
      ENDIF.
      CREATE OBJECT saplink TYPE (objectline-classname)
             EXPORTING name = objname.
      ixmldocument = saplink->createixmldocfromobject( ).
    ELSE.
      ixmldocument = xmldocument.
    ENDIF.
    objelement = ixmldocument->get_root_element( ).
* Search and delete same object(s) in nugget
    DATA: docfilter   TYPE REF TO if_ixml_node_filter,
          dociterator TYPE REF TO if_ixml_node_iterator,
          currentnode TYPE REF TO if_ixml_node,
          rootattr    TYPE REF TO if_ixml_named_node_map,
          attrnode    TYPE REF TO if_ixml_node,
          nodename    TYPE string.

* create a filter to traverse the nugget by object type like CLAS or PROG
    docfilter = xmldoc->create_filter_name_ns( objtype ).
* apply the filter to the iterator
    dociterator = xmldoc->create_iterator_filtered( docfilter ).
* get the first object of that type in the nugget
    currentnode = dociterator->get_next( ).

*  if this node is not blank proceed to check the attributes
    WHILE currentnode IS NOT INITIAL.
*   get object name
      rootattr = currentnode->get_attributes( ).
      attrnode = rootattr->get_item( 0 ).
      nodename = attrnode->get_value( ).
*   if the name of the node is the same as the passed parameter, delete the node
      IF nodename = objname.
        currentnode->remove_node( ).
        rval = sy-subrc.
*      exit. " let's remove duplicate entries as well (otherwise we could replace_child as well)
      ENDIF.
      currentnode = dociterator->get_next( ).
    ENDWHILE.

* append new object to nugget
* get rood node of nugget
    rootnode = xmldoc->get_root_element( ).
* append new object to nugget
    rval = rootnode->append_child( objelement ).

  ENDMETHOD.


METHOD checkobjectexists.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA: docfilter   TYPE REF TO if_ixml_node_filter,
          dociterator TYPE REF TO if_ixml_node_iterator,
          currentnode TYPE REF TO if_ixml_node,
          rootattr    TYPE REF TO if_ixml_named_node_map,
          attrnode    TYPE REF TO if_ixml_node,

          nodename    TYPE string,
          existsflag  TYPE flag.

* create a filter to traverse the nugget by object type like CLAS or PROG
    docfilter = xmldoc->create_filter_name_ns( objtype ).
* apply the filter to the iterator
    dociterator = xmldoc->create_iterator_filtered( docfilter ).
* get the first object of that type in the nugget
    currentnode = dociterator->get_next( ).

*  if this node is not blank proceed to check the attributes
    WHILE currentnode IS NOT INITIAL.
* get object name
      rootattr = currentnode->get_attributes( ).
      attrnode = rootattr->get_item( 0 ).
      nodename = attrnode->get_value( ).
*   if the name of the node is the same as the passed parameter, set the flag
      IF nodename = objname.
        existsflag = 'X'.
      ENDIF.
      currentnode = dociterator->get_next( ).
    ENDWHILE.
    IF existsflag = 'X'.
      retval = 0.
    ELSE.
      retval = 4.
    ENDIF.
  ENDMETHOD.


METHOD constructor.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA rootnode TYPE REF TO if_ixml_element.
    DATA rval TYPE i.
*data xmlDoc type ref to if_ixml_document.

    IF name IS NOT INITIAL.
      nuggname = name.
      ixml = cl_ixml=>create( ).
      xmldoc = ixml->create_document( ).
*  may need this from create empty nugget
*dan this was commented out, any ideas why??  Uncommented for Zake.
      rootnode = xmldoc->create_element( 'nugget' ).
      rval = rootnode->set_attribute( name = 'name' value = nuggname ).
      rval = xmldoc->append_child( rootnode ).

      streamfactory = ixml->create_stream_factory( ).
    ELSEIF ixmldocument IS NOT INITIAL.
      TRY.
          ixml = cl_ixml=>create( ).
          xmldoc = ixmldocument.
          rootnode = xmldoc->get_root_element( ).
          nuggname = rootnode->get_attribute( 'name' ).
          streamfactory = ixml->create_stream_factory( ).
        CATCH cx_root. " May happen if someone passed a file that is no nugget
          RAISE EXCEPTION TYPE ybcx_saplink
            EXPORTING
              textid = ybcx_saplink=>system_error.
      ENDTRY.
    ELSE.
      RAISE EXCEPTION TYPE ybcx_saplink
        EXPORTING
          textid = ybcx_saplink=>system_error.
    ENDIF.
  ENDMETHOD.


METHOD createemptyxml.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA ixml TYPE REF TO if_ixml.
    DATA rootnode TYPE REF TO if_ixml_element.
    DATA rval TYPE i.
    DATA xmldoc TYPE REF TO if_ixml_document.

    ixml = cl_ixml=>create( ).
    xmldoc = ixml->create_document( ).
    rootnode = xmldoc->create_element( 'nugget' ).
    rval = rootnode->set_attribute( name = 'name' value = nuggetname ).
    rval = xmldoc->append_child( rootnode ).
    ixmldocument = xmldoc.

  ENDMETHOD.


METHOD createixmldocfromnugget.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    ixmldocument = xmldoc.
  ENDMETHOD.


METHOD deleteobjectfromnugget.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA: docfilter   TYPE REF TO if_ixml_node_filter,
          dociterator TYPE REF TO if_ixml_node_iterator,
          currentnode TYPE REF TO if_ixml_node,
          rootattr    TYPE REF TO if_ixml_named_node_map,
          attrnode    TYPE REF TO if_ixml_node,

          nodename    TYPE string.

* create a filter to traverse the nugget by object type like CLAS or PROG
    docfilter = xmldoc->create_filter_name_ns( objtype ).
* apply the filter to the iterator
    dociterator = xmldoc->create_iterator_filtered( docfilter ).
* get the first object of that type in the nugget
    currentnode = dociterator->get_next( ).

*  if this node is not blank proceed to check the attributes
    WHILE currentnode IS NOT INITIAL.
* get object name
      rootattr = currentnode->get_attributes( ).
      attrnode = rootattr->get_item( 0 ).
      nodename = attrnode->get_value( ).
*   if the name of the node is the same as the passed parameter, delete the node
      IF nodename = objname.
        currentnode->remove_node( ).
        retval = sy-subrc.
        RETURN.
      ENDIF.
      currentnode = dociterator->get_next( ).
    ENDWHILE.
  ENDMETHOD.


METHOD getnextobject.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA anode TYPE REF TO if_ixml_node.
    DATA stemp TYPE string.
    DATA rootnode TYPE REF TO if_ixml_node.
    DATA namefilter TYPE REF TO if_ixml_node_filter.
    DATA parentfilter TYPE REF TO if_ixml_node_filter.
    DATA currentnode TYPE REF TO if_ixml_node.
    DATA newnode TYPE REF TO if_ixml_node.
    DATA: rval       TYPE i,
          lo_object  TYPE REF TO  ybcl_saplink,
          l_tabix    TYPE i,
          ls_objects TYPE ts_objects.

    IF wt_objects IS INITIAL.
      IF iterator IS  INITIAL.
        namefilter = xmldoc->create_filter_name_ns( name = 'nugget' ).
        parentfilter = xmldoc->create_filter_parent( namefilter ).
        iterator = xmldoc->create_iterator_filtered( parentfilter ).
      ENDIF.
      currentnode ?= iterator->get_next( ).

      WHILE currentnode IS NOT INITIAL.
        ADD 1 TO l_tabix.
        ixmldocument = ixml->create_document( ).
        newnode = currentnode->clone( ).
        rval = ixmldocument->append_child( newnode ).
        CLEAR ls_objects.

        ybcl_saplink=>checkobject(
          EXPORTING
            i_ixmldocument = ixmldocument
          IMPORTING
*                   e_objtype      =
*                   e_objname      =
*                   e_pluginexists =
*                   e_objectexists =
             e_targetobject = lo_object
               ).
        IF lo_object IS BOUND.
          ls_objects-nugget_level = lo_object->nugget_level.
        ELSE.
* We will not handle this here
          ls_objects-nugget_level = 0.
        ENDIF.
        ls_objects-sort = l_tabix.
        ls_objects-xmldocument = ixmldocument.
        INSERT ls_objects INTO TABLE wt_objects.
        currentnode ?= iterator->get_next( ).
      ENDWHILE.
    ENDIF.
    ADD 1 TO w_index.
    READ TABLE wt_objects INTO ls_objects INDEX w_index.

    IF sy-subrc = 0.
      ixmldocument = ls_objects-xmldocument.
    ELSE.
      CLEAR ixmldocument.
    ENDIF.

  ENDMETHOD.


METHOD getnuggetinfo.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    DATA rootnode TYPE REF TO if_ixml_element.
    TRY.
        rootnode = ixmldocument->get_root_element( ).
        name = rootnode->get_attribute( 'name' ).
      CATCH cx_root. " May happen if someone passed a file that is no nugget
        RAISE EXCEPTION TYPE ybcx_saplink
          EXPORTING
            textid = ybcx_saplink=>system_error.
    ENDTRY.
  ENDMETHOD.


METHOD reset.
*/---------------------------------------------------------------------\
*| This file is part of SAPlink.                                       |
*|                                                                     |
*| Copyright 2014 SAPlink project members                              |
*|                                                                     |
*| Licensed under the Apache License, Version 2.0 (the "License");     |
*| you may not use this file except in compliance with the License.    |
*| You may obtain a copy of the License at                             |
*|                                                                     |
*|     http://www.apache.org/licenses/LICENSE-2.0                      |
*|                                                                     |
*| Unless required by applicable law or agreed to in writing, software |
*| distributed under the License is distributed on an "AS IS" BASIS,   |
*| WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or     |
*| implied.                                                            |
*| See the License for the specific language governing permissions and |
*| limitations under the License.                                      |
*\---------------------------------------------------------------------/
    IF iterator IS NOT INITIAL.
      REFRESH: wt_objects.
      CLEAR w_index.
      iterator->reset( ).
    ENDIF.
  ENDMETHOD.
ENDCLASS.
